<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-body">
        <form class="form-search">
            <div class="col-md-12 border p-10 border-radius-5">
                <div class="col-md-10 html_date_range">
                    <div class="col-md-5 form-group">
                        <label>Status</label>
                        <select name="member" class="form-control">
                            <option value="">SEMUA MEMBER</option>
                            <?php
                            foreach ($data_member as $item_member) {
                                echo '<option value="' . $this->encrypt->encode($item_member->id) . '">' . $item_member->code . ' - ' . $item_member->name . '</option>';
                            }
                            ?>
                        </select>
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Tanggal Awal</label>
                        <input type="text" class="form-control bg-white datepicker" name="date_from" readonly>
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-1 text-center">
                        <label for=""></label><br>
                        <label for="">S/D</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Tanggal Akhir</label>
                        <input type="text" class="form-control bg-white datepicker" name="date_to" readonly>
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="col-md-2">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-success btn_search">Cari Data</button>
                </div>
            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>

<div class="card">
    <div class="card-body">
        <div class="html_respon">
            <div class="bg-empty-data"></div>
            <h3 class="text-center text-muted">Isilah form pencarian terlebih dahulu</h3>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>