<?php
$encrypt_post_data = $this->encrypt->encode(json_encode($data_deposito));
?>
<div class="col-md-12">
    <table class="table table-hover table_history" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>kode</th>
                <th>Tanggal</th>
                <th>Member</th>
                <th>saldo awal</th>
                <th>saldo Top Up</th>
                <th>Saldo Akhir</th>
                <th>Administrasi</th>
                <th>Bayar</th>
                <th>Kembali</th>
                <th>Catatan</th>
                <th>Petugas</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_deposito as $item_deposito) {
                $counter++;
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $item_deposito->code . '</td>
                            <td>' . $item_deposito->date . '</td>
                            <td>' . $item_deposito->member_code . '</td>
                            <td>Rp.' . number_format($item_deposito->saldo_deposito, 0, '.', '.') . '</td>
                            <td>Rp.' . number_format($item_deposito->price_top_up, 0, '.', '.') . '</td>
                            <td>Rp.' . number_format($item_deposito->total_deposito, 0, '.', '.') . '</td>
                            <td>Rp.' . number_format($item_deposito->administration, 0, '.', '.') . '</td>
                            <td>Rp.' . number_format($item_deposito->payment, 0, '.', '.') . '</td>
                            <td>Rp.' . number_format($item_deposito->rest, 0, '.', '.') . '</td>
                            <td>' . $item_deposito->note . '</td>
                            <td>' . $item_deposito->user_name . '</td>
                        </tr>
                ';
            }
            ?>
        </tbody>
    </table>
</div>
<div class="col-md-12 text-right">
    <form method="POST" action="<?= base_url('deposito_report/get_excel'); ?>">
        <small>(*klik untuk cetak laporan)</small>
        <input type="hidden" value="<?= $encrypt_post_data; ?>" name="data_result">
        <button type="submit" class="btn btn-success btn-lg"><i class="fa fa-file-excel-o"></i> Cetak Excel</button>
    </form>
</div>