<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Deposito_report extends CI_Controller
{
    var $location = 'data_deposito_report/';
    var $tb_name = 'tb_deposito';
    var $module_name = 'deposito_report';
    var $js_page = 'deposito_report';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function index()
    {
        $data_member = $this->db->order_by('id')->get('tb_member')->result();
        $data['data_member'] = $data_member;
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Laporan TOP UP DEPOSITO";
        $data['view_file'] = $this->location . 'form_search';
        $this->load->view('template/media_admin', $data);
    }

    public function validate_get_data()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date_from') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_from';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function get_data()
    {
        $this->validate_get_data();
        $date_from      = $this->input->post('date_from');
        $date_to        = $this->input->post('date_to');
        $id_member      = $this->encrypt->decode($this->input->post('member'));
        $explode_date_from = explode('-', $date_from);
        $date_from_sql = $explode_date_from[2] . '-' . $explode_date_from[1] . '-' . $explode_date_from[0];
        $explode_date_to = explode('-', $date_to);
        $date_to_sql = $explode_date_to[2] . '-' . $explode_date_to[1] . '-' . $explode_date_to[0];

        $this->db->select('
            tb_deposito.*,
            tb_member.code AS code_member,
            tb_member.code AS member_code,
            tb_member.name AS member_name,       
            tb_user.name AS user_name
        ');
        $this->db->from('tb_deposito');
        $this->db->join('tb_member', 'tb_deposito.id_member = tb_member.id', 'left');
        $this->db->join('tb_user', 'tb_deposito.created_by = tb_user.id', 'left');
        $this->db->where(['tb_deposito.status' => 1, 'tb_deposito.date >=' => $date_from_sql, 'tb_deposito.date <=' => $date_to_sql]);
        if (!empty($id_member)) {
            $this->db->where(['tb_deposito.id_member' => $id_member]);
        }
        $get_data_deposito = $this->db->get()->result();
        $data['data_deposito'] = $get_data_deposito;
        $html_respon = $this->load->view($this->location . 'view_search_result', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function history_payment()
    {
        $data['data_member'] = $this->db->order_by('name')->get('tb_member')->result();
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "LAPORAN Data Pembayaran PIUTANG";
        $data['view_file'] = $this->location . 'form_history_payment';
        $this->load->view('template/media_admin', $data);
    }

    // public function get_history_payment()
    // {
    //     $this->validate_get_history_credit();
    //     $type_search    = $this->input->post('type_search');
    //     $type           = $this->input->post('type');
    //     $code           = $this->input->post('code');
    //     $member           = $this->encrypt->decode($this->input->post('member'));
    //     $status = $this->encrypt->decode($this->input->post('status'));

    //     if ($type_search == 1) {
    //         $date_from      = $this->input->post('date_from');
    //         $date_to        = $this->input->post('date_to');
    //         $explode_date_from = explode('-', $date_from);
    //         $date_from_sql = $explode_date_from[2] . '-' . $explode_date_from[1] . '-' . $explode_date_from[0];
    //         $explode_date_to = explode('-', $date_to);
    //         $date_to_sql = $explode_date_to[2] . '-' . $explode_date_to[1] . '-' . $explode_date_to[0];
    //         $array_where = [
    //             'tb_credit_has_payment.date >=' => $date_from_sql,
    //             'tb_credit_has_payment.date <=' => $date_to_sql
    //         ];
    //         if (!empty($member)) {
    //             $array_where['tb_credit.id_member'] = $member;
    //         }
    //     } else {
    //         $array_where = [
    //             'tb_credit.code' => $code
    //         ];
    //     }
    //     //get data payment
    //     $this->db->select(
    //         '
    //                 tb_credit_has_payment.*,
    //                 tb_credit.price AS price_credit,
    //                 tb_credit.date AS date_credit,
    //                 tb_credit.code AS credit_code,
    //                 tb_user.name AS user_name,
    //                 tb_member.name AS member_name
    //             '
    //     );
    //     $this->db->from('tb_credit_has_payment');
    //     $this->db->join('tb_credit', 'tb_credit_has_payment.id_credit = tb_credit.id', 'left');
    //     $this->db->join('tb_user', 'tb_credit_has_payment.created_by = tb_user.id', 'left');
    //     $this->db->join('tb_member', 'tb_credit.id_member = tb_member.id', 'left');
    //     $this->db->where($array_where);
    //     $get_data = $this->db->get()->result();
    //     $data['data_credit'] = $get_data;
    //     $html_respon = $this->load->view($this->location . 'view_search_payment_list', $data, TRUE);


    //     $array_respon = [
    //         'status' => TRUE,
    //         'html_respon' => $html_respon
    //     ];
    //     echo json_encode($array_respon);
    // }

    private function count_date($start_date, $end_date)
    {
        $start_date = new DateTime($start_date);
        $end_date = new DateTime($end_date);
        $interval = $start_date->diff($end_date);
        return $interval;
    }

    public function get_excel()
    {
        // print_r($_POST);
        $data_result = $this->encrypt->decode($this->input->post('data_result'));
        $array_result = json_decode($data_result);

        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('5');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('20');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');
        $sheet->getColumnDimension('L')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:M2")->getFont()->setBold(true);

        //marge and center
        $sheet->mergeCells('A1:L2');
        $sheet->getStyle('A1:L2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:L2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN TOP UP DEPOSITO');
        $sheet->getStyle('A3:L3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        //sheet table resume 
        $from = "A3"; // or any value
        $to = "L3"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'KODE');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'MEMBER');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'SALDO AWAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'SALDO TOP UP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G3', 'SALDO AKHIR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H3', 'ADMINISTRASI');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I3', 'BAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J3', 'KEMBALI');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K3', 'CATATAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L3', 'PETUGAS');

        $no = 0;
        $sheet_number_resume = 3;
        $sheet_number_detail = 0;
        foreach ($array_result as $data_table) {
            $sheet_number_resume++;
            $no++;
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->code);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_table->date);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->member_code);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->saldo_deposito);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->price_top_up);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_table->total_deposito);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->administration);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume, $data_table->payment);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $data_table->rest);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $sheet_number_resume, $data_table->note);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L' . $sheet_number_resume, $data_table->user_name);
        }

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN' . date('d-m-Y'));

        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN TOP UP DEPOSITO ' . date('d-m-Y') . '.xlsx"');

        //Download
        $objWriter->save("php://output");
    }
}
