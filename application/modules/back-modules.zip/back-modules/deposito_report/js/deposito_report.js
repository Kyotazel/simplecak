var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/deposito_report';
var save_method;
var table_paid;
var table_has_paid;
var id_use;
$(document).ready(function(){
    $('.table_payment').DataTable();
})

function reload_table(){
    table_paid.ajax.reload(null, false); //reload datatable ajax
    table_has_paid.ajax.reload(null,false); //reload datatable ajax
}


$('.btn_search').click(function (e) {
    e.preventDefault();
    $(this).button('loading');
	$('.form-group').removeClass('has-error');
	$('.help-block').empty();  
	  //defined form
    var formData = new FormData($('.form-search')[0]);
	  $.ajax({
	    url: controller+'/get_data',
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData : false,
	    dataType :"JSON",
	    success: function(data){
            if (data.status) {
                // notif_success('Data Berhasil Disimpan');
                $('.html_respon').html(data.html_respon);
                $('.table_history').DataTable();
	      } else{
	        for (var i = 0; i < data.inputerror.length; i++)
	         {
	            $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
	            $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
	         }
	      }
	      $('.btn_search').button('reset');
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	        $('.btn_search').button('reset');
            alert_error('something wrong');
	      }
	  });//end ajax
})


$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
})

$(document).on('keyup', '.money_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    var money = money_function(qty, '');
    $(this).val(money);
})

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    return rupiah;
}