<html>
<head>
	<title></title>
</head>
<style type="text/css">
	.body{
		font-size: 10px;
		font-family:Times, serif;
	}
	.jarak{
		height: 25px;	
	}

	.lebar{
		width: 70px;
	}
	.lebar-kecil{
		width: 40px;
	}

	/*table{
		width: 90%;
	}*/
	.table{
		/*width: 100px;*/
		border: 1px solid #C6C6C6;
		border-collapse: collapse;
		padding-left: 8px;
		padding-right: 8px;
	}

	th{
		border: 1px solid #C6C6C6;
		border-collapse: collapse;
		padding-left: 8px;
		padding-right: 8px; 
	}
	.table  tr td{
		border: 1px solid #C6C6C6;
		border-collapse: collapse;
		padding-left: 8px;
		padding-right: 8px; 
	}
	.more_width{
		width: 100px;
	}
	.small_width{
		width: 3px;
	}
	.much_width{
		width: 300px;
	}
	.more_than_width{
		width: 150px;
	}
	hr{
		border-top: 0.1px solid #8c8b8b;
	}
	</style>
	<?php 
		function get_date_indo($date){
		    $nameOfDay = date('D', strtotime($date));
		    $dayList = array(
		      'Sun' => 'Minggu',
		      'Mon' => 'Senin',
		      'Tue' => 'Selasa',
		      'Wed' => 'Rabu',
		      'Thu' => 'Kamis',
		      'Fri' => 'Jumat',
		      'Sat' => 'Sabtu'
		    );

		    $bulan = array (
		    1 =>   'Januari',
		    'Februari',
		    'Maret',
		    'April',
		    'Mei',
		    'Juni',
		    'Juli',
		    'Agustus',
		    'September',
		    'Oktober',
		    'November',
		    'Desember'
		  );
		  //explode date 
		    $date_explode = explode('-',$date);
		    $date_indo = $date_explode[2].'&nbsp;'.$bulan[intval($date_explode[1])].'&nbsp;'.$date_explode[0];
		    $return_value = $dayList[$nameOfDay].', '.$date_indo; 
		    return $date_indo;
		  }

		  $date_now = get_date_indo(date('Y-m-d'));
	 ?>
<body>
	
	<table>
		<tr>
			<td><img style="width:200px;" src="<?php echo base_url('upload/profile/'.$data_profile['image']); ?>"></td>
			<td>
				<h1 style="margin:0"><?php echo strtoupper($data_profile['name']); ?></h1>
				<h4 style="margin:0"><?php echo $data_profile['address']; ?></h4>
				<p style="padding:0;margin:0;">Email : <b><?php echo $data_profile['email']; ?></b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; No.telf : <b><?php echo $data_profile['number_phone']; ?></b></p>
			</td>
		</tr>
	</table>
	<hr>
	<div align="center">
		<h3 style="margin:0;" align="center">Laporan Laba / Rugi</h3>
		<h5 style="margin:0;">Periode : <?php echo $date_range; ?> </h5>
	</div>
	<br>
	<table>
		<tr>
			<td style="width:150px;">PEMASUKAN</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;">Rp.<?php echo number_format($data_sales['grand_total'],0,'.','.'); ?></td>
			<td style="width:10px;">&nbsp;</td>
			<td style="width:150px;">PENGELUARAN</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;">Rp.<?php echo number_format($data_stock['grand_total'],0,'.','.'); ?></td>
		</tr>
		<tr>
			<td colspan="3" style="width:150px;"><br>Rincian Pemasukan:</td>
			<td style="width:10px;">&nbsp;</td>
			<td colspan="3" style="width:150px;"><br>Rincian Pengeluaran:</td>
		</tr>
		<tr>
			<td style="width:150px;">Total Nota</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;"><?php echo number_format($data_sales['count_receipt'],0,'.','.'); ?> NOTA</td>
			<td style="width:10px;">&nbsp;</td>
			<td style="width:150px;">Total Uang Pembelian</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;">Rp.<?php echo number_format($data_stock['grand_total'],0,'.','.'); ?></td>
		</tr>
		<tr>
			<td style="width:150px;">Total Uang Diterima</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;">Rp.<?php echo number_format($data_sales['payment'],0,'.','.'); ?></td>
			<td style="width:10px;">&nbsp;</td>
			<td style="width:150px;">Jumlah Kartu Stok</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;"><?php echo number_format($data_stock['count_stock_card'],0,'.','.'); ?> Kartu Stok</td>
		</tr>
		<tr>
			<td style="width:150px;">Total Uang Kembalian</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;">Rp.<?php echo number_format($data_sales['rest_payment'],0,'.','.'); ?></td>
			<td style="width:10px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width:150px;">Total Uang Penjualan</td>
			<td style="width:5px;">:</td>
			<td style="width:150px;">Rp.<?php echo number_format($data_sales['grand_total'],0,'.','.'); ?></td>
			<td style="width:10px;">&nbsp;</td>
		</tr>
	</table>
	<hr>
	<table>
		<tr>
			<td>TOTAL PEMASUKAN</td>
			<td>:</td>
			<td>Rp.<?php echo number_format($data_sales['grand_total'],0,'.','.'); ?></td>
		</tr>
		<tr>
			<td>TOTAL PENGELUARAN</td>
			<td>:</td>
			<td>Rp.<?php echo number_format($data_stock['grand_total'],0,'.','.'); ?></td>
		</tr>
		<tr>
			<td></td>
			<td colspan="2">------------------------------------ (-)</td>
		</tr>
		<tr>
			<td>LABA (RUGI)</td>
			<td>:</td>
			<td>Rp.<?php echo number_format($result_advantage,0,'.','.'); ?></td>
		</tr>
	</table>
	<hr>
		<h3 style="height:1px;" align="center"> LABA (RUGI)&nbsp;&nbsp;&nbsp;&nbsp; : <b>Rp.<?php echo number_format($result_advantage,0,'.','.'); ?></b></h3>
	<hr>
	<table>
		<tr>
			<td style="width:400px">&nbsp;</td>
			<td align="center"><?php echo $data_profile['city']; ?>, <?php echo $date_now; ?> </td>
		</tr>
		<tr>
			<td width="500px">&nbsp;</td>
			<td align="center">Penanggung Jawab </td>
		</tr>
		<tr>
			<td width="500px">&nbsp;</td>
			<td align="center">
				<br><br><br><br>
				<b><?php echo $data_profile['owner_name']; ?></b><br>
				_______________________________ 
			</td>
		</tr>
	</table>

</body>
</html>