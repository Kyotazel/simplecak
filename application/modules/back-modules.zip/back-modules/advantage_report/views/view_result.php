<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-body">
        <div class="col-md-2" align="center">
            <img style="height:80px" src="<?php echo base_url('upload/profile/' . $data_profile['image']); ?>">
        </div>
        <div class="col-md-7">
            <h1><?php echo $data_profile['name']; ?></h1>
            <h4><?php echo $data_profile['address']; ?></h4>
            <h5>Email : <b><?php echo $data_profile['email']; ?></b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; No.Telf : <b><?php echo $data_profile['number_phone']; ?></b></h5>
        </div>
        <div class="col-md-12">
            <hr>
            <h4 align="center">LAPORAN LABA/RUGI</h4>
            <h4 align="center">Periode: <b><?php echo $date_range; ?></b> </h4>
            <hr>
            <div class="col-md-6">
                <table width="100%" style="font-size:20px;">
                    <tr>
                        <td width="180px;">PEMASUKAN</td>
                        <td width="10px">:</td>
                        <td>Rp. <?php echo number_format($data_sales['grand_total'], 0, '.', '.');  ?></td>
                    </tr>
                </table>
                <hr>
                <label>Rincian Pemasukan</label>
                <table width="100%">
                    <tr>
                        <td width="200px;">Total Nota</td>
                        <td width="10px;">:</td>
                        <td colspan="2"><?php echo $data_sales['count_receipt']; ?> NOTA</td>
                    </tr>
                    <tr>
                        <td width="200px;">Total Uang Diterima</td>
                        <td width="10px;">:</td>
                        <td width="20px;">Rp.</td>
                        <td><?php echo number_format($data_sales['payment'], 0, '.', '.');  ?></td>
                    </tr>
                    <tr>
                        <td width="200px;">Total Uang Kembalian</td>
                        <td width="10px;">:</td>
                        <td width="20px;">Rp.</td>
                        <td><?php echo number_format($data_sales['rest_payment'], 0, '.', '.');  ?></td>
                    </tr>
                    <tr>
                        <td width="200px;">Total Uang Penjualan</td>
                        <td width="10px;">:</td>
                        <td width="20px;">Rp.</td>
                        <td><?php echo number_format($data_sales['grand_total'], 0, '.', '.');  ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <table width="100%" style="font-size:20px;">
                    <tr>
                        <td width="180px;">PENGELUARAN</td>
                        <td width="10px">:</td>
                        <td>Rp. <?php echo number_format($data_stock['grand_total'], 0, '.', '.');  ?></td>
                    </tr>
                </table>
                <hr>
                <label>Rincian Pengeluaran</label>
                <table width="100%">
                    <tr>
                        <td width="200px;">Total Uang Pembelian Barang</td>
                        <td width="10px;">:</td>
                        <td width="20px;">Rp.</td>
                        <td><?php echo number_format($data_stock['grand_total'], 0, '.', '.');  ?></td>
                    </tr>
                    <tr>
                        <td width="200px;">Jumlah Kartu Stok</td>
                        <td width="10px;">:</td>
                        <td colspan="2"><?php echo number_format($data_stock['count_stock_card'], 0, '.', '.');  ?> Kartu Stok</td>
                    </tr>
                </table>
            </div>
            <div class="col-md-12">
                <hr>
                <table width="100%" style="font-size:20px;">
                    <tr>
                        <td width="300px">TOTAL PEMASUKAN</td>
                        <td width="40px;">Rp.</td>
                        <td><?php echo number_format($data_sales['grand_total'], 0, '.', '.');  ?></td>
                    </tr>
                    <tr>
                        <td>TOTAL PENGELUARAN</td>
                        <td>Rp.</td>
                        <td>
                            <?php echo number_format($data_stock['grand_total'], 0, '.', '.');  ?>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td colspan="2">----------------------------------------------- (-)</td>
                    </tr>
                    <tr>
                        <td>LABA(RUGI)</td>
                        <td>Rp.</td>
                        <td><?php echo number_format($result_advantage, 0, '.', '.');  ?></td>
                    </tr>
                </table>
                <hr>
                <h4 align="center">LABA (RUGI)&nbsp;&nbsp;&nbsp;&nbsp; : <b><?php echo number_format($result_advantage, 0, '.', '.');  ?></b></h4>
                <hr>
            </div>
        </div>
        <div class="col-md-12" align="right">
            <form action="<?php echo base_url('advantage_report/print_report'); ?>" method="POST">
                <input type="hidden" name="date_from" value="<?php echo $date['date_from']; ?>">
                <input type="hidden" name="date_to" value="<?php echo $date['date_to']; ?>">
                <button type="submit" class="btn btn-default btn-lg"><i class="fa fa-print"></i> CETAK PDF</button>
            </form>
        </div>
    </div>
    <!-- end box body -->
</div>