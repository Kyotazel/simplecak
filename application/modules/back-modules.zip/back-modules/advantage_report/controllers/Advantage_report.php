<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Advantage_report extends CI_Controller
{
    var $location = 'data_advantage_report/';
    var $module_name = 'advantage_report';

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function index()
    {
        $data['data_member'] = $this->db->query("select id,name from tb_member order by id DESC")->result();
        $data['data_product'] = $this->db->query("select id,name from tb_product order by id DESC")->result();
        $data['tagline_page'] = "LAPORAN LABA / RUGI";
        $data['view_file'] = $this->location . 'form';
        $this->load->view('template/media_admin', $data);
    }
    public function change_to_sql_date($date)
    {
        $date_explode = explode('-', $date);
        $date_sql = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        return $date_sql;
    }
    public function validate_input()
    {
        $status = false;
        $date_from     = $this->input->post('date_from');
        $date_to     = $this->input->post('date_to');

        if ($date_from == '') {
            $this->session->set_flashdata('error_date_from', 'harus disi dulu');
            $status = TRUE;
        }
        if ($date_to == '') {
            $this->session->set_flashdata('error_date_to', 'harus disi dulu');
            $status = TRUE;
        }

        if ($status == TRUE) {
            redirect(base_url($this->module_name));
        }
    }

    public function get_report()
    {

        $this->validate_input();
        $date_from     = $this->change_to_sql_date($this->input->post('date_from'));
        $date_to     = $this->change_to_sql_date($this->input->post('date_to'));
        //get data profile 
        $data['data_profile'] = $this->db->get('tb_profile')->row_array();
        //get data  sales
        $this->db->select('
							SUM(grand_total) AS grand_total,
							SUM(payment) AS payment,
							SUM(rest_payment) AS rest_payment,
							COUNT(id) AS count_receipt
						 ');
        $this->db->from('tb_sales');
        $this->db->where("date BETWEEN  '$date_from' AND '$date_to' ");
        $get_data_sales = $this->db->get()->row_array();
        //get data stock card
        $this->db->select('
							SUM(grand_total) AS grand_total,
							COUNT(id) AS count_stock_card
						 ');
        $this->db->from('tb_stock_opname');
        $this->db->where("date BETWEEN  '$date_from' AND '$date_to' ");
        $get_data_stock = $this->db->get()->row_array();
        //coount result
        $result_advantage = $get_data_sales['grand_total'] - $get_data_stock['grand_total'];
        $data['data_stock'] = $get_data_stock;
        $data['data_sales'] = $get_data_sales;
        $data['result_advantage'] = $result_advantage;
        $data['date_range'] = $this->change_to_sql_date($date_from) . '&nbsp;&nbsp; S/D&nbsp;&nbsp;' . $this->change_to_sql_date($date_to);
        //date 
        $data['date'] = array('date_from' => $date_from, 'date_to' => $date_to);
        $data['tagline_page'] = "LAPORAN LABA / RUGI";
        $data['view_file'] = $this->location . 'view_result';
        $this->load->view('template/media_admin', $data);
    }

    public function print_report()
    {
        // if($this->input->post('last_query')==''){
        // 	redirect(base_url('sales_report'));
        // }
        $date_from     = $this->input->post('date_from');
        $date_to     = $this->input->post('date_to');
        //get data profile 
        $data['data_profile'] = $this->db->get('tb_profile')->row_array();
        //get data  sales
        $this->db->select('
							SUM(grand_total) AS grand_total,
							SUM(payment) AS payment,
							SUM(rest_payment) AS rest_payment,
							COUNT(id) AS count_receipt
						 ');
        $this->db->from('tb_sales');
        $this->db->where("date BETWEEN  '$date_from' AND '$date_to' ");
        $get_data_sales = $this->db->get()->row_array();
        //get data stock card
        $this->db->select('
							SUM(grand_total) AS grand_total,
							COUNT(id) AS count_stock_card
						 ');
        $this->db->from('tb_stock_opname');
        $this->db->where("date BETWEEN  '$date_from' AND '$date_to' ");
        $get_data_stock = $this->db->get()->row_array();
        //coount result
        $result_advantage = $get_data_sales['grand_total'] - $get_data_stock['grand_total'];
        $data['data_stock'] = $get_data_stock;
        $data['data_sales'] = $get_data_sales;
        $data['result_advantage'] = $result_advantage;
        $data['date_range'] = $this->change_to_sql_date($date_from) . '&nbsp;&nbsp; S/D&nbsp;&nbsp;' . $this->change_to_sql_date($date_to);

        ob_clean();

        $data['data_range'] = '';
        $data['data_profile'] = $this->db->get('tb_profile')->row_array();

        ob_start();
        $this->load->view($this->location . 'print_report', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('./assets/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en');
        $pdf->WriteHTML($html);
        $pdf->Output('laporan Laba Rugi (' . date('d-m-Y') . ').pdf', 'D');
    }
}
