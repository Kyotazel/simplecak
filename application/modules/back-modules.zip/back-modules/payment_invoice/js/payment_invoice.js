url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;

var save_method;
var table_receive;
var table_reject;
var id_use;
$(document).ready(function () {
    // table_receive = $('.table_receive').DataTable({
    //     "ajax": {
    //         "url": url_controller + "/list_data",
    //         "type": "POST"
    //     }
    // });
    search_data();
    $('.chosen').chosen();
});


$(document).on('click', '.btn_search_data', function (e) { 
    e.preventDefault();
    search_data();
});

function search_data() {
    showLoading();
    $('.modal-title').text('INVOICE');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    $.ajax({
        url: url_controller + "list_data_request",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                $('.html_respon').html(data.html_respon);
                $(document).find('.table_request').DataTable();
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }

    });
}

$(document).on('click', '.btn_create_invoice', function (e) { 
    e.preventDefault();
    showLoading();
    var id_receipt = $(this).data('id');
    $.ajax({
        url: url_controller + "form_invoice",
        type: "POST",
        data:{'id':id_receipt},
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.html_respon_modal').html(data.html_respon);
                $('#modal-form').modal('show');

                $(document).find('.datepicker').datepicker({
                    autoclose: true,
                    format: 'dd-mm-yyyy',
                });
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });
});




$(document).on('click', '.btn-save-invoice', function () { 

    var invoice = $(document).find('[name="invoice"]').val();
    if (invoice == '') {
        alert_error('Kode invoice belum diisi');
        return false;
    }
    var due_date = $(document).find('[name="due_date"]').val();
    if (due_date == '') {
        alert_error('Tanggal jatuh tempo belum diisi');
        return false;
    }
    var id = $(this).data('id');
    swal({
        title: "Apakah anda yakin?",
        text: "Data invoice akan disimpan!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            showLoading();
            $.ajax({
                url: url_controller + "save_invoice",
                type: "POST",
                data:{'invoice':invoice,'due_date':due_date,'id_receipt':id},
                dataType: "JSON",
                success: function(data) {
                    if (data.status) {
                        notif_success('Invoice Berhasil Dibuat');
                        location.reload();
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    hideLoading();
                    alert('Error deleting data');
                }
            });
        }
    });

});

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
})

$(document).on('keyup', '.money_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    var money = money_function(qty, '');
    $(this).val(money);
})

function money_function(angka, prefix) {
    
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    return rupiah;
}

function to_money(angka, prefix) {
    
    var number_string = angka,
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    return rupiah;
}

function delete_dot_value(value) {
    var array_value = value.split('.');
    var count_array = array_value.length;
    payment_value = value;
    for (var i = 0; i < count_array; i++) {
        payment_value = payment_value.replace('.', '');
    };
    return payment_value;
}

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
});


// function money_function(angka, prefix) {
//     var number_string = angka.replace(/[^,\d]/g, '').toString(),
//     split = number_string.split(','),
//     sisa = split[0].length % 3,
//     rupiah = split[0].substr(0, sisa),
//     ribuan = split[0].substr(sisa).match(/\d{3}/gi);

// if (ribuan) {
//     separator = sisa ? '.' : '';
//     rupiah += separator + ribuan.join('.');
// }

// rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
// return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
// }
