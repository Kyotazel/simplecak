<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Payment_invoice extends BackendController
{
    var $module_name        = 'payment_invoice';
    var $module_directory   = 'payment_invoice';
    var $module_js          = ['payment_invoice'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "Penerimaan";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data_request()
    {
        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $id_supplier = $this->input->post('id_supplier');
        $status = $this->input->post('status');


        $array_where = [];
        $array_where_in = [];

        $array_where['tb_request.status'] = 1;

        if ($status != '') {
            if ($status == 0) {
                $array_where['tb_receipt.id_debt'] = 0;
            }
            if ($status == 1) {
                $array_where['tb_receipt.id_debt >'] = 0;
            }
        }

        if ($date_from) {
            $array_where['tb_receipt.received_date >='] = $date_from;
        }
        if ($date_to) {
            $array_where['tb_receipt.received_date <='] = $date_to;
        }
        if ($id_supplier) {
            $array_where_in['tb_request.id_supplier'] = $id_supplier;
        }

        $array_query = [
            'select' => '
                tb_request.*,
                COUNT(tb_request_has_product.id) AS count_item,
                tb_account_warehouse.name AS warehouse_name,
                tb_account_warehouse.address AS warehouse_address,
                mst_vendor.name AS supplier_name,
                mst_vendor.address AS supplier_address,
                tb_receipt.id_debt,
                tb_debt.invoice_code,
                tb_debt.date AS debt_date
            ',
            'from' => 'tb_request',
            'join' => [
                'tb_request_has_product,tb_request.id = tb_request_has_product.id_request,left',
                'tb_account_warehouse,tb_request.id_account_warehouse = tb_account_warehouse.id,left',
                'mst_vendor,tb_request.id_supplier = mst_vendor.id,left',
                'tb_receipt,tb_request.id = tb_receipt.id_request,inner', //validate both table
                'tb_debt,tb_receipt.id_debt = tb_debt.id,left'
            ],
            'group_by' => 'tb_request.id',
            'order_by' => 'tb_request.id, DESC'
        ];

        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }

        $get_data = Modules::run('database/get', $array_query)->result();


        $data_po['data_request'] = $get_data;
        $html_po = $this->load->view('view_search_result', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }

    public function form_invoice()
    {
        Modules::run('security/is_ajax');
        $id_receipt = $this->input->post('id');

        $this->db->select('
        tb_receipt_has_product.*,
        tb_product.code AS product_code,
        tb_product.name AS product_name,
        tb_product.qty_unit AS qty_unit,
        tb_unit.name AS unit_name,
        tb_base_unit.name AS base_unit_name
        ');
        $this->db->from('tb_receipt_has_product');
        $this->db->join('tb_request_has_product', 'tb_request_has_product.id = tb_receipt_has_product.id_item_request', 'left');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_base_unit', 'tb_unit.id_base_unit = tb_base_unit.id', 'left');
        $get_data_detail = $this->db->where(['tb_receipt_has_product.id_receive' => $id_receipt])->get()->result();
        $data_po['data_detail'] = $get_data_detail;


        $this->db->select('
        tb_receipt.*,
        tb_account_warehouse.name AS suppplier_name,
        COUNT(tb_receipt_has_product.id) AS count_item,
        tb_request.code AS request_code
        ');
        $this->db->from('tb_receipt');
        $this->db->join('tb_receipt_has_product', 'tb_receipt.id = tb_receipt_has_product.id_receive', 'left');
        $this->db->join('tb_request', 'tb_receipt.id_request = tb_request.id', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $get_data = $this->db->where(['tb_receipt.id' => $id_receipt])->group_by('tb_receipt.id')->get()->row();
        $data_po['data_receipt'] = $get_data;

        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS warehouse_name,
                            tb_account_warehouse.address AS warehouse_address,
                            mst_vendor.name AS supplier_name,
                            mst_vendor.address AS supplier_address,
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_account_warehouse = tb_account_warehouse.id', 'left');
        $this->db->join('mst_vendor', 'tb_request.id_supplier = mst_vendor.id', 'left');
        $get_request = $this->db->where(['tb_request.id' => $get_data->id_request])->group_by('tb_request.id')->get()->row();
        $data_po['data_request'] = $get_request;

        $html_po = $this->load->view('_partials/component_preview_invoice', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }

    public function save_invoice()
    {
        Modules::run('security/is_ajax');

        $invoice = $this->input->post('invoice');
        $due_date = Modules::run('helper/change_date', $this->input->post('due_date'), '-');
        $id_receipt = $this->input->post('id_receipt');

        $this->db->select('
        tb_receipt.*,
        tb_request.id_supplier
        ');
        $this->db->from('tb_receipt');
        $this->db->join('tb_receipt_has_product', 'tb_receipt.id = tb_receipt_has_product.id_receive', 'left');
        $this->db->join('tb_request', 'tb_receipt.id_request = tb_request.id', 'left');
        $get_data = $this->db->where(['tb_receipt.id' => $id_receipt])->group_by('tb_receipt.id')->get()->row();

        //['invoice','','deskripsi','hutang','tanggal_hutang','tanggal_jatuh_tempo','id_vendor']
        $data = [
            'invoice' => $invoice,
            'id_vendor' => $get_data->id_supplier,
            'hutang' => $get_data->grandtotal_correction,
            'tanggal_hutang' => date('Y-m-d'),
            'tanggal_jatuh_tempo' => $due_date,
            'deskripsi' => 'Transaksi GR ( #' . $get_data->code . ' )',
        ];
        Modules::run('debt/insert_debt', $data);

        $get_debt = Modules::run('database/find', 'tb_debt', ['invoice_code' => $invoice])->row();
        Modules::run('database/update', 'tb_receipt', ['id' => $get_data->id], ['id_debt' => $get_debt->id]);

        echo json_encode(['status' => TRUE]);
    }
}
