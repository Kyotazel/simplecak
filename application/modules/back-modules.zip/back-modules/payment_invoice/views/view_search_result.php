<div class="table-responsive">
    <table class="table t-shadow table_request" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>GR</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_request as $item_po) {
                $counter++;

                $data['data_request'] = $item_po;
                $data['data_receipt'] = Modules::run('database/find', 'tb_receipt', ['id_request' => $item_po->id])->row();

                $html_detail = $this->load->view('_partials/item_po', $data, TRUE);
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $html_detail . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>