<style>
    .datepicker {
        z-index: 1000 !important;
    }
</style>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h3 class="col-8">Purchase Invoice ( PI )</h3>
        </div>

    </div>

    <div class="card-body">
        <form action="" class="form-input">
            <div class="row mb-3 border-dashed p-3">
                <div class="col-md-2">
                    <label for="">Tanggal Awal</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                        </div>
                        <input class="form-control bg-white datepicker" name="date_from" readonly="" placeholder="pilih tanggal" type="text">
                    </div>
                </div>
                <div class="col-md-2">
                    <label for="">Tanggal Akhir</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                        </div>
                        <input class="form-control bg-white datepicker" name="date_to" readonly="" placeholder="pilih tanggal" type="text">
                    </div>
                </div>
                <div class="col-md-4">
                    <label for="">Supplier</label>
                    <select name="id_supplier[]" class="form-control chosen" id="" multiple>
                        <?php
                        foreach ($data_customer as $item_data) {
                            echo '
                                    <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                ';
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="">Status</label>
                    <select name="status" class="form-control" id="">
                        <option value="">Semua</option>
                        <option selected value="0">Menunggu Diproses</option>
                        <option value="1">Telah Diproses</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="">&nbsp;</label><br>
                    <button class="btn btn-rounded btn-primary-gradient btn_search_data"> <i class="fa fa-search"></i> Cari Data</button>
                </div>
            </div>

        </form>

        <div class="html_respon"></div>
    </div>
</div>



<div class="modal" id="modal-form" data-backdrop="static">
    <div class="modal-dialog" style="min-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>

            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>