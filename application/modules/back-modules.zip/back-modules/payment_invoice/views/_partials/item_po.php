<?php
$btn_payment = Modules::run('security/edit_access', '
    <small>(*klik untuk membuat invoice GR )</small>
    <a href="javascript:void(0)" class="btn btn-primary-gradient btn-rounded btn_create_invoice" data-id="' . $data_receipt->id . '"> Buat Invoice <i class="fa fa-paper-plane"></i></a>
');
if ($data_request->id_debt) {
    $btn_payment = '
    <small>(*Detail Invoice )</small>
    <a href="' . Modules::run('helper/create_url', 'debt/detail?data=' . urlencode($this->encrypt->encode($data_receipt->id_debt))) . '" class="btn btn-light btn-rounded font-weight-bold" data-id="' . $data_receipt->id . '"> Lihat Detail Invoice <i class="fa fa-arrow-circle-right"></i></a>
    ';
}

?>

<div class="row">
    <h2 class="mb-3 col-6">
        <span class="badge badge-light tx-20 badge-pill">NOMOR PO : <strong><?= $data_request->code; ?></strong></span>
        &nbsp;&nbsp;
        <span class="badge badge-light tx-20 badge-pill">NOMOR GR : <strong><?= $data_receipt->code; ?></strong></span>
    </h2>
    <div class="col-6 row">
    </div>
</div>
<div class="row" style="align-items:baseline;">
    <div class="col-md-4 row">
        <label for="" class="font-weight-bold text-uppercase col-12 m-0"><i class="fa fa-truck"></i> Keterangan PO</label>
        <div class="col-12">
            <table style="width:100%;" class="table-no-border">
                <tr>
                    <td style="width:100px ;">Supplier</td>
                    <td style="width: ;">:</td>
                    <td>
                        <div class="row col-12 border-dashed">
                            <div class="col">
                                <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->supplier_name; ?></b></div>
                                <p class="tx-12">
                                    <?= $data_request->supplier_address; ?>
                                </p>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="width:100px ;">Lokasi Kirim</td>
                    <td style="width: ;">:</td>
                    <td>
                        <div class="row col-12 border-dashed">
                            <div class="col">
                                <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->warehouse_name; ?></b></div>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="fa fa-truck project bg-primary-transparent text-primary "></i>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="col-md-4 ">
        <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Resume GOOD RECEIVE</label>
        <div class="row text-right">
            <div class="p-2 border-dashed col-6">
                <small>Sub Total (GR) : &nbsp;</small>
                <h4 class=" m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grand_total_product, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-6">
                <small>Pajak PPN : &nbsp;</small>
                <h4 class="m-0 p-0 total_po">Rp.<?= number_format($data_receipt->tax_price, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                <small>Tanggal Terima : <b><?= Modules::run('helper/date_indo', $data_receipt->received_date, '-'); ?></b></small>
                &nbsp;&nbsp;|&nbsp;&nbsp;
                <small>Total GR : &nbsp;</small>
                <h4 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grandtotal_receipt, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                <small>Penyesuaian Total GR : &nbsp;</small>
                <h4 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grandtotal_correction, 0, '.', '.'); ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-4 ">
        <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> INVOICE VENDOR</label>
        <div class="row text-right">
            <div class="p-2 border-dashed col-12">
                <small>No.Invoice : &nbsp;</small>
                <span class="m-0 p-0 total_po badge badge-light tx-20">#<?= $data_request->invoice_code; ?></span>
            </div>
            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                <small>Nilai Hutang : &nbsp;</small>
                <h4 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grandtotal_receipt, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-12 ">
                <small>Tanggal Jatuh Tempo : &nbsp;</small>
                <span class="tx-15 font-weight-bold"><?= Modules::run('helper/date_indo', $data_request->debt_date, '-'); ?></span>
            </div>
        </div>
    </div>
    <div class="col-12 text-right mt-1">
        <?= $btn_payment; ?>
    </div>
</div>