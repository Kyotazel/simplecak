<?php


?>
<div class="">
    <div class="invoice-header">
        <h1 class="invoice-title">DETAIL GR ( #<?= $data_receipt->code; ?> )</h1>
        <div class="billed-from">
        </div><!-- billed-from -->
    </div><!-- invoice-header -->
    <div class="table-responsive mg-t-40">
        <table class="table table_detail_request">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Produk</th>
                    <th>Nama Produk</th>
                    <th>Satuan Produk</th>
                    <th>Qty GR</th>
                    <th>Harga GR</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 0;
                foreach ($data_detail as $item_detail) {

                    $subtotal = $item_detail->price_receive * $item_detail->qty_receive;
                    $counter++;
                    if (!empty($item_detail->conversion_name)) {
                        $unit_request = $item_detail->conversion_name . ' / ' . $item_detail->qty_conversion . ' ' . $item_detail->unit_name;
                    } else {
                        $unit_request = $item_detail->unit_name;
                    }
                    $conversion_name = $item_detail->unit_name;

                    echo '
                                    <tr class="item_receive">
                                        <td>' . $counter . '</td>
                                        <td>' . $item_detail->product_code . '</td>
                                        <td>' . $item_detail->product_name . '</td>
                                        <td>' . $item_detail->unit_name . '</td>
                                        <td>
                                            <div class="input-group">
                                                <input readonly class="form-control border-dashed bg-white  " value="' . number_format($item_detail->qty_receive, 0, '.', '.') . '" >
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1">' . $conversion_name . '</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">Rp.</span>
                                                </div>
                                                <input  class="form-control bg-white border-dashed" readonly  value="' . number_format($item_detail->price_receive, 0, '.', '.') . '" type="text">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">Rp.</span>
                                                </div>
                                                <input  class="form-control bg-white border-dashed" readonly  value="' . number_format($subtotal, 0, '.', '.') . '" type="text">
                                            </div>
                                        </td>
                                    </tr>
                                ';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>