<?php
$data['company'] = [
    'name' => Modules::run('database/find', 'app_setting', ['field' => 'company_name'])->row()->value,
    'company_tagline' => Modules::run('database/find', 'app_setting', ['field' => 'company_tagline'])->row()->value,
    'company_email' => Modules::run('database/find', 'app_setting', ['field' => 'company_email'])->row()->value,
    'company_number_phone' => Modules::run('database/find', 'app_setting', ['field' => 'company_number_phone'])->row()->value,
    'company_address' => Modules::run('database/find', 'app_setting', ['field' => 'company_address'])->row()->value,
    'company_logo' => Modules::run('database/find', 'app_setting', ['field' => 'company_logo'])->row()->value
];

?>
<style>
    .datepicker {
        z-index: 10000;
    }
</style>
<div class="row">

    <div class="col-8">

        <div class="panel panel-primary tabs-style-2">
            <div class=" tab-menu-heading">
                <div class="tabs-menu1">
                    <!-- Tabs -->
                    <ul class="nav panel-tabs main-nav-line">

                        <?php

                        echo '
                                    <li><a href="#tab4" class="nav-link active" data-toggle="tab">DETAIL GR</a></li>
                                ';

                        ?>
                    </ul>
                </div>
            </div>
            <div class="panel-body tabs-menu-body main-content-body-right border">
                <div class="tab-content">
                    <div class="tab-pane active" id="tab4">
                        <?php
                        $data['data_detail_po'] = $data_detail;
                        $this->load->view('_partials/detail_invoice', $data);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-4">
        <div class="card">
            <div class="card-header bg-primary-gradient">
                <div class="row">
                    <h5 class="card-title col-12 text-white"><i class="fa fa-file"></i> FORM INVOICE </h5>
                </div>
            </div>
            <div class="card-body">
                <div class="col-12">
                    <!-- <label class=" m-0" for="" class="d-block">Nama Kapal :</label> -->
                    <div class="mt-1 row">
                        <div class="col-md-12 row p-1">
                            <label class="font-weight-bold"><i class="fa fa-user"></i> Data Supplier :</label>
                            <div class="row col-12 border-dashed">
                                <div class="col">
                                    <div class="h3 mt-2 mb-2 text-primary"><b><?= $data_request->supplier_name; ?></b></div>
                                    <p class="tx-12"><?= $data_request->supplier_address; ?></p>
                                </div>
                                <div class="col-auto align-self-center ">
                                    <div class="feature mt-0 mb-0">
                                        <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 border-dashed p-2">
                                <small class="text-muted"><i class="fa fa-calendar"></i> Tanggal PO: </small>
                                <label for="" class="d-block font-weight-bold m-0"><b> <?= Modules::run('helper/date_indo', $data_request->date, '-'); ?></b></label>
                            </div>
                            <div class="col-6 border-dashed p-2">
                                <small class="text-muted"><i class="fa fa-box"></i> Tanggal GR: </small>
                                <label for="" class="d-block font-weight-bold m-0"><b> <?= Modules::run('helper/date_indo', $data_receipt->received_date, '-'); ?></b></label>
                            </div>
                            <div class="p-2 border-dashed col-6">
                                <small>Sub Total (GR) : &nbsp;</small>
                                <h3 class=" m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grand_total_product, 0, '.', '.'); ?></h3>
                            </div>
                            <div class="p-2 border-dashed col-6">
                                <small>Pajak PPN : &nbsp;</small>
                                <h3 class="m-0 p-0 total_po">Rp.<?= number_format($data_receipt->tax_price, 0, '.', '.'); ?></h3>
                            </div>
                            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                                <small>Total GR : &nbsp;</small>
                                <h3 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grandtotal_receipt, 0, '.', '.'); ?></h3>
                            </div>
                            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                                <small>Total Penyesuaian GR (Tagihan Supplier) : &nbsp;</small>
                                <h3 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grandtotal_correction, 0, '.', '.'); ?></h3>
                            </div>
                            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                                <small class="col-4">Kode Invoice : &nbsp;</small>
                                <input type="text" class="form-control" name="invoice">
                            </div>
                            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                                <small class="col-4">Jatuh Tempo : &nbsp;</small>
                                <input type="text" class="form-control datepicker bg-white" name="due_date" readonly>
                            </div>
                            <div class="p-2  col-12 mt-2 text-center">
                                <small>Pastikan data sudah benar , Tekan tombol dibawah untuk menyimpan data.</small>
                                <a href="javascript:void(0)" data-id="<?= $data_receipt->id; ?>" style="width:80%;" class="btn  btn-primary-gradient btn-save-invoice btn-rounded btn-lg font-weight-bold">Simpan Invoice</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>