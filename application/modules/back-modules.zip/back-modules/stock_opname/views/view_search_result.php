<div class="table-responsive">
    <table class="table t-shadow table_request" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>STOK opname</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // $status_po = Modules::run('database/find', 'app_module_setting', ['field' => 'status_po'])->result();
            // $array_status = [];
            // foreach ($status_po as $item_data) {
            //     $array_status[$item_data->value] = $item_data->label;
            // }
            $counter = 0;
            // $data['status_po'] = $array_status;
            foreach ($data_opname as $item_po) {
                $counter++;
                $data['data_detail'] = $item_po;
                $html_detail = $this->load->view('_partials/item_po', $data, TRUE);
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $html_detail . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>