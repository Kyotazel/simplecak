<style>
    .datepicker {
        z-index: 10000 !important;
    }
</style>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h3 class="col-8">Stock Opname</h3>
            <div class="col-4 text-right">
                <small>(*Klik untuk tambah data)</small>
                <a href="<?= Modules::run('helper/create_url', 'stock_opname/add'); ?>" class="btn btn-primary-gradient btn-rounded btn_link"><i class="fa fa-credit-card"></i> Tambah Data Stock Opname</a>
            </div>
        </div>

    </div>

    <div class="card-body">
        <form action="" class="form-input">
            <div class="row mb-3 border-dashed p-3">
                <div class="col-md-3">
                    <label for="">Tanggal Awal</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                        </div>
                        <input class="form-control bg-white datepicker" name="date_from" readonly="" placeholder="pilih tanggal" type="text">
                    </div>
                    <span class="help-block notif_date_from text-danger"></span>
                </div>
                <div class="col-md-3">
                    <label for="">Tanggal Akhir</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                        </div>
                        <input class="form-control bg-white datepicker" name="date_to" readonly="" placeholder="pilih tanggal" type="text">
                    </div>
                    <span class="help-block notif_date_to text-danger"></span>
                </div>
                <div class="col-md-2">
                    <label for="">Status</label>
                    <select name="status" class="form-control" id="">
                        <option value="">Semua</option>
                        <?php
                        $status_opname = Modules::run('helper/get_config', 'status_stock_opaname');
                        foreach ($status_opname as $key => $item_data) {
                            $selected = $key == 0 ? 'selected' : '';
                            echo '
                                    <option ' . $selected . ' class="text-capitalize" value="' . $key . '">' . $item_data . '</option>
                                ';
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="">&nbsp;</label><br>
                    <button class="btn btn-rounded btn-primary-gradient btn_search_data"> <i class="fa fa-search"></i> Cari Data</button>
                </div>
            </div>
        </form>

        <div class="html_respon_data"></div>
    </div>
</div>



<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>