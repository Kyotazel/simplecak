<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col-8">
                <h3>Daftar Acara Diskon</h3>
            </div>
            <div class="col-4 text-right">
                <?= Modules::run('security/create_access', '
                    <small>(*klik untuk menambah diskon)</small>
                    <a href="' . Modules::run('helper/create_url', 'event/add') . '" class="btn btn-primary-gradient btn-rounded btn_link font-weight-bold"><i class="fa fa-plus-circle"></i> Tambah Acara Diskon</a>
                '); ?>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table t-shadow table-data">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Acara</th>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Akhir</th>
                        <th>Jumlah ITEM</th>
                        <th>Hitung Mundur</th>
                        <th>Status</th>
                        <th width="200px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal-detail">
    <div class="modal-dialog" style="min-width:80%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>