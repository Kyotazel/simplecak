<?php
$array_type_discount = [
    1 => 'diskon harga',
    2 => 'diskon persentase',
    3 => 'Bonus ( gratis )'
];
?>
<style>
    .datepicker {
        z-index: 10000 !important;
    }
</style>
<div class="col-12">
    <h2>Form Diskon</h2>
</div>
<div class="card">
    <div class="card-header bg-primary-gradient">
        <div class="row">
            <h4 class="card-title text-white col-8">Keterangan Diskon</h4>
            <div class="col-4 text-right">
                <a href="<?= Modules::run('helper/create_url', 'event'); ?>" class="btn btn-light btn-rounded"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-8 row">
                <div class="form-group col-md-6">
                    <label for="">Nama Acara</label>
                    <input type="text" class="form-control bg-white border-dashed font-weight-bold tx-20" value="<?= $data_event->name; ?>" name="name" readonly>
                    <span class="help-block notif_name"></span>
                </div>
                <div class="form-group col-md-3">
                    <label for="">Tanggal Mulai Diskon</label>
                    <input type="text" class="form-control bg-white border-dashed font-weight-bold tx-20" value="<?= Modules::run('helper/date_indo', $data_event->start_date, '-'); ?>" name="name" readonly>
                    <span class="help-block notif_date"></span>
                </div>
                <div class="form-group col-md-3">
                    <label for="">Tanggal Akhir Diskon</label>
                    <input type="text" class="form-control bg-white border-dashed font-weight-bold tx-20" value="<?= Modules::run('helper/date_indo', $data_event->expired_date, '-'); ?>" name="name" readonly>
                    <span class="help-block notif_date"></span>
                </div>
            </div>
            <div class="col-md-4 border-dashed p-2">
                <label for="" class="font-weight-bold text-uppercase m-0"><i class="fa fa-tv"></i> Hitung Mundur</label>
                <div class="row col-12 mb-1 countdown_unloading" data-date-now="<?= $data_event->start_date; ?>" data-date-to="<?= $data_event->expired_date; ?>">
                    <div class="col-3 p-1 border rounded text-center">
                        <h5 for="" class="p-0 m-0 text-danger text_day">-</h5>
                        <small for="" class="d-block font-weight-bold">Hari</small>
                    </div>
                    <div class="col-3 p-1 border rounded text-center">
                        <h5 for="" class="p-0 m-0 text-danger text_hour">-</h5>
                        <small for="" class="d-block font-weight-bold">Jam</small>
                    </div>
                    <div class="col-3 p-1 border rounded text-center">
                        <h5 for="" class="p-0 m-0 text-danger text_minute">-</h5>
                        <small for="" class="d-block font-weight-bold">Menit</small>
                    </div>
                    <div class="col-3 p-1 border rounded text-center">
                        <h5 for="" class="p-0 m-0 text-danger text_second">-</h5>
                        <small for="" class="d-block font-weight-bold">Detik</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header pb-0">
        <h4 class="card-title">Detail Produk Terdiskon</h4>
    </div>
    <div class="card-body">
        <div class="col-md-12 html_respon m-0 p-0">
            <form class="form-detail-discount">
                <table class="table table-bordered t-shadow">
                    <thead>
                        <tr>
                            <th>Produk Terjual</th>
                            <th>Produk Diskon</th>
                        </tr>
                    </thead>
                    <tbody class="tbody_item detail_request">
                        <?php

                        $array_type_discount = [
                            1 => 'diskon harga',
                            2 => 'diskon persentase',
                            3 => 'Bonus ( gratis )'
                        ];

                        $array_params_discount = [
                            1 => 'Qty',
                            2 => 'Harga'
                        ];

                        foreach ($detail_event as $item_event) {
                            $value_disc = '';
                            if ($item_event->discount_type == 1) {
                                $value_disc = 'Rp.' . number_format($item_event->discount_value, 0, '.', '.');
                            }
                            if ($item_event->discount_type == 2) {
                                $value_disc = $item_event->discount_value . ' %';
                            }
                            if ($item_event->discount_type == 3) {
                                $value_disc = 'GRATIS';
                            }


                            $html_list_product_sales = '';
                            $explode_product_sales = explode(',', $item_event->list_product_sales);

                            foreach ($explode_product_sales as $item) {

                                $explode_item = explode('-', $item);

                                $label = '';
                                if ($explode_item[1] == 1) {
                                    $get_product = Modules::run('database/find', 'tb_product', ['id' => $explode_item[0]])->row();
                                    $label = $get_product->code . ' - ' . $get_product->name;
                                }
                                if ($explode_item[1] == 2) {
                                    $get_category = Modules::run('database/find', 'tb_main_category', ['id' => $explode_item[0]])->row();
                                    $label = 'Kategori : ' . $get_category->name;
                                }

                                $html_list_product_sales .= '
                                    <span class="tag mb-1">' . $label . '</span>
                                ';
                            }

                            $product_discount = '';
                            if ($item_event->data_type == 1) {
                                $product_discount = $item_event->product_discount_code . ' - ' . $item_event->product_discount_name;
                            }
                            if ($item_event->data_type == 2) {
                                $product_discount = ' Kategori : ' . $item_event->category_name;
                            }

                            echo '
                                <tr>
                                    <td style="width:45%;">
                                        <div class="row col-12">
                                            <label class=" col-12 font-weight-bold"><span class="badge-light tx-14 p-2">Produk Terjual :</span></label>
                                            <div class="p-2 col-12 border-dashed">' . $html_list_product_sales . '</div>
                                            <div class="p-2 col-6 border-dashed">
                                                <span>Parameter Diskon: <b>' . $array_params_discount[$item_event->param_sales] . '</b></span>
                                            </div>
                                            <div class="p-2 col-6 border-dashed">
                                                <span class="d-block">Nilai Min : <b>' . $item_event->min_sales . '</b></span>
                                                <span class="d-block">Nilai Max : <b>' . $item_event->max_sales . '</b></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td style="width:45%;">
                                        <div class="row col-12">
                                            <label class=" col-12 font-weight-bold "><span class="badge-light tx-14 p-2">Produk Diskon  :</span></label>
                                            <div class="p-2 col-6 border-dashed">
                                                <span>Jenis Diskon: <b>' . $array_type_discount[$item_event->discount_type] . '</b></span>
                                            </div>
                                            <div class="p-2 col-6 border-dashed">
                                                <span class="d-block">Nilai Diskon : <b>' . $value_disc . '</b></span>
                                            </div>
                                            <div class="p-2 col-12 border-dashed">
                                                <span class="tag">' . $product_discount . '</span>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            
                            ';
                        }
                        ?>
                    </tbody>
                </table>
            </form>
        </div>

    </div>
    <!-- /.box-body -->

</div>