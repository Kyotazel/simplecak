<div class="col-md-12">
    <div class="table-responsive">
        <table class="table table-striped table-product">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Produk</th>
                    <th>Nama produk</th>
                    <th>Jual Satuan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 0;
                foreach ($data_product as $item_product) {
                    $counter++;
                    echo '
                                <tr>
                                    <td>' . $counter . '</td>
                                    <td>' . $item_product->code . '</td>
                                    <td>' . strtoupper($item_product->name) . '</td>
                                    <td>Rp.' . number_format($item_product->price, 0, '.', '.') . '</td>
                                    <td class="td_' . $item_product->id . '">
                                        <a href="javascript:void(0)" data-type="' . $type . '" data-id="' . $this->encrypt->encode($item_product->id) . '" class="btn btn-success btn-add-item"><i class="fa fa-send"></i> Pilih</a>
                                    </td>
                                </tr>
                            ';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>