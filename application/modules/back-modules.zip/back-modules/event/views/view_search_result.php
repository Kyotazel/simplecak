<div class="col-md-12">
    <hr>
    <div class="">
        <div class="table-responsive">
            <table class="table table-striped table_data">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>barcode</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th>merk</b></th>
                        <th>Satuan</b></th>
                        <th>stok minimal</b></th>
                        <th>harga pokok</th>
                        <th>harga jual</b></th>
                        <th>persentase untung</th>
                        <th>tgl input</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = $start_no;
                    foreach ($data_product as $data_table) {
                        $persentage = (($data_table->price - $data_table->main_price) / $data_table->main_price) * 100;
                        $no++;
                        echo '
                            <tr>
                                <td>' . $no . '</td>
                                <td>' . $data_table->code . '</td>
                                <td>' . $data_table->barcode . '</td>
                                <td>' . $data_table->name . '</td>
                                <td>' . $data_table->main_category_name . '</td>
                                <td>' . $data_table->merk_name . '</td>
                                <td>' . $data_table->unit_name . '</td>
                                <td>' . $data_table->stock_minimum . '</td>
                                <td>Rp.' . number_format($data_table->main_price, 0, '.', '.') . '</td>
                                <td>Rp.' . number_format($data_table->price, 0, '.', '.') . '</td>
                                <td>' . ceil($persentage) . '%</td>
                                <td>' . $data_table->created_date . '</td>
                                <td>
                                <a href="javascript:void(0)" data-type="' . $type . '" data-id="' . $this->encrypt->encode($data_table->id) . '" class="btn btn-primary btn-rounded btn-add-item"><i class="fa fa-send"></i> Pilih</a>
                                </td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-12">
                    <!--Tampilkan pagination-->
                    <?php echo $html_pagination; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.box-body -->
</div>