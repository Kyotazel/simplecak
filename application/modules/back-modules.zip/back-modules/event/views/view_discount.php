<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-body">
        <form class="form-discount">
            <div class="col-md-12 row">
                <div class="form-group col-md-5">
                    <label for="">Nama Acara</label>
                    <input type="text" class="form-control" name="name">
                    <span class="help-block text-danger notif_name"></span>
                </div>
                <div class="form-group col-md-3">
                    <label for="">Tanggal Akhir Acara</label>
                    <input type="text" name="date" class="form-control bg-white datepicker" readonly>
                    <span class="help-block text-danger notif_date"></span>
                </div>
                <div class="col-md-4">
                    <label for="">&nbsp;</label><br>
                    <button type="button" id="add_button" data-type="1" title="add data" class="btn btn-light  btn-rounded btn_add_get_item">
                        <i class="fa fa-tv"></i> Pilih Produk
                    </button>
                </div>
            </div>
            <div class="col-md-12 border border-radius-5 p-20">
                <table id="table_user" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Kode Produk</th>
                            <th>Nama Produk</th>
                            <th>Harga Jual Satuan</th>
                            <th width="150px">Diskon</th>
                            <th>Batal</th>
                        </tr>
                    </thead>
                    <tbody class="tbody_product">
                    </tbody>
                </table>
            </div>
            <div class="col-md-12 text-right p-20 mt-2">
                <a href="<?= Modules::run('helper/create_url', 'event'); ?>" class="btn btn-light  btn-rounded btn_link"><i class="fa fa-arrow-circle-left"></i> Batal</a>
                <button type="submit" class="btn btn-primary btn-rounded btn-save-discount"><i class="fa fa-save"></i> Simpan Data</button>
            </div>
        </form>

    </div>
    <!-- /.box-body -->

</div>



<div class="modal" id="modal-detail">
    <div class="modal-dialog" style="min-width:80%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal_datail"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light  btn-rounded pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:80%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <form class="form-input">
                    <div class="col-md-12 row">
                        <div class="col-md-3">
                            <label>Kategori Produk</label>
                            <select name="id_category" class="form-control">
                                <option value="">TIDAK ADA</option>
                                <?php
                                foreach ($data_main_category as $item_main_category) {
                                    echo '<option value="' . $this->encrypt->encode($item_main_category->id) . '">' . $item_main_category->name . '</option>';
                                }
                                ?>
                            </select>
                            <span class="help-block text-danger" style="color:red;"></span>
                        </div>
                        <div class="col-md-3">
                            <label>Merk</label>
                            <select name="id_merk" class="form-control">
                                <option value="">TIDAK ADA</option>
                                <?php
                                foreach ($data_merk as $item_merk) {
                                    echo '<option value="' . $this->encrypt->encode($item_merk->id) . '">' . $item_merk->name . '</option>';
                                }
                                ?>
                            </select>
                            <span class="help-block text-danger" style="color:red;"></span>
                        </div>
                        <div class="col-md-3">
                            <label>Barcode</label>
                            <input type="text" class="form-control" name="barcode">
                            <span class="help-block text-danger" style="color:red;"></span>
                        </div>
                        <div class="col-md-3">
                            <label>Nama Produk</label>
                            <input type="text" class="form-control" name="name">
                            <span class="help-block text-danger" style="color:red;"></span>
                        </div>
                        <div class="col-md-12 text-right mt-2">
                            <button type="submit" class="btn btn-primary-gradient btn-rounded btn_search"> <i class="fa fa-search"></i> Cari Data </button>
                        </div>
                    </div>
                </form>
                <span class="clearfix"></span>
                <div class="html_respon_modal"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light  btn-rounded pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>