<?php
$array_type_discount = [
    1 => 'diskon harga',
    2 => 'diskon persentase',
    3 => 'Bonus ( gratis )'
];
?>
<style>
    .datepicker {
        z-index: 10000 !important;
    }
</style>
<div class="col-12">
    <h2>Form Diskon</h2>
</div>
<div class="card">
    <div class="card-header bg-primary-gradient">
        <h4 class="card-title text-white">Keterangan Diskon</h4>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-8 row">
                <div class="form-group col-md-6">
                    <label for="">Nama Acara</label>
                    <input type="text" class="form-control" name="name">
                    <span class="help-block notif_name"></span>
                </div>
                <div class="form-group col-md-3">
                    <label for="">Tanggal Mulai Diskon</label>
                    <input type="text" name="date_from" class="form-control bg-white datepicker" readonly>
                    <span class="help-block notif_date"></span>
                </div>
                <div class="form-group col-md-3">
                    <label for="">Tanggal Akhir Diskon</label>
                    <input type="text" name="date_to" class="form-control bg-white datepicker" readonly>
                    <span class="help-block notif_date"></span>
                </div>
            </div>
            <div class="col-md-4 border-dashed">
                <label for="" class="font-weight-bold text-uppercase m-0"><i class="fa fa-tv"></i> Resume Transaksi</label>
                <div class="row ">
                    <div class="p-2  col-7 d-flex justify-content-start align-items-center border-right">
                        <small>Total Item : &nbsp;</small>
                        <h3 class="text-primary m-0 p-0 total_item_discount">0 ITEM</h3>
                    </div>
                    <div class="col-md-5">
                        <div class="text-right">
                            <button class="btn btn-primary-gradient btn-rounded btn-save-discount"> Simpan Diskon <i class="fa fa-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h4 class="card-title">Detail Produk Terdiskon</h4>
    </div>
    <div class="card-body">
        <div class="col-md-12">
            <form class="form_input_discount">
                <div class="col-md-12 row">
                    <input type="hidden" name="data_product">
                    <div class="col-6 row  p-2 border-dashed">
                        <label for="" class="col-12 font-weight-bold">Produk Terjual :</label>
                        <div class="col-4 mb-2">
                            <label for="">Kategori / Produk</label>
                            <select name="datatype_sales" class="form-control">
                                <option value="1">Produk</option>
                                <option value="2">Kategori</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">(*pilih jenis data)</small>
                        </div>
                        <div class="col-12"></div>
                        <div class="col-12 html-form-category-sales row" style="display:none;">
                            <div class="col-md-12 form-group mb-1">
                                <label>Kategori</label>
                                <input type="hidden" name="id_sales">
                                <select name="subcategory_sales" class="chosen form-control">
                                    <?php
                                    foreach ($data_subcategory as $item_category) {
                                        echo '
                                                <option value="' . $item_category->id . '">' . $item_category->name . '</option>
                                            ';
                                    }
                                    ?>
                                </select>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="col-12 html-form-product-sales row">
                            <div class="col-md-4 form-group mb-1">
                                <label>Kode Barang</label>
                                <input type="hidden" name="id_sales">
                                <input type="text" class="form-control barcode" data-type="sales" name="barcode_sales">
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-6 form-group mb-1">
                                <label>Nama Produk</label>
                                <input type="text" class="form-control product-name" data-type="sales" name="product_name_sales">
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-2 form-group mb-1">
                                <label>&nbsp;</label><br>
                                <a href="javascript:void(0)" class="btn btn-primary-gradient btn-rounded btn_add_item_sales"> Tambah</a>
                                <!-- <small class="d-block">(SHIFT + ENTER)</small> -->
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="col-12 p-2 border-dashed mb-1 list_sales"></div>
                        <div class="col-md-4 form-group mb-1">
                            <label>Parameter Diskon</label>
                            <select name="unit_sales" class="form-control" name="unit">
                                <option value="1">QTY</option>
                                <option value="2">Harga</option>
                            </select>
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-4 form-group mb-1">
                            <label>Nilai Min. Beli</label>
                            <input type="text" class="form-control number_only" name="min_qty_sales">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-4 form-group mb-1">
                            <label>Nilai Maks. Beli</label>
                            <input type="text" class="form-control number_only" name="max_qty_sales">
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-6 row  p-2 border-dashed">
                        <label for="" class="col-12 font-weight-bold">Produk Terdiskon :</label>
                        <div class="col-4 mb-2">
                            <label for="">Kategori / Produk</label>
                            <select name="datatype_discount" class="form-control">
                                <option value="1">Produk</option>
                                <option value="2">Kategori</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">(*pilih jenis data)</small>
                        </div>
                        <div class="col-12"></div>
                        <div class="col-12 html-form-category-discount row" style="display:none;">
                            <div class="col-md-12 form-group mb-1">
                                <label>Kategori</label>
                                <input type="hidden" name="id_sales">
                                <select name="subcategory_discount" class="chosen form-control">
                                    <?php
                                    foreach ($data_subcategory as $item_category) {
                                        echo '
                                                <option value="' . $item_category->id . '">' . $item_category->name . '</option>
                                            ';
                                    }
                                    ?>
                                </select>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="col-12 row html-form-product-discount">
                            <div class="col-md-4 form-group mb-1">
                                <label>Kode Barang</label>
                                <input type="hidden" name="id_bonus">
                                <input type="text" class="form-control barcode" data-type="bonus" name="barcode_bonus">
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-8 form-group mb-1">
                                <label>Nama Produk</label>
                                <input type="text" class="form-control product-name" data-type="bonus" name="product_name_bonus">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <hr class="col-12">
                        <div class="col-md-4 form-group mb-1">
                            <label>Jenis Diskon</label>
                            <select name="unit_discount" class="form-control text-capitalize" name="unit_discount">
                                <?php
                                foreach ($array_type_discount as $key => $value) {
                                    echo '
                                        <option class="text-capitalize" value="' . $key . '">' . $value . '</option>
                                    ';
                                }
                                ?>
                            </select>
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-5 form-group mb-1">
                            <label>Nilai Diskon</label>
                            <input type="text" class="form-control number_only" name="discount_value">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-3 form-group mb-1">
                            <label>&nbsp;</label><br>
                            <a href="javascript:void(0)" class="btn btn-primary-gradient btn-rounded btn_add_item_discount btn-block"><i class="fa fa-plus-circle"></i> Tambah Item</a>
                            <!-- <small class="d-block">(SHIFT + ENTER)</small> -->
                            <span class="help-block"></span>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-12 html_respon m-0 p-0">
            <hr>
            <form class="form-detail-discount">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Produk Terjual</th>
                            <th>Produk Diskon</th>
                            <th style="width:20px;">Batal</th>
                        </tr>
                    </thead>
                    <tbody class="tbody_item detail_request">
                        <tr class="html_no_data">
                            <td colspan="3" class="text-center">
                                <div class="bg-empty-data"></div>
                                <h3 class="text-center text-muted mb-10">Pilihlah Data Produk Diskon</h3>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>

    </div>
    <!-- /.box-body -->

</div>