var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var table;
var id_use;
var type = 0;
var count_item = 0;
$(document).ready(function(){
	table = $('.table-data').DataTable({
        "ajax": {
            "url": url_controller+"/list_data",
            "type": "POST"
        }
    });

    // table_has_paid= $('.table_has_paid').DataTable({
    //     "ajax": {
    //         "url": url_controller+"/list_has_paid",
    //         "type": "POST"
    //     }
    // });
    
    // table_has_paid= $('.table_reject').DataTable({
    //     "ajax": {
    //         "url": url_controller+"/list_reject",
    //         "type": "POST"
    //     }
    // });
    
    //alert('ok');

    // $('.table_payment').DataTable();

    // alert_error('something wrong');
    countdown_timer_unloading();
    $('.chosen').chosen();
})

function reload_table(){
    table.ajax.reload(null, false); //reload datatable ajax
    // table_has_paid.ajax.reload(null,false); //reload datatable ajax
}

$(document).on('click', '.btn_remove', function () {
    var id = $(this).data('id');

    swal({
        title: "Apakah anda yakin?",
        text: "data akan dihapus!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
        function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: url_controller + '/delete_data',
                    type: "POST",
                    data: { 'id': id },
                    dataType: "JSON",
                    success: function (data) {
                        $('#modal-form').modal('hide');
                        notif_success('data berhasil dihapus');
                        reload_table();
                        $('.btn_remove');
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        $('.btn_remove');
                        alert_error('something wrong');
                    }
                });//end ajax
            }
        });
});

$('.barcode').autocomplete({
    source: url_controller + "/get_barcode_choosen",
    select: function(event, ui) {
        event.preventDefault();

        var type = $(this).data('type');
        if (type == 'sales') {
            $('[name="id_sales"]').val(ui.item.id);
            $('[name="barcode_sales"]').val(ui.item.code);
            $('[name="product_name_sales"]').val(ui.item.label);
        } else {
            $('[name="id_bonus"]').val(ui.item.id);
            $('[name="barcode_bonus"]').val(ui.item.code);
            $('[name="product_name_bonus"]').val(ui.item.label);
        }

        get_unit_request(ui.item.id);
        $('[name="qty"]').focus();
    }
});

$('.product-name').autocomplete({
    source: url_controller + "/get_product_auto",
    select: function(event, ui) {
        event.preventDefault();
        var type = $(this).data('type');
        if (type == 'sales') {
            $('[name="id_sales"]').val(ui.item.id);
            $('[name="barcode_sales"]').val(ui.item.code);
            $('[name="product_name_sales"]').val(ui.item.label);
        } else {
            $('[name="id_bonus"]').val(ui.item.id);
            $('[name="barcode_bonus"]').val(ui.item.code);
            $('[name="product_name_bonus"]').val(ui.item.label);
        }

        get_unit_request(ui.item.id);
        $('[name="qty"]').focus();
    }
});

function get_unit_request(id) {
    $.ajax({
	    url: url_controller+'/get_unit_request',
	    type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            $('[name="unit"]').html(data.html_respon);
            $('[name="data_product"]').val(data.data_product);
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_add_product');
	       alert_error('something wrong');
	      }
	  });//end ajax
}



$('[name="datatype_sales"]').change(function () { 
    var data_type = $(this).val();
    if (data_type == 1) {
        $('.html-form-category-sales').hide();
        $('.html-form-product-sales').show();
    } else {
        $('.html-form-category-sales').show();
        $('.html-form-product-sales').hide();
    }
});

$('[name="datatype_discount"]').change(function () { 
    var data_type = $(this).val();
    if (data_type == 1) {
        $('.html-form-category-discount').hide();
        $('.html-form-product-discount').show();
    } else {
        $('.html-form-category-discount').show();
        $('.html-form-product-discount').hide();
    }
});


$('.btn_add_item_sales').click(function () { 
    var id = $('[name="id_sales"]').val();
    var barcode = $('[name="barcode_sales"]').val();
    var name = $('[name="product_name_sales"]').val();

    if (id == '') {
        alert_error('produk belum diisi');
        return false;
    }

    $.ajax({
	    url: url_controller+'/check_availibilty',
	    type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            if (data.status) {
                $(document).find('.list_sales').find('.item_tag_sales_' + id).remove();

                $('.list_sales').append(`
                    <span data-id="`+id+`" class="tag mb-1 item_tag item_tag_sales_`+id+`">
                        ` + name +`
                        <a href="javascript:void(0)" class="tag-addon del_item_tag"><i class="fe fe-x"></i></a>
                    </span>
                `);
            } else {
                alert_error('Produk "'+name+'" ini sudah terdiskon di acara yang lain');
            }

            $('[name="id_sales"]').val('');
            $('[name="barcode_sales"]').val('');
            $('[name="product_name_sales"]').val('');
            $('[name="barcode_sales"]').focus();
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_add_product');
	       alert_error('something wrong');
	      }
    });//end ajax    
});

$(document).on('click', '.del_item_tag', function () { 
    $(this).closest('.tag').remove();   
});

$(document).on('click', '.btn_add_item_discount', function () {
    $('.html_no_data').css('display', 'none');

    var datatype_sales = $('[name="datatype_sales"]').val();
    var list_id_product_sales = '';
    var html_product_sales = $(document).find('.list_sales').html();

    if (datatype_sales == 1) {
        $(document).find('.list_sales').find('.item_tag').each(function () { 
            var id_curent = $(this).data('id');
            list_id_product_sales += id_curent + ',';
        });
    
        if (list_id_product_sales == '') {
            alert_error('Produk terjual Belum Dipilih');
            return false;
        }
    } else {
        list_id_product_sales = $('[name="subcategory_sales"]').val();

        var gettext = $('[name="subcategory_discount"]').find('option:selected').text();
        html_product_sales = '<span class="badge badge-info tx-15">Kategori : ' + gettext + '</span>';

        if (list_id_product_sales == '') {
            alert_error('Kategori Produk Terjual Belum Dipilih');
            return false;
        }
    }
    
   
    var unit_sales_name = $('[name="unit_sales"] option:selected').text();
    var unit_sales_id = $('[name="unit_sales"]').val();
    var value_min_sales = $('[name="min_qty_sales"]').val();
    var value_max_sales = $('[name="max_qty_sales"]').val();
    var product_name_bonus = $('[name="product_name_bonus"]').val();

    var datatype_discount = $('[name="datatype_discount"]').val();
    if (datatype_discount == 1) {
        var id_product_bonus = $('[name="id_bonus"]').val();
        if (id_product_bonus == '') {
            alert_error('Produk Diskon Belum Dipilih');
            return false;
        }
    } else {
        var id_product_bonus = $('[name="subcategory_discount"]').val();
        product_name_bonus = 'Kategori : '+$('[name="subcategory_discount"]').find('option:selected').text();
        if (id_product_bonus == '') {
            alert_error('Kategori Produk Diskon Belum Dipilih');
            return false;
        }
    }

    
    var barcode_bonus = $('[name="barcode_bonus"]').val();
    var unit_discount_name = $('[name="unit_discount"] option:selected').text();
    var unit_discount_id = $('[name="unit_discount"]').val();
    var discount_value = $('[name="discount_value"]').val();



    var html_append = `
        <tr>
            <input type="hidden" name="datatype_sales[]" value="`+ datatype_sales +`">
            <input type="hidden" name="id_product_sales[]" value="`+ list_id_product_sales +`">
            <input type="hidden" name="unit_sales_id[]" value="`+ unit_sales_id +`">
            <input type="hidden" name="value_min_sales[]" value="`+ value_min_sales +`">
            <input type="hidden" name="value_max_sales[]" value="`+ value_max_sales +`">

            <input type="hidden" name="datatype_discount[]" value="`+ datatype_discount +`">
            <input type="hidden" name="id_product_bonus[]" value="`+ id_product_bonus +`">
            <input type="hidden" name="unit_discount_id[]" value="`+ unit_discount_id +`">
            <input type="hidden" name="discount_value[]" value="`+ discount_value +`">
            
            <td style="width:45%;">
                <div class="row col-12">
                    <label class="badge col-12"><span class="badge-light tx-14">Produk Terjual :</span></label>
                    <div class="p-2 col-12 border-dashed">`+ html_product_sales +`</div>
                    <div class="p-2 col-6 border-dashed">
                        <span>Parameter Diskon: <b>`+unit_sales_name+`</b></span>
                    </div>
                    <div class="p-2 col-6 border-dashed">
                        <span class="d-block">Nilai Min : <b>`+ value_min_sales +`</b></span>
                        <span class="d-block">Nilai Max : <b>`+value_max_sales+`</b></span>
                    </div>
                </div>
            </td>
            <td style="width:45%;">
                <div class="row col-12">
                    <label class="badge col-12"><span class="badge-light tx-14">Produk Diskon  :</span></label>
                    <div class="p-2 col-6 border-dashed">
                        <span>Jenis Diskon: <b>`+unit_discount_name+`</b></span>
                    </div>
                    <div class="p-2 col-6 border-dashed">
                        <span class="d-block">Nilai Diskon : <b>`+discount_value  +`</b></span>
                    </div>
                    <div class="p-2 col-12 border-dashed">
                        <span class="tag">`+product_name_bonus+`</span>
                    </div>
                </div>
            </td>
            <td>
                <a href="javascript:void(0)" class="btn btn-danger btn-pill btn-cancel-item"><i class="fa fa-times"></i></a>
            </td>
        </tr>
    `;
    $('.detail_request').append(html_append);
    $(document).find('.list_sales').html('');
    $('.form_input_discount')[0].reset();
    $('[name="datatype_sales"]').change();
    $('[name="datatype_discount"]').change();

    count_item = count_item + 1;
    $('.total_item_discount').text(count_item + ' ITEM');
});

$(document).on('click', '.btn-cancel-item', function () { 
    $(this).closest('tr').remove();
    count_item = count_item - 1;
    $('.total_item_discount').text(count_item + ' ITEM');
});

$(document).on('click', '.btn-save-discount', function (e) { 
    e.preventDefault();
    var name = $('[name="name"]').val();
    if (name == '') {
        alert_error('nama acara harus diisi');
        return false;
    }
    
    var date_from = $('[name="date_from"]').val();
    if (date_from == '') {
        alert_error('tanggal awal harus diisi');
        return false;
    }
    var date_to = $('[name="date_to"]').val();
    if (date_to == '') {
        alert_error('tanggal akhir harus diisi');
        return false;
    }

    swal({
        title: 'Apakah anda yakin?',
        text: "pastikan Data Sudah Benar",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,simpan data',
        cancelButtonText: 'Batal'
    },
        function (isConfirm) {
            if (isConfirm) {
                save_discount();
            }
        });

});

function save_discount() {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();

    var name = $('[name="name"]').val();
    var date_from = $('[name="date_from"]').val();
    var date_to = $('[name="date_to"]').val();
    //defined form
    var formData = new FormData($('.form-detail-discount')[0]);
    formData.append('name', name);
    formData.append('date_from', date_from);
    formData.append('date_to', date_to);
    $.ajax({
        url: url_controller + '/save_discount',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                alert_success('Data Berhasil Disimpan');
                window.location.href = url_controller+'detail?data='+data.id_url;
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_' + data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                        $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                    }
                }
            }
            hideLoading();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
}


$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
});

$(document).on('keyup', '.money_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    var money = money_function(qty, '');
    $(this).val(money);
});


function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    return rupiah;
}

function countdown_timer_unloading() {
    var x = setInterval(function() {
        $('.countdown_unloading').each(function () {
            type = $(this).data('type');
            //alert(type);
            
            if (type == 'datetime') {
                date_to = $(this).data('date-to');
            } else {
                date_to = $(this).data('date-to') + ' 00:00:00';
            }
            
            selector = $(this);
            console.log(date_to);
            var countDownDate = new Date(date_to).getTime();
            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            selector.find('.text_day').text(days);
            selector.find('.text_hour').text(hours);
            selector.find('.text_minute').text(minutes);
            selector.find('.text_second').text(seconds);
            // If the count down is finished, write some text
            if (distance < 0) {
                //clearInterval(x);
                selector.parent().html(`
                    <h3 class="text-muted text-center">EXPIRED</h3>
                `);
            }
        });

    }, 1000);
}