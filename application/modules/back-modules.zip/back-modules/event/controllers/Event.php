<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Event extends BackendController
{
    var $module_name        = 'event';
    var $module_directory   = 'event';
    var $module_js          = ['event'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();

        $this->app_data['page_title'] = "Event";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        Modules::run('security/is_ajax');
        $array_query = [
            'select' => '
                tb_event.*,
                COUNT(tb_event_has_discount.id) AS count_data
            ',
            'from' => 'tb_event',
            'join' => [
                'tb_event_has_discount, tb_event.id = tb_event_has_discount.id_event, left'
            ],
            'group_by' => 'tb_event.id'
        ];
        $list_data = Modules::run('database/get', $array_query)->result();
        $no = 0;
        $data = [];
        foreach ($list_data as $data_table) {
            $no++;
            //create date 
            $status_on = $data_table->status ? 'on' : '';
            $row = array();
            $row[] = $no;
            $row[] = strtoupper($data_table->name);
            $row[] = Modules::run('helper/date_indo', $data_table->start_date, '-');
            $row[] = Modules::run('helper/date_indo', $data_table->expired_date, '-');
            $row[] = $data_table->count_data . ' ITEM';
            $row[] = '
                    <div class="row col-12 mb-1 countdown_unloading" data-date-now="' . $data_table->start_date . '" data-date-to="' . $data_table->expired_date . '">
                        <div class="col-3 p-1 border rounded text-center">
                            <h5 for="" class="p-0 m-0 text-danger text_day">-</h5>
                            <small for="" class="d-block font-weight-bold">Hari</small>
                        </div>
                        <div class="col-3 p-1 border rounded text-center">
                            <h5 for="" class="p-0 m-0 text-danger text_hour">-</h5>
                            <small for="" class="d-block font-weight-bold">Jam</small>
                        </div>
                        <div class="col-3 p-1 border rounded text-center">
                            <h5 for="" class="p-0 m-0 text-danger text_minute">-</h5>
                            <small for="" class="d-block font-weight-bold">Menit</small>
                        </div>
                        <div class="col-3 p-1 border rounded text-center">
                            <h5 for="" class="p-0 m-0 text-danger text_second">-</h5>
                            <small for="" class="d-block font-weight-bold">Detik</small>
                        </div>
                    </div>
            ';
            $row[] = '
                <div class="main-toggle main-toggle-dark change_status_maintenance ml-3 ' . $status_on . '"><span></span></div>
            ';
            $row[] = '
                <a href="' . Modules::run('helper/create_url', 'event/detail?data=' . urlencode($this->encrypt->encode($data_table->id))) . '" class="btn btn-primary-gradient btn-rounded  font-weight-bold">Detail</a>
            ';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function add()
    {
        $this->app_data['data_main_category'] = $this->db->get('tb_main_category')->result();
        $this->app_data['data_subcategory'] = Modules::run('database/find', 'tb_main_category', ['type' => 3])->result();

        $this->app_data['page_title'] = "FORM ACARA DISKON";
        $this->app_data['view_file'] = 'view_add';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    //===================== autocomplete ===================================


    public function get_product()
    {
        $this->db->select('
                            tb_product.id ,
                            tb_product.code,
                            tb_product.name,
                            tb_product.stock,
                            tb_product.qty_unit,
                            tb_product.main_price,
                            tb_product.main_unit_price,
                            tb_unit.name AS unit_name,
                            tb_base_unit.name AS base_unit_name
                        ');
        $this->db->from('tb_product');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_base_unit', 'tb_unit.id_base_unit = tb_base_unit.id', 'left');
        // $this->db->where(['tb_product.status' => TRUE]);
        $get_data_product = $this->db->order_by('tb_product.name')->get()->result();
        $data['data_product'] = $get_data_product;
        $html_respon = $this->load->view($this->location . 'view_list_product', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function get_product_auto()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                                                    a.id,
                                                    a.code, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
			 									    where a.name like '%$term%' LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->code . ' - ' . $data_product->name,
                        'id' => $data_product->id,
                        'code' => $data_product->code,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_barcode_choosen()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                                                    a.id,
                                                    a.code, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
			 									    where a.code like '%$term%' LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->code . ' - ' . $data_product->name,
                        'code' => $data_product->code,
                        'id' => $data_product->id,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_unit_request()
    {
        $id = $this->input->post('id');
        $get_data_current = $this->db->where(['id' => $id])->get('tb_product')->row();
        $data_unit = $this->db->where(['id' => $get_data_current->id_unit])->get('tb_unit')->row();
        //get other conversion
        $get_all_conversion = $this->db->where(['id_product' => $id])->order_by('qty')->get('tb_product_has_conversion')->result();
        $array_value = [
            'id' => 0,
            'name' => $data_unit->name,
            'qty' => 1
        ];
        $html_option = '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $data_unit->name . '</option>';
        foreach ($get_all_conversion as $item_conversion) {
            $array_value = [
                'id' => $item_conversion->id,
                'name' => $item_conversion->name,
                'qty' => $item_conversion->qty
            ];
            $html_option .= '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $item_conversion->name . '</option>';
        }

        $array_respon = [
            'html_respon' => $html_option,
            'status' => TRUE,
            'data_product' => $this->encrypt->encode(json_encode($get_data_current)),
            'stock_warehouse' => $get_data_current->stock_warehouse
        ];
        echo json_encode($array_respon);
    }
    //===================================== end autocomplete =================================================================

    public function check_availibilty()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $array_query = [
            'from' => 'tb_event',
            'join' => [
                'tb_event_has_discount, tb_event.id = tb_event_has_discount.id_event, left',
                'tb_event_has_product_sales, tb_event_has_discount.id = tb_event_has_product_sales.id_event_has_discount AND tb_event_has_product_sales.id_product = ' . $id . ' , left',
            ],
            'where' => [
                'tb_event.status' => 1,
                'tb_event_has_discount.status' => 1,
                'tb_event_has_product_sales.id_product' => $id
            ]
        ];
        $get_data = Modules::run('database/get', $array_query)->row();

        // if (!empty($get_data)) {
        //     echo json_encode(['status' => false]);
        // } else {
        //     echo json_encode(['status' => true]);
        // }

        echo json_encode(['status' => true]);
    }

    public function save_discount()
    {
        Modules::run('security/is_ajax');

        $datatype_sales = $this->input->post('datatype_sales');
        $id_product_sales = $this->input->post('id_product_sales');
        $unit_sales_id = $this->input->post('unit_sales_id');
        $value_min_sales = $this->input->post('value_min_sales');
        $value_max_sales = $this->input->post('value_max_sales');

        $datatype_discount = $this->input->post('datatype_discount');
        $id_product_bonus = $this->input->post('id_product_bonus');
        $unit_discount_id = $this->input->post('unit_discount_id');
        $discount_value = $this->input->post('discount_value');

        $name = $this->input->post('name');
        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');

        $array_insert = [
            'name' => $name,
            'start_date' => $date_from,
            'expired_date' => $date_to,
            'status' => 1,
            'created_by' => $this->session->userdata('us_id')
        ];
        Modules::run('database/insert', 'tb_event', $array_insert);

        //get id
        $get_max_id = $this->db->select('MAX(id) AS max_id')->get('tb_event')->row();
        //insert discount
        foreach ($id_product_sales as $key => $value) {

            $id_product_sales_current   = $id_product_sales[$key];
            $unit_sales_id_current      = $unit_sales_id[$key];
            $value_min_sales_current    = $value_min_sales[$key];
            $value_max_sales_current    = $value_max_sales[$key];
            $datatype_sales_current     = $datatype_sales[$key];


            $id_product_bonus_current   = $id_product_bonus[$key];
            $unit_discount_id_current   = $unit_discount_id[$key];
            $discount_value_current     = $discount_value[$key];
            $datatype_discount_current     = $datatype_discount[$key];


            $array_insert_bonus = [
                'id_event' => $get_max_id->max_id,
                'param_sales' => $unit_sales_id_current,
                'min_sales' => $value_min_sales_current,
                'max_sales' => $value_max_sales_current,
                'discount_type' => $unit_discount_id_current,
                'id_product_discount' => $id_product_bonus_current,
                'discount_value' => $discount_value_current,
                'status' => 1,
                'data_type' => $datatype_discount_current
            ];
            Modules::run('database/insert', 'tb_event_has_discount', $array_insert_bonus);
            $max_bonus = $this->db->select('MAX(id) AS max_id')->get('tb_event_has_discount')->row();

            $explode_product_sales = explode(',', $id_product_sales_current);
            foreach ($explode_product_sales as $item_product_current) {
                if (empty($item_product_current) || $item_product_current == '') {
                    continue;
                }
                $array_insert_detail_sales = [
                    'id_event_has_discount' => $max_bonus->max_id,
                    'id_product' => $item_product_current,
                    'data_type' => $datatype_sales_current
                ];
                Modules::run('database/insert', 'tb_event_has_product_sales', $array_insert_detail_sales);
            }
        }

        echo json_encode(['status' => TRUE, 'id_url' => urlencode($this->encrypt->encode($get_max_id->max_id))]);
    }

    public function detail()
    {
        $id =  $this->encrypt->decode($this->input->get('data'));
        $data_event = Modules::run('database/find', 'tb_event', ['id' => $id])->row();
        $this->app_data['data_event'] = $data_event;

        $array_detail_discount = [
            'select' => '
                tb_event_has_discount.*,
                tb_main_category.name AS category_name,
                tb_product.code AS product_discount_code,
                tb_product.name AS product_discount_name,
                GROUP_CONCAT(tb_event_has_product_sales.id_product,"-",tb_event_has_product_sales.data_type) AS list_product_sales
            ',
            'from' => 'tb_event_has_discount',
            'join' => [
                'tb_product, tb_event_has_discount.id_product_discount = tb_product.id , left',
                'tb_event_has_product_sales, tb_event_has_discount.id = tb_event_has_product_sales.id_event_has_discount , left',
                'tb_product AS product_sales, tb_event_has_product_sales.id_product = product_sales.id , left',
                'tb_main_category, tb_event_has_discount.id_product_discount = tb_main_category.id , left',
            ],
            'where' => [
                'tb_event_has_discount.id_event' => $id
            ],
            'group_by' => 'tb_event_has_discount.id'
        ];
        $get_detail = Modules::run('database/get', $array_detail_discount)->result();
        $this->app_data['detail_event'] = $get_detail;

        $this->app_data['page_title'] = "DETAIL DISKON";
        $this->app_data['view_file'] = 'view_detail';
        echo Modules::run('template/main_layout', $this->app_data);
    }
}
