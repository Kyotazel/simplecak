<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales_invoice extends BackendController
{
    var $module_name        = 'sales_invoice';
    var $module_directory   = 'sales_invoice';
    var $module_js          = ['sales_invoice'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "SALES INVOICE";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function get_code()
    {
        $number_text = 0;
        $db_name = 'tb_receipt';
        $simbol = 'GR';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }


    public function list_data_request()
    {

        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $id_customer = $this->input->post('id_customer');
        $status = $this->input->post('status');



        $array_where = [];
        $array_where_in = [];

        $array_where['tb_sales.status'] = 0;

        if ($date_from) {
            $array_where['tb_sales.date >='] = $date_from;
        }
        if ($date_to) {
            $array_where['tb_sales.date <='] = $date_to;
        }
        if ($id_customer) {
            $array_where_in['tb_sales.id_member'] = $id_customer;
        }
        if ($status) {
            $array_where['tb_sales.status'] = $status;
        }


        $array_query = [
            'select' => '
                tb_sales.*,
                mst_customer.code AS customer_code,
                mst_customer.name AS customer_name,
                mst_customer.address AS customer_address,
            ',
            'from' => 'tb_sales',
            'join' => [
                'mst_customer,tb_sales.id_member = mst_customer.id,left'
            ],
            'group_by' => 'tb_sales.id',
            'order_by' => 'tb_sales.id, DESC'
        ];



        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }




        $get_data = Modules::run('database/get', $array_query)->result();

        $data_po['data_so'] = $get_data;
        $html_po = $this->load->view('view_search_result', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }

    public function confirm_so()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $status = $this->input->post('status');
        $confirm = 2;


        if ($status == 1) {
            $confirm = 1;

            $get_so = Modules::run('database/find', 'tb_sales', ['id' => $id])->row();
            $member = Modules::run('database/find', 'mst_customer', ['id' => $get_so->id_member])->row();

            $deadline = date('Y-m-d', strtotime('+' . $member->top_nota . ' days', strtotime($get_so->date))); //operasi penjumlahan tanggal sebanyak 6 hari

            $desc = 'Piutang SO : ' . $get_so->code;
            $array_insert = [
                'id_transaction' => $id,
                'invoice_code' => $get_so->code,
                'description' => $desc,
                'price' => $get_so->grand_total_sales,
                'rest_credit' => $get_so->grand_total_sales,
                'date' => $get_so->date,
                'deadline' => $deadline,
                'id_customer' => $get_so->id_member
            ];
            Modules::run('credit/insert_credit', $array_insert);
        }
        $array_update = [
            'is_confirm' => $confirm,
            'status' => $status
        ];
        Modules::run('database/update', 'tb_sales', ['id' => $id], $array_update);
        echo json_encode(['status' => TRUE]);
    }
}
