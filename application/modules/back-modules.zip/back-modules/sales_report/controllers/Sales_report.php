<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales_report extends CI_Controller
{
    var $location = 'data_sales_report/';
    var $module_name = 'sales_report';
    var $js_page    = 'sales_report';

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function index()
    {
        $data['data_member'] = $this->db->query("select * from tb_member order by id DESC")->result();
        // $data['data_product'] = $this->db->query("select id,name from tb_product order by id DESC")->result();
        $data['tagline_page'] = "LAPORAN PENJUALAN";
        $data['view_file'] = $this->location . 'form';
        $this->load->view('template/media_admin', $data);
    }

    public function change_to_sql_date($date)
    {
        $date_explode = explode('-', $date);
        $date_sql = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        return $date_sql;
    }

    public function validate_input()
    {
        $status = false;
        $date_from     = $this->input->post('date_from');
        $date_to     = $this->input->post('date_to');

        if ($date_from == '') {
            $this->session->set_flashdata('error_date_from', 'harus disi dulu');
            $status = TRUE;
        }
        if ($date_to == '') {
            $this->session->set_flashdata('error_date_to', 'harus disi dulu');
            $status = TRUE;
        }

        if ($status == TRUE) {
            redirect(base_url($this->module_name));
        }
    }

    public function get_report()
    {
        $data['data_member'] = $this->db->query("select * from tb_member order by id DESC")->result();
        // $data['data_product'] = $this->db->query("select id,name from tb_product order by name")->result();
        $this->validate_input();

        $date_from     = $this->change_to_sql_date($this->input->post('date_from'));
        $date_to     = $this->change_to_sql_date($this->input->post('date_to'));
        $id_member     = $this->input->post('id_member');
        $id_product = $this->input->post('id_product');
        //create where
        $range_product = 'SEMUA BARANG';
        $range_member = 'SEMUA MEMBER';
        // $where_form = "where b.date BETWEEN '$date_from' AND '$date_to' ";
        // if (!empty($id_product)) {
        //     $where_form .= " AND a.id_product = '$id_product' ";
        //     //get dta product choosen
        //     $get_data_product_choosen = $this->db->query("select name from tb_product where id = '$id_product' ")->row_array();
        //     $range_product = $get_data_product_choosen['name'];
        // }
        $where_form = '';
        if (!empty($id_member)) {
            $where_form .= " AND b.id_member = '$id_member' ";
            $get_data_member_choosen = $this->db->query("select name from tb_member where id = '$id_member' ")->row_array();
            $range_member = $get_data_member_choosen['name'];
        }
        //decide view file
        // $view_file = '';
        // if (!empty($id_product)) {
        //     $view_file = 'view_base_product';
        // } else {
        //     $view_file = 'view_all_item';
        // }

        $view_file = 'view_all_item';

        //creta array range
        $array_range = array(
            'date_from' => $this->input->post('date_from'),
            'date_to' => $this->input->post('date_to'),
            'product' => $range_product,
            'member' => $range_member
        );

        $this->db->select('
            tb_sales.*,
            tb_member.name AS member_name,
            tb_member.code AS member_code
            ');
        $this->db->from('tb_sales');
        $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
        $this->db->where(['tb_sales.date>=' => $date_from, 'tb_sales.date<=' => $date_to]);
        $get_data_report = $this->db->get();
        // print_r($this->db->last_query());
        //decide view file
        $data['array_range'] = $array_range;
        $data['data_result'] = $get_data_report;
        $data['tagline_page'] = "LAPORAN PENJUALAN";
        $data['view_file'] = $this->location . $view_file;
        $this->load->view('template/media_admin', $data);
    }

    public function print_all_item()
    {
        if ($this->input->post('last_query') == '') {
            redirect(base_url('sales_report'));
        }

        ob_clean();
        $query = $this->input->post('last_query');
        $query = str_replace('group by code_sales', '', $query);
        $query = str_replace('SUM(a.total_price) as grand_total_buy,', '', $query);
        $data['data_result'] = $this->db->query($query)->result();
        $data['data_range'] = json_decode(str_replace("'", '"', $this->input->post('array_range')));
        //profile 
        $data['data_profile'] = $this->db->get('tb_profile')->row_array();
        ob_start();
        $this->load->view('print_sales/print_all_item', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('./assets/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en');
        $pdf->WriteHTML($html);
        $pdf->Output('laporan penjualan (' . date('d-m-Y') . ').pdf', 'D');
    }

    public function print_base_on_product()
    {
        if ($this->input->post('last_query') == '') {
            redirect(base_url('sales_report'));
        }
        ob_clean();
        $query = $this->input->post('last_query');
        $array_data = json_decode(str_replace("'", '"', $this->input->post('data_range')));
        $data['data_range'] = $array_data;
        $data['data_result'] = $this->db->query($query)->result();
        $data['data_profile'] = $this->db->get('tb_profile')->row_array();
        ob_start();
        $this->load->view('print_sales/print_base_on_product', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('./assets/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en');
        $pdf->WriteHTML($html);
        $pdf->Output('laporan penjualan (' . date('d-m-Y') . ').pdf', 'D');
    }

    public function sales_book()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "LAPORAN SETORAN KASIR";
        $data['view_file'] = $this->location . 'form_sales_book';
        $this->load->view('template/media_admin', $data);
    }

    private function validate_search_sales_recapitulation()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date_from') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_from';
            $data['status'] = FALSE;
        }

        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }

        if (!empty($_POST['date_from']) && !empty($_POST['date_to'])) {
            if (strtotime($_POST['date_to']) < strtotime($_POST['date_from'])) {
                $data['error_string'][] = 'harus lebih besar dari tanggal awal';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function search_sales_recapitulation()
    {
        $this->validate_search_sales_recapitulation();
        $date_from  = $this->change_to_sql_date($this->input->post('date_from'));
        $date_to    = $this->change_to_sql_date($this->input->post('date_to'));
        $cashier    = $this->input->post('cashier');

        if (!empty($cashier)) {
            $this->db->where(['tb_sales_recapitulation.created_by' => $cashier]);
        }
        $this->db->select('
            tb_sales_recapitulation.*,
            tb_user.name AS user_name
            ');
        $this->db->from('tb_sales_recapitulation');
        $this->db->join('tb_user', 'tb_sales_recapitulation.created_by = tb_user.id', 'left');
        $this->db->where(['DATE(tb_sales_recapitulation.created_date) >=' => $date_from, 'DATE(tb_sales_recapitulation.created_date) <=' => $date_to]);
        $this->db->order_by('tb_sales_recapitulation.sales_date', 'DESC');
        $get_data = $this->db->get()->result();
        $data['data_sales'] = $get_data;

        $data['date'] = [
            'date_from' => $this->input->post('date_from'),
            'date_to' => $this->input->post('date_to')
        ];

        $view_file = $this->load->view($this->location . 'view_result_sales_recapitulation', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $view_file
        ];
        echo json_encode($array_respon);
    }

    public function print_sales_recapitulation_excel()
    {
        $data_result = $this->encrypt->decode($this->input->post('data_result'));
        $array_result = json_decode($data_result);

        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('5');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('20');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');
        $sheet->getColumnDimension('L')->setWidth('20');
        $sheet->getColumnDimension('M')->setWidth('20');
        $sheet->getColumnDimension('N')->setWidth('20');
        $sheet->getColumnDimension('O')->setWidth('20');
        $sheet->getColumnDimension('P')->setWidth('20');
        $sheet->getColumnDimension('Q')->setWidth('20');
        $sheet->getColumnDimension('R')->setWidth('20');
        $sheet->getColumnDimension('S')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:L2")->getFont()->setBold(true);

        //marge and center
        $sheet->mergeCells('A1:Q2');
        $sheet->getStyle('A1:Q2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:Q2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN BUKU PENJUALAN');
        $sheet->getStyle('A3:Q3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A3"; // or any value
        $to = "S3"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'TANGGAL TUTUP SHIFT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'KASIR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'TOTAL NOTA PENJUALAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'TOTAL NOTA DEPOSITO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'UANG MODAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G3', 'TOTAL PEMB. DEPOSITO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H3', 'TOTAL PEMB. POINT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I3', 'TOTAL PIUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J3', 'TOTAL OMSET PENJUALAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K3', 'TOTAL UANG CASH');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L3', 'TOTAL UANG DEPOSITO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M3', 'UANG DIPAKAI');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N3', 'TOTAL WAJIB SETOR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O3', 'NOMINAL SETOR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P3', 'MARGIN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('Q3', 'CATATAN');
        $no = 0;
        $array_status = [
            0 => 'Belum Lunas',
            1 => 'Telah Lunas',
            2 => 'Dibatalkan'
        ];
        $array_status_expired = [
            0 => 'Belum Jatuh Tempo',
            1 => 'Telah Jatuh Tempo'
        ];

        $sheet_number_resume = 3;
        $sheet_number_detail = 0;
        foreach ($array_result as $data_table) {

            $sheet_number_resume++;
            $no++;

            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->date);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_table->cashier);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->total_invoice);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->total_invoice_deposito);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->capital_money);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_table->deposito_price_sales);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->point_price_sales);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume, $data_table->total_credit_price);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $data_table->total_omset_sales);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $sheet_number_resume, $data_table->cash_price_sales);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L' . $sheet_number_resume, $data_table->total_price_deposito);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M' . $sheet_number_resume, $data_table->price_usage);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N' . $sheet_number_resume, $data_table->total_price);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O' . $sheet_number_resume, $data_table->total_price_report);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P' . $sheet_number_resume, $data_table->margin);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('Q' . $sheet_number_resume, $data_table->note);
            $sheet_number_detail = $sheet_number_resume;
        }
        // $sheet_number_detail += 1;
        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN' . date('d-m-Y'));
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN BUKU PENJUALAN ' . date('d-m-Y') . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function get_excel()
    {
        $data_result = $this->encrypt->decode($this->input->post('data_result'));
        $array_result = json_decode($data_result);

        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('5');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('20');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');
        $sheet->getColumnDimension('L')->setWidth('20');
        $sheet->getColumnDimension('M')->setWidth('20');
        $sheet->getColumnDimension('N')->setWidth('20');
        $sheet->getColumnDimension('O')->setWidth('20');
        $sheet->getColumnDimension('P')->setWidth('20');
        $sheet->getColumnDimension('Q')->setWidth('20');
        $sheet->getColumnDimension('R')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:R2")->getFont()->setBold(true);

        //marge and center
        $sheet->mergeCells('A1:R2');
        $sheet->getStyle('A1:R2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:R2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN NOTA PENJUALAN');
        $sheet->getStyle('A3:R3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A3"; // or any value
        $to = "R3"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'NO NOTA');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'MEMBER');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'TOTAL DISKON');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'TOTAL PEMBELIAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G3', 'PPN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H3', 'TOTAL PPN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I3', 'PPH');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J3', 'TOTAL PPH');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K3', 'TOTAL WAJIB BAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L3', 'TOTAL HPP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M3', 'PERSENTASE UNTUNG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N3', 'DEPOSITO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O3', 'POINT');
        // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O3', 'UANG TUNAI');
        // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P3', 'TOTAL BAYAR');
        // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('Q3', 'KEMBALI');
        // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R3', 'NOMINAL PIUTANG');
        $no = 0;
        $array_status = [
            0 => 'Belum Lunas',
            1 => 'Telah Lunas',
            2 => 'Dibatalkan'
        ];
        $array_status_expired = [
            0 => 'Belum Jatuh Tempo',
            1 => 'Telah Jatuh Tempo'
        ];

        //total
        $grand_total_sales = 0;
        $total_ppn = 0;
        $total_pph = 0;
        $total_hpp = 0;
        $total_advantage = 0;
        $grand_total = 0;


        $sheet_number_resume = 3;
        $sheet_number_detail = 0;
        $grand_total_discount = 0;
        foreach ($array_result as $data_table) {


            $ppn_percentage = $data_table->ppn_price > 0 ? $data_table->ppn : 0;
            $pph_percentage = $data_table->pph_price > 0 ? $data_table->pph : 0;
            $percentage_advantage = (($data_table->grand_total_sales - $data_table->grand_total_hpp) / $data_table->grand_total_sales);

            //total
            $grand_total_sales += $data_table->grand_total_sales;
            $total_ppn += $data_table->ppn_price;
            $total_pph += $data_table->pph_price;
            $total_hpp += $data_table->grand_total_hpp;
            $total_advantage += $percentage_advantage;
            $grand_total += $data_table->grand_total;
            $grand_total_discount += $data_table->total_discount_product;

            $date_explode = explode('-', $data_table->date);
            $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];



            $sheet_number_resume++;
            $no++;
            $credit_status = $data_table->credit_status ? 'PIUTANG' : 'LUNAS';

            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->code);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_table->member_code);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $date_html);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->total_discount_product);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->grand_total_sales);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $ppn_percentage . '%');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->ppn_price);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume, $pph_percentage);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $data_table->pph_price);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $sheet_number_resume, $data_table->grand_total);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L' . $sheet_number_resume, $data_table->grand_total_hpp);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M' . $sheet_number_resume, $percentage_advantage);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N' . $sheet_number_resume, $data_table->deposito_payment);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O' . $sheet_number_resume, $data_table->point_payment);
            // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O' . $sheet_number_resume, $data_table->cash_payment);
            // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P' . $sheet_number_resume, $data_table->payment);
            // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('Q' . $sheet_number_resume, $data_table->rest_payment);
            // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R' . $sheet_number_resume, $data_table->credit_price);
            $sheet_number_detail = $sheet_number_resume;
        }
        $sheet_number_detail += 1;
        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN' . date('d-m-Y'));
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN NOTA PENJUALAN ' . date('d-m-Y') . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }
}
