<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>

    <?php
    $get_cashier = $this->db->where(['level' => 1])->get('tb_user')->result();
    ?>

    <div class="card-body">
        <form class="form-search">
            <div class="col-md-12 border border-radius-5 p-10">
                <div class="col-md-7">
                    <div class="col-md-5 form-group">
                        <label>Tanggal Awal</label>
                        <input type="text" class="form-control datepicker" name="date_from" placeholder="klik untuk pilih tanggal..." readonly style="background-color:#fff;">
                        <span class="help-block" style="color:red;"></span>
                    </div>
                    <div class="col-md-1" align="center">
                        <label style="padding-top:30px;">S/d</label>
                    </div>
                    <div class="col-md-6 form-group">
                        <label>Tanggal Akhir</label>
                        <input type="text" class="form-control datepicker" name="date_to" placeholder="klik untuk pilih tanggal..." readonly style="background-color:#fff;">
                        <span class="help-block" style="color:red;"></span>
                    </div>
                </div>
                <div class="col-md-3 form-group">
                    <label>Kasir</label>
                    <select name="cashier" class="form-control" id="">
                        <option value="">Semua Kasir</option>
                        <?php
                        foreach ($get_cashier as $item_cashier) {
                            echo '<option value="' . $item_cashier->id . '">' . $item_cashier->name . '</option>';
                        }
                        ?>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-2">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-success btn-search"><i class="fa fa-send"></i> Ambil Data</button>
                </div>
            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>

<div class="html_respon"></div>