<?php
$this->load->view('data_sales_report/form');
?>

<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <h4>Hasil Pencarian</h4>
    </div>
    <div class="card-body">
        <div class="col-md-6">
            <table style="width:100%;" style="font-size:20px;">
                <?php
                echo '
                		<tr>
		                  <td width="50px">Range</td>
		                  <td width="10px" align="center">:</td>
		                  <td>' . $array_range['date_from'] . '&nbsp;&nbsp;s/d&nbsp;&nbsp;' . $array_range['date_to'] . '</td>
		                </tr>
		                <tr>
		                  <td width="50px">Member</td>
		                  <td width="5px">:</td>
		                  <td>' . $array_range['member'] . '</td>
		                </tr>
                	';

                ?>
            </table>
        </div>
        <span class="clearfix"></span>
        <hr>
        <table class="table table_list table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Nota</th>
                    <th>member</th>
                    <th>tanggal</th>
                    <th>Total Diskon</th>
                    <th>Total Pembelian</th>
                    <th>PPN</th>
                    <th>Total PPN</th>
                    <th>PPH</th>
                    <th>Total PPH</th>
                    <th>Total Wajib Bayar</th>
                    <th>Total HPP</th>
                    <th>Persentase Keuntungan</th>
                    <th>Deposito</th>
                    <th>Point</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $encrypt_post_data = $this->encrypt->encode(json_encode($data_result->result()));
                $no = 0;
                $total_grand = 0;
                $total_payment = 0;
                $total_rest_payment = 0;

                //total
                $grand_total_sales = 0;
                $total_ppn = 0;
                $total_pph = 0;
                $total_hpp = 0;
                $total_advantage = 0;
                $grand_total = 0;
                $grand_total_discount = 0;

                foreach ($data_result->result() as $data_table) {
                    $no++;
                    //create date 
                    $date_explode = explode('-', $data_table->date);
                    $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
                    $credit_status = $data_table->credit_status ? '<label class="label label-warning">PIUTANG</label>' : '<label class="label label-success">LUNAS</label>';

                    $ppn_percentage = $data_table->ppn_price > 0 ? $data_table->ppn : 0;
                    $pph_percentage = $data_table->pph_price > 0 ? $data_table->pph : 0;
                    $percentage_advantage = (($data_table->grand_total_sales - $data_table->grand_total_hpp) / $data_table->grand_total_sales) * 100;

                    //total
                    $grand_total_sales += $data_table->grand_total_sales;
                    $total_ppn += $data_table->ppn_price;
                    $total_pph += $data_table->pph_price;
                    $total_hpp += $data_table->grand_total_hpp;
                    $total_advantage += $percentage_advantage;
                    $grand_total += $data_table->grand_total;
                    $grand_total_discount += $data_table->total_discount_product;

                    echo '
                            <tr>
                                <td>' . $no . '</td>
                                <td>' . $data_table->code . '</td>
                                <td>' . $data_table->member_code . '</td>
                                <td>' . $date_html . '</td>
                                <td>Rp ' . number_format($data_table->total_discount_product, 0, '.', '.') . '</td>
                                <td>Rp ' . number_format($data_table->grand_total_sales, 0, '.', '.') . '</td>
                                <td> ' . number_format($ppn_percentage, 0, '.', '.') . '%</td>
                                <td>Rp ' . number_format($data_table->ppn_price, 0, '.', '.') . '</td>
                                <td> ' . number_format($pph_percentage, 0, '.', '.') . '%</td>
                                <td>Rp ' . number_format($data_table->pph_price, 0, '.', '.') . '</td>
                                <td>Rp ' . number_format($data_table->grand_total, 0, '.', '.') . '</td>
                                <td>Rp ' . number_format($data_table->grand_total_hpp, 0, '.', '.') . '</td>
                                <td> ' . round($percentage_advantage) . '%</td>
                                <td>Rp ' . number_format($data_table->deposito_payment, 0, '.', '.') . '</td>
                                <td>Rp ' . number_format($data_table->point_payment, 0, '.', '.') . '</td>
                                <td><buton class="btn btn-info btn-xs" onclick="detail_sales(' . "'" . $data_table->id . "'" . ')"><i class="fa fa-list"></i> Detail</button></td>
                            </tr>
                        ';
                }
                ?>
            </tbody>
            <tfoot>
                <?php
                echo '
                        <tr>
                            <td>TOTAL</td>
                            <td></td>
                            <td></td>
                            <td>' . $date_html . '</td>
                            <td>Rp ' . number_format($grand_total_discount, 0, '.', '.') . '</td>
                            <td>Rp ' . number_format($grand_total_sales, 0, '.', '.') . '</td>
                            <td> </td>
                            <td>Rp ' . number_format($total_ppn, 0, '.', '.') . '</td>
                            <td></td>
                            <td>Rp ' . number_format($total_pph, 0, '.', '.') . '</td>
                            <td>Rp ' . number_format($grand_total, 0, '.', '.') . '</td>
                            <td>Rp ' . number_format($total_hpp, 0, '.', '.') . '</td>
                            <td> ' . round($percentage_advantage) . '%</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    ';
                ?>
            </tfoot>
        </table>
        <span class="clearfix"></span>
        <div class="text-right">
            <form method="POST" action="<?= base_url('sales_report/get_excel'); ?>">
                <small>(*klik untuk cetak laporan)</small>
                <input type="hidden" value="<?= $encrypt_post_data; ?>" name="data_result">
                <button type="submit" class="btn btn-success btn-lg"><i class="fa fa-file-excel-o"></i> Cetak Excel</button>
            </form>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal_view_detail_sales" data-backdrop="static">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="view_detail_sales">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<script type="text/javascript" src="<?php echo base_url('assets/assets_admin/'); ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>function_toast.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('.table_list').DataTable();
    var controller = 'sales/';
    var base_url = '<?php echo base_url(); ?>' + controller;

    function detail_sales(id) {
        showLoading();
        $('.modal-title').text('DETAIL');
        var url = base_url + 'detail_sales/' + id;
        // var formData = new FormData($('#form_sales')[0]);
        $.ajax({
            url: url,
            type: "GET",
            dataType: "HTML",
            success: function(data) {
                hideLoading();
                $('.view_detail_sales').html(data);
                $('#modal_view_detail_sales').modal('show');
                // $('.table_view_sales').DataTable();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('error process');
                showLoading();
            }
        });
    }
</script>