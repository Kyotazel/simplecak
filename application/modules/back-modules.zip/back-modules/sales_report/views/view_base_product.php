<?php
$this->load->view('data_sales_report/form');
?>

<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <h4>Hasil Pencarian</h4>
    </div>
    <div class="card-body">
        <div class="col-md-6">
            <table style="width:100%;" style="font-size:20px;">
                <?php
                echo '
                    <tr>
                      <td width="50px">Range</td>
                      <td width="10px">:</td>
                      <td>' . $array_range['date_from'] . '&nbsp;&nbsp;s/d&nbsp;&nbsp;' . $array_range['date_to'] . '</td>
                    </tr>
                    <tr>
                      <td width="50px">Barang</td>
                      <td width="10px" align="center">:</td>
                      <td>' . $array_range['product'] . '</td>
                    </tr>
                    <tr>
                      <td width="50px">Member</td>
                      <td width="10px">:</td>
                      <td>' . $array_range['member'] . '</td>
                    </tr>
                  ';

                ?>
            </table>
        </div>
        <div class="col-md-6">
            <form method="POST" action="<?php echo base_url('sales_report/print_base_on_product'); ?>">
                <input type="hidden" name="data_range" value="<?php echo str_replace('"', "'", json_encode($array_range)); ?>">
                <input type="hidden" name="last_query" value="<?php echo $this->db->last_query(); ?>">
                <button type="submit" class="btn btn-default pull-right"><i class="fa fa-print"></i> cetak Laporan</button>
            </form>
        </div>
        <span class="clearfix"></span>
        <hr>
        <table class="table table_list table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Nota</th>
                    <th>Nama Barang</th>
                    <th>tanggal</th>
                    <th>Grand Total</th>
                    <th>member</th>
                </tr>
            </thead>
            <tbody>
                <?php
                function count_stock_result($stock, $qty_unit, $unit_name, $base_unit_name)
                {
                    if ($stock != false) {
                        $base_unit_val = $stock % $qty_unit;
                        //count unit val
                        $unit_val     = ($stock - $base_unit_val) / $qty_unit;
                        // stock current
                        $stock_current = '';
                        if ($unit_val > 0) {
                            $stock_current .= number_format($unit_val, 0, '.', '.') . '&nbsp;' . $unit_name;
                        }
                        if ($base_unit_val > 0) {
                            if ($unit_val > 0) {
                                $stock_current .= '<br>';
                            }
                            $stock_current .= number_format($base_unit_val, 0, '.', '.') . '&nbsp;' . $base_unit_name;
                        }
                    } else {
                        $stock_current = '0&nbsp;' . $base_unit_name;
                    }

                    return $stock_current;
                }

                $no = 0;
                $total_grand = 0;
                $total_payment = 0;
                $total_rest_payment = 0;
                foreach ($data_result->result() as $data_table) {
                    //count total
                    $total_grand += $data_table->grand_total_buy;

                    //view
                    $no++;
                    //create date 
                    $date_explode = explode('-', $data_table->date);
                    $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
                    echo '
                  			<tr>
                  				<td>' . $no . '</td>
                  				<td>' . $data_table->code_sales . '</td>
                          <td>' . $data_table->name . '</td>
                  				<td>' . $date_html . '</td>
                  				<td>Rp ' . number_format($data_table->grand_total_buy, 0, '.', '.') . '</td>
                  				<td>' . $data_table->member_name . '</td>
                  			</tr>
                  		 ';
                }
                echo '
                  		</tbody>
		              	<tfoot>
		              		<tr>
		              			<td colspan="4" align="center"><b>TOTAL</b></td>
		              			<td><b>Rp ' . number_format($total_grand, 0, '.', '.') . '</b></td>
		              		</tr>
		              	</tfoot>
                  		';
                ?>
        </table>

    </div>
    <!-- /.box-body -->

</div>
<script type="text/javascript" src="<?php echo base_url('assets/assets_admin/'); ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>function_toast.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('.table_list').DataTable();
</script>