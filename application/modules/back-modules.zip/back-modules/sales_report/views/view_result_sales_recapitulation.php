<?php
$data_encrypt = $this->encrypt->encode(json_encode($data_sales));
$encrypt_date = $this->encrypt->encode(json_encode($date));
?>
<div class="card">
    <div class="card-body">
        <div class="col-md-12">
            <div class="table-responsive responsivetable">
                <table class="table table-striped table-detail-sales">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal tutup shift</th>
                            <th>Kasir</th>
                            <th>Total Nota Penjualan</th>
                            <th>Total Nota Deposito</th>
                            <th>uang Modal</th>
                            <th>Total Pembayaran Deposito</th>
                            <th>Total Pembayaran Point</th>
                            <th>Total Piutang</th>
                            <th>Total Omset Penjualan</th>
                            <th>Total Uang Cash</th>
                            <th>Total Uang Deposito</th>
                            <th>Uang Dipakai</th>
                            <th>Total Wajib Setor</th>
                            <th>Nominal Setor</th>
                            <th>Margin</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        $deposito_price_sales = 0;
                        $point_price_sales = 0;
                        $total_credit_price = 0;
                        $total_cash_price = 0;
                        $total_invoice = 0;
                        $total_invoice_deposito = 0;
                        $total_item_sales = 0;
                        $total_qty_sales = 0;
                        $total_omset_sales = 0;
                        $total_price_deposito = 0;
                        $total_price_usage = 0;
                        $total_price = 0;
                        $total_price_report = 0;
                        $total_margin = 0;
                        $total_capital_money = 0;
                        $data_result = [];
                        foreach ($data_sales as $item_sales) {
                            $no++;
                            echo '
                            <tr>
                            <td>' . $no . '</td>
                            <td>' . $item_sales->created_date . '</td>
                            <td>' . $item_sales->user_name . '</td>
                            <td>' . $item_sales->total_invoice . ' Nota</td>
                            <td>' . $item_sales->total_invoice_deposito . ' Nota</td>
                            <td>' . number_format($item_sales->capital_money, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->deposito_price_sales, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->point_price_sales, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->total_credit_price, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->total_omset_sales, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->cash_price_sales, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->total_price_deposito, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->price_usage, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->total_price, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->total_price_report, 0, '.', '.') . '</td>
                            <td>' . number_format($item_sales->margin, 0, '.', '.') . '</td>
                            <td>' . $item_sales->note . '</td>
                            </tr>
                            ';
                            //add to data result
                            $data_result[] = [
                                'date' => $item_sales->created_date,
                                'cashier' => $item_sales->user_name,
                                'total_item' => $item_sales->total_item_sales,
                                'qty_sales' => $item_sales->total_qty_sales,
                                'total_invoice' => $item_sales->total_invoice,
                                'total_invoice_deposito' => $total_invoice_deposito,
                                'capital_money' => $item_sales->capital_money,
                                'deposito_price_sales' => $item_sales->deposito_price_sales,
                                'point_price_sales' => $item_sales->point_price_sales,
                                'total_credit_price' => $item_sales->total_credit_price,
                                'total_omset_sales' => $item_sales->total_omset_sales,
                                'cash_price_sales' => $item_sales->cash_price_sales,
                                'total_price_deposito' => $item_sales->total_price_deposito,
                                'price_usage' => $item_sales->price_usage,
                                'total_price' => $item_sales->total_price,
                                'total_price_report' => $item_sales->total_price_report,
                                'margin' => $item_sales->margin,
                                'note' => $item_sales->note
                            ];

                            $total_capital_money += $item_sales->capital_money;
                            $total_invoice += $item_sales->total_invoice;
                            $total_invoice_deposito += $item_sales->total_invoice_deposito;
                            $total_item_sales += $item_sales->total_item_sales;
                            $total_qty_sales += $item_sales->total_qty_sales;
                            $total_omset_sales += $item_sales->total_omset_sales;
                            $total_price_deposito += $item_sales->total_price_deposito;
                            $total_margin += $item_sales->margin;
                            $total_price_usage += $item_sales->price_usage;
                            $total_price += $item_sales->total_price;
                            $total_price_report += $item_sales->total_price_report;
                            $total_cash_price += $item_sales->cash_price_sales;
                            $deposito_price_sales += $item_sales->deposito_price_sales;
                            $point_price_sales += $item_sales->point_price_sales;
                            $total_credit_price = $item_sales->total_credit_price;
                        }
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <?php
                            echo '
                            <th colspan="3">TOTAL</th>
                            <th>' . number_format($total_invoice, 0, '.', '.') . ' Nota</th>
                            <th>' . number_format($total_invoice_deposito, 0, '.', '.') . ' Nota</th>
                            <th>Rp.' . number_format($total_capital_money, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($deposito_price_sales, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($point_price_sales, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_credit_price, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_omset_sales, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_cash_price, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_price_deposito, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_price_usage, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_price, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_price_report, 0, '.', '.') . '</th>
                            <th>Rp.' . number_format($total_margin, 0, '.', '.') . '</th>
                            <th></th>
                            ';
                            ?>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <div class="col-md-12 text-right p-20">
            <form method="POST" action="<?= base_url('sales_report/print_sales_recapitulation_excel'); ?>">
                <small>(*klik untuk cetak laporan)</small>
                <input type="hidden" value="<?= $this->encrypt->encode(json_encode($data_result)); ?>" name="data_result">
                <button type="submit" class="btn btn-success btn-lg"><i class="fa fa-file-excel-o"></i> Cetak Excel</button>
            </form>
        </div>
    </div>
    <!-- /.box-body -->
</div>