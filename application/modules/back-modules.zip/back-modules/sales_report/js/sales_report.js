var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/sales_report';
var save_method;
var table_paid;
var table_has_paid;
var id_use;
$(document).ready(function(){
	// table_paid= $('.table_paid').DataTable({
    //     "ajax": {
    //         "url": controller+"/list_paid",
    //         "type": "POST"
    //     }
    // });

    // table_has_paid= $('.table_has_paid').DataTable({
    //     "ajax": {
    //         "url": controller+"/list_has_paid",
    //         "type": "POST"
    //     }
    // });
    
    // table_has_paid= $('.table_reject').DataTable({
    //     "ajax": {
    //         "url": controller+"/list_reject",
    //         "type": "POST"
    //     }
    // });
    // $('.table_payment').DataTable();
    // alert('ok');
})


$('.btn-search').click(function (e) {
    e.preventDefault();
    $(this).button('loading');
	$('.form-group').removeClass('has-error');
	$('.help-block').empty();  
	  //defined form
	var formData = new FormData($('.form-search')[0]);
    $.ajax({
    url: controller+'/search_sales_recapitulation',
    type: "POST",
    data: formData,
    contentType: false,
    processData : false,
    dataType :"JSON",
    success: function(data){
        if(data.status){
            $('.html_respon').html(data.html_respon);
            $('.table-detail-sales').DataTable();
        } else{
        for (var i = 0; i < data.inputerror.length; i++)
            {
                $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
            }
        }
        $('.btn-search').button('reset');
    },
        error:function(jqXHR, textStatus, errorThrown)
        {
        $('.btn-search').button('reset');
        alert_error('something wrong');
        }
    });//end ajax
})