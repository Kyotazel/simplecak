var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var id_use = 0;
var status_delivery;
var status_credit;
var save_method;
var status_ready;
    var table;
    // var controller = 'cashier/';
    // var url_controller = '<?php echo url_controller(); ?>' + controller;
    // var qty_stock_return;
    $(document).ready(function() {
        // $('.btn_print').click();
        // $('#modal_view_detail_sales').modal('show');
        $('.chosen').chosen();

        disable_submit();
        // get_data_member();
        get_code_sales()
        get_number_sales_today()
        $('#barcode').focus();
        count_grand_total();
        //for payment
        setInterval(function() {
            $('.rest_payment_review').fadeOut(500).fadeIn(500);
        }, 100);

        //----------------shortcut----------------------------
        shortcut.add("ctrl+enter", function() {
            // Do something
            //$('.btn_payment').click();
            $('#form_payment').collapse("show"); 
            //$('#payment').focus();
        });

        shortcut.add("esc", function() {
            // Do something
            $('#form_payment').collapse("hide");
            $('#barcode').focus();
        });

        shortcut.add("shift+a", function() {
            // Do something
            $('.btn_search_member').click();
        });
        
        // shortcut.add("enter", function() {
        //     // Do something
        //     $('.add_sales_item').click();
        // });
        shortcut.add("f1", function() {
            // Do something
            if(status_ready==true){
                $('#btn_save').click();
            } else {
                alert_error('tidak ada pembelian');
            }
            
        });

        shortcut.add("f2", function() {
            // Do something
            $('.btn_choose_product').click();
        });
        shortcut.add("f3", function() {
            // Do something
            view_stock(); 
        });
        shortcut.add("f4", function() {
            // Do something
            view_sales_today(); 
        });
        

        shortcut.add("esc", function() {
            // Do something
            $('.modal').modal('hide');
        });

        $(document).scannerDetection({
            timeBeforeScanTest: 200, // wait for the next character for upto 200ms
            startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
            endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
            avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
            onComplete: function (barcode, qty) {
                var barcode_current = $('#barcode').val();
                $.ajax({
                    url: url_controller + 'get_barcode_choosen/',
                    type: "POST",
                    dataType: "JSON",
                    data: { 'barcode': barcode_current },
                    success: function (ui) {
                        if (ui.status) {
                            id_use = 0;
                            $('.add_html_review').empty();
                            // var qty_stock_return = correct_stock(ui.item.stock, ui.item.id);
                            $('.notif_name').empty();
                            $('.notif_qty').empty();
                            if (ui.item.stock <= 0) {
                                alert_error('stok kosong sudah habis');
                                $('#barcode').val('');
                                $('#price_product').val('');
                                $('#price_shown').val('');
                                $('[name="data_product"]').val('');
                                $('#unit').html('');
                                $('#product-name').val('');
                                $('#qty_buy').val('');
                                $('#barcode').focus();
                                $('.unit_name').text('');
                                // $(this).val('');
                                $(this).focus();
                            } else {
                                $('#price_product').val(ui.item.price);
                                $('#price_shown').val(money_function(ui.item.price));
                                $('#id_product').val(ui.item.id);
                                $('#stock').val(ui.item.stock);
                                // alert_error(ui.item.id);
                                $('.unit_name').text('/ ' + ui.item.unit_name);
                                $('#price_product').val(ui.item.price);
                                $('#product-name').val(ui.item.label + ' (stok : ' + ui.item.stock + ' ' + ui.item.unit_name + ')');
                                $('#qty_buy').val('');
                                get_unit_request(ui.item.id)
                                $('#qty_buy').focus();
                            }
                        } else {
                            // alert_error('barang tidak ditemukan');
                        }
                            
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        alert_error('error process');
                    }
                });
            } // main callback function	
        });

        
    })

    function disable_submit() {
        $('#form_sales').submit(false);
    }
    
    $(document).on('keypress', '.search_product', function (event) {
        if (event.keyCode === 13) { 
            $('.btn_search').click();
        } 
    });

    $(document).on('keypress', '#qty_buy', function (event) {
        if (event.keyCode === 13) { 
            $('.add_sales_item').click();
        } 
    });

    $(document).on('keyup', '#sales_employee', function () {
        var value_current = $(this).val();
        $('#sales_employee').autocomplete({
            source: url_controller + "get_sales_employee",
            search: function () {
                $(".load_icon").show();
            },
            response: function () {
                $(".load_icon").hide();
            },
            select: function(event, ui) {
                event.preventDefault();
                id_use = 0;
                //console.log(id_use);
                $('.add_html_review').empty();
                $('#sales_employee').val(ui.item.name);
                $('#id_sales_employee').val(ui.item.id);
            }
        });
    });


    $(document).on('keyup', '#member_name', function () {
        var value_current = $(this).val();
        $('#member_name').autocomplete({
            source: url_controller + "get_member_auto",
            search: function () {
                $(".load_icon").show();
            },
            response: function () {
                $(".load_icon").hide();
            },
            select: function(event, ui) {
                event.preventDefault();
                id_use = 0;
                console.log(id_use);
                $('.add_html_review').empty();
                $('#member_id').val(ui.item.id);
                $('#member_code').val(ui.item.code);
                $('#member_name').val(ui.item.name);
                search_member(ui.item.code);
                //btn_search_member.click();
            }
        });
    });


function search_member(code){
    //var member_code = $('[name="member_code"]').val();
    $.ajax({
        url: url_controller+'/get_member',
        type: "POST",
        dataType: "JSON",
        data:{'member_code':code},
        success: function (data) {
            if (data.status) {
                $('.html_respon_member').html(data.html_respon);
                form_payment_member(data.id_member);
            } else {
                swal(
                    'DATA TIDAK ADA!',
                    'kode member tidak ditemukan',
                    'warning'
                );
            }
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_search_member');
            alert_error('something wrong');
        }
    });//end ajax
}


$(document).on('keyup', '#barcode', function () {
    var value_current = $(this).val();
    $('#barcode').autocomplete({
        source: url_controller + "get_product_code_auto",
        search: function () {
            $(".load_icon").show();
        },
        response: function () {
            $(".load_icon").hide();
        },
        select: function(event, ui) {
            event.preventDefault();
            id_use = 0;

            var id_member = $(document).find('#id_member').val();
            if (id_member == '' || typeof id_member == 'undefined') {
                $('#barcode').val('');
                $('#product-name').val('');
                alert_error('pilih member terlebih dahulu');
                return false;
            }
            // var customer_price = $(document).find('#customer_price').val();
            // if (customer_price == '' || customer_price == 0 || typeof customer_price == 'undefined') {
            //     $('#barcode').val('');
            //     $('#product-name').val('');

            //     alert_error('harga customer belum di setting di pengaturan harga');
            //     return false;
            // }

            $('.add_html_review').empty();
            // var qty_stock_return = correct_stock(ui.item.stock, ui.item.id);
            $('.notif_name').empty();
            $('.notif_qty').empty();
            if (ui.item.stock <= 0) {
                alert_error('stok kosong sudah habis');
                reset_add_form();
                $(this).focus();
            } else {
                $('#price_product').val(ui.item.price);
                //$('#price_shown').val(money_function(ui.item.price));

                $("#price").empty();

                // for(i = 0 ; i < ui.item.price.length ; i++){
                //     var o = new Option(money_function(ui.item.price[i]), ui.item.price[i]);
                //     $(o).html(money_function(ui.item.price[i]));
                //     $("#price").append(o);
                // }
                var obj = ui.item.price;
                // Object.keys(obj).forEach(key => {
                //     if (key == customer_price) {
                //         $("#price").html('<option value="'+ obj[key]+'">'+ obj[key]+'</option>');
                //     }
                // });

                $('#id_product').val(ui.item.id);
                $('#stock').val(ui.item.stock);
                // alert_error(ui.item.id);
                $('.unit_name').text('/ ' + ui.item.unit_name);
                $('#price_product').val(ui.item.price);
                $('#product-name').val(ui.item.label + ' (stok : ' + ui.item.stock + ' ' + ui.item.unit_name + ')');
                $('#qty_buy').val('');
                get_unit_request(ui.item.id)
                $('#qty_buy').focus();
            }
        }
    });
});


$('#product-name').autocomplete({
    source: url_controller + "get_product_auto",
    select: function(event, ui) {
        event.preventDefault();
        var id_member = $(document).find('#id_member').val();
        if (id_member == '' || typeof id_member == 'undefined') {
            $('#barcode').val('');
            $('#product-name').val('');
            alert_error('pilih member terlebih dahulu');
            return false;
        }
        var customer_price = $(document).find('#customer_price').val();
        
        // if (customer_price == '' || customer_price == '0' || typeof customer_price == 'undefined') {
        //     $('#barcode').val('');
        //     $('#product-name').val('');
            
        //     alert_error('harga customer belum di setting di pengaturan harga');
        //     return false;
        // }

        id_use = 0;
        $('.add_html_review').empty();
        // var qty_stock_return = correct_stock(ui.item.stock, ui.item.id);
        $('.notif_name').empty();
        $('.notif_qty').empty();
        if (ui.item.stock <= 0) {
            alert_error('stok kosong sudah habis');
            reset_add_form();
            $(this).focus();
        } else {
            //$('#price_product').val(ui.item.price);
            $("#price").empty();
            for(i = 0 ; i < ui.item.price.length ; i++){
                var o = new Option(money_function(ui.item.price[i]), ui.item.price[i]);
                $(o).html(money_function(ui.item.price[i]));
                $("#price").append(o);
            }
            

            //$('#price_shown').val(money_function(ui.item.price));
            $('#id_product').val(ui.item.id);
            $('#stock').val(ui.item.stock);
            //alert_error(ui.item.id);
            $('.unit_name').text('/ ' + ui.item.unit_name);
            //$('#price_product').val(ui.item.price);
            $('#product-name').val(ui.item.label + ' (stok : ' + ui.item.stock + ' ' + ui.item.unit_name + ')');
            $('#qty_buy').val('');
            get_unit_request(ui.item.id)
            $('#qty_buy').focus();
        }
    }
});

function get_unit_request(id) {
    var id_member = $('#id_member').val();
    $.ajax({
        url: url_controller+'/get_unit_request',
        type: "POST",
        dataType: "JSON",
        data: {
            'id': id,
            'id_member':id_member
        },
        success: function (data) {
            $('[name="unit"]').html(data.html_respon);
            $('[name="data_product"]').val(data.data_product);

            if (data.price_type == 0) {
                reset_add_form();
                alert_error('Tipe harga Produk belum di atur');
            } else {
                $("#price").html('<option value="'+ data.price_use+'">'+ data.price_use+'</option>');
            }

        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_add_product');
            alert_error('something wrong');
        }
    });//end ajax
}

function reset_add_form() {
    $('#barcode').val('');
    $('#price_product').val('');
    $('#price_shown').val('');
    $('[name="data_product"]').val('');
    $('#unit').html('');
    $("#price").empty();
    $('#product-name').val('');
    $('#qty_buy').val('');
    $('#barcode').focus();
    $('.unit_name').text('');
}


$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
});

    // stock

    //add sales item
$('.add_sales_item').click(function () {
    $('.help-block').empty();
    $('.form-group').removeClass('has-error');
    var id_product_current = $('#id_product').val();
    var url = url_controller + 'add_item';
    var formData = new FormData($('#form_sales')[0]);
    $.ajax({
        url: url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.tr_' + data.id_product).remove();
                $('.add_html_item_sales').append(data.html_respon);
                notif_success('data berhasil ditambah');
                count_grand_total();
                //empty form
                $('#barcode').val('');
                $('#price_product').val('');
                $('#price_shown').val('');
                $('[name="data_product"]').val('');
                $('#unit').html('');
                $('#price').empty();
                $('#product-name').val('');
                $('#qty_buy').val('');
                $('#barcode').focus();
                $('.unit_name').text('');
                id_use = 0;
            } else {
                // var data_product = $('[name="data_product"]').val();
                for (var i = 0; i < data.inputerror.length; i++) {
                    // $('.notif_' + data.inputerror[i]).parent().addClass('has-error');
                    if (data.inputerror[i] == 'less_stock') {
                        swal(
                            'STOK TIDAK CUKUP!',
                            data.error_string[i],
                            'warning'
                        );
                    } else {
                        if (id_use > 0) {
                            console.log(id_use);
                            $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                        }
                    }
                        
                }
            }
            id_use++;
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
});

    $('.btn_clear_barcode').click(function () {
        $('#barcode').val('');
        $('#price_product').val('');
        $('#price_shown').val('');
        $('[name="data_product"]').val('');
        $('#unit').html('');
        $('#product-name').val('');
        $('#qty_buy').val('');
        $('#barcode').focus();
        $('.unit_name').text('');
        $("#price").empty();
    })

    function count_grand_total() {
        var grand_total_sales = 0;
        var ppn_item = 0;
        var pph_item = 0;
        var count_item = 0;

        if ($('.checked_ppn').prop('checked')) {
            var status_ppn = true;
        }else{
            var status_ppn = false;
        }

        if ($('.checked_pph').prop('checked')) {
            var status_pph = true;
        }else{
            var status_pph = false;
        }

        $("input[name='id_product[]']").each(function() {
            count_item++
            var id_product = $(this).val();
            grand_total_sales += parseInt($('.total_price_item_' + id_product).val());

            if (status_ppn) {
                ppn_item += parseInt($('.ppn_item_' + id_product).val());
            }

            if (status_pph) {
                pph_item += parseInt($('.pph_item_' + id_product).val());
            }
        })
        var grand_total = grand_total_sales + ppn_item + pph_item;
        var grand_total_shown   = money_function(String(grand_total), 'Rp.');
        var grand_total_ppn     = money_function(String(ppn_item), 'Rp.');
        var grand_total_pph     = money_function(String(pph_item), 'Rp.');
        $('#grand_total_shown').text(grand_total_shown);
        $('#grand_total_shown2').text(grand_total_shown);
        $('.text-ppn').text(grand_total_ppn);
        $('.text-pph').text(grand_total_pph);
        $('#all_item').val(count_item);
        $('#grand_total').val(grand_total);
        $('#ppn').val(ppn_item);
        $('#pph').val(pph_item);
        $('#grand_total_sales').val(grand_total_sales);
    }

    function del_tr(id) {
        $('.add_html_review').empty();
        $('.add_html_item_sales').find('.tr_' + id).remove();
        $('.checked_point').removeClass('off');
        $('.checked_deposito').removeClass('off');
        $('[name="deposito"]').val('');
        $('[name="point"]').val('');
        total_payment();
        count_grand_total();
    }
    
$('.btn_search_member').click(function () {
    $(this);
    var member_code = $('[name="member_code"]').val();
    $.ajax({
        url: url_controller + '/get_member',
        type: "POST",
        dataType: "JSON",
        data: { 'member_code': member_code },
        success: function (data) {
            if (data.status) {
                $('.html_respon_member').html(data.html_respon);
                form_payment_member(data.id_member);
            } else {
                swal(
                    'DATA TIDAK ADA!',
                    'kode member tidak ditemukan',
                    'warning'
                );
            }
            $('.btn_search_member');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_search_member');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_clear_member', function () {
    $('.html_respon_member').empty();
    form_payment_member(0);
    total_payment();
});

    //additionla function
$('.money_only').keyup(function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});

    function delete_dot_value(value) {
        var array_value = value.split('.');
        var count_array = array_value.length;
        payment_value = value;
        for (var i = 0; i < count_array; i++) {
            payment_value = payment_value.replace('.', '');
        };
        return payment_value;
    }

    //sshow review

    $('.btn_payment').click(function() {
        $('.notif_btn_payment').empty();
        $('#payment').focus();
        var grand_total = $('#grand_total').val();
        var payment_value = $('[name="total_payment"]').val();
        var id_sales = $(this).data('id');
        // console.log(payment_value);
        
        var empty_status = false;
        if (payment_value == '') {
            empty_status = true;
        }
        payment_value = delete_dot_value(payment_value);;
        //console.log(payment_value);
        payment_value = parseInt(payment_value);
        grand_total = parseInt(grand_total);
        //decide delivery status 
        if ($('.delivery_status').prop('checked')) {
            status_delivery = 1;
        } else {
            status_delivery = 0;
        }
        //decide credit status
        if ($('.credit_status').prop('checked')) {
            status_credit = 1;
        } else {
            status_credit = 0;
        }
        // console.log(grand_total);
        var count_rest_payment = payment_value - grand_total;

        //count saldo debt 
        var status_saldo_debt = true;
        var debt_price = 0;
        var saldo_debt = $('#debt_saldo').val();
        if (status_credit & count_rest_payment < 0) {
            debt_price = grand_total - payment_value;
            if (parseInt(saldo_debt) < debt_price) {
                status_saldo_debt = false;
            }
        }
        // alert_error(count_rest_paymnet);
        /* if (grand_total == false) {
            $('.notif_btn_payment').text('belum ada pembelian');
        } else if (count_rest_payment < 0 && status_credit == 0) {
            $('.notif_btn_payment').text('pembayaran kurang');
        } else if (empty_status == true) {
            $('.notif_btn_payment').text('harus diisi');
        }else if (status_saldo_debt == false) {
            swal(
                'SALDO HUTANG TIDAK CUKUP',
                'hutang : '+money_function(String(debt_price),'')+'<br> sisa saldo hutang : '+money_function(saldo_debt,''),
                'warning'
            );
        } else { */
            var formData = new FormData($('#form_sales')[0]);
            $.ajax({
                url: url_controller+'/validate_payment',
                data: formData,
                type: "POST",
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    if (data.status) {
                        status_ready = true;
                        var code_nota = $('#code').val();
                        var date = $('#date').val();
                        var table_list_item = $('.cover_table_list').html();
                        $('.add_html_review').html(table_list_item);
                        $('.add_html_review').find('#table_list_item').find('.btn-del').parent().remove();
                        var all_item = $('#all_item').val();
                        var grand_total_sales = $('#grand_total_sales').val();
                        var grand_total = $('#grand_total').val();
                        var ppn_value = $('#ppn').val();
                        var pph_value = $('#pph').val();
                        var label_ppn = $('.label_ppn').text();
                        var label_pph = $('.label_pph').text();
                        $('.add_html_review').find('#table_list_item').append('<tr><td colspan="3"><b>JUMLAH ITEM</b></td><td><b>' + money_function(all_item) + '</b></td><td colspan="2"><b>TOTAL PEMBELIAN</b></td><td><b>Rp.' + money_function(grand_total_sales) + '</b></td></tr>');
                        $('.add_html_review').find('#table_list_item').append('<tr><td colspan="4"></td><td colspan="2"><b>' + label_ppn + '</b></td><td><b>Rp.' + money_function(ppn_value) + '</b></td></tr>');
                        $('.add_html_review').find('#table_list_item').append('<tr><td colspan="4"></td><td colspan="2"><b>' + label_pph + '</b></td><td><b>Rp.' + money_function(pph_value) + '</b></td></tr>');
                        $('.add_html_review').find('#table_list_item').append('<tr><td colspan="4"></td><td colspan="2"><b>GRAND TOTAL</b></td><td><b>Rp.' + money_function(grand_total) + '</b></td></tr>');
                        
                        $('.grand_total_review').text('Rp ' + money_function(grand_total));
                        $('.payment_review').text('Rp ' + money_function(String(payment_value)));
                        $('.rest_payment_review').text('Rp ' + money_function(String(count_rest_payment)));
                        $('#code_nota').text(code_nota);
                        $('#date_order').text(date);
                        $('#modal_member_name').text($('#member_name').val());
                        $('#modal_sales_name').text($('#sales_employee').val());
                        get_member_buyer();
                        get_form(status_delivery,status_credit,grand_total,payment_value);
                        $('#modal_review_sales').modal('show');
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            $('.'+data.inputerror[i]).text(data.error_string[i]);
                        }
                    }
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_add_product');
                    alert_error('something wrong');
                }
            });//end ajax

            
        //}
    })

    function get_form(status_delivery,status_credit,grand_total,payment) {
        $.ajax({
            url: url_controller+'get_form',
            type: "POST",
            data:{'status_delivery':status_delivery,'status_credit':status_credit,'grand_total':grand_total,'payment':payment},
            dataType: "JSON",
            success: function(data) {
                $('.html_payment').html(data.html_payment);
                $('.html_form').html(data.html_form);

                $('.datepicker_today').datepicker({
                    autoclose: true,
                    format: 'dd-mm-yyyy',
                    startDate: new Date()
                });
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }   
        });
    }
    
    // function get_data_member() {
    //     var url = url_controller + 'get_html_data_member';
    //     // var formData = new FormData($('#form_sales')[0]);
    //     $.ajax({
    //         url: url,
    //         type: "GET",
    //         dataType: "HTML",
    //         success: function(data) {
    //             $('#id_member').html(data);
    //         },
    //         error: function(jqXHR, textStatus, errorThrown) {
    //             alert_error('error process');
    //         }
    //     });
    // }
    

    function form_payment_member(value_current) {
        $.ajax({
            url: url_controller+'/get_member_value',
            type: "POST",
            dataType: "JSON",
            data:{'value':value_current},
            success: function(data) {
                if (data.status) {
                    if (data.status_point) {
                        $('.payment-point').show();
                        $('[name="saldo_point"]').val(data.total_point);
                        $('.saldo_point').text(data.html_total_point);
                    } else {
                        $('.payment-point').hide();
                    }

                    if (data.status_deposito) {
                        $('.payment-deposito').show();
                        $('.saldo_deposito').text(data.html_total_deposito);
                        $('[name="saldo_deposito"]').val(data.total_deposito);
                    } else {
                        $('.payment-deposito').hide();
                    }
                } else {
                    $('.payment-point').hide();
                    $('.payment-deposito').hide();
                    $('.form-credit').hide();
                }

                if (data.id_member) {
                    $('.form-credit').show();
                } else {
                    $('.form-credit').hide();
                }

                $('.checked_point').removeClass('off');
                $('.checked_deposito').removeClass('off');
                $('[name="deposito"]').val('');
                $('[name="point"]').val('');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    }

    function get_member_buyer() {
        // var id_member = $('#id_member').val()
        // var url = url_controller + 'get_member_buyer/' + id_member;
        // // var formData = new FormData($('#form_sales')[0]);
        // $.ajax({
        //     url: url,
        //     type: "GET",
        //     dataType: "JSON",
        //     success: function(data) {
        //         $('#member_name').text(data.name);
        //     },
        //     error: function(jqXHR, textStatus, errorThrown) {
        //         alert_error('error process');
        //     }
        // });
    }

    function get_code_sales() {
        var url = url_controller + 'get_code_sales';
        // var formData = new FormData($('#form_sales')[0]);
        $.ajax({
            url: url,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
                $('#code').val(data.code);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    }
    
    function total_payment() {
        var cash_payment = $('[name="payment"]').val();
        var deposito_payment    = $('[name="deposito"]').val();
        var point_payment = $('[name="point"]').val();
        if (cash_payment == '') {
            cash_payment = 0;    
        } else {
            cash_payment = delete_dot_value(cash_payment);
        }

        if (deposito_payment == '') {
            deposito_payment = 0;
        } else {
            deposito_payment = delete_dot_value(deposito_payment);
        }

        if (point_payment == '') {
            point_payment = 0;
        } else {
            point_payment = delete_dot_value(point_payment);
        }
        
        cash_payment = parseInt(cash_payment);
        deposito_payment = parseInt(deposito_payment);
        point_payment = parseInt(point_payment);

        var total_payment = cash_payment + deposito_payment + point_payment;
        console.log(total_payment);
        
        
        var money_total_payment = money_function2(total_payment,'Rp.');
        $('#text-payment').text(money_total_payment);
        $('[name="total_payment"]').val(total_payment);
    }
    
    $('[name="payment"]').keyup(function () {
        total_payment();
    })

    $('[name="deposito"]').keyup(function () {
        total_payment();
        var saldo_deposito = parseInt($('[name="saldo_deposito"]').val());
        var deposito_current = parseInt(delete_dot_value($('[name="deposito"]').val()));
        var total_payment_new = parseInt($('[name="total_payment"]').val());
        var grand_total_new = parseInt($('#grand_total').val());

        if (deposito_current > saldo_deposito || total_payment_new > grand_total_new) {
            $('[name="deposito"]').val('');
            total_payment();
            alert_error('maksimal : ' + grand_total_new);
        }
    })

    $('[name="point"]').keyup(function () {
        total_payment();

        var saldo_point = parseInt($('[name="saldo_point"]').val());
        var point_current = parseInt(delete_dot_value($('[name="point"]').val()));
        var total_payment_new_2 = parseInt($('[name="total_payment"]').val());
        var grand_total_new_2 = parseInt($('#grand_total').val());

        if (point_current > saldo_point || total_payment_new_2 > grand_total_new_2) {
            $('[name="point"]').val('');
            total_payment();
            alert_error('maksimal : ' + grand_total_new_2);
        }

    })

    $('.checked_deposito').change(function () {
        if ($(this).prop('checked')) {
            var grand_total = $('#grand_total').val();
            if (grand_total == '' || grand_total == 0) {
                swal(
                    'BELUM ADA PEMBELIAN!',
                    'belum ada produk pembelian!',
                    'warning'
                );
                $('.checked_deposito').removeClass('off');
            } else {
                $('[name="deposito"]').val('');
                count_rest_payment('.checked_deposito', 'deposito', 'saldo_deposito');
            }
        }else{
            $('[name="deposito"]').val('');
            total_payment();
        }
    });

    $('.checked_point').change(function () {
        if ($(this).prop('checked')) {
            var grand_total = $('#grand_total').val();
            if (grand_total == '' || grand_total == 0) {
                swal(
                    'BELUM ADA PEMBELIAN!',
                    'belum ada produk pembelian!',
                    'warning'
                );
                $('.checked_point').removeClass('off');
            } else {
                $('[name="point"]').val('');
                count_rest_payment('.checked_point', 'point', 'saldo_point');
            }
        }else{
            $('[name="point"]').val('');
            total_payment();
        }
    });

    $('.checked_ppn').change(function () {
        count_grand_total();
        $('.checked_point').removeClass('off');
        $('[name="point"]').val('');
        $('[name="deposito"]').val('');
        $('.checked_deposito').removeClass('off');
        total_payment();
    });
    $('.checked_pph').change(function () {
        count_grand_total();
        $('.checked_point').removeClass('off');
        $('[name="point"]').val('');
        $('[name="deposito"]').val('');
        $('.checked_deposito').removeClass('off');
        total_payment();
    });

    function count_rest_payment(checkbox,name,saldo) {
        var cash_payment_count = $('[name="payment"]').val();
        var deposito_payment_count    = $('[name="deposito"]').val();
        var point_payment_count = $('[name="point"]').val();
        var grand_total_count = $('#grand_total').val();
        var saldo = parseInt($('[name="'+saldo+'"]').val());

        if (cash_payment_count == '') {
            cash_payment_count = 0;    
        } else {
            cash_payment_count = delete_dot_value(cash_payment_count);
        }

        if (deposito_payment_count == '') {
            deposito_payment_count = 0;
        } else {
            deposito_payment_count = delete_dot_value(deposito_payment_count);
        }

        if (point_payment_count == '') {
            point_payment_count = 0;
        } else {
            point_payment_count = delete_dot_value(point_payment_count);
        }
        
        cash_payment_count = parseInt(cash_payment_count);
        deposito_payment_count = parseInt(deposito_payment_count);
        point_payment_count = parseInt(point_payment_count);

        var total_payment_current = cash_payment_count + deposito_payment_count + point_payment_count;
        var rest_payment = parseInt(grand_total_count) - total_payment_current;
        if (saldo < rest_payment) {
            rest_payment = saldo;
        }

        if (rest_payment <= 0) {
            $(checkbox).removeClass('off') 
        } else {
            $('[name="'+name+'"]').val(money_function(String(rest_payment)));
        }
        total_payment();
    }
    
    $('.btn_choose_product').click(function () {
        $('.modal-title').text('PILIH PRODUK');
        $.ajax({
            url: url_controller + '/get_all_product',
            type: "POST",
            dataType: "JSON",
            success: function (data) {
                $('.view_stock_current').html(data.html_respon);
                $('#modal_stock_current').modal('show');
                $(document).find('.chosen').chosen();
                $('.table_view_stock').DataTable();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('.btn_choose_product');
                alert_error('something wrong');
            }
        });//end ajax
    });

    $(document).on('click', '.add_cart_product', function () {
        var data_current = $(this).data('id');
        $.ajax({
            url: url_controller + '/choose_product_cart',
            type: "POST",
            dataType: "JSON",
            data:{'data_current':data_current},
            success: function (ui) {
                if (ui.status) {
                    if (ui.item.stock <= 0) {
                        swal(
                            'STOK KOSONG!',
                            'mohon maaf, stok barang kosong!',
                            'warning'
                        );
                    } else {
                        $('#price_product').val(ui.item.price);
                        //$('#price_shown').val(money_function(ui.item.price));
                        $('#id_product').val(ui.item.id);
                        $('#stock').val(ui.item.stock);
                        // alert_error(ui.item.id);
                        $("#price").empty();
                        for(i = 0 ; i < ui.item.price.length ; i++){
                            var o = new Option(money_function(ui.item.price[i]), ui.item.price[i]);
                            $(o).html(money_function(ui.item.price[i]));
                            $("#price").append(o);
                        }

                        $('.unit_name').text('/ ' + ui.item.unit_name);
                        $('#price_product').val(ui.item.price);
                        $('#product-name').val(ui.item.label + ' (stok : ' + ui.item.stock + ' ' + ui.item.unit_name + ')');
                        $('#qty_buy').val('');
                        get_unit_request(ui.item.id)
                        $('#qty_buy').focus();
                        $('#modal_stock_current').modal('hide');
                    }
                } else {
                    alert_error('something wrong');
                }
                
                
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('.btn_choose_product');
                alert_error('something wrong');
            }
        });//end ajax
    });

    
    $(document).on('click', '#btn_save', function () {
        // $('#modal_review_sales').modal('hide');
        // showLoading();
        $('.help-block').empty();
        $('.form-group').removeClass('has-error');
        var id_sales_so = $('#btn_paymen_so').data('id');
        
        var url = url_controller + 'save_sales';
        var formData = new FormData($('#form_sales')[0]);
        formData.append('id_sales_so', id_sales_so);
        if (status_credit == 1) {
            formData.append('name_responsible', $('[name="name_responsible"]').val());
            formData.append('expired_date', $('[name="expired_date"]').val());
            formData.append('note', $('[name="note"]').val());
            formData.append('id_sales', $('[name="id_sales_employee"]').val());
        }
        if (status_delivery == 1) {
            formData.append('receiver', $('[name="receiver"]').val());
            formData.append('number_phone', $('[name="number_phone"]').val());
            formData.append('postal_code', $('[name="postal_code"]').val());
            formData.append('kec', $('[name="kec"]').val());
            formData.append('regency', $('[name="regency"]').val());
            formData.append('province', $('[name="province"]').val());
            formData.append('address',$('[name="address"]').val());
            formData.append('id_sales', $('[name="id_sales_employee"]').val());
        }
        $.ajax({
            url: url,
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            dataType: "JSON",
            success: function (data) {
                if (data.status) {
                    if (data.id_sales_so > 0) {
                        location.href = url_controller;
                    }
                    status_ready = false;
                    $('#modal_review_sales').modal('hide');
                    notif_success('pembelian berhasil disimpan');
                    get_code_sales();
                    $('#sales_employee').val('');
                    $('#id_sales_employee').val('');
                    $('#member_id').val('');
                    $('#member_name').val('');

                    $('#price_product').val('');
                    $('#price_shown').val('');
                    $('#id_product').val('');
                    $('#stock').val('');
                    $('#qty_buy').val('');
                    $('#barcode').val('');
                    $('.base_unit_name').text('');
                    $('#price_product').val('');
                    $('#product-name').val('');
                    $('.credit_status').prop('checked', false);
                    $('.delivery_status').prop('checked', false);
                    //payment form
                    $('#grand_total').val('');
                    $('#grand_total_sales').val('');
                    $('#grand_total_shown').text('Rp.0');
                    $('#pph').val('');
                    $('#ppn').val('');
                    $('.text-ppn').text('Rp.0');
                    $('.text-pph').text('Rp.0');
                    $('#payment').val('');
                    $('[name="total_payment"]').val('');
                    $('#all_item').val('');
                    $('#text-payment').text('0');
                    $('[name="deposito"]').val('');
                    $('[name="point"]').val('');
                    $('.payment-point').hide();
                    $('.payment-deposito').hide();
                    $('.html_respon_member').empty();
                    $('[name="member_code"]').val('');
                    $('.form-credit').hide();

                    $('.checked_point').removeClass('off');
                    $('.checked_deposito').removeClass('off');
                    $('.checked_ppn').removeClass('off');
                    $('.checked_pph').removeClass('off');
                    $('.credit_status').removeClass('off');

                    // count_grand_total();
                    //tabel item sales
                    $('.add_html_item_sales').empty();
                    //modal item review
                    $('.add_html_review').empty();
                    get_number_sales_today()
                    $('#barcode').focus();
                    count_grand_total();

                    swal(
                        'Berhasil!',
                        'transaksi telah disimpan!',
                        'success'
                    );
                    //print nota
                    get_invoice(data.id);
                    // $('#form_payment').collapse("hide"); 
                    
                } else {
                    for (var i = 0; i < data.inputerror.length; i++)
                    {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                    }
                }
                $('#btn_save');
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('#btn_save');
                alert_error('error process');
            }
        });   
    })

    function get_invoice(id) {
        $.ajax({
            url: url_controller+'/print_nota',
            type: "POST",
            dataType: "JSON",
            data:{'id':id},
            success: function (data) {
                $('#html_nota').html(data.html_respon);
                // $('.cover_btn_print').html(data.btn_print);

                // $(document).on('click', '.btn_print', function () { });
                $('.btn_print').click();
                // $('[name="data_product"]').val(data.data_product);
            },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_add_product');
                    alert_error('something wrong');
                }
        });//end ajax
    }

    $(document).on('click', '.btn_show_promo', function () {
        var value_current_promo = $(this).data('id');
        $.ajax({
            url: url_controller+'/show_promo',
            type: "POST",
            data:{'value':value_current_promo},
            dataType: "JSON",
            success: function (data) {
                $('#modal_promo').modal('show');
                $('.html_respon_promo').html(data.html_respon);
                setInterval(function () {
                    $(".blink").toggle();
                }, 500)
                
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('something wrong')
            }
        });
        
    })

    $('.del_all_item').click(function () {

        swal({
            title: 'Apakah anda yakin?',
            text: "data transaksi ini akan dikosongkan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya,lanjutkan',
            cancelButtonText: 'Batal'
        },
    function(isConfirm) {
            if (isConfirm) {
                status_ready = false;
                $('.help-block').empty();
                $('#modal_review_sales').modal('hide');
                get_code_sales();
                $('#price_product').val('');
                $('#price_shown').val('');
                $('#id_product').val('');
                $('#stock').val('');
                $('#qty_buy').val('');
                $('#barcode').val('');
                $('.base_unit_name').text('');
                $('#price_product').val('');
                $('#product-name').val('');
                $('.credit_status').prop('checked', false);
                $('.delivery_status').prop('checked', false);
                //payment form
                $('#grand_total').val('');
                $('#grand_total_sales').val('');
                $('#grand_total_shown').text('Rp.0');
                $('#pph').val('');
                $('#ppn').val('');
                $('.text-ppn').text('Rp.0');
                $('.text-pph').text('Rp.0');
                $('#payment').val('');
                $('[name="total_payment"]').val('');
                $('#all_item').val('');
                $('#text-payment').text('0');
                $('[name="deposito"]').val('');
                $('[name="point"]').val('');
                $('.payment-point').hide();
                $('.payment-deposito').hide();
                $('.html_respon_member').empty();
                $('[name="member_code"]').val('');
                $('.form-credit').hide();

                $('.checked_point').removeClass('off');
                $('.checked_deposito').removeClass('off');
                $('.checked_ppn').removeClass('off');
                $('.checked_pph').removeClass('off');
                $('.credit_status').removeClass('off');

                // count_grand_total();
                //tabel item sales
                $('.add_html_item_sales').empty();
                //modal item review
                $('.add_html_review').empty();
                get_number_sales_today()
                $('#barcode').focus();
                count_grand_total();

                notif_success('transaksi telah dikosongkan!');
            } 
        });


    });
    

function money_function(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}
    
function money_function2(angka, prefix) {
    console.log(angka);

        var number_string = angka.toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
    
    

    // ------------------------------------- part add member ------------------------------------------------------
    function add_user() {
        save_method = 'add'
        $('#form_member')[0].reset();
        $('.form-group').removeClass('has-error');
        $('.help-block').empty();
        $('.modal-title').text('Form Member');
        $('#modal_member').modal('show');
    }

    function save_member() {
        $('.form-group').removeClass('has-error');
        $('.help-block').empty();
        $('#modal_member').modal('hide');
        showLoading();
        var url = 'member/save';
        //defined form
        var formData = new FormData($('#form_member')[0]);
        $.ajax({
            url: url,
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            dataType: "JSON",
            success: function(data) {
                if (data.status) {
                    console.log(data);
                    // $('#modal_user').modal('hide');
                    hideLoading();
                    notif_success('data berhasil disimpan!');
                    get_data_member();
                    $('#id_member').val(data.id_member);
                } else {
                    hideLoading();
                    $('#modal_member').modal('show');
                    for (var i = 0; i < data.inputerror.length; i++) {
                        $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                        $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                    }
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });

    }

    //--------------------------------------------- part stock view --------------------------------------------------
    function view_stock() {
        showLoading();
        $('.modal-title').text('STOK BARANG');
        var url = url_controller + 'get_stock_current';
        // var formData = new FormData($('#form_sales')[0]);
        $.ajax({
            url: url,
            type: "GET",
            dataType: "HTML",
            success: function(data) {
                hideLoading();
                $('.view_stock_current').html(data);
                $('#modal_stock_current').modal('show');
                $(document).find('.chosen').chosen();
                $('.table_view_stock').DataTable();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    }

    function number_only(id_name) {
        var qty = $("#" + id_name).val();
        var clean_word = qty.replace(/[^,\d]/g, '');
        $("#" + id_name).val(clean_word);
    }

    //------------------------------------------- part view sales -----------------------------------------
    function get_number_sales_today() {
        var url = url_controller + 'count_sales_today';
        // var formData = new FormData($('#form_sales')[0]);
        $.ajax({
            url: url,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
                $('.order_today').text(data.count);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    }

    function view_sales_today() {
        showLoading();
        $('.modal-title').text('DATA PENJUALAN HARI INI');
        var url = url_controller + 'get_view_sales_today';
        // var formData = new FormData($('#form_sales')[0]);
        $.ajax({
            url: url,
            type: "GET",
            dataType: "HTML",
            success: function(data) {
                hideLoading();
                $('.view_sales_today').html(data);
                $('#modal_view_sales').modal('show');
                $('.table_view_sales').DataTable();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    }

    function view_detail_sales(id) {
        // alert_error(id);
        // $('#modal_view_detail_sales').modal('show');
        showLoading();
        $('.modal-title').text('DETAIL');
        var url = url_controller + 'get_detail_sales/' + id;
        // var formData = new FormData($('#form_sales')[0]);
        $.ajax({
            url: url,
            type: "GET",
            dataType: "HTML",
            success: function(data) {
                hideLoading();
                $('.view_detail_sales').html(data);
                $('#modal_view_detail_sales').modal('show');
                // $('.table_view_sales').DataTable();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
                hideLoading();
            }
        });
    }

    // table_view_sales

function print_nota(id_sales) {
    var url = url_controller + 'cetak_struk/' + id_sales;
    // window.print();
    // $('.view_detail_sales').print();
    var formData = new FormData($('#form_sales')[0]);
    $.ajax({
        url: url,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            // notif_success('nota berhasil dicetak');
            swal(
                'Berhasil!',
                'Nota berhasil di cetak!',
                'success'
            );
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });    
}
    
$('.btn_view_event').click(function () {
    var type = $(this).data('id');
    var text_promo = type == '1' ? 'DATA DISKON BARANG' : 'DATA PROMO BARANG';
    $('.modal-title').text(text_promo);
    $.ajax({
        url: url_controller+'/get_discount',
        type: "POST",
        dataType: "JSON",
        data:{'type':type},
        success: function(data) {
            hideLoading();
            $('.view_detail_sales').html(data.html_respon);
            $('.table-event').DataTable();
            $('#modal_view_detail_sales').modal('show');
            // $('.table_view_sales').DataTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})
    
    //------------------------------ short cut --------------------------


    
$(document).on('click', '.btn_search', function (e) {
    e.preventDefault();
    $(this);
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    $.ajax({
        url: url_controller + "search_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon').html(data.html_respon);
                notif_success('selesai');
                $(".pagination").rPage();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_search');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_search');
            alert_error('something wrong');
        }

    });
});


//pagination 
$(document).on('click', '.page-link', function () {
    var page_number = $(this).data('ci-pagination-page');
    $(this).text('load..');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    formData.append('page', page_number);
    $.ajax({
        url: url_controller + "search_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon').html(data.html_respon);
                notif_success('selesai');
                $(".pagination").rPage();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_search');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_search');
            alert_error('something wrong');
        }

    });
});