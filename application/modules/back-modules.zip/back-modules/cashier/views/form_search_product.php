<?php
$status = isset($status_add) ? TRUE : FALSE;
?>
<div class="col-md-12">
        <form class="form-input">
            <input type="hidden" name="status" value="<?php echo $status?>"/>
            <div class="row border rounded p-3">
                <div class="col-md-6">
                    <label>DEVISI</label>
                    <select name="id_devision[]" multiple class="form-control chosen">
                        <option value="">TIDAK ADA</option>
                        <?php
                        foreach ($data_devision as $item_main_category) {
                            echo '<option value="' . $item_main_category->id . '">' . $item_main_category->name . '</option>';
                        }
                        ?>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-6">
                    <label>KATEGORI</label>
                    <select name="id_category[]" multiple class="form-control chosen">
                        <option value="">TIDAK ADA</option>
                        <?php
                        foreach ($data_category as $item_data) {
                            echo '<option value="' . $item_data->id . '">' . $item_data->name . '</option>';
                        }
                        ?>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-3 mt-2">
                    <label>Kode</label>
                    <input type="text" class="form-control" name="code">
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-7 mt-2">
                    <label>Nama Produk</label>
                    <input type="text" class="form-control" name="name">
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-2 text-right mt-2" style="padding:0 !important;margin:0 !important;">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-primary btn-rounded btn_search btn-block"> <i class="fa fa-search"></i> Cari Data </button>
                </div>
            </div>
        </form>
</div>
<!-- /.box-body -->
<span class="clearfix"></span>
<hr>
<div class="html_respon">
    <h1 class="text-center text-gray">ISILAH FORM PENCARIAN TERLEBIH DAHULU</h1>
</div>