<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table_data">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Divisi</th>
                        <th>Kategori</th>
                        <th>Satuan</b></th>
                        <th>Harga 1</b></th>
                        <th>Harga 2</b></th>
                        <th>Harga 3</b></th>
                        <th>Harga 4</b></th>
                        <th>STOK</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = $start_no;
                    
                    foreach ($data_product as $data_table) {
                        $data_current = $this->encrypt->encode(json_encode($data_table));
                        $no++;
                        if ($status_add) {
                            $html_btn = '<a href="javascript:void(0)" data-id="' . $data_current . '" class="btn btn-default add_cart_product"> <i class="fa fa-shopping-cart"></i> Masukan Keranjang</a>';
                        } else {
                            $html_btn = '';
                        }

                        echo '
                            <tr>
                                <td>' . $no . '</td>
                                <td>' . $data_table->code . '</td>
                                <td>' . $data_table->name . '</td>
                                <td>' . $data_table->devision_name . '</td>
                                <td>' . $data_table->category_name . '</td>
                                <td>' . $data_table->unit_name . '</td>
                                <td>' . number_format($data_table->price_1, 0, ",", ".") . '</td>
                                <td>' . number_format($data_table->price_2, 0, ",", ".") . '</td>
                                <td>' . number_format($data_table->price_3, 0, ",", ".") . '</td>
                                <td>' . number_format($data_table->price_4, 0, ",", ".") . '</td>
                                <td>' . $data_table->stock . '</td>
                                <td>' . $html_btn . '</td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-4">
                    <!--Tampilkan pagination-->
                    <?php echo $html_pagination; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.box-body -->
</div>