<style type="text/css">
    .auto-squence>.form-control {
        /*display: inline-block;*/
        float: left;
        width: 48%;
        /*background-color: red;*/
        margin: 0;
        /*padding: 0;*/
    }
</style>
<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <label style="font-size:15px;" class="col-md-2 label label-info"><i class="fa fa fa-cart-arrow-down"></i> Penjualan Hari Ini</label>
        <div class="col-md-4">
            <label><i class="fa fa-circle text-red"></i> Add Item = <span class="text-red">(Enter)</span> </label> &nbsp;|
            <label><i class="fa fa-circle text-red"></i> Payment = <span class="text-red">(Ctrl + Enter)</span></label> &nbsp;|
            <label><i class="fa fa-circle text-red"></i> Save = <span class="text-red">(F1)</span></label> &nbsp;
        </div>
        <div class="col-md-6" align="right">
            <!-- <button type="button" id="add_button" onclick="add_user()" class="btn btn-default"><i class="fa fa-user"></i> Tambah Member <b>(F2)</b></button> -->
            <button type="button" id="add_button" onclick="view_stock()" class="btn btn-default"><i class="fa fa-list-alt"></i> Lihat Stok <b>(F3)</b></button>
            <button type="button" class="btn btn-default btn_view_event" data-id="1"><i class="fa fa-gift"></i> Produk Diskon</button>
            <button type="button" class="btn btn-default btn_view_event" data-id="2"><i class="fa fa-gift"></i> Produk Promo</button>
            <button type="button" id="add_button" onclick="view_sales_today()" class="btn btn-default"><i class="fa fa-history"></i> <label class="order_today"></label> Penjualan hari ini <b>(F4)</b></button>
        </div>
    </div>
    <!-- end box header -->
    <div class="card-body">
        <form class="form-horizontal" id="form_sales" method="POST">
            <div class="col-md-12">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Kode</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="code" name="code" readonly style="background-color:#fff;" placeholder="code">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-3 control-label">Tanggal</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="date" name="date" readonly style="background-color:#fff;" placeholder="date" value="<?php echo $date_order; ?>">
                        </div>
                    </div>
                    <hr>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-3 control-label">Member</label>
                        <div class="col-sm-7">
                            <input class="form-control form-control-lg" name="member_code" placeholder="masukan kode member">
                        </div>
                        <div class="col-sm-2 text-center">
                            <a href="javascript:void(0)" class="btn btn-default btn_search_member"><i class="fa fa-search"></i></a>
                            <small class="block">SHIFT + A</small>
                        </div>
                    </div>
                    <div class="form-group html_respon_member"></div>
                </div>
                <div class="col-md-7" style="border:1px solid #00a65a;padding:5px;margin-left:30px;margin-right:10px;padding:10px;border-radius:5px;">
                    <div class="col-md-12" align="center" style="margin-bottom:10px;">
                        <input type="hidden" name="grand_total" id="grand_total">
                        <input type="hidden" name="grand_total_sales" id="grand_total_sales">
                        <input type="hidden" name="ppn" id="ppn">
                        <input type="hidden" name="pph" id="pph">
                        <input type="hidden" name="all_item" id="all_item">
                        <h5 class="headline text-green col-md-12">GRAND TOTAL :</h5>
                        <h1 class="headline text-green col-md-12" id="grand_total_shown">Rp.0</h1>
                        <span class="clearfix"></span>
                        <hr>
                        <h5 class="headline text-green col-md-12">Bayar :</h5>
                        <h1 class="headline text-green col-md-12" id="text-payment">0</h1>
                        <input type="hidden" name="total_payment">
                    </div>
                    <div class="col-md-12" align="center">
                        <!-- <label for="inputPassword3" class="col-sm-3 control-label">Bayar</label> -->
                        <div class="col-sm-9">
                            <div class="col-md-12">
                                <label for="inputEmail3" class="col-sm-4 control-label">BAYAR :</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control money_only payment" name="payment" id="payment" style="height:40px;font-size:20px;" placeholder="Rp..">
                                    <span class="help-block notif_btn_payment" style="color:red;"></span>
                                </div>
                            </div>
                            <span class="clearfix"></span>
                            <div class="col-md-12 text-left payment-deposito d-none">
                                <input type="hidden" name="saldo_deposito">
                                <div for="inputEmail3" class="col-sm-4 control-label text-bold" style="margin-top: 30px;">DEPOSITO :</div>
                                <div class="col-sm-8">
                                    <div style="width: 100%">
                                        <label for="">(Saldo : <span class="text-green saldo_deposito"></span> ) </label>
                                        <input type="checkbox" data-toggle="toggle" data-on="Lunasi otomatis" data-off="Lunasi otomatis" class="checked_deposito" data-size="mini" data-onstyle="success" data-width="120">
                                    </div>
                                    <input type="text" class="form-control money_only payment" name="deposito" style="height:40px;font-size:20px;" placeholder="Rp..">
                                    <span class="help-block notif_btn_deposit" style="color:red;"></span>
                                </div>
                            </div>
                            <span class="clearfix"></span>
                            <div class="col-md-12 text-left payment-point d-none">
                                <input type="hidden" name="saldo_point">
                                <div for="inputEmail3" class="col-sm-4 control-label text-bold" style="margin-top: 30px;">POINT :</div>
                                <div class="col-sm-8">
                                    <div style="width: 100%">
                                        <label for="">(Saldo : <span class="text-green saldo_point"></span> )</label>
                                        <input type="checkbox" data-toggle="toggle" data-on="Lunasi otomatis" data-off="Lunasi otomatis" class="checked_point" data-size="mini" data-onstyle="success" data-width="120">
                                    </div>
                                    <input type="text" class="form-control money_only payment" name="point" style="height:40px;font-size:20px;" placeholder="Rp..">
                                    <span class="help-block notif_btn_point" style="color:red;"></span>
                                </div>
                            </div>
                            <span class="clearfix"></span>
                            <div class="col-md-12">
                                <label for="inputEmail3" class="col-sm-4 control-label">&nbsp;</label>
                                <div class="col-sm-8">
                                    <div class="col-md-6 text-left">
                                        <label class="text-muted label_ppn">PPN <?= $get_ppn->value; ?>% =</label> <span class="text-ppn">Rp.-</span><br>
                                        <input type="checkbox" data-width="100" class="checked_ppn" data-toggle="toggle" data-on="Aktif" data-off="Non-Aktif" data-size="mini" data-onstyle="success">
                                    </div>
                                    <div class="col-md-6 text-left">
                                        <label class="text-muted label_pph">PPH <?= $get_pph->value; ?>% =</label> <span class="text-pph">Rp.-</span><br>
                                        <input type="checkbox" data-width="100" class="checked_pph" data-toggle="toggle" data-on="Aktif" data-off="Non-Aktif" data-size="mini" data-onstyle="success">
                                    </div>
                                    <div class="col-md-6 pull-right text-left d-none form-credit">
                                        <label> Piutang</label><br>
                                        <input type="checkbox" data-toggle="toggle" data-width="100" name="credit_status" class="credit_status" value="1" data-on="Aktif" data-off="Non-Aktif" data-size="mini" data-onstyle="success">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <button type="button" class="btn btn-lg btn-success btn_payment"> Bayar</button>
                            <small class="block">shortcut : <b>Ctrl + Enter</b></small>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end col md-12 -->
            <span class="clearfix"></span>

            <div class="row mt-10">
                <div class="col-md-4">
                    <label for="">Barcode / Nama Barang</label> <small>(*ketik barcode produk atau nama barang)</small>
                    <input type="text" class="form-control  form-control-lg" id="barcode" name="barcode" autofocus placeholder="ketik disini">
                    <span class="help-block notif_name" style="color:red;"></span>
                </div>
                <div class="col-md-1">
                    <label for="">&nbsp;</label><br>
                    <span class="load_icon d-none">
                        <i class="fa fa-refresh fa-spin"></i> loading...
                    </span>
                </div>
                <div class="col-md-3">
                    <label for="">&nbsp;</label><br>
                    <button class="btn btn-default btn_clear_barcode"><i class="fa fa-refresh"></i> Bersihkan</button> ||
                    <button class="btn btn-default btn_choose_product"><i class="fa fa-tv"></i> Pilih Produk <b>(F2)</b></button>
                </div>
                <span class="clearfix"></span>
                <div class="col-xs-4">
                    <label>Nama Barang</label>
                    <input type="hidden" name="data_product">
                    <input type="text" class="form-control" id="product-name" name="product_name" placeholder="ketik disini">
                    <span class="help-block notif_name" style="color:red;"></span>
                </div>
                <div class="col-xs-2 form-group">
                    <label>Harga Satuan</label>
                    <div class="input-group">
                        <!-- <input type="hidden" name="price" id="price_product"> -->
                        <input type="text" name="price" class="form-control money_only" readonly id="price_shown" style="background-color:#fff;">
                        <span class="input-group-addon unit_name"></span>
                    </div>
                    <span class="help-block notif_price"></span>
                </div>

                <div class="col-xs-3 base_product_change">
                    <label class="col-xs-12">Jumlah Beli</label>
                    <div class="auto-squence">
                        <input type="text" class="form-control number_only" id="qty_buy" name="qty_buy">
                        <select class="form-control" id="unit" name="unit">
                        </select>
                    </div>
                    <span class="help-block notif_qty" style="color:red;"></span>
                </div>
                <div class="col-xs-3">
                    <label>&nbsp;</label><br>
                    <button type="button" class="btn btn-default btn-md add_sales_item"><i class="fa fa-plus"></i> Tambah <b>(ENTER)</b></button>
                    &nbsp;&nbsp; || &nbsp;&nbsp;
                    <button type="button" class="btn btn-danger btn-md del_all_item"><i class="fa fa-refresh"></i> Hapus Semua</b></button>

                </div>
                <!-- <div class="col-xs-2">
                    <label>&nbsp;</label><br>
                    <button type="button" class="btn btn-default btn-md add_sales_item"><i class="fa fa-plus"></i> Tambah <b>(ENTER)</b></button>
                </div> -->
            </div>
            <hr>
            <div class="cover_table_list">
                <table id="table_list_item" class="table  table-striped">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Harga Satuan</th>
                            <th>QTY</th>
                            <th>Potongan Member</th>
                            <th>Diskon</th>
                            <th>Total</th>
                            <th>Bonus</th>
                        </tr>
                    </thead>
                    <tbody class="add_html_item_sales">
                    </tbody>
                </table>
            </div>
        </form>
    </div>
</div>
<span class="clearfix"></span>
<div class="col-md-8 bg-white d-none" id="html_nota">
</div>
<div class="col-md-4 d-none">
    <button type="button" class="btn_print" onclick="printJS('html_nota', 'html')">
        Print Form
    </button>
</div>

<div class="modal" id="modal_review_sales" data-backdrop="static">
    <div class="modal-dialog" style="width:85%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">REVIEW PEMBELIAN</h4>
            </div>
            <div class="card-body pad">
                <div class="col-md-12">
                    <table width="100%" class="" style="font-size:15px;">
                        <tr>
                            <td height="25px" width="120px">Kode Nota</td>
                            <td width="5px">:</td>
                            <td id="code_nota"></td>
                        </tr>
                        <tr>
                            <td height="25px">Tanggal</td>
                            <td>:</td>
                            <td id="date_order"></td>
                        </tr>
                        <tr>
                            <td height="25px">Nama Member</td>
                            <td>:</td>
                            <td id="member_name"></td>
                        </tr>
                    </table>
                    <!-- <small><u>ITEM PEMBELIAN</u></small> -->
                    <div class="add_html_review"></div>
                </div>
                <div class="col-md-12">
                    <div class="col-md-8">
                        <div class="html_form"></div>
                    </div>
                    <div class="col-md-4">
                        <div class="html_payment"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<div class="modal" id="modal_view_sales" data-backdrop="static">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="card-body pad">
                <div class="view_sales_today"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<div class="modal" id="modal_view_detail_sales" tabindex="-1">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="view_detail_sales">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>


<div class="modal" id="modal_stock_current">
    <div class="modal-dialog" style="width:80%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="view_stock_current"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<div class="modal" id="modal_member" data-backdrop="static">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <form role="form" id="form_member">
                    <input type="hidden" name="id">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="masukan nama..">
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nomor HP</label>
                            <input type="text" class="form-control" name="no_hp" id="no_hp" onkeyup="number_only('no_hp')" maxlength="13" placeholder="masukan nama..">
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Alamat</label>
                            <textarea class="form-control" name="address"></textarea>
                            <span class="help-block"></span>
                        </div>
                        <div class="card-footer">
                            <button type="button" onclick="save_member()" class="btn btn-lg btn-primary pull-right"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                        </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<div class="modal" id="modal_promo">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Promo</h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_promo"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>