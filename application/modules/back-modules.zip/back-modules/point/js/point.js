var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/point';
var save_method;
var table;
var id_use;
$(document).ready(function(){
	table= $('.table_data').DataTable({
        "ajax": {
            "url": controller+"/list_data",
            "type": "POST"
        },
        "fnDrawCallback": function() {
		   $('.checkbox_status').bootstrapToggle();
		}
    });
    // console.log(controller);
})

function reload_table(){
     table.ajax.reload(null,false); //reload datatable ajax 
}

$('.btn_add').click(function () {
    $('.btn_save').button('reset');
	save_method = 'add';
	$('.form-group').removeClass('has-error');
 	$('.help-block').empty();
    $('.form-input')[0].reset();
	$('.modal-title').text('TAMBAH DATA');
	$('#modal-form').modal('show');
})

$('.btn_save').click(function (e) {
    e.preventDefault();
    $(this).button('loading');
	$('.form-group').removeClass('has-error');
	$('.help-block').empty();  
	  //defined form
	   var formData = new FormData($('.form-input')[0]);
	   var url;
	   if(save_method=='add'){
	    url = '/save';
	   }else{
           url = '/update';
           formData.append('id', id_use);
	   }
	  $.ajax({
	    url: controller+url,
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData : false,
	    dataType :"JSON",
	    success: function(data){
	      if(data.status){
	      	$('#modal-form').modal('hide');
	        reload_table();
	        notif_success('Data Berhasil Disimpan');
	      } else{
	        for (var i = 0; i < data.inputerror.length; i++)
	         {
	            $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
	            $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
	         }
	      }
	      $('.btn_save').button('reset');
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	        $('.btn_save').button('reset');
            alert_error('something wrong');
	      }
	  });//end ajax
})

$(document).on("change", ".checkbox_status", function () {
    var id = $(this).val();
    if ($(this).prop('checked')) {
        status_active = 1;
    }else{
        status_active = 0;
    }
    $.ajax({
        url: controller+'/update_status',
        type: "POST",
        data: {'status':status_active,'id':id},
        dataType :"JSON",
        success: function(data){
                notif_success('status berhasil diupdate');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_save').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_edit', function () {
    var id = $(this).data('id');
    $('.modal-title').text('UPDATE DATA');
    $('.form-input')[0].reset();
	save_method = 'update';
	var PostData = {'id':id};
	$.ajax({
	    url: controller+'/get_edit',
	    type: "POST",
	    data: PostData,
	    dataType :"JSON",
        success: function (data) {
            id_use = data.id;  
            $('[name="price"]').val(data.min_price);
            $('[name="point"]').val(data.point);
            $('[name="note"]').val(data.note);
	      	$('#modal-form').modal('show'); 
	        $('.btn_save').button('reset');
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_save').button('reset');
	       alert_error('something wrong');
	      }
	  });//end ajax
})

$(document).on('click', '.btn_remove', function () {
    var id = $(this).data('id');
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,hapus data',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: controller+'/delete',
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function(data){
                    $('#modal-form').modal('hide'); 
                    notif_success('data berhasil dihapus');
                    reload_table();
                    $('.btn_remove').button('reset');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_remove').button('reset');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
})