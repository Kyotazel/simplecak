<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Point extends CI_Controller
{
    var $location = 'data_point/';
    var $tb_name = 'tb_member';
    var $module_name = 'point';
    var $js_page = 'point';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    // public function get_code()
    // {
    //     $number_text = 0;
    //     $db_name = $this->tb_name;
    //     $simbol = get_string_code($this->module_name);
    //     $first_number = 1;
    //     $code_pattern = substr(date('Y'), 2) . date('md');
    //     $code_pattern_like = $simbol . $code_pattern;
    //     $get_data_exist = $this->db->query("select max(code) as max_code from $db_name ")->row_array();
    //     if (!empty($get_data_exist['max_code'])) {
    //         $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
    //         $code = $clean_simbol + 1;
    //     } else {
    //         $code = $code_pattern . $first_number;
    //     }
    //     $code_return = $simbol . $code;
    //     return $code_return;
    // }


    public function index()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Data Point";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin', $data);
    }

    public function list_data()
    {
        $db_name = $this->tb_name;
        $this->db->select('
                            tb_point.*,
                            tb_user.name AS user_name
                        ');
        $this->db->from('tb_point');
        $this->db->join('tb_user', 'tb_point.created_by = tb_user.id', 'left');
        $this->db->order_by('tb_point.id', 'DESC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            if ($data_table->status == 1) {
                $status_checked = 'checked';
            } else {
                $status_checked = '';
            }
            $row = array();
            $row[] = $no;
            $row[] = 'Rp.' . number_format($data_table->min_price, 0, '.', '.');
            $row[] = $data_table->point;
            $row[] = $data_table->note;
            $row[] = '<input type="checkbox" ' . $status_checked . ' data-size="small" data-on="Active" value="' . $this->encrypt->encode($data_table->id) . '" data-off="Non-Active" class="checkbox_status" data-toggle="toggle">';
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = '<a class="btn btn-sm btn-primary-gradient btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="glyphicon glyphicon-pencil"></i> edit</a>
				  <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="glyphicon glyphicon-trash"></i> Hapus</a>';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }
        if ($this->input->post('point') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'point';
            $data['status'] = FALSE;
        }
        if ($this->input->post('note') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'note';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();
        $price     = $this->input->post('price');
        $point     = $this->input->post('point');
        $note      = $this->input->post('note');
        //insert data
        $array_insert = array(
            'min_price' => $price,
            'point' => $point,
            'note' => $note,
            'status' => TRUE,
            'created_date' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('us_id')
        );
        $this->model->insert('tb_point', $array_insert);
        echo json_encode(array('status' => TRUE));
    }
    public function update_status()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $status = $this->input->post('status');
        $array_update = [
            'status' => $status
        ];
        $this->model->update(array('id' => $id), $array_update, 'tb_point');
        echo json_encode(['status' => TRUE]);
    }

    public function get_edit()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_data = $this->model->find(array('id' => $id), 'tb_point')->row_array();
        echo json_encode($get_data);
    }
    public function update()
    {
        $this->validate_insert();
        $id        = $this->input->post('id');
        $price     = $this->input->post('price');
        $point     = $this->input->post('point');
        $note      = $this->input->post('note');
        //insert data
        $array_update = array(
            'min_price' => $price,
            'point' => $point,
            'note' => $note,
            'updated_by' => $this->session->userdata('us_id')
        );
        $this->model->update(array('id' => $id), $array_update, 'tb_point');
        echo json_encode(array('status' => TRUE));
    }
    public function delete()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $this->model->delete(array('id' => $id), 'tb_point');
        echo json_encode(array('status' => TRUE));
    }
}
