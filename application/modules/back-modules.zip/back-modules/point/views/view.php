<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <button type="button" id="add_button" title="add data" class="btn btn-default pull-right btn_add">
            <i class="fa fa-plus"></i> Tambah Data
        </button>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped table_data">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Min Harga Beli</th>
                    <th>Point</th>
                    <th>Keterangan</th>
                    <th>Status</th>
                    <th>Tanggal input</th>
                    <th>Petugas</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <form role="form" class="form-input">
                    <input type="hidden" name="id">
                    <div class="card-body">
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">Min.Harga Pembelian</label>
                            <input type="text" class="form-control number_only" name="price">
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">Point</label>
                            <input type="text" class="form-control number_only" name="point">
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1">Keterangan</label>
                            <textarea class="form-control" name="note"></textarea>
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group col-md-12 text-right">
                            <button class="btn btn-success btn_save">Simpan Data</button>
                        </div>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>