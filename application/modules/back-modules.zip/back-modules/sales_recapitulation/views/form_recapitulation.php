<?php
$data_sales->date = $date;
$encrypt_data_sales = $this->encrypt->encode(json_encode($data_sales));
?>
<div class="card">
    <div class="card-header">
        <label style="font-size:15px;" class="col-md-3 label label-info p-10"><i class="fa fa fa-file-o"></i> SETORAN HARI INI</label>
    </div>
    <div class="card-body">
        <form class="form-horizontal form-input" method="POST">
            <div class="col-md-12">
                <div class="col-md-4 html_resume">
                    <div style="padding:10px" class="text-center">
                        <small>Total Penjualan:</small>
                        <h1>Rp.<?= number_format($data_sales->sum_price_total_sales, 0, '.', '.'); ?></h1>
                    </div>
                    <br>
                    <table class="table">
                        <tr>
                            <td width="200px">Tanggal</td>
                            <td width="5px">:</td>
                            <td><b><?= $date; ?></b></td>
                        </tr>
                        <tr>
                            <td>Total Nota</td>
                            <td>:</td>
                            <td><b><?= $data_sales->total_invoice; ?> NOTA</b></td>
                        </tr>
                        <tr>
                            <td>Total Item Terjual</td>
                            <td>:</td>
                            <td><b><?= $data_sales->sum_total_item; ?> ITEM</b></td>
                        </tr>
                        <tr>
                            <td>Total Jumlah Terjual</td>
                            <td>:</td>
                            <td><b><?= $data_sales->sum_total_qty; ?> PCS</b></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-7" style="border:1px solid #00a65a;padding:5px;margin-left:30px;margin-right:10px;padding:10px;border-radius:5px;">
                    <div class="col-md-12" align="center" style="margin-bottom:10px;">
                        <h5 class="headline text-green col-md-12">TOTAL UANG PENJUALAN :</h5>
                        <h1 class="headline text-green col-md-12" id="grand_total_shown">Rp.<?= number_format($data_sales->sum_price_total_sales, 0, '.', '.'); ?><b></b></h1>
                    </div>
                    <div class="col-md-12" align="center">
                        <div class="col-md-9">
                            <div class="col-md-12">
                                <label for="inputPassword3" class="col-sm-3 control-label">Setor</label>
                                <div class="col-sm-9">
                                    <div class="col-md-12 form-group">
                                        <input type="text" class="form-control money_only" name="payment" id="payment" style="height:40px;font-size:20px;" placeholder="Rp..">
                                        <span class="help-block notif_btn_payment" style="color:red;"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label for="inputPassword3" class="col-sm-3 control-label">Catatan</label>
                                <div class="col-sm-9">
                                    <div class="col-md-12 form-group">
                                        <textarea name="note" class="form-control" name="note" rows="5"></textarea>
                                        <span class="help-block" style="color:red;"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" data-id="<?= $encrypt_data_sales; ?>" class="btn btn-lg btn-success btn_review"> Simpan</button>
                            <small class="block">shortcut : <b>Enter</b></small>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end col md-12 -->
        </form>
        <span class="clearfix"></span>
        <hr>
        <div class="col-md-12">
            <h3>Detail Nota:</h3>
            <div class="table-responsive">
                <table class="table table-striped table-detail-sales">
                    <thead>
                        <tr>
                            <th width="40px">No</th>
                            <th>No.Nota</th>
                            <th>Tanggal</th>
                            <th>Total Item</th>
                            <th>Grand Total</th>
                            <th>Member</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $counter = 0;
                        foreach ($data_detail_sales as $item_sales) {
                            $counter++;
                            echo '
                                    <tr>
                                        <td>' . $counter . '</td>
                                        <td>' . $item_sales->code . '</td>
                                        <td>' . $item_sales->date . '</td>
                                        <td>' . $item_sales->count_item . ' ITEM</td>
                                        <td>' . number_format($item_sales->grand_total, 0, '.', '.') . '</td>
                                        <td>' . $item_sales->member_name . '</td>
                                    </tr>
                                ';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal" id="modal-detail">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>