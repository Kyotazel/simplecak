<div class="col-md-6">
    <table class="table">
        <tr>
            <td width="150px">Tanggal Setor</td>
            <td width="10px">:</td>
            <td>
                <b><?= $data_recapitulation->created_date; ?></b>
            </td>
        </tr>
        <tr>
            <td>Tanggal Penjualan</td>
            <td>:</td>
            <td>
                <b><?= $data_recapitulation->sales_date; ?></b>
            </td>
        </tr>
        <tr>
            <td>Total Nota</td>
            <td>:</td>
            <td>
                <b><?= $data_recapitulation->total_invoice; ?> NOTA</b>
            </td>
        </tr>
        <tr>
            <td>Total Item</td>
            <td>:</td>
            <td>
                <b><?= $data_recapitulation->total_item_sales; ?> ITEM</b>
            </td>
        </tr>
        <tr>
            <td>Jumlah Terjual</td>
            <td>:</td>
            <td><b><?= $data_recapitulation->total_qty_sales; ?> PCS</b></td>
        </tr>
    </table>
</div>
<div class="col-md-6">
    <div class="col-md-12 text-center p-10 border border-radius-5">
        <h5 class="headline col-md-12">TOTAL UANG PENJUALAN :</h5>
        <h2 class="headline text-green col-md-12" id="grand_total_shown"><b>Rp.<?= number_format($data_recapitulation->total_price_sales, 0, '.', '.'); ?></b></h2>
    </div>
    <div class="col-md-12 text-center p-10 border border-radius-5">
        <h5 class="headline col-md-12">TOTAL UANG SETOR :</h5>
        <h2 class="headline text-green col-md-12" id="grand_total_shown"><b>Rp.<?= number_format($data_recapitulation->report_price_sales, 0, '.', '.'); ?></b></h2>
    </div>
    <div class="col-md-12 text-center p-10 border border-radius-5">
        <h5 class="headline col-md-12">MARGIN :</h5>
        <h2 class="headline text-green col-md-12" id="grand_total_shown"><b>Rp.<?= number_format($data_recapitulation->margin, 0, '.', '.'); ?></b></h2>
    </div>
</div>
<div class="col-md-12">
    <hr>
    <h2>DETAIL NOTA :</h2>
    <br>
    <span class="clearfix"></span>
    <div class="table-responsive">
        <table class="table table-responsive table-data">
            <thead>
                <tr>
                    <th width="80px">No</th>
                    <th>No.Nota</th>
                    <th>Tanggal</th>
                    <th>Total Item</th>
                    <th>Grand Total</th>
                    <th>Member</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 0;
                foreach ($data_sales as $item_sales) {
                    $counter++;
                    echo '
                            <tr>
                                <td>' . $counter . '</td>
                                <td>' . $item_sales->code . '</td>
                                <td>' . $item_sales->date . '</td>
                                <td>' . $item_sales->count_item . ' ITEM</td>
                                <td>' . number_format($item_sales->grand_total, 0, '.', '.') . '</td>
                                <td>' . $item_sales->member_name . '</td>
                            </tr>
                        ';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>