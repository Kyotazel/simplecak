<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header text-right">
        <a href="<?= base_url('sales_recapitulation'); ?>" class="btn btn-default"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
    </div>
    <div class="card-body">
        <form class="form-search-sales">
            <div class="col-md-12 border p-10 border-radius-5">
                <div class="col-md-4 form-group">
                    <label for="">Tanggal Penjualan</label>
                    <input type="text" name="date" class="form-control datepicker bg-white" readonly>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-3 form-group">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-success btn-search-sales"><i class="fa fa-send"></i> Ambil Data</button>
                </div>

            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>
<div class="html_respon"></div>