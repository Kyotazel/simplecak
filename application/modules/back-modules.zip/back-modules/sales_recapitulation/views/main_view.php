<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header text-right">
        <a href="<?= base_url('sales_recapitulation/add'); ?>" class="btn btn-default"><i class="fa fa-plus"></i> Tambah Data</a>
    </div>
    <div class="card-body">
        <table class="table table-striped table_data">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Setor</th>
                    <th>Tanggal Penjualan</th>
                    <th>Item Terjual</th>
                    <th>Jumlah Terjual</th>
                    <th>Total Terjual</th>
                    <th>Total Penjualan</th>
                    <th>Total Disetor</th>
                    <th>Margin</th>
                    <th>Petugas</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="width:65%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>