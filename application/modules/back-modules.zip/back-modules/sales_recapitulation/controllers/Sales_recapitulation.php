<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales_recapitulation extends CI_Controller
{
    var $location = 'data_sales_recapitulation/';
    var $tb_name = 'tb_member';
    var $module_name = 'sales_recapitulation';
    var $js_page = 'sales_recapitulation';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    // public function get_code()
    // {
    //     $number_text = 0;
    //     $db_name = $this->tb_name;
    //     $simbol = get_string_code($this->module_name);
    //     $first_number = 1;
    //     $code_pattern = substr(date('Y'), 2) . date('md');
    //     $code_pattern_like = $simbol . $code_pattern;
    //     $get_data_exist = $this->db->query("select max(code) as max_code from $db_name ")->row_array();
    //     if (!empty($get_data_exist['max_code'])) {
    //         $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
    //         $code = $clean_simbol + 1;
    //     } else {
    //         $code = $code_pattern . $first_number;
    //     }
    //     $code_return = $simbol . $code;
    //     return $code_return;
    // }

    public function index()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Setoran & Rekapitulasi Penjualan";
        $data['view_file'] = $this->location . 'main_view';
        $this->load->view('template/media_admin', $data);
    }

    public function list_data()
    {
        $db_name = $this->tb_name;
        $this->db->select('
            tb_sales_recapitulation.*,
            tb_user.name AS user_name
            ');
        $this->db->from('tb_sales_recapitulation');
        $this->db->join('tb_user', 'tb_sales_recapitulation.created_by = tb_user.id', 'left');
        $this->db->order_by('tb_sales_recapitulation.id', 'DESC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->created_date;
            $row[] = $data_table->sales_date;
            $row[] = $data_table->total_invoice . ' NOTA';
            $row[] = $data_table->total_item_sales . ' ITEM';
            $row[] = $data_table->total_qty_sales . ' PCS';
            $row[] = number_format($data_table->total_price_sales, 0, '.', '.');
            $row[] = number_format($data_table->report_price_sales, 0, '.', '.');
            $row[] = number_format($data_table->margin, 0, '.', '.');
            $row[] = $data_table->user_name;
            $row[] = '<a class="btn btn-info btn_detail" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-tv"></i> Detail</a>';
            $data[] = $row;
        }
        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function add()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Setoran & Rekapitulasi Penjualan";
        $data['view_file'] = $this->location . 'form_add';
        $this->load->view('template/media_admin', $data);
    }

    private function change_date($date)
    {
        $explode_date = explode('-', $date);
        $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
        return $date_return;
    }
    public function validate_search_sales()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }
    public function search_sales()
    {
        $this->validate_search_sales();
        $date  = $this->change_date($this->input->post('date'));
        $data['date'] = $this->input->post('date');
        $this->db->select('
            GROUP_CONCAT(tb_sales.id) AS list_id_sales,
            COUNT(DISTINCT tb_sales.id) AS total_invoice,
            SUM(DISTINCT grand_total) AS sum_price_total_sales,
            SUM(tb_detail_sales.qty) AS sum_total_qty,
            COUNT(DISTINCT tb_detail_sales.id_product) AS sum_total_item
            ');
        $this->db->from('tb_sales');
        $this->db->join('tb_detail_sales', 'tb_sales.id = tb_detail_sales.id_sales', 'left');
        // $this->db->group_by('tb_sales.id');
        $this->db->where(['tb_sales.date' => $date]);
        $get_data_sales = $this->db->get()->row();
        $data['data_sales'] = $get_data_sales;

        $this->db->select('
            tb_sales.*,
            tb_member.name AS member_name,
            COUNT(tb_detail_sales.id) AS count_item
            ');
        $this->db->from('tb_sales');
        $this->db->join('tb_detail_sales', 'tb_sales.id = tb_detail_sales.id_sales', 'left');
        $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
        $this->db->where(['tb_sales.date' => $date]);
        $this->db->group_by('tb_sales.id');
        $get_detail_sales = $this->db->get()->result();
        $data['data_detail_sales'] = $get_detail_sales;

        $view_file = $this->load->view($this->location . 'form_recapitulation', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $view_file
        ];
        echo json_encode($array_respon);
    }

    public function validate_review_recapitulation()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('payment') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'payment';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function review_recapitulation()
    {
        $this->validate_review_recapitulation();
        $data_current = json_decode($this->encrypt->decode($this->input->post('data_current')), TRUE);
        $payment = str_replace('.', '', $this->input->post('payment'));
        $html_resume = $_POST['html_resume'];
        $margin = $payment - $data_current['sum_price_total_sales'];
        $note = $this->input->post('note');
        $html_respon = '
        <div class="col-md-6">
        ' . $html_resume . '
        </div>
        <div class="col-md-6">
        <div class="col-md-12 text-center p-10 border border-radius-5">
        <h5 class="headline text-green col-md-12">TOTAL UANG PENJUALAN :</h5>
        <h2 class="headline text-green col-md-12" id="grand_total_shown"><b>Rp.' . number_format($data_current['sum_price_total_sales'], 0, '.', '.') . '</b></h2>
        </div>
        <div class="col-md-12 text-center p-10 border border-radius-5">
        <h5 class="headline text-green col-md-12">TOTAL UANG SETOR :</h5>
        <h2 class="headline text-green col-md-12" id="grand_total_shown"><b>Rp.' . number_format($payment, 0, '.', '.') . '</b></h2>
        </div>
        <div class="col-md-12 text-center p-10 border border-radius-5">
        <h5 class="headline text-green col-md-12">MARGIN :</h5>
        <h2 class="headline text-green col-md-12" id="grand_total_shown"><b>Rp.' . number_format($margin, 0, '.', '.') . '</b></h2>
        </div>
        <div class="col-md-12 text-center p-10 border border-radius-5">
        <h5 class="headline text-green col-md-12">Catatan :</h5>
        <p class="text-left">
        ' . $note . '
        </p>
        </div>
        <div class="col-md-12 p-20">
        <button class="btn btn-success btn_save_recapitulation btn-block"><i class="fa fa-save"></i> Simpan Data</button>
        </div>  
        </div>
        ';

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save_recapitulation()
    {
        $data_current = json_decode($this->encrypt->decode($this->input->post('data_current')), TRUE);
        $payment = str_replace('.', '', $this->input->post('payment'));
        $html_resume = $_POST['html_resume'];
        $margin = $payment - $data_current['sum_price_total_sales'];
        $date  = $this->change_date($data_current['date']);
        $note = $this->input->post('note');
        $explode_list_sales = explode(',', $data_current['list_id_sales']);
        $json_list_sales = json_encode($explode_list_sales);
        $array_insert = [
            'sales_date' => $date,
            'total_invoice' => $data_current['total_invoice'],
            'total_price_sales' => $data_current['sum_price_total_sales'],
            'total_item_sales' => $data_current['sum_total_item'],
            'total_qty_sales' => $data_current['sum_total_qty'],
            'report_price_sales' => $payment,
            'margin' => $margin,
            'note' => $note,
            'list_id_sales' => $json_list_sales,
            'created_by' => $this->session->userdata('us_id')
        ];
        $this->model->insert('tb_sales_recapitulation', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    public function get_detail()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_data_current = $this->db->where(['id' => $id])->get('tb_sales_recapitulation')->row();
        $json_list_id = json_decode($get_data_current->list_id_sales, TRUE);

        $this->db->select('
            tb_sales.*,
            tb_member.name AS member_name,
            COUNT(tb_detail_sales.id) AS count_item
            ');
        $this->db->from('tb_sales');
        $this->db->join('tb_detail_sales', 'tb_sales.id = tb_detail_sales.id_sales', 'left');
        $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
        $this->db->where_in('tb_sales.id', $json_list_id);
        $this->db->group_by('tb_sales.id');
        $data_sales = $this->db->get()->result();

        $data['data_recapitulation'] = $get_data_current;
        $data['data_sales'] = $data_sales;

        $view_file = $this->load->view($this->location . 'view_detail', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $view_file
        ];
        echo json_encode($array_respon);
    }

    // public function validate_insert()
    // {
    //     $data = array();
    //     $data['error_string'] = array();
    //     $data['inputerror'] = array();
    //     $data['status'] = TRUE;

    //     if ($this->input->post('price') == '') {
    //         $data['error_string'][] = 'harus diisi';
    //         $data['inputerror'][] = 'price';
    //         $data['status'] = FALSE;
    //     }
    //     if ($this->input->post('point') == '') {
    //         $data['error_string'][] = 'harus diisi';
    //         $data['inputerror'][] = 'point';
    //         $data['status'] = FALSE;
    //     }
    //     if ($this->input->post('note') == '') {
    //         $data['error_string'][] = 'harus diisi';
    //         $data['inputerror'][] = 'note';
    //         $data['status'] = FALSE;
    //     }
    //     if ($data['status'] == FALSE) {
    //         echo json_encode($data);
    //         exit();
    //     }
    // }

    // public function save()
    // {
    //     $this->validate_insert();
    //     $price     = $this->input->post('price');
    //     $point     = $this->input->post('point');
    //     $note      = $this->input->post('note');
    //     //insert data
    //     $array_insert = array(
    //         'min_price' => $price,
    //         'point' => $point,
    //         'note' => $note,
    //         'status' => TRUE,
    //         'created_date' => date('Y-m-d H:i:s'),
    //         'created_by' => $this->session->userdata('us_id')
    //     );
    //     $this->model->insert('tb_point', $array_insert);
    //     echo json_encode(array('status' => TRUE));
    // }
    // public function update_status()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $status = $this->input->post('status');
    //     $array_update = [
    //         'status' => $status
    //     ];
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(['status' => TRUE]);
    // }

    // public function get_edit()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $get_data = $this->model->find(array('id' => $id), 'tb_point')->row_array();
    //     echo json_encode($get_data);
    // }
    // public function update()
    // {
    //     $this->validate_insert();
    //     $id        = $this->input->post('id');
    //     $price     = $this->input->post('price');
    //     $point     = $this->input->post('point');
    //     $note      = $this->input->post('note');
    //     //insert data
    //     $array_update = array(
    //         'min_price' => $price,
    //         'point' => $point,
    //         'note' => $note,
    //         'updated_date' => date('Y-m-d H:i:s'),
    //         'updated_by' => $this->session->userdata('us_id')
    //     );
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
    // public function delete()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $this->model->delete(array('id' => $id), 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
}
