var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/sales_recapitulation';
var save_method;
var table;
var id_use;
$(document).ready(function(){
	table= $('.table_data').DataTable({
        "ajax": {
            "url": controller+"/list_data",
            "type": "POST"
        }
    });
})

// function reload_table(){
//      table.ajax.reload(null,false); //reload datatable ajax 
// }

// $('.btn_add').click(function () {
//     $('.btn_save').button('reset');
// 	save_method = 'add';
// 	$('.form-group').removeClass('has-error');
//  	$('.help-block').empty();
//     $('.form-input')[0].reset();
// 	$('.modal-title').text('TAMBAH DATA');
// 	$('#modal-form').modal('show');
// })

$('.btn-search-sales').click(function (e) {
    e.preventDefault();
    $(this).button('loading');
	$('.form-group').removeClass('has-error');
	$('.help-block').empty();  
	  //defined form
	var formData = new FormData($('.form-search-sales')[0]);
    $.ajax({
    url: controller+'/search_sales',
    type: "POST",
    data: formData,
    contentType: false,
    processData : false,
    dataType :"JSON",
    success: function(data){
        if(data.status){
            $('.html_respon').html(data.html_respon);
            $('.table-detail-sales').DataTable();
        } else{
        for (var i = 0; i < data.inputerror.length; i++)
            {
                $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
            }
        }
        $('.btn-search-sales').button('reset');
    },
        error:function(jqXHR, textStatus, errorThrown)
        {
        $('.btn-search-sales').button('reset');
        alert_error('something wrong');
        }
    });//end ajax
})

$(document).on('click', '.btn_review', function (e) {
    e.preventDefault();
    $(this).button('loading');
    $('.modal-title').text('Koreksi Kembali');
    var data_current = $(this).data('id');
    var value_payment = $('#payment').val();
    var html_resume = $('.html_resume').html();
    var note = $('[name="note"]').val();
    $('.form-group').removeClass('has-error');
	$('.help-block').empty();  
    $.ajax({
        url: controller+'/review_recapitulation',
        type: "POST",
        data: {'data_current':data_current,'payment':value_payment,'html_resume':html_resume,'note':note},
        dataType :"JSON",
        success: function (data) {
            if (data.status) {
                $('#modal-detail').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                }
            }
            $('.btn_review').button('reset');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_review').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
})

$(document).on('click', '.btn_save_recapitulation', function () {
    var data_current = $('.btn_review').data('id');
    var value_payment = $('#payment').val();
    var note = $('[name="note"]').val();
    var html_resume = $('.html_resume').html();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    
    Swal.fire({
            title: 'Apakah anda yakin?',
            text: "data ini akan disimpan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya,hapus lanjutkan',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: controller+'/save_recapitulation',
                    type: "POST",
                    data: {'data_current':data_current,'payment':value_payment,'html_resume':html_resume,'note':note},
                    dataType :"JSON",
                    success: function (data) {
                        if (data.status) {
                            window.location.href = controller;
                        } else {
                            for (var i = 0; i < data.inputerror.length; i++)
                            {
                                $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                                $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                            }
                        }
                    },
                    error:function(jqXHR, textStatus, errorThrown)
                    {
                        $('.btn_save').button('reset');
                        alert_error('something wrong');
                    }
                });//end ajax
            }
        })    
})


$(document).on('click', '.btn_detail', function () {
    var id = $(this).data('id');
    $('.modal-title').text('DETAIL DATA');
    $.ajax({
        url: controller+'/get_detail',
        type: "POST",
        data: {'id':id},
        dataType :"JSON",
        success: function (data) {
            if (data.status) {
                $('#modal-form').modal('show');
                $('.html_respon').html(data.html_respon);
                $('.table-data').DataTable();
            } 
            $('.btn_detail').button('reset');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_detail').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
})

// $(document).on('click', '.btn_remove', function () {
//     var id = $(this).data('id');
//     Swal.fire({
//         title: 'Apakah anda yakin?',
//         text: "data ini akan dihapus",
//         type: 'warning',
//         showCancelButton: true,
//         confirmButtonColor: '#3085d6',
//         cancelButtonColor: '#d33',
//         confirmButtonText: 'Ya,hapus data',
//         cancelButtonText: 'Batal'
//     }).then((result) => {
//         if (result.value) {
//             $.ajax({
//                 url: controller+'/delete',
//                 type: "POST",
//                 data: {'id':id},
//                 dataType :"JSON",
//                 success: function(data){
//                     $('#modal-form').modal('hide'); 
//                     notif_success('data berhasil dihapus');
//                     reload_table();
//                     $('.btn_remove').button('reset');
//                 },
//                 error:function(jqXHR, textStatus, errorThrown)
//                 {
//                     $('.btn_remove').button('reset');
//                     alert_error('something wrong');
//                 }
//             });//end ajax
//         }
//     })
// })

// $(document).on('keyup', '.number_only', function () {
//     var qty = $(this).val();
//     var clean_word = qty.replace(/[^,\d]/g, '');
//     $(this).val(clean_word);
// })

$(document).on('keyup', '.money_only', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
})

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

if (ribuan) {
    separator = sisa ? '.' : '';
    rupiah += separator + ribuan.join('.');
}

rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}