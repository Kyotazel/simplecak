<?php
$this->load->view("data_rate_product/form");
?>
<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <h4>Hasil Pencarian</h4>
    </div>
    <div class="card-body">
        <table style="width:100%;" style="font-size:20px;">
            <tr>
                <td width="50px">Range</td>
                <td width="5px">:</td>
                <td>
                    <?php echo $data_range['date_from'] . '&nbsp;&nbsp;s/d&nbsp;&nbsp;' . $data_range['date_to']; ?>
                </td>
            </tr>
        </table>
        <hr>
        <table class="table table_list table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Satuan</th>
                    <th>Jumlah Terjual</th>
                </tr>
            </thead>
            <tbody>
                <?php
                function count_stock_result($stock, $qty_unit, $unit_name, $base_unit_name)
                {
                    if ($stock != false) {
                        $base_unit_val = $stock % $qty_unit;
                        //count unit val
                        $unit_val     = ($stock - $base_unit_val) / $qty_unit;
                        // stock current
                        $stock_current = '';
                        if ($unit_val > 0) {
                            $stock_current .= number_format($unit_val, 0, '.', '.') . '&nbsp;' . $unit_name;
                        }
                        if ($base_unit_val > 0) {
                            if ($unit_val > 0) {
                                $stock_current .= '<br>';
                            }
                            $stock_current .= number_format($base_unit_val, 0, '.', '.') . '&nbsp;' . $base_unit_name;
                        }
                    } else {
                        $stock_current = '0&nbsp;' . $base_unit_name;
                    }

                    return $stock_current;
                }


                $no = 0;
                foreach ($data_result->result() as $data_table) {
                    $no++;
                    //create html sold stock

                    echo '
                        <tr>
                          <td>' . $no . '</td>
                          <td>' . $data_table->code . '</td> 
                          <td>' . $data_table->name . '</td>
                          <td>' . $data_table->unit_name . '</td>
                          <td>' . $data_table->qty_buy . '</td>
                        </tr>
                        ';
                }

                ?>

            </tbody>
        </table>
    </div>
    <!-- /.box-body -->

</div>
<script type="text/javascript" src="<?php echo base_url('assets/assets_admin/'); ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>function_toast.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('.table_list').DataTable();
</script>