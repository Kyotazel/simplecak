<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo base_url('rate_product/search_rate'); ?>">
            <div class="col-md-4">
                <label>Tanggal Awal</label>
                <input type="text" class="form-control datepicker" name="date_from" placeholder="klik untuk pilih tanggal..." readonly style="background-color:#fff;font-size:20px;">
                <span class="help-block" style="color:red;"><?php echo $this->session->flashdata('error_date_from'); ?></span>
            </div>
            <div class="col-md-1" align="center">
                <label style="padding-top:30px;">S/d</label>
            </div>
            <div class="col-md-4">
                <label>Tanggal Akhir</label>
                <input type="text" class="form-control datepicker" name="date_to" placeholder="klik untuk pilih tanggal..." readonly style="background-color:#fff;font-size:20px;">
                <span class="help-block" style="color:red;"><?php echo $this->session->flashdata('error_date_to'); ?></span>
            </div>
            <div class="col-md-2">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-info  btn-block"> <i class="fa fa-search"></i> Hitung Rate</button>
            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>