<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rate_product extends CI_Controller
{
    var $location = 'data_rate_product/';
    var $module_name = 'rate_product';

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }


    public function index()
    {
        $data['tagline_page'] = "Rating Barang";
        $data['view_file'] = $this->location . 'form';
        $this->load->view('template/media_admin', $data);
    }

    public function change_to_sql_date($date)
    {
        $date_explode = explode('-', $date);
        $date_sql = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        return $date_sql;
    }

    public function validate_input()
    {
        $status = false;
        $date_from     = $this->input->post('date_from');
        $date_to     = $this->input->post('date_to');

        if ($date_from == '') {
            $this->session->set_flashdata('error_date_from', 'harus disi dulu');
            $status = TRUE;
        }
        if ($date_to == '') {
            $this->session->set_flashdata('error_date_to', 'harus disi dulu');
            $status = TRUE;
        }

        if ($status == TRUE) {
            redirect(base_url($this->module_name));
        }
    }

    public function search_rate()
    {
        $this->validate_input();
        $date_from     = $this->change_to_sql_date($this->input->post('date_from'));
        $date_to     = $this->change_to_sql_date($this->input->post('date_to'));
        $get_data_rate = $this->db->query("
											select a.id,
											a.code,
											a.name,
											a.qty_unit,
											SUM(b.qty) as qty_buy,
											c.name as unit_name,
											e.date 
											from tb_product a 
											LEFT join tb_detail_sales b on a.id = b.id_product
											LEFT join tb_unit c on a.id_unit = c.id 
											left join tb_sales e on b.id_sales = e.id
											where e.date BETWEEN '$date_from' and '$date_to'
											GROUP by a.id order by qty_buy DESC

										  ");
        //create array range
        $array_range = array(
            'date_from' => $this->input->post('date_from'),
            'date_to' => $this->input->post('date_to')
        );
        $data['data_range'] = $array_range;
        $data['data_result'] = $get_data_rate;
        $data['tagline_page'] = "Rating Barang";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin', $data);
    }
}
