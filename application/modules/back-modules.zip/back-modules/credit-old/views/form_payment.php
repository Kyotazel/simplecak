<?php
$btn_payment = '';
if ($data_credit->status == FALSE) {
    $btn_payment = '
                        <a href="' . base_url('admin/credit/add_payment?data=' . urlencode($this->encrypt->encode($data_credit->id))) . '" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Tambah Data Pembayaran</a>
                    ';
}

if (strtotime($data_credit->deadline) < strtotime(date('Y-m-d'))) {
    //expired
    $label_expired = '<label class="text-danger text-bold font-weight-bold">Telah Jatuh Tempo</label>';
} else {
    //expired
    $label_expired = '<label class="text-success text-bold font-weight-bold">Belum Jatuh Tempo</label>';
}
?>


<div class="card">
    <div class="card-body">

        <div class="row">
            <div class="col-md-4 mb-10 mt-10 html_resume_credit">
                <div class="card">
                    <div class="card-header text-white bg-primary-gradient">
                        <h5>Keterangan Piutang</h5>
                    </div>

                    <div class="card-body shadow-none">
                        <table class="table">
                            <tr>
                                <td width="150px">Kode</td>
                                <td width="5px">:</td>
                                <td><b><?= $data_credit->code; ?></b></td>
                            </tr>
                            <tr>
                                <td width="150px">Invoice</td>
                                <td width="5px">:</td>
                                <td><b><?= $data_credit->invoice_code; ?></b></td>
                            </tr>
                            <tr>
                                <td>Nominal</td>
                                <td>:</td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                        </div>
                                        <input type="text" class="form-control border-dashed bg-white" readonly value="<?= number_format($data_credit->price, 0, '.', '.'); ?>">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>Sisa Tanggungan</td>
                                <td>:</td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                        </div>
                                        <input type="text" class="form-control border-dashed bg-white" readonly value="<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?>">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>Customer</td>
                                <td>:</td>
                                <td><b><?= $data_credit->member_name ? $data_credit->member_name : '-'; ?></b></td>
                            </tr>
                            <tr>
                                <td>Tanggal Piutang</td>
                                <td>:</td>
                                <td><b><?= Modules::run('helper/date_indo', $data_credit->date, '-'); ?> s/d <?= Modules::run('helper/date_indo', $data_credit->deadline, '-'); ?></b></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td>:</td>
                                <td><b><?= $data_credit->status ? '<label class="text-primary font-weight-bold">Telah Lunas</label>' : '<label class="text-danger font-weight-bold">Belum Lunas</label>'; ?></b></td>
                            </tr>
                            <tr>
                                <td>Status Jatuh Tempo</td>
                                <td>:</td>
                                <td><b><?= $label_expired; ?></b></td>
                            </tr>
                        </table>
                        <label>Deskripsi:</label>
                        <div class="border p-2">
                            <p>
                                <?= $data_credit->description; ?>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-8">
                <!-- <h3 class="text-green mb-10">Form Pembayaran :</h3> -->

                <form class="form-horizontal form_payment">
                    <div class="col-md-12 text-right">
                        <a href="<?= base_url('admin/credit/detail?data=' . urlencode($this->encrypt->encode($data_credit->id))); ?>" class="btn btn-primary btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                    </div>
                    <div class="col-md-12 text-center mb-3">
                        <small class="text-center">sisa Tanggungan :</small>
                        <h2 class="text-red p-10 shadow div_center" style="width:300px;margin:0 auto;">Rp.<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?></h2>
                    </div>
                    <div class="col-md-12 mt-10">
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Nominal Pembayaran</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon" style="font-size:20px;">Rp.</span>
                                    <input type="text" class="form-control form-control-lg money_only" name="price" style="font-size:20px;">
                                </div>
                                <span class="help-block text-danger notif_price"></span>
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputPassword3" class="col-sm-3 control-label">Keterangan</label>

                            <div class="col-sm-9">
                                <textarea name="note" class="form-control" rows="8"></textarea>
                                <span class="help-block text-danger"></span>
                            </div>
                        </div>
                        <div class="form-group text-right">
                            <small>(*Klik untuk simpan data)</small>
                            <button type="submit" data-id="<?= $this->encrypt->encode($data_credit->id); ?>" class="btn btn-primary btn_preview">Simpan Data Pembayaran</button>
                        </div>
                    </div>
                </form>


                <?php
                if ($data_credit->status == 2) {
                    echo '
                            <div class="col-md-12 mb-10">
                                <hr>
                                <h2 class="text-center text-muted" >PIUTANG <b>' . $data_credit->code . '</b> TELAH DIBATALKAN </h2>
                                <hr>
                            </div>
                            <div class="col-md-4 mt-10">
                                <label>Keterangan Pembatalan:</label>
                                <table class="table">
                                    <tr>
                                        <td width="150px">Tanggal Dibatalkan </td>
                                        <td width="5px">:</td>
                                        <td><b>' . $data_credit->updated_date . '</b></td>
                                    </tr>
                                    <tr>
                                    <td>Dibatlakan Oleh</td>
                                    <td>:</td>
                                    <td><b>' . $data_credit->user_name . '</b></td>
                                </tr>
                                </table>
                            </div>
                            <div class="col-md-8 mt-10">
                                <label>Catatan Pembatalan:</label>
                                <div class="p-10 border border-radius-5">' . $data_credit->reject_note . '</div>
                            </div>
                            <div class="col-md-12 text-right">
                                <a href="' . base_url('credit') . '" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Lihat Data Piutang</a>
                            </div>
                        ';
                }
                ?>
                <div class="col-md-12 mt-10">
                    <h5 class="text-green mb-10 card-footer">Detail Angsuran :</h5>
                    <div class="table-responsive">
                        <table class="table table_payment">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kode Pembayaran</th>
                                    <th>Tanggal Pembayaran</th>
                                    <th>Jumlah Tagihan</th>
                                    <th>Jumlah Dibayar</th>
                                    <th>Sisa Tanggungan</th>
                                    <th>Catatan</th>
                                    <th>status</th>
                                    <th>Petugas</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 0;
                                foreach ($data_detail as $item_detail) {
                                    $counter++;
                                    $label_status = $item_detail->status ? '<label class="label label-success">Lunas</label>' : '<label class="label label-warning">Belum Lunas</label>';
                                    echo '
                                            <tr>
                                                <td>' . $counter . '</td>
                                                <td>' . $item_detail->code . '</td>
                                                <td>' . $item_detail->date . '</td>
                                                <td>Rp.' . number_format($item_detail->credit_price, 0, '.', '.') . '</td>
                                                <td>Rp.' . number_format($item_detail->payment_price, 0, '.', '.') . '</td>
                                                <td>Rp.' . number_format($item_detail->rest_credit, 0, '.', '.') . '</td>
                                                <td>' . $item_detail->note . '</td>
                                                <td>' . $label_status . '</td>
                                                <td>' . $item_detail->user_name . '</td>
                                                <td>
                                                    <a href="" class="btn btn-primary"><i class="fa fa-print"></i> Cetak Nota</a>
                                                </td>
                                            </tr>
                                        ';
                                }
                                if (empty($data_detail)) {
                                    echo '
                                            <tr>
                                                <td colspan="10" class="text-center">
                                                    <div class="bg-empty-data"></div>
                                                    <h3 class="text-center text-muted">Tidak ada data pembayaran</h3>
                                                </td>
                                            </tr>
                                        ';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-right mt-10">
                        <a href="<?= base_url('credit'); ?>" class="btn btn-primary btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="max-width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="p-10 border-radius-5 html_resume_credit_modal"></div>
                        </div>
                        <div class="col-md-6">
                            <h2 class="text-center">Preview Pembayaran</h2>
                            <div class="col-md-12 text-center">
                                <small class="text-center">sisa Tanggungan :</small>
                                <h5 class="text-red  shadow div_center" style="width:300px;margin:0 auto;">Rp.<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?></h5>
                            </div>
                            <div class="col-md-12 html_payment_preview"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>