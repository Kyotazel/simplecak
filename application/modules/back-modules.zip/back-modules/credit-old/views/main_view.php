<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <h5 class="header-title mb-4 col-md-4">Piutang Belum Lunas</h5>
                <div class="col-md-8">
                    <div class="float-right d-md-block">
                        <div class="dropdown">
                            <a href="<?= base_url('admin/credit/history_credit'); ?>" class="btn btn-light btn-rounded">
                                <i class="mdi mdi-laptop mr-1"></i> Lihat Riwayat Piutang
                            </a>
                            <a href="<?= base_url('admin/credit/history_payment'); ?>" class="btn btn-light btn-rounded">
                                <i class="mdi mdi-laptop mr-1"></i> Lihat Riwayat Pembayaran
                            </a>
                        </div>
                    </div>
                </div>
            </div>


            <div class="table-responsive">
                <table class="table table-hover table_credit" width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>kode</th>
                            <th>Kode Invoice</th>
                            <th>Nominal Piutang</th>
                            <th>Telah Dibayar</th>
                            <th>Sisa Piutang</th>
                            <th>Tgl Piutang</th>
                            <th>Usia (hr)</th>
                            <th>Status Jatuh Tempo</th>
                            <th>Customer</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <div class="mt-3 text-right">
                <small>(* klik untuk klik data)</small>
                <a href="<?= base_url('admin/credit/print_list_data') ?>" class="btn btn-primary">CETAK EXCEL</a>
            </div>
        </div>
    </div>
</div>


<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>