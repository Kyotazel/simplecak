<?php
$conf_payment_method = Modules::run('helper/get_config', 'payment_method');
$counter = 0;
$array_list_data = [];
$resume_payment = [];
$html_tr = '';
foreach ($data_credit as $item_credit) {
    $array_pattern = [];
    $counter++;
    $label_status  = $item_credit->status ? '<label class="text-primary font-weight-bold">Lunas</label>' : '<label class="font-weight-bold">Belum Lunas</label>';
    $text_status = $item_credit->status ? 'Lunas' : 'Belum Lunas';

    $payment_method = isset($conf_payment_method[$item_credit->payment_type]) ? $conf_payment_method[$item_credit->payment_type] : '';

    $html_tr .= '
                    <tr>
                        <td>' . $counter . '</td>
                        <td>' . $item_credit->code . '</td>
                        <td>' . $item_credit->invoice_code . '</td>
                        <td>' . Modules::run('helper/date_indo', $item_credit->date_credit, '-') . '</td>
                        <td class="border">
                            <small>Jumlah Piutang :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm border-dashed font-weight-bold bg-white" readonly value="' . number_format($item_credit->price_credit, 0, '.', '.') . '">
                            </div>
                            <small>Sisa Piutang :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm border-dashed font-weight-bold bg-white" readonly value="' . number_format($item_credit->credit_price, 0, '.', '.') . '">
                            </div>
                        </td>
                        <td class="border">
                            <small>Jumlah Pembayaran :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm border-dashed font-weight-bold bg-white" readonly value="' . number_format($item_credit->payment_price, 0, '.', '.') . '">
                            </div>
                            <small>Sisa tanggungan :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm border-dashed font-weight-bold bg-white" readonly value="' . number_format($item_credit->rest_credit, 0, '.', '.') . '">
                            </div>
                        </td>
                        <td>' . Modules::run('helper/date_indo', $item_credit->date, '-') . '</td>
                        <td>' . $label_status . '</td>
                        <td>' . $payment_method . '</td>
                        <td>' . $item_credit->user_name . '</td>
                    </tr>
                ';

    $array_pattern = [
        'invoice' => $item_credit->invoice_code,
        'tanggal_piutang' => $item_credit->date_credit,
        'total_piutang' => $item_credit->price_credit,
        'sisa_piutang' => $item_credit->credit_price,
        'jumlah_bayar' => $item_credit->payment_price,
        'sisa_tanggugan' => $item_credit->rest_credit,
        'tanggal_bayar' => $item_credit->date,
        'status_piutang' => $text_status
    ];
    $array_list_data['data_print'][] = $array_pattern;

    //resume payment
    if (isset($resume_payment[$item_credit->payment_type])) {
        $resume_payment[$item_credit->payment_type] += $item_credit->payment_price;
    } else {
        $resume_payment[$item_credit->payment_type] = $item_credit->payment_price;
    }
}
$array_list_data['param'] = $params;
$data_print = $this->encrypt->encode(json_encode($array_list_data));


?>
<div class="mt-3 mb-3 ">
    <div class="row">
        <div class="col-9 row">
            <?php
            foreach ($resume_payment as $key => $value) {
                $payment_method = isset($conf_payment_method[$key]) ? $conf_payment_method[$key] : '';
                echo '
                            <div class="col-md-4 ">
                                <div class="row shadow-2 p-3">
                                    <div class="col">
                                        <div class=""><i class="fa fa-tv"></i> ' . $payment_method . '</div>
                                        <div class="h3 mt-2 mb-2">
                                            <b>Rp.' . number_format($value, 0, '.', '.') . '</b>
                                        </div>
                                    </div>
                                    <div class="col-auto align-self-center ">
                                        <div class="feature mt-0 mb-0">
                                            <i class="ti-wallet project bg-success-transparent text-success "></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ';
            }
            ?>

        </div>
        <div class="col-3">
            <form method="POST" action="<?= base_url('admin/credit/print_payment'); ?>">
                <input type="hidden" name="data_print" value="<?= $data_print; ?>">
                <small>(*klik untuk cetak)</small>
                <button type="submit" class="btn btn-primary btn-rounded">CETAK EXCEL</button>
            </form>
        </div>
    </div>
</div>
<div class="col-md-12">
    <table class="table  table_history t-shadow" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>kode</th>
                <th>Kode Invoice</th>
                <th>Tanggal Piutang</th>
                <th>Sebelum Dibayar</th>
                <th>Setelah Dibayar</th>
                <th>Tgl Pembayaran</th>
                <th>Status piutang</th>
                <th>Metode Bayar</th>
                <th>Petugas</th>
            </tr>
        </thead>
        <tbody>
            <?= $html_tr; ?>
        </tbody>
    </table>

</div>