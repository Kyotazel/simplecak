<div class="card">
    <div class="card-body">
        <form class="form-input-credit">
            <div class="col-md-5">
                <h3 class="text-green mb-10">*Nominal Piutang</h3>
                <div class="form-group">
                    <label>masukan Nominal Piutang</label>
                    <div class="input-group">
                        <span class="input-group-addon" style="font-size:20px;">Rp.</span>
                        <input type="text" class="form-control form-control-lg money_only" name="price" style="font-size:20px;">
                    </div>
                    <span class="help-block notif_price"></span>
                </div>
                <span class="clearfix"></span>
                <hr>
                <h3 class="text-green mb-10">*Penanggung Jawab Piutang</h3>
                <div class="form-group col-md-12">
                    <label>Nama Penanggung Jawab</label>
                    <input type="text" class="form-control" name="responsible_name">
                    <span class="help-block"></span>
                </div>
                <div class="form-group col-md-6">
                    <label>Tanggal Jatuh Tempo</label>
                    <input type="text" class="form-control datepicker_today bg-white" readonly name="date">
                    <span class="help-block"></span>
                </div>
                <div class="form-group col-md-6">
                    <label>Pilih Member</label>
                    <select name="id_member" class="form-control">
                        <?= $html_option_member; ?>
                    </select>
                    <span class="help-block"></span>
                </div>
            </div>
            <div class="col-md-7">
                <h3 class="text-green mb-10">*Catatan Piutang</h3>
                <div class="form-group">
                    <label>Catatan :</label>
                    <textarea name="note" class="form-control" rows="13"></textarea>
                    <span class="help-block"></span>
                </div>
                <div class="form-group text-right">
                    <small>(*klik untuk simpan data)</small>
                    <button class="btn btn-success btn_save" type="submit">Simpan Data Piutang</button>
                </div>
            </div>
        </form>
    </div>
</div>