<div class="row">
    <div class="col-lg-12 col-xl-12 col-md-12 container_list">
        <div class="card">
            <div class="card-body">
                <div class="mb-3 row">
                    <h3 class="col-md-8">DAFTAR CUSTOMER</h3>
                    <div class="col-md-4 text-right">
                        <?= Modules::run('security/create_access', '<a href="javascript:void(0)" class="btn btn-primary-gradient btn-rounded btn_add"> <i class="fa fa-plus-circle"></i> Tambah Data</a>'); ?>
                    </div>
                </div>
                <form class="form-search">
                    <div class="mb-2 border p-2 row rounded border-dashed">
                        <div class="form-group col-md-3">
                            <label>Jenis Customer ( Customer Type )</label>
                            <select name="customer_type[]" class="form-control chosen" multiple id="">
                                <?php foreach ($member_type as $item) {
                                    echo ' <option value="' . $item->id . '">' . $item->name . '</option> ';
                                } ?>
                            </select>
                            <span class="help-block notif_customer_type"></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Kelas Customer ( Customer Class )</label>
                            <select name="customer_class[]" class="form-control chosen" multiple id="">
                                <?php foreach ($member_class as $item) {
                                    echo ' <option value="' . $item->id . '">' . $item->name . '</option> ';
                                } ?>
                            </select>
                            <span class="help-block notif_customer_type"></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Nama</label>
                            <input class="form-control" name="name">
                        </div>
                        <div class="form-group col-md-2">
                            <label>Ktp</label>
                            <input class="form-control" name="ktp">
                        </div>
                        <div class="form-group col-md-1">
                            <label>&nbsp;</label><br>
                            <button class="btn btn-primary-gradient btn-rounded font-weight-bold btn-block btn_search"><i class="fa fa-search"></i> Cari</button>
                        </div>
                    </div>
                </form>
                <div class="table-responsive mt-2">
                    <table id="table_data" class="table table-bordered dt-responsive nowrap t-shadow" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <th style="width: 5%;">No</th>
                            <th>Gambar</th>
                            <th style="width: 30%;">NAMA LENGKAP</th>
                            <th>KTP & NPWP</th>
                            <th>Email & Telp</th>
                            <th>TYPE & CLASS</th>
                            <th>Metode Pembayaran</th>
                            <th style="width: 10%;"></th>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div class="text-right pt-3">
                    <form class="form-print" method="POST" action="<?= Modules::run('helper/create_url', 'customer/print'); ?>">
                        <small>(*klik untuk export)</small>
                        <button type="submit" name="print_excel" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-excel"></i> Cetak Excel</button>
                        <button type="submit" name="print_pdf" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-pdf"></i> Cetak PDF</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- end main content-->

<div class="modal fade" tabindex="-1" id="modal_form">
    <div class="modal-dialog" style="max-width: 50%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form id="form-data">
                    <input type="hidden" name="id" id="id" />
                    <label for=""><b>Data Customer</b></label>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label>Upload</label>
                            <input type="file" class="form-control" name="media" />
                            <span class="help-block notif_media"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>ID Customer</label>
                            <input type="text" class="form-control" name="code" />
                            <span class="help-block notif_code"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control " name="name" />
                            <span class="help-block notif_pic"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>No.KTP</label>
                            <input type="text" class="form-control " name="ktp" />
                            <span class="help-block notif_pic"></span>
                        </div>
                        <div class="form-group col-md-8">
                            <label>NPWP</label>
                            <input type="text" class="form-control " name="npwp" />
                            <span class="help-block notif_npwp"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <label>Alamat</label>
                            <textarea name="address" class="form-control" rows="5"></textarea>
                            <span class="help-block notif_address"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>No.telp</label>
                            <input type="text" class="form-control" name="number_phone" />
                            <span class="help-block notif_number_phone"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Email</label>
                            <input type="text" class="form-control" name="email" />
                            <span class="help-block notif_email"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Status Aktif</label>
                            <select name="active_status" class="form-control">
                                <option value="Y">Aktif</option>
                                <option value="N">Non-Aktif</option>
                            </select>
                            <span class="help-block notif_active_status"></span>
                        </div>
                    </div>
                    <hr>
                    <label for=""><b>Kategori Customer & Jenis Pembayaran</b></label>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label>Jenis Customer ( Customer Type )</label>
                            <select name="customer_type" class="form-control" id="">
                                <?php foreach ($member_type as $item) {
                                    echo ' <option value="' . $item->id . '">' . $item->name . '</option> ';
                                } ?>
                            </select>
                            <span class="help-block notif_customer_type"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Kelas Customer ( Customer Class )</label>
                            <select name="customer_class" class="form-control" id="">
                                <?php foreach ($member_class as $item) {
                                    echo ' <option value="' . $item->id . '">' . $item->name . '</option> ';
                                } ?>
                            </select>
                            <span class="help-block notif_customer_type"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Ketegori Pembayaran</label>
                            <select name="payment_method" class="form-control" id="">
                                <?php foreach ($payment_method as $key => $label) {
                                    echo ' <option value="' . $key . '">' . $label . '</option> ';
                                } ?>
                            </select>
                            <span class="help-block notif_payment_method"></span>
                        </div>
                    </div>
                    <div class="col-12 text-right">
                        <button type="button" class="btn btn-secondary btn-rounded" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary-gradient btn-rounded btn_save"><i class="fa fa-save"></i> Simpan Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>