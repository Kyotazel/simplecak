<?php
$array_jurnal = [
    0 => 'Jurnal',
    1 => 'penyesuaian'
];
?>
<style>
    .form-group {
        margin-bottom: 0;
    }
</style>

<form class="form-input">
    <div class="card">
        <div class="card-body">
            <div class="row html_form_import">
                <div class="col-md-3">
                    <label>Upload (CSV)</label>
                    <input type="file" name="upload" class="form-control">
                    <span class="help-block text-danger" style="color:red;"></span>
                </div>
                <div class="col-md-2 no-padding no-margin">
                    <label for="">&nbsp;</label><br>
                    <button class="btn btn-primary btn_import_csv"><i class="fa fa-paper-plane"></i> Import Data</button>
                </div>
                <div class="col-md-7 progressbar_import" style="display:none;align-items:center;flex-wrap:wrap;">
                    <label class="loading-text" for="" style="width:100% ;"></label>
                    <div class="progress" style="width:100% ;height: 20px;">
                        <div class="progress-bar progress-bar-striped import_progress bg-primary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-12">
                    <div class="html_respon_import">

                        <div class="col-12 p-3 border" style=" min-height: 400px;height: 400px;overflow: scroll;">
                            <div class="row">
                                <h4 class="col-9">DATA IMPORT</small></h4>
                                <div class="col-3 resume">
                                    <!-- <label class="font-weight-bold tx-16" for="">Resume : <b class="text-resume-balance"></b></label> -->
                                </div>
                            </div>
                            <div class="view_html_import"></div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        <!-- /.card-body -->

    </div>
</form>

<div class="modal" id="modal_form">
    <div class="modal-dialog" style="max-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="box-body pad">
                <div class="html_respon_modal"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>