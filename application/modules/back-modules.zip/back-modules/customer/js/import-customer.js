var controller = baseUrl + '/' + prefix_folder_admin + '/customer/' + _controller;

var save_method;
var id_use = 0;
var table;

var data_list = [];
var counter_loop = 0;
var count_data = 0;
var counter_req = 1;
var number_data = 20;
var fail_status = 0;
var fail_step = 0;
var date_current = '';
var html_balance = '';
var html_not_balance = '';
var html_error_coa = '';

var count_balance = 0;
var count_not_balance = 0;
var count_error_coa = 0;

var data_import = [];


$(document).ready(function(){
});

$('.btn_import_csv').click(function (e) {
    e.preventDefault();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  

    $('.btn_import_csv').hide();
    $(document).find('.html_form_save').remove();
    
    html_balance = '';
    html_not_balance = '';
    html_error_coa = '';
    count_balance = 0;
    count_not_balance = 0;
    count_error_coa = 0;

    
      //defined form
        var formData = new FormData($('.form-input')[0]);
        var url;
        $.ajax({
        url: controller+'/import_data',
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                
                count_data = data.count;
                counter_loop = Math.round(count_data / number_data);
                if ((count_data - (counter_loop * number_data)) > 0) {
                    counter_loop = counter_loop + 1;
                }

                data_list = data.list;
                $('.progressbar_import').css('display', 'flex');
                $('.loading-text').text('processing...');
                
                if (count_data > 0) {
                    do_import_csv(counter_req);
                }

            } else {
                $('.btn_import_csv').show();
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_import_csv').show();
            alert_error('something wrong');
        }
    });//end ajax
});


function data_send(counter,list_data){
    var start = ((counter-1) * number_data);
    var end = start+number_data;
        console.log(start+' s-d '+end);
    var data_respon = [];
    for (let index = 0; index < number_data; index++) {
        if(typeof list_data[start] !== 'undefined' ){
            data_respon.push(list_data[start])
        }
        start++
    }
    return data_respon;
}


var array_respon = [];

function do_import_csv(counter) {
    data_post = data_send(counter, data_list);
    $.ajax({
        url: controller+'/processing_view',
        type: 'POST',
        data: {
            'list': JSON.stringify(data_post)
        },
        dataType: "JSON",
        success: function(response) {
            //counter_loop = counter_loop-1;
            var list_mediaGot = response.list;
            $percentage_progress = Math.round(((counter_req / counter_loop) * 100));
            
            //progress bar
            if ($percentage_progress >= 100 || counter_loop == 1) {
                $(document).find('.import_progress').css('width','100%');
                $(document).find('.import_progress').text('100%');
                $(document).find('.import_progress').addClass('bg-success');
                setTimeout(function () {
                    $('.progressbar_import').css('display', 'none');
                    $(document).find('.import_progress').removeClass('bg-success');
                    $(document).find('.import_progress').css('width', '0%');
                    $(document).find('.import_progress').text('0%');
                    $('.btn_import_csv').show();
                    $('[name="upload"]').prop('disabled', false);
                    $('.form-input')[0].reset();

                }, 2000);
            } else {
                $(document).find('.import_progress').css('width', $percentage_progress + '%');
                $(document).find('.import_progress').text($percentage_progress + '%');
            }

            //html view
            html_balance += response.html_respon;

            //fill data respon
            for (let index = 0; index < response.list.length; index++) {
                const data_current = response.list[index];
                data_import.push(data_current);
            }

            
            if(counter_loop > counter_req){
                counter_req = counter_req + 1;
                if(fail_status == 1){
                    fail_step = fail_step-1;
                }
                fail_status = 0;
                do_import_csv(counter_req);
            } else {
                counter_req = 1;
                counter_loop = 0;

                var array_views_data = {
                    'html_balance': html_balance
                };

                show_import_view(array_views_data);
                // alert('yeeaayyy, finish');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            //counter_loop = counter_loop-1;
            if(counter_loop > counter_req){
                counter_req = counter_req + 1;
                // do_import_csv(counter_req);
            }

            $('.btn_import_csv').show();
            $('[name="upload"]').prop('disabled', false);
        }
    });
}

function show_import_view(data_view) {
    $('.progressbar_import').css('display', 'none');
    $('.view_html_import').html(`
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>KODE</th>
                    <th>NAMA</th>
                    <th>NPWP</th>
                    <th>KTP</th>
                    <th>TYPE</th>
                    <th>CLASS</th>
                    <th>TOP NOTA</th>
                    <th>TOP INTERNAL</th>
                    <th>LIMIT</th>
                </tr>
            </thead>
            <tbody>`+data_view.html_balance+`</tbody>
        </table>
    `);

    $('.html_form_import').append(`
            <div class="col-md-7 text-right html_form_save">
                <label for="">&nbsp;</label>
                <br>
                <a class="btn btn-primary btn_save_import text-white" href="javascript:void(0)" style="width:300px;"> Simpan Data Import <i class="fa fa-arrow-circle-right"></i></a>
                <small class="d-block">(*klik untuk simpan data import)</small>
            </div>
        `);
}

//================================================================== saving import ========================================================

$(document).on('click', '.btn_save_import', function () { 


    swal({
        title: "Apakah anda yakin?",
        text: "data akan Disimpan!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            count_data = data_import.length;
            counter_loop = Math.round(count_data / number_data);
            if ((count_data - (counter_loop * number_data)) > 0) {
                counter_loop = counter_loop + 1;
            }
            $('.progressbar_import').css('display', 'flex');
            $('.loading-text').text('saving...');

            $(document).find('.html_form_save').hide();
            $(document).find('.btn_import_csv').prop('disabled',true);
            $('[name="upload"]').prop('disabled', true);

            save_import(counter_req);
        }
    });
    
});



function save_import(counter) {
    data_post = data_send(counter, data_import);
    $.ajax({
        url: controller+'/save_import',
        type: 'POST',
        data: {
            'list': JSON.stringify(data_post)
        },
        dataType: "JSON",
        success: function(response) {
            //counter_loop = counter_loop-1;
            $percentage_progress = Math.round(((counter_req / counter_loop) * 100));
            
            //progress bar
            if ($percentage_progress >= 100 || counter_loop == 1) {
                $(document).find('.import_progress').css('width','100%');
                $(document).find('.import_progress').text('100%');
                $(document).find('.import_progress').addClass('bg-success');
                setTimeout(function () {
                    $('.progressbar_import').css('display', 'none');
                    $(document).find('.import_progress').removeClass('bg-success');
                    $(document).find('.import_progress').css('width', '0%');
                    $(document).find('.import_progress').text('0%');
                    $('.btn_import_csv').show();
                    $('[name="upload"]').prop('disabled', false);
                    $('.form-input')[0].reset();

                }, 2000);
            } else {
                $(document).find('.import_progress').css('width', $percentage_progress + '%');
                $(document).find('.import_progress').text($percentage_progress + '%');
            }

            
            if(counter_loop > counter_req){
                counter_req = counter_req + 1;
                if(fail_status == 1){
                    fail_step = fail_step-1;
                }
                fail_status = 0;
                //loop
                save_import(counter_req);
            } else {
                counter_req = 1;
                counter_loop = 0;

                //succcess 
                reload_all_form();
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            //counter_loop = counter_loop-1;
            if(counter_loop > counter_req){
                counter_req = counter_req + 1;
                // save_import(counter_req);
            }
            
            $(document).find('.btn_save_import').show();
            $('[name="upload"]').prop('disabled', false);
        }
    });
}

function reload_all_form() {

    alert_success('Data berhasil disimpan');

    $(document).find('.html_form_save').remove();
    $(document).find('.btn_import_csv').prop('disabled',false);
    $('[name="upload"]').prop('disabled', false);

    $('.view_html_balance').html('');
    $('.view_html_not_balance').html('');
    $('.view_html_coa_error').html('');

    //count data
    $('.text-resume-balance').html('');
    $('.text-resume-not-balance').html('');
    $('.text-resume-coa').html('');

}