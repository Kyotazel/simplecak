<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Customer extends BackendController
{
    var $module_name        = 'customer';
    var $module_directory   = 'customer';
    var $module_js          = ['customer'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['member_type'] = Modules::run('database/find', 'tb_member_category', ['type' => 1])->result();
        $this->app_data['member_class'] = Modules::run('database/find', 'tb_member_category', ['type' => 2])->result();
        $this->app_data['payment_method'] = Modules::run('helper/get_config', 'payment_method');

        $this->app_data['page_title'] = "Data Customer";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        Modules::run('security/is_ajax');
        $arr_customer_type = $this->input->post('customer_type');
        $arr_customer_class = $this->input->post('customer_class');
        $name = $this->input->post('name');
        $ktp = $this->input->post('ktp');

        $array_where['mst_customer.isDeleted'] = 'N';
        $array_where_in = [];
        $array_like = [];

        if (!empty($arr_customer_type)) {
            $array_where_in['member_type.id'] = $arr_customer_type;
        }
        if (!empty($arr_customer_class)) {
            $array_where_in['member_class.id'] = $arr_customer_class;
        }
        if ($name != '') {
            $array_like['mst_customer.name'] = $name . ',both';
        }
        if ($ktp != '') {
            $array_like['mst_customer.ktp'] = $ktp . ',both';
        }

        $array_search = [];
        $array_query = [
            'select' => '
                mst_customer.*,
                member_class.name AS member_class_name,
                member_type.name AS member_type_name
            ',
            'from' => 'mst_customer',
            'join' => [
                'tb_member_category AS member_type, mst_customer.id_member_type = member_type.id, left',
                'tb_member_category AS member_class, mst_customer.id_member_class = member_class.id, left',
            ],
            'where' => $array_where,
            'order_by' => 'mst_customer.id, DESC'
        ];
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }
        if (!empty($array_like)) {
            $array_query['like'] = $array_like;
        }

        $conf_payment_method = Modules::run('helper/get_config', 'payment_method');


        $get_data = Modules::run('database/get', $array_query)->result();
        $no = 0;
        $data = [];
        foreach ($get_data as $data_table) {

            $id_encrypt = $this->encrypt->encode($data_table->id);
            $btn_delete     = Modules::run('security/delete_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-danger btn-rounded btn_delete"><i class="las la-trash"></i> </a>');
            $btn_edit     = Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-warning-gradient btn-rounded btn_edit"><i class="las la-pen"></i> </a>');
            $active = $data_table->isActive == 'Y' ? 'on' : '';

            $payment_method = isset($conf_payment_method[$data_table->payment_method]) ? $conf_payment_method[$data_table->payment_method] : '(Belum Dipilih)';

            $image = $data_table->image ? base_url('upload/customer/' . $data_table->image) : base_url('assets/themes/valex/img/faces/3.jpg');
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = '
                    <div class="main-img-user avatar-md d-block">
                        <img alt="avatar" class="rounded-circle" src="' . $image . '">
                    </div>
                    <label for="" class="d-flex mt-1">
                        <div class="main-toggle-group-demo">
                            <div data-id="' . $data_table->id . '" class="main-toggle main-toggle-dark change_status ' . $active . '"><span></span></div>
                        </div>
                    </label>
                ';
            $row[] = '
                    <span class="badge badge-light font-weight-bold tx-15">#' . $data_table->code . '</span>
                    <div class="row col-12 border-dashed" style="white-space:initial;width:300px;">
                        <div class="col">
                            <div class=" mt-2 mb-2 text-primary"><b>' . strtoupper($data_table->name) . '</b></div>
                            <p class="tx-11" style="white-space:initial;">' . $data_table->address . '</p>
                        </div>
                        <div class="col-auto align-self-center ">
                            <div class="feature mt-0 mb-0">
                                <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                            </div>
                        </div>
                    </div>
                ';
            $row[] = '
                <div class="p-2 border-dashed">
                    <small class="text-muted">KTP :</small><br>
                    ' . $data_table->ktp . '
                </div>
                <div class="p-2 border-dashed">
                    <small class="text-muted">NPWP :</small><br>
                    ' . $data_table->npwp . '
                </div>
            ';
            $row[] = '
                <div class="p-2 border-dashed">
                    <small class="text-muted">Email :</small><br>
                    ' . $data_table->email . '
                </div>
                <div class="p-2 border-dashed">
                    <small class="text-muted">Telp :</small><br>
                    ' . $data_table->number_phone . '
                </div>
            ';
            $row[] = '
                <div class="input-group" style="width:200px;">
                    <div class="input-group-prepend">
                        <div class="input-group-text font-weight-bold" style="width:60px";>
                            Type
                        </div>
                    </div>
                    <input type="text" readonly value="' . $data_table->member_type_name . '"  class="form-control bg-white border-dashed font-weight-bold">
                </div>
                <div class="input-group" style="width:200px;">
                    <div class="input-group-prepend">
                        <div class="input-group-text font-weight-bold" style="width:60px";>
                            Class
                        </div>
                    </div>
                    <input type="text" readonly value="' . $data_table->member_class_name . '"  class="form-control bg-white border-dashed font-weight-bold">
                </div>
            ';
            $row[] = '
                <div class="input-group" style="width:150px;">
                    <input type="text" readonly value="' . $payment_method . '"  class="form-control bg-white border-dashed font-weight-bold">
                </div>
            ';
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );

        $array_respon = ['search' => $this->encrypt->encode(json_encode($array_search)), 'list' => $ouput];

        echo json_encode($array_respon);
    }


    private function validate_save()
    {
        Modules::run('security/is_ajax');
        $data = array();

        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->input->post('id');
        if ($this->input->post('code') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'code';
            $data['status'] = FALSE;
        } else {
            $code = $this->input->post('code');
            $get_code = Modules::run('database/find', 'mst_customer', ['code' => $code])->row();
            if (!empty($get_code) && $get_code->id != $id) {
                $data['error_string'][] = 'Kode Telah Terpakai';
                $data['inputerror'][] = 'code';
                $data['status'] = FALSE;
            }
        }

        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }
        // if ($this->input->post('pic') == '') {
        //     $data['error_string'][] = 'Harus Diisi';
        //     $data['inputerror'][] = 'pic';
        //     $data['status'] = FALSE;
        // }
        // if ($this->input->post('npwp') == '') {
        //     $data['error_string'][] = 'Harus Diisi';
        //     $data['inputerror'][] = 'npwp';
        //     $data['status'] = FALSE;
        // }
        // if ($this->input->post('address') == '') {
        //     $data['error_string'][] = 'Harus Diisi';
        //     $data['inputerror'][] = 'address';
        //     $data['status'] = FALSE;
        // }
        // if ($this->input->post('number_phone') == '') {
        //     $data['error_string'][] = 'Harus Diisi';
        //     $data['inputerror'][] = 'number_phone';
        //     $data['status'] = FALSE;
        // }
        // if ($this->input->post('email') == '') {
        //     $data['error_string'][] = 'Harus Diisi';
        //     $data['inputerror'][] = 'email';
        //     $data['status'] = FALSE;
        // }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_save();

        $code    = $this->input->post('code');
        $ktp    = $this->input->post('ktp');
        $name    = $this->input->post('name');
        $npwp    = $this->input->post('npwp');
        $address    = $this->input->post('address');
        $number_phone    = $this->input->post('number_phone');
        $email    = $this->input->post('email');
        $active_status    = $this->input->post('active_status');
        $payment_method    = $this->input->post('payment_method');
        $credit_limit = str_replace('.', '', $this->input->post('credit_limit'));

        $customer_type    = $this->input->post('customer_type');
        $customer_class    = $this->input->post('customer_class');
        $top_nota    = $this->input->post('top_nota');
        $top_internal    = $this->input->post('top_internal');

        $array_insert = [
            'code' => $code,
            'ktp' => $ktp,
            'id_member_type' => $customer_type,
            'id_member_class' => $customer_class,
            'name' => $name,
            'npwp' => $npwp,
            'email' => $email,
            'number_phone' => $number_phone,
            'address' => $address,
            'payment_method' => $payment_method,
            'isActive' => $active_status,
            'created_by' => $this->session->userdata('us_id')
        ];

        if ($_FILES['media']['name'] != '') {
            $array_insert['image'] = $this->upload_image();
        }

        Modules::run('database/insert', 'mst_customer', $array_insert);
        echo json_encode(['status' => true]);
    }

    public function get_data()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_data = Modules::run('database/find', 'mst_customer', ['id' => $id])->row();
        echo json_encode($get_data);
    }

    private function upload_image()
    {
        $config['upload_path']          = realpath(APPPATH . '../upload/customer');
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('media')) //upload and validate
        {
            $data['inputerror'][] = 'upload_banner';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            $upload_data = $this->upload->data();
            $image_name = $upload_data['file_name'];
            return $image_name;
        }
    }

    public function update()
    {
        Modules::run('security/is_ajax');
        $this->validate_save();


        $id     = $this->input->post('id');

        $code    = $this->input->post('code');
        $ktp    = $this->input->post('ktp');
        $name    = $this->input->post('name');
        $npwp    = $this->input->post('npwp');
        $address    = $this->input->post('address');
        $number_phone    = $this->input->post('number_phone');
        $email    = $this->input->post('email');
        $active_status    = $this->input->post('active_status');

        $customer_type    = $this->input->post('customer_type');
        $customer_class    = $this->input->post('customer_class');
        $payment_method    = $this->input->post('payment_method');

        $array_update = [
            'code' => $code,
            'ktp' => $ktp,
            'id_member_type' => $customer_type,
            'id_member_class' => $customer_class,
            'name' => $name,
            'npwp' => $npwp,
            'email' => $email,
            'number_phone' => $number_phone,
            'address' => $address,
            'payment_method' => $payment_method,
            'isActive' => $active_status,
            'created_by' => $this->session->userdata('us_id')
        ];

        if ($_FILES['media']['name'] != '') {
            $array_update['image'] = $this->upload_image();
        }

        Modules::run('database/update', 'mst_customer', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }

    public function delete_data()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        $array_update = ['isDeleted' => 'Y'];
        Modules::run('database/update', 'mst_customer', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }

    public function update_status()
    {
        Modules::run('security/is_ajax');
        $status = $this->input->post('status') ? 'Y' : 'N';
        $id = $this->input->post('id');

        Modules::run('database/update', 'mst_customer', ['id' => $id], ['isActive' => $status]);
        echo json_encode(['status' => TRUE]);
    }


    public function print()
    {
        $encrypt_data_search = $this->encrypt->decode($this->input->post('search'));
        $data_search = json_decode($encrypt_data_search);

        $array_where['mst_customer.isDeleted'] = 'N';
        $array_query = [
            'select' => '
                mst_customer.*
            ',
            'from' => 'mst_customer',
            'where' => $array_where,
            'order_by' => 'mst_customer.id, DESC'
        ];
        $get_data = Modules::run('database/get', $array_query)->result();

        if ($this->input->post('print_excel')) {
            $this->export_excel($get_data);
        }
        if ($this->input->post('print_pdf')) {
            $this->export_pdf($get_data);
        }
    }

    public function export_excel($data)
    {
        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('5');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('30');
        $sheet->getColumnDimension('D')->setWidth('30');
        $sheet->getColumnDimension('E')->setWidth('25');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('15');
        $sheet->getColumnDimension('I')->setWidth('40');
        $sheet->getColumnDimension('J')->setWidth('10');

        //bold style 
        $sheet->getStyle("A1:J2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:J2');
        $sheet->getStyle('A1:J2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:J2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA CUSTOMER');
        $sheet->getStyle('A3:J3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A3"; // or any value
        $to = "J3"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'NAMA LENGKAP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'EMAIL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'NO.TELP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'NPWP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'PIC');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G3', 'KREDIT LIMIT (RP)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H3', 'LIMIT JATUH TEMPO (HARI)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I3', 'ALAMAT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J3', 'STATUS');
        $sheet_number_resume = 3;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );


        foreach ($data as $data_table) {
            $active = $data_table->isActive == 'Y' ? 'Aktif' : 'Non-Aktif';
            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->name);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_table->email);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->number_phone);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->npwp);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->pic);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_table->credit_limit);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->expired_limit);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume, $data_table->address);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $active);
            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA CUSTOMER PER ' . date('d-m-Y') . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function export_pdf($data_customer)
    {
        error_reporting(0);
        ob_clean();
        $data['data_customer'] = $data_customer;
        //print_r($data['data_profile']);
        //exit;
        ob_start();
        $this->load->view('pdf_customer', $data);
        //print_r($html);
        //exit;
        $html = ob_get_contents();
        ob_end_clean();
        require_once('../assets/plugin/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('L', 'A4', 'en', true, 'UTF-8', array(5, 5, 5, 5));
        $pdf->WriteHTML($html);
        $pdf->Output('LAPORAN DATA CUSTOMER PER -' . date('d-m-Y') . '.pdf', 'D');
    }
}
