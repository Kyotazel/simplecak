<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Import extends CommonController
{

    var $module_name        = 'import_customer';
    var $module_directory   = 'customer';
    var $module_js          = ['import-customer'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['member_type'] = Modules::run('database/find', 'tb_member_category', ['type' => 1])->result();
        $this->app_data['member_class'] = Modules::run('database/find', 'tb_member_category', ['type' => 2])->result();

        $this->app_data['page_title'] = "Data Customer";
        $this->app_data['view_file'] = 'import/view_import';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function validate_do_import_data()
    {
        Modules::run('security/is_ajax');
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->encrypt->decode($this->input->post('id'));
        if ($_FILES['upload']['name'] == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'upload';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    private function do_upload_file()
    {
        $config['upload_path']          = realpath(APPPATH . '../upload/csv');
        $config['allowed_types']        = 'csv';
        // $config['max_size']             = 100; //set max size allowed in Kilobyte
        // $config['max_width']            = 1000; // set max width image allowed
        // $config['max_height']           = 1000; // set max height allowed
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('upload')) //upload and validate
        {
            $data['inputerror'][] = 'upload';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            return $this->upload->data('file_name');
        }
    }

    public function import_data()
    {
        $file_name = $this->do_upload_file();
        $file_content = fopen(APPPATH . '../upload/csv/' . $file_name, "r");

        $counter = 0;
        $array_data_csv = [];
        $array_data_csv_fix = [];
        $array_token = [];
        $array_counter_key = [];
        $counter_key = 0;
        while (($data_csv = fgetcsv($file_content, 10000000, ",")) !== FALSE) {
            $counter++;
            $data_csv[0] = trim($data_csv[0]);


            if ($counter == 1) {
                continue;
                if (
                    $data_csv[0] != 'AKUN' ||
                    $data_csv[1] != 'TANGGAL' ||
                    $data_csv[2] != 'KETERANGAN' ||
                    $data_csv[3] != 'DEBIT' ||
                    $data_csv[4] != 'KREDIT' ||
                    $data_csv[5] != 'TOKEN'
                ) {
                    continue;
                    $data['inputerror'][] = 'upload';
                    $data['error_string'][] = 'format csv salah'; //show ajax error
                    $data['status'] = FALSE;
                    echo json_encode($data);
                    exit();
                }

                continue;
            }


            $code = $data_csv[1];
            $name = $data_csv[2];
            $ktp = $data_csv[3];
            $npwp = $data_csv[4];

            $array_type = [
                'A' => [
                    'id' => 8,
                    'name' => 'GROSIR'
                ],
                'B' => [
                    'id' => 9,
                    'name' => 'SEMI-GROSIR'
                ],
                'C' => [
                    'id' => 10,
                    'name' => 'RETAIL'
                ],
                'D' => [
                    'id' => 11,
                    'name' => 'UMUM'
                ]
            ];
            $grosir = $data_csv[5];
            $semi_grosir = $data_csv[6];
            $retail = $data_csv[7];
            $umum = $data_csv[8];
            $status_text = $grosir . $semi_grosir . $retail . $umum;
            $arr_type = isset($array_type[$status_text]) ? $array_type[$status_text] : [];

            $array_class = [
                1 => [
                    'id' => 13,
                    'name' => 'VIP'
                ],
                2 => [
                    'id' => 14,
                    'name' => 'BIG'
                ],
                3 => [
                    'id' => 15,
                    'name' => 'MIDDLE'
                ],
                4 => [
                    'id' => 16,
                    'name' => 'SMALL'
                ]
            ];

            $vip = $data_csv[9];
            $big = $data_csv[10];
            $middle = $data_csv[11];
            $small = $data_csv[12];
            $status_text = $vip . $big . $middle . $small;
            $arr_class = isset($array_class[$status_text]) ? $array_class[$status_text] : [];

            $top_nota = $data_csv[14];
            $top_internal = $data_csv[15];
            $limit = $data_csv[16];



            $array_data_csv_fix[] = [
                'code' => $code,
                'name' => $name,
                'npwp' => $npwp,
                'ktp' => $ktp,
                'type' => $arr_type,
                'class' => $arr_class,
                'top_nota' => $top_nota,
                'top_internale' => $top_internal,
                'limit' => $limit
            ];
        }





        echo json_encode(['status' => TRUE, 'list' => $array_data_csv_fix, 'count' => count($array_data_csv_fix)]);
    }

    public function processing_view()
    {
        $list_data = $this->input->post('list');
        $list_data = json_decode($list_data, TRUE);
        $html_respon = '';
        foreach ($list_data as $arr_customer) {
            $type = isset($arr_customer['type']['name']) ?  $arr_customer['type']['name'] : '';
            $class = isset($arr_customer['class']['name']) ?  $arr_customer['class']['name'] : '';

            $html_respon .= '
                <tr>
                    <td>' . $arr_customer['code'] . '</td>
                    <td>' . $arr_customer['name'] . '</td>
                    <td>' . $arr_customer['npwp'] . '</td>
                    <td>' . $arr_customer['ktp'] . '</td>
                    <td>' . $type . '</td>
                    <td>' . $class . '</td>
                    <td>' . $arr_customer['top_nota'] . '</td>
                    <td>' . $arr_customer['top_internale'] . '</td>
                    <td>' . $arr_customer['limit'] . '</td>
                </tr>

            ';
        }

        echo json_encode(
            [
                'status' => true,
                'html_respon' => $html_respon,
                'list' => $list_data
            ]
        );
    }

    public function save_import()
    {
        $list_data = $this->input->post('list');
        $list_data = json_decode($list_data, TRUE);
        foreach ($list_data as $arr_customer) {

            $type = isset($arr_customer['type']['id']) ?  $arr_customer['type']['id'] : 0;
            $class = isset($arr_customer['class']['id']) ?  $arr_customer['class']['id'] : 0;

            $array_insert = [
                'code' => $arr_customer['code'],
                'ktp' => $arr_customer['ktp'],
                'id_member_type' => $type,
                'id_member_class' => $class,
                'name' => $arr_customer['name'],
                'npwp' => $arr_customer['npwp'],
                'email' => '',
                'number_phone' => '',
                'address' => '',
                'isActive' => 1,
                'credit_limit' => (int) $arr_customer['limit'],
                'top_nota' => $arr_customer['top_nota'],
                'top_internal' => $arr_customer['top_internale'],
                'created_by' => $this->session->userdata('us_id')
            ];
            Modules::run('database/insert', 'mst_customer', $array_insert);
        }
        echo json_encode(['status' => TRUE]);
    }
}
