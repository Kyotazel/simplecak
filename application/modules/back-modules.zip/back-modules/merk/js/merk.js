var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var id_use = 0;
var table;

$(document).ready(function() {
    table = $('#table_user').DataTable({
        "ajax": {
            "url": url_controller + "list_data",
            "type": "POST"
        }
    });

    $('.chosen').chosen();
})
//end document ready 

function reload_table() {
    table.ajax.reload(null, false); //reload datatable ajax 
}

function add_unit() {
    save_method = 'add'
    $('#form_unit')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('.modal-title').text('Form Merk');
    $('#modal_unit').modal('show');
}

function save() {
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    showLoading();
    var url;
    if (save_method == 'add') {
        url = url_controller + "save";
    } else {
        url = url_controller + "update";
    }
    //defined form
    var formData = new FormData($('#form_unit')[0]);
    $.ajax({
        url: url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                // $('#modal_user').modal('hide');
                $('#modal_unit').modal('hide');
                hideLoading();
                reload_table();
                notif_success('data berhasil disimpan!');
            } else {
                hideLoading();
                $('#modal_unit').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }

        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('error process');
            hideLoading();
        }

    });

}



function edit_unit(id) {
    $('.help-block').empty();
    save_method = 'update';
    $('.modal-title').text('Form Unit');
    $('#form_unit')[0].reset();
    $('.form-group').removeClass('has-error');
    $('help-block').empty();
    // $('.not-update').empty();
    // var urlupdate = url_controller+""
    $.ajax({
        url: url_controller + "get_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            $('[name="id"]').val(data.id);
            $('[name="name"]').val(data.name);
            $('[name="code"]').val(data.code);
            $('[name="main_category"]').val(data.id_main_category).trigger("chosen:updated");
            $('#modal_unit').modal('show');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('error process');
            showLoading();
        }
    });
}


function delete_unit(id) {
    swal({
        title: "Apakah anda yakin?",
        text: "data akan dihapus!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: url_controller + "delete/" + id,
                type: "POST",
                dataType: "JSON",
                success: function(data) {
                    //if success
                    hideLoading();
                    reload_table();
                    notif_success('data berhasil dihapus..!');
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('Error deleting data');
                }
            });
        }
    });

}