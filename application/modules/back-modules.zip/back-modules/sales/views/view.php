<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>

    <div class="card-body">
        <form class="form-input">
            <div class="col-md-12">
                <div class="col-md-3">
                    <label>Pencarian</label>
                    <select name="type" class=" form-control">
                        <option value="1">Penjualan Hari Ini</option>
                        <option value="2">Range Tanggal</option>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-2">
                    <label>Kasir</label>
                    <select name="id_cashier" class="form-control">
                        <option value="">SEMUA</option>
                        <?php
                        foreach ($data_cashier as $item_cashier) {
                            echo '
                                    <option value="' . $item_cashier->id . '">' . $item_cashier->name . '</option>
                                ';
                        }
                        ?>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-7 d-none form_date ">
                    <div class="col-md-4 form-group">
                        <label for="">Tanggal Awal</label>
                        <input type="text" readonly class="bg-white form-control datepicker" name="date_from">
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-1 text-center">
                        <label for="">&nbsp;</label><br>
                        <label for="">S/D</label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="">Tanggal Akhir</label>
                        <input type="text" readonly class="bg-white form-control datepicker" name="date_to">
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-2">
                        <label for="">&nbsp;</label><br>
                        <button class="btn btn-success btn_search"><i class="fa fa-search"></i> Cari Data</button>
                    </div>
                </div>
                <div class="col-md-7 form_today">
                    <div class="col-md-3">
                        <label for="">&nbsp;</label><br>
                        <button class="btn btn-success btn_search"><i class="fa fa-search"></i> Cari Data</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>
<div class="html_respon"></div>

<div class="modal" id="modal_view_detail_sales">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="view_detail_sales">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<script type="text/javascript" src="<?php echo base_url('assets/assets_admin/'); ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>function_toast.js"></script>
<script type="text/javascript">
    var save_method;
    var table;
    var controller = 'sales/';
    var base_url = '<?php echo base_url(); ?>' + controller;
    $(document).ready(function() {
        // table = $('#table_list').DataTable({
        //     "ajax": {
        //         "url": base_url + "list_data",
        //         "type": "POST"
        //     }
        // });
    })

    $('[name="type"]').change(function() {
        var value = $(this).val();
        if (value == 1) {
            $('.form_date').hide();
            $('.form_today').show();
        } else {
            $('.form_date').show();
            $('.form_today').hide();
        }
    });


    $('.btn_search').click(function(e) {
        e.preventDefault();
        $(this).button('loading');
        $('.form-group').removeClass('has-error');
        $('.help-block').empty();
        //defined form
        var formData = new FormData($('.form-input')[0]);
        var url;
        $.ajax({
            url: controller + '/search_data',
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            dataType: "JSON",
            success: function(data) {
                if (data.status) {
                    $('.html_respon').html(data.html_respon);
                    $(".pagination").rPage();
                } else {
                    for (var i = 0; i < data.inputerror.length; i++) {
                        $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                        $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                    }
                }
                $('.btn_search').button('reset');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('.btn_search').button('reset');
                alert_error('something wrong');
            }
        }); //end ajax
    });

    //pagination 
    $(document).on('click', '.page-link', function() {
        var page_number = $(this).data('ci-pagination-page');
        $(this).text('load..');
        $('.form-group').removeClass('has-error');
        $('.help-block').empty();
        $('#modal_product').modal('hide');
        // showLoading();
        //defined form
        var formData = new FormData($('.form-input')[0]);
        formData.append('page', page_number);
        $.ajax({
            url: controller + '/search_data',
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            dataType: "JSON",
            success: function(data) {
                if (data.status) {
                    $('.html_respon').html(data.html_respon);
                    $(".pagination").rPage();
                } else {
                    for (var i = 0; i < data.inputerror.length; i++) {
                        if (data.inputerror[i] == 'price') {
                            $('.notif_' + data.inputerror[i]).parent().addClass('has-error');
                            $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                        } else {
                            $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                            $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                        }
                    }
                }
                $('.btn_search').button('reset');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('.btn_search').button('reset');
                alert_error('something wrong');
            }
        }); //end ajax
    });


    function detail_sales(id) {
        showLoading();
        $('.modal-title').text('DETAIL');
        var url = base_url + 'detail_sales/' + id;
        // var formData = new FormData($('#form_sales')[0]);
        $.ajax({
            url: url,
            type: "GET",
            dataType: "HTML",
            success: function(data) {
                hideLoading();
                $('.view_detail_sales').html(data);
                $('#modal_view_detail_sales').modal('show');
                // $('.table_view_sales').DataTable();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('error process');
                showLoading();
            }
        });
    }
</script>