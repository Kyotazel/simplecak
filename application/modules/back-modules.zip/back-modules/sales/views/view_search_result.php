<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="table_list" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No Nota</th>
                        <th>Tanggal</th>
                        <th>Grand Total</th>
                        <th>Bayar</th>
                        <th>Kembali</th>
                        <th>Member</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $counter = $start_no;
                    foreach ($data_sales as $data_table) {
                        $counter++;
                        $date_explode = explode('-', $data_table->date);
                        $date_oder = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];

                        echo '
                            <tr>
                                <td>' . $counter . '</td>
                                <td>' . $data_table->code . '</td>
                                <td>' . $date_oder . '</td>
                                <td>' . number_format($data_table->grand_total, 0, '.', '.') . '</td>
                                <td>' .  number_format($data_table->payment, 0, '.', '.') . '</td>
                                <td>' . number_format($data_table->rest_payment, 0, '.', '.') . '</td>
                                <td>' . $data_table->member_name . '</td>
                                <td>
                                    <a class="btn btn-sm btn-primary-gradient" href="javascript:void(0)" title="detail penjualan" onclick="detail_sales(' . "'" . $data_table->id . "'" . ')"><i class="fa fa-list"></i> Detail</a>
                                </td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-12">
                    <!--Tampilkan pagination-->
                    <?php echo $html_pagination; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.box-body -->
</div>