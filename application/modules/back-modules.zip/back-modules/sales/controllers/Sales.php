<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales extends CI_Controller
{
    var $location = 'data_sales/';
    var $tb_name = 'tb_sales';
    var $module_name = 'sales';

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function index()
    {
        $data['data_cashier'] = $this->db->where(['level' => 1])->get('tb_user')->result();
        $data['tagline_page'] = "Data Penjualan";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin', $data);
    }

    private function change_date($date)
    {
        $date_explode = explode('-', $date);
        $date_return = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        return $date_return;
    }

    public function validate_search()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $type   = $this->input->post('type');
        if ($type == 2) {
            if ($this->input->post('date_from') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'date_from';
                $data['status'] = FALSE;
            }
            if ($this->input->post('date_to') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }
    public function search_data()
    {
        $this->validate_search();
        $type   = $this->input->post('type');
        $id_cashier    = $this->input->post('id_cashier');
        $today =  date('Y-m-d');
        if ($type == 1) {
            $additional_where = "WHERE a.date = '$today' ";
        } else {
            $date_from = $this->change_date($this->input->post('date_from'));
            $date_to = $this->change_date($this->input->post('date_to'));
            $additional_where = "WHERE  a.date >=  '$date_from'  AND a.date <= '$date_to' ";
        }
        if (!empty($id_cashier)) {
            $additional_where .= " AND a.created_by = $id_cashier";
        }
        $get_sales = $this->db->query("select a.id,
                                        a.code,
                                        a.date,
                                        a.grand_total,
                                        a.payment,
                                        a.rest_payment,
                                        b.name as member_name  
                                        from tb_sales a 
                                        left join tb_member b on a.id_member = b.id
                                        " . $additional_where)->result();
        $page = $this->input->post('page');
        $main_query = $this->db->last_query();
        $limit_data = 25;
        if (!empty($page) && $page != 'undefined') {
            $start_page = ($page * $limit_data) - $limit_data;
            $data['start_no'] = $start_page;
        } else {
            $start_page = 0;
            $data['start_no'] = 0;
        }
        $get_query = $main_query . ' LIMIT ' . $start_page . ',' . $limit_data;
        $count_all = $this->db->query($main_query)->num_rows();
        $get_data = $this->db->query($get_query)->result();


        $num_links = round($count_all / $limit_data);

        $html_pagination_item = '';
        $counter = 0;
        if ($num_links > 1) {
            for ($i = 0; $i < $num_links; $i++) {
                $counter++;
                $active = $page == $counter ? 'active' : '';
                $html_pagination_item .= '<li class="page-item ' . $active . '"><a class="page-link btn_pagination" data-ci-pagination-page="' . $counter . '"  href="javascript:void(0)">' . $counter . '</a></li>';
            }
        }

        $html_pagination = '
                            <div class="pagging text-center">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        ' . $html_pagination_item . '
                                    </ul>
                                </nav>
                            </div>
                        ';
        $data['html_pagination'] = $html_pagination;

        $data['data_sales'] = $get_data;


        $html_respon = $this->load->view($this->location . 'view_search_result', $data, TRUE);

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function list_data()
    {
        $db_name = 'tb_product';
        // $date_today = date('Y-m-d');
        $get_sales = $this->db->query("select a.id,a.code,a.date,a.grand_total,a.payment,a.rest_payment,b.name as member_name  from tb_sales a left join tb_member b on a.id_member = b.id order by a.id DESC ");
        $data = array();
        $no = 0;
        foreach ($get_sales->result() as $data_table) {
            //create date
            $date_explode = explode('-', $data_table->date);
            $date_oder = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $date_oder;
            $row[] = number_format($data_table->grand_total, 0, '.', '.');
            $row[] = number_format($data_table->payment, 0, '.', '.');
            $row[] = number_format($data_table->rest_payment, 0, '.', '.');
            if ($data_table->member_name == '') {
                $row[] = '-';
            } else {
                $row[] = $data_table->member_name;
            }

            $row[] = '<a class="btn btn-sm btn-primary-gradient" href="javascript:void(0)" title="detail penjualan" onclick="detail_sales(' . "'" . $data_table->id . "'" . ')"><i class="fa fa-list"></i> Detail</a>';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function detail_sales($id_sales)
    {
        $get_data_detail = $this->db->query("select a.*,
											b.code as code_sales,
                                            b.grand_total,
                                            b.ppn,
                                            b.ppn_price,
                                            b.pph,
                                            b.pph_price,
                                            b.grand_total_sales,
											b.payment,
											b.rest_payment,
                                            b.date,
                                            b.credit_status,
                                            b.credit_price,
											c.name,
											c.code as product_code,
											c.qty_unit,
                                            c.code as code_product,
                                            c.price AS real_sales_price,
											d.name as unit_name,
                                            f.name as member_name,
                                            h.code AS credit_code,
                                            h.name AS responsible_name,
                                            h.price AS credit_price_current,
                                            h.note AS credit_note,
                                            h.deadline AS credit_deadline,
                                            i.name AS conversion_name,
                                            i.qty AS conversion_qty
											from tb_detail_sales a 
											left join tb_sales b on a.id_sales = b.id
											left join tb_product c on a.id_product = c.id 
											left join tb_unit d on c.id_unit = d.id 
                                            left join tb_member f on b.id_member = f.id
                                            left join tb_credit h on b.code = h.sales_code 
                                            left join tb_product_has_conversion i on a.id_conversion_unit = i.id 
											where a.id_sales = '$id_sales'
											")->result();
        // print_r($get_data_detail[0]);
        // exit;
        $date_order_explode = explode('-', $get_data_detail[0]->date);
        $date_order_html = $date_order_explode[2] . '-' . $date_order_explode[1] . '-' . $date_order_explode[0];
        //status
        $status_credit  = $get_data_detail[0]->credit_status ? '<label class="label label-success">TRUE</label>' : '-';
        $label_credit   = $get_data_detail[0]->credit_price > 0 ? 'Rp.' . number_format($get_data_detail[0]->credit_price, 0, '.', '.') : '-';
        //create html form
        $html_delivery = '';
        // if ($get_data_detail[0]->delivery_status) {
        //     $html_delivery = '
        //                         <div class="col-md-6 p-10  border-radius-5 pull-right">
        //                             <h3>Alamat Tujuan:</h3>
        //                             <table class="table">
        //                                 <tr>
        //                                     <td width="200px">Kode Pengiriman</td>
        //                                     <td width="10px">:</td>
        //                                     <td><b>' . $get_data_detail[0]->delivery_code . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Kepada</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->receiver . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Tujuan</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->kec . '&nbsp;-&nbsp;' . $get_data_detail[0]->city . '&nbsp;-&nbsp;' . $get_data_detail[0]->province . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Alamat Lengkap</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->address . '</b></td>
        //                                 </tr>
        //                             </table>
        //                         </div>
        //                     ';
        // }

        $html_credit = '';
        if ($get_data_detail[0]->credit_status) {
            $html_credit = '
                                <div class="col-md-6 p-10 border border-radius-5 mb-10 pull-right">
                                    <h3>Keterangan Piutang:</h3>
                                    <table class="table">
                                        <tr>
                                            <td width="200px">Kode Piutang</td>
                                            <td width="10px">:</td>
                                            <td><b>' . $get_data_detail[0]->credit_code . '</b></td>
                                        </tr>
                                        <tr>
                                            <td>Penganggung Jawab</td>
                                            <td>:</td>
                                            <td><b>' . $get_data_detail[0]->responsible_name . '</b></td>
                                        </tr>
                                        <tr>
                                            <td>Jumlah Piutang</td>
                                            <td>:</td>
                                            <td><b>Rp.' . number_format($get_data_detail[0]->credit_price_current, 0, '.', '.') . '</b></td>
                                        </tr>
                                        <tr>
                                            <td>Jatuh Tempo</td>
                                            <td>:</td>
                                            <td><b>' . $get_data_detail[0]->credit_deadline . '</b></td>
                                        </tr>
                                        <tr>
                                            <td>Catatan</td>
                                            <td>:</td>
                                            <td><b>' . $get_data_detail[0]->credit_note . '</b></td>
                                        </tr>
                                    </table>
                                </div>
                            ';
        }

        $data_html = '
					<table class="col-md-6">
                      <tr>
                        <td width="200px" height="30px">Kode</td>
                        <td width="5px">:</td>
                        <td>' . $get_data_detail[0]->code_sales . '</td>
                      </tr>
                      <tr>
                        <td width="100px" height="30px">Tanggal</td>
                        <td width="5px">:</td>
                        <td>' . $date_order_html . '</td>
                      </tr>
                      <tr>
                        <td width="100px" height="30px">Member</td>
                        <td width="5px">:</td>
                        <td>' . $get_data_detail[0]->member_name . '</td>
                      </tr>
                    </table>
                    <table class="col-md-6">
                     <tr>
                        <td width="200px" height="30px">Grand Total</td>
                        <td width="5px">:</td>
                        <td>Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</td>
                      </tr>
                      <tr>
                        <td height="30px">Bayar</td>
                        <td>:</td>
                        <td>Rp.' . number_format($get_data_detail[0]->payment, 0, '.', '.') . '</td>
                      </tr>
                      <tr>
                        <td height="30px">Kembali</td>
                        <td>:</td>
                        <td>Rp.' . number_format($get_data_detail[0]->rest_payment, 0, '.', '.') . '</td>
                      </tr>
                      <tr>
                        <td height="30px">Status Piutang</td>
                        <td>:</td>
                        <td>' . $status_credit . '</td>
                      </tr>
                      <tr>
                        <td height="30px">Jumlah Piutang</td>
                        <td>:</td>
                        <td>' . $label_credit . '</td>
                      </tr>
                    </table>
                    <span class="clearfix"></span>
                    <hr>
                    <span class="clearfix"></span>
                    <table class="table">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Kode</th>
                          <th>nama</th>
                          <th>Harga Satuan</th>
                          <th>Jumlah Beli</th>
                          <th>Diskon</th>
                          <th>Bonus</th>
                          <th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
					';
        //get data here
        $no = 0;
        foreach ($get_data_detail as $data_detail) {
            $no++;
            //count base qty buy 

            if ($data_detail->conversion_name) {
                $label_qty_buy = '';
                $unit_value = $data_detail->qty % $data_detail->conversion_qty;
                $conversion_value = ($data_detail->qty - $unit_value) / $data_detail->conversion_qty;

                if ($conversion_value > 0) {
                    $conversion_qty = $data_detail->conversion_qty * $conversion_value;
                    $label_qty_buy .= $conversion_value . ' ' . $data_detail->conversion_name . '( ' . $conversion_qty . ' ' . $data_detail->unit_name . ')' . '<br>';
                }
                if ($unit_value > 0) {
                    $label_qty_buy .= $unit_value . ' ' . $data_detail->unit_name;
                }
            } else {
                $label_qty_buy = $data_detail->qty . ' ' . $data_detail->unit_name;
            }

            $html_price =  number_format($data_detail->price, 0, '.', '.');
            if ($data_detail->price != $data_detail->real_sales_price) {
                $html_price = '<del class="text-muted">' . number_format($data_detail->real_sales_price, 0, '.', '.') . '</del> <span>Rp.' . number_format($data_detail->price, 0, '.', '.') . '</span>';
            }

            $data_html .= '
						<tr>
                          <td>' . $no . '</td>	
                          <td>' . $data_detail->product_code . '</td>
                          <td>' . $data_detail->name . '</td>
                          <td>' . $html_price . '</td>
                          <td>' . $label_qty_buy . '</td>
                          <td>' . $data_detail->discount . '% ( Rp.' . number_format($data_detail->price_discount, 0, '.', '.') . ' )' . '</td>
                          <td>' . $data_detail->bonus . '</td>
                          <td>' . number_format($data_detail->total_price, 0, '.', '.') . '</td>
                        </tr>
					';
        } //end foreach
        $data_html .= '
                        <tr>
                            <td colspan="7" class="text-right">Total Pembelian</td>
                            <td>:</td>
                            <td><b>Rp.' . number_format($get_data_detail[0]->grand_total_sales, 0, '.', '.') . '</b></td>
                        </tr>
                        <tr>
                            <td colspan="7" class="text-right">PPN ' . $get_data_detail[0]->ppn . ' %</td>
                            <td>:</td>
                            <td><b> Rp.' . number_format($get_data_detail[0]->ppn_price, 0, '.', '.') . '</b></td>
                        </tr>
                        <tr>
                            <td colspan="7" class="text-right">PPH ' . $get_data_detail[0]->pph . ' %</td>
                            <td>:</td>
                            <td><b> Rp.' . number_format($get_data_detail[0]->pph_price, 0, '.', '.') . '</b></td>
                        </tr>
                        <tr>
                            <td colspan="7" class="text-right">GRAND TOTAL</td>
                            <td>:</td>
                            <td><b> Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</b></td>
                        </tr>
                    ';

        $data_html .= '
                      </tbody>
                    </table>
                    <hr>
                    ' . $html_delivery . $html_credit;
        echo $data_html;
    }
}
