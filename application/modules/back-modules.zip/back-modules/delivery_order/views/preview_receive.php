<div class="card">
    <div class="card-body">

        <div class="col-md-12 ">
            <div class="text-left mb-10 p-10">
                <h3>Detail Barang PO <span class="badge badge-light">( Total Item : <?= $data_request->count_item; ?> ITEM )</span></h3>
            </div>
            <table class="table table_detail_request">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Produk</th>
                        <th>Nama Produk</th>
                        <th>Satuan Produk</th>
                        <th>Qty PO</th>
                        <th>Harga Beli</th>
                        <th>Qty Terima</th>
                        <th>Selish</th>
                        <th>HPP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $counter = 0;
                    foreach ($data_detail as $item_detail) {
                        $counter++;
                        if (!empty($item_detail->conversion_name)) {
                            $unit_request = $item_detail->conversion_name . ' / ' . $item_detail->qty_conversion . ' ' . $item_detail->unit_name;
                        } else {
                            $unit_request = $item_detail->unit_name;
                        }
                        $conversion_name = $item_detail->conversion_name ? $item_detail->conversion_name : $item_detail->unit_name;

                        $qty_receive = isset($array_qty[$item_detail->id]) ? str_replace('.', '', $array_qty[$item_detail->id]) : 0;
                        $price_receive = isset($array_price[$item_detail->id]) ? str_replace('.', '', $array_price[$item_detail->id]) : 0;
                        $hpp_price = isset($hpp_receive[$item_detail->id]) ? str_replace('.', '', $hpp_receive[$item_detail->id]) : 0;
                        $interval = $qty_receive -  $item_detail->qty;

                        echo '
                                <tr class="item_receive">
                                    <td>' . $counter . '</td>
                                    <td>' . $item_detail->product_code . '</td>
                                    <td>' . $item_detail->product_name . '</td>
                                    <td>' . $item_detail->unit_name . '</td>
                                    <td class="qty_po" data-value="' . $item_detail->qty . '">' . $item_detail->qty . ' ' . $conversion_name . '</td>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Rp.</span>
                                            </div>
                                            <input data-id="' . $item_detail->id . '" readonly class="form-control bg-white  price_receive money_only border-dashed" readonly data-qty="' . $item_detail->qty . '" value="' . number_format($price_receive, 0, '.', '.') . '" name="price_receive[' . $item_detail->id . ']"  placeholder="pilih tanggal" type="text">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <input data-id="' . $item_detail->id . '" data-qty="' . $item_detail->qty . '" readonly class="form-control border-dashed bg-white  qty_receive number_only" value="' . number_format($qty_receive, 0, '.', '.') . '" name="qty_receive[' . $item_detail->id . ']"  placeholder="pilih tanggal" type="text">
                                            <div class="input-group-append">
                                                <span class="input-group-text" id="basic-addon1">' . $conversion_name . '</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="qty_interval_' . $item_detail->id . '">' . $interval . '</td>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">Rp.</span>
                                            </div>
                                            <input class="form-control bg-white  hpp_receive_' . $item_detail->id . ' border-dashed" readonly value="' . number_format($hpp_price, 0, '.', '.') . '" name="price_receive[' . $item_detail->id . ']"  placeholder="pilih tanggal" type="text">
                                        </div>
                                    </td>
                                </tr>
                            ';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-12 p-3 text-right">
            <small>(*klik untuk simpan data)</small>
            <a href="javascript:void(0)" class="btn btn-rounded btn-primary-gradient btn_save" data-id="<?= $data_request->id; ?>">Simpan Transaksi <i class="fa fa-paper-plane"></i></a>
        </div>
    </div>
</div>