<?php
function change_date($date)
{
    $date_explode = explode('-', $date);
    $date_return = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
    return $date_return;
}

function date_function($date, $type, $return)
{
    if ($type == 'timestamp') {
        $timestamp_explode = explode(' ', $date);
        //create date indo
        $date_explode = explode('-', $timestamp_explode[0]);
        $date_indo = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        if ($return == 'time') {
            return $timestamp_explode[1];
        } elseif ($return == 'date') {
            return $timestamp_explode[0];
        } else {
            return $date_indo;
        }
    } else {
        $date_explode = explode('-', $date);
        $date_indo = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        if ($return == 'time') {
            return '-';
        } elseif ($return == 'date') {
            return $date;
        } else {
            return $date_indo;
        }
    }
}

function date_indo($date, $delimiter)
{
    $array_month = [
        '01' => 'januari', '02' => 'februari', '03' => 'maret', '04' => 'april', '05' => 'mei', '06' => 'juni', '07' => 'juli', '08' => 'agustus', '09' => 'september', '10' => 'oktober', '11' => 'november', '12' => 'december'
    ];
    $explode_date = explode($delimiter, $date);
    $date_return = $explode_date[2] . ' ' . ucfirst($array_month[$explode_date[1]]) . ' ' . $explode_date[0];
    return $date_return;
}


?>
<style type="text/css">
    .body {
        font-size: 10px;
        font-family: Times, serif;
    }

    .jarak {
        height: 25px;
    }

    .lebar {
        width: 70px;
    }

    .lebar-kecil {
        width: 40px;
    }

    /*table{
		width: 90%;
	}*/
    .table {
        /*width: 100px;*/
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
    }

    th {
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
        font-size: 11px;
    }

    .table tr td {
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
        font-size: 11px;
    }

    .more_width {
        width: 100px;
    }

    .small_width {
        width: 3px;
    }

    .much_width {
        width: 300px;
    }

    .width_200 {
        width: 200px;
    }

    .more_than_width {
        width: 150px;
    }

    /*hr{
		border-top: 0.1px solid #8c8b8b;
	}*/
    .hr_style {
        border-top: 1px dashed #808080;
        border-bottom: 1px dashed #fff;
    }

    .delivery_address {
        /*background-color: red;*/
        border: 1px dashed #808080;
    }

    .text-capitalize {
        text-transform: capitalize;
    }
</style>
<html>

<head>
    <title></title>
</head>

<body>
    <table>
        <tr>
            <td style="width: 363px;">
                <img style="width: 70px;" src="<?= base_url('upload/' . $company['company_logo']); ?>" alt="">
                <h4 style="margin: 0px;padding:0px;"><?= $company['name']; ?></h4>
                <p style="margin: 0px;padding:0px;font-size:10px;margin-top:3px;">
                    <?= $company['company_address']; ?><br>
                    No.Telp :<?= $company['company_number_phone']; ?> | Email : <?= $company['company_email']; ?>

                </p>
            </td>
            <td style="width: 350px;">
                <h4 style="margin:0;padding:0px;"><u>DELIVERY ORDER</u></h4>
                <table style="font-size: 11px;">
                    <tr>
                        <td>NO.DO</td>
                        <td>: <?= $delivery_order['code']; ?></td>
                    </tr>
                    <tr>
                        <td>Petugas (Driver)</td>
                        <td>: <?= $delivery_order['employee_name']; ?></td>
                    </tr>
                    <tr>
                        <td>Transportasi</td>
                        <td>: <?= $delivery_order['transport_name']; ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal DO</td>
                        <td>: <?= Modules::run('helper/change_date', $delivery_order['date'], '-'); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
    <?php
    foreach ($list_SO as $item_so) {


        $array_query = [
            'select' => '
                    tb_sales.*,
                    mst_customer.code AS customer_code,
                    mst_customer.name AS customer_name,
                    mst_customer.address AS customer_address,
                ',
            'from' => 'tb_sales',
            'join' => [
                'mst_customer,tb_sales.id_member = mst_customer.id,left'
            ],
            'where' => [
                'tb_sales.id' => $item_so['id_sales']
            ],
            'group_by' => 'tb_sales.id',
            'order_by' => 'tb_sales.id, DESC'
        ];

        $get_so = Modules::run('database/get', $array_query)->row();

        $get_data_detail = $this->db->query("select a.*,
        b.code as code_sales,
        b.grand_total,
        b.ppn,
        b.ppn_price,
        b.pph,
        b.pph_price,
        b.grand_total_sales,
        b.payment,
        b.rest_payment,
        b.date,
        b.credit_status,
        b.credit_price,
        c.name,
        c.code as product_code,
        c.qty_unit,
        c.code as code_product,
        d.name as unit_name,
        f.name as member_name,
        h.code AS credit_code,
        h.price AS credit_price_current,
        h.note AS credit_note,
        h.deadline AS credit_deadline,
        i.name AS conversion_name,
        i.qty AS conversion_qty
        from tb_detail_sales a 
        left join tb_sales b on a.id_sales = b.id
        left join tb_product c on a.id_product = c.id 
        left join tb_unit d on c.id_unit = d.id 
        left join mst_customer f on b.id_member = f.id
        left join tb_credit h on b.code = h.id_transaction 
        left join tb_product_has_conversion i on a.id_conversion_unit = i.id 
        where a.id_sales = '$get_so->id'
        ")->result();

        $no = 0;
        $html_tr = '';
        foreach ($get_data_detail as $data_detail) {
            $no++;
            //count base qty buy 

            if ($data_detail->conversion_name) {
                $label_qty_buy = '';
                $unit_value = $data_detail->qty % $data_detail->conversion_qty;
                $conversion_value = ($data_detail->qty - $unit_value) / $data_detail->conversion_qty;

                if ($conversion_value > 0) {
                    $conversion_qty = $data_detail->conversion_qty * $conversion_value;
                    $label_qty_buy .= $conversion_value . ' ' . $data_detail->conversion_name . '( ' . $conversion_qty . ' ' . $data_detail->unit_name . ')' . '<br>';
                }
                if ($unit_value > 0) {
                    $label_qty_buy .= $unit_value . ' ' . $data_detail->unit_name;
                }
            } else {
                $label_qty_buy = $data_detail->qty . ' ' . $data_detail->unit_name;
            }


            $label_discount = '';
            if ($data_detail->price_discount > 0) {
                $discount_per_item = $data_detail->price_discount / $data_detail->qty;
                if ($data_detail->discount > 0) {
                    $label_discount = $data_detail->discount . ' %  / ' . $data_detail->unit_name . ' <br> ( <del>Rp.' . number_format($data_detail->price_discount, 0, '.', '.') . '</del> )';
                } else {
                    $label_discount = 'Rp.' . number_format($discount_per_item, 0, '.', '.') . '/ ' . $data_detail->unit_name . ' <br> ( <del>Rp.' . number_format($data_detail->price_discount, 0, '.', '.') . '</del> )';
                }
            }

            // <th style="width:20px;padding:5px;">No</th>
            //             <th style="width:80px;padding:5px;">KODE BARANG</th>
            //             <th style="width:200px;padding:5px;">NAMA BARANG</th>
            //             <th style="width:80px;padding:5px;">HARGA</th>
            //             <th style="width:30px;padding:5px;">QTY</th>
            //             <th style="width:80px;padding:5px;">DISKON</th>
            //             <th style="width:100px;padding:5px;">TOTAL</th>


            $html_tr .= '
           <tr>
               <td style="padding:5px;width:20px;">' . $no . '</td>	
               <td style="padding:5px;width:80px;">' . $data_detail->product_code . '</td>
               <td style="padding:5px;width:200px;">' . $data_detail->name . '</td>
               <td style="padding:5px;width:80px;">' . number_format($data_detail->price, 0, '.', '.') . '</td>
               <td style="padding:5px;width:30px;">' . $label_qty_buy . '</td>
               <td style="padding:5px;width:80px;">' . $label_discount . '</td>
               <td style="padding:5px;width:100px;">' . number_format($data_detail->total_price, 0, '.', '.') . '</td>
           </tr>
           ';
        } //end foreach

        $html_tr .= '
            <tr>
                <td colspan="6" style="text-align:right"; class="text-right">Total Pembelian</td>
                <td> : <b>Rp.' . number_format($get_data_detail[0]->grand_total_sales, 0, '.', '.') . '</b></td>
            </tr>
            <tr>
                <td colspan="6" style="text-align:right";  class="text-right">PPN ' . $get_data_detail[0]->ppn . ' %</td>
                <td>: <b> Rp.' . number_format($get_data_detail[0]->ppn_price, 0, '.', '.') . '</b></td>
            </tr>
            <tr>
                <td colspan="6" style="text-align:right"; class="text-right">PPH ' . $get_data_detail[0]->pph . ' %</td>
                <td>: <b> Rp.' . number_format($get_data_detail[0]->pph_price, 0, '.', '.') . '</b></td>
            </tr>
            <tr>
                <td colspan="6" style="text-align:right"; class="text-right">GRAND TOTAL</td>
                <td>: <b> Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</b></td>
            </tr>
        ';

        echo '
            <table class="table" style="vertical-align: top;">
                    <tr style="vertical-align: middle;">
                        <td colspan="4" style="padding:5px;">
                            ' . $get_so->customer_code . ' - ' . $get_so->customer_name . '<br>
                            <small>' . $get_so->customer_address . '</small>
                        </td>
                        <td colspan="3" style="padding:5px;">
                            <small>NO.SO :</small>
                            <b> ' . $get_so->code . '</b>
                        </td>
                    </tr>
                    <tr style="vertical-align: middle;text-align:center;">
                        <th style="width:20px;padding:5px;">No</th>
                        <th style="width:80px;padding:5px;">KODE BARANG</th>
                        <th style="width:200px;padding:5px;">NAMA BARANG</th>
                        <th style="width:80px;padding:5px;">HARGA</th>
                        <th style="width:30px;padding:5px;">QTY</th>
                        <th style="width:80px;padding:5px;">DISKON</th>
                        <th style="width:100px;padding:5px;">TOTAL</th>
                    </tr>
                    ' . $html_tr . '

            </table>
            <br>
        ';
    }
    ?>
</body>

</html>