<div class="col-md-12">
    <table class="table table-hover table_add_request" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Total Item</th>
                <th>Grand Total</th>
                <th>Keterangan</th>
                <th>Gudang</th>
                <th>Tanggal input</th>
                <th>Petugas</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 0;
            foreach ($data_request as $item_data) {
                $id_encrypt = $this->encrypt->encode($item_data->id);
                $no++;
                echo '
                        <tr>
                            <td>' . $no . '</td>
                            <td>' . $item_data->code . '</td>
                            <td>' . $item_data->date . '</td>
                            <td>' . $item_data->name . '</td>
                            <td>' . $item_data->count_item . '</td>
                            <td>Rp.' . number_format($item_data->grandtotal, 0, '.', '.') . '</td>
                            <td>' . $item_data->note . '</td>
                            <td>' . $item_data->supplier_name . '</td>
                            <td>' . $item_data->created_date . '</td>
                            <td>' . $item_data->user_name . '</td>
                            <td>
                                <a href="' . Modules::run('helper/create_url', 'receive/add_receive?data=' . urlencode($id_encrypt)) . '" class="btn btn-default"><i class="fa fa-send"></i> Lakukan Penerimaan</a>
                            </td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>