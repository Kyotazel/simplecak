<?php
$get_data_detail = $this->db->query("select a.*,
b.code as code_sales,
b.grand_total,
b.ppn,
b.ppn_price,
b.pph,
b.pph_price,
b.grand_total_sales,
b.payment,
b.rest_payment,
b.date,
b.credit_status,
b.credit_price,
c.name,
c.code as product_code,
c.qty_unit,
c.code as code_product,
d.name as unit_name,
f.name as member_name,
h.code AS credit_code,
h.price AS credit_price_current,
h.note AS credit_note,
h.deadline AS credit_deadline,
i.name AS conversion_name,
i.qty AS conversion_qty
from tb_detail_sales a 
left join tb_sales b on a.id_sales = b.id
left join tb_product c on a.id_product = c.id 
left join tb_unit d on c.id_unit = d.id 
left join mst_customer f on b.id_member = f.id
left join tb_credit h on b.code = h.id_transaction 
left join tb_product_has_conversion i on a.id_conversion_unit = i.id 
where a.id_sales = '$id_sales'
")->result();
// print_r($get_data_detail[0]);
// exit;
$date_order_explode = explode('-', $get_data_detail[0]->date);
$date_order_html = $date_order_explode[2] . '-' . $date_order_explode[1] . '-' . $date_order_explode[0];
//status
$status_credit  = $get_data_detail[0]->credit_status ? '<label class="label label-success">TRUE</label>' : '-';
$label_credit   = $get_data_detail[0]->credit_price > 0 ? 'Rp.' . number_format($get_data_detail[0]->credit_price, 0, '.', '.') : '-';
//create html form
$html_delivery = '';
// if ($get_data_detail[0]->delivery_status) {
//     $html_delivery = '
//                         <div class="col-md-6 p-10  border-radius-5 pull-right">
//                             <h3>Alamat Tujuan:</h3>
//                             <table class="table">
//                                 <tr>
//                                     <td width="200px">Kode Pengiriman</td>
//                                     <td width="10px">:</td>
//                                     <td><b>' . $get_data_detail[0]->delivery_code . '</b></td>
//                                 </tr>
//                                 <tr>
//                                     <td>Kepada</td>
//                                     <td>:</td>
//                                     <td><b>' . $get_data_detail[0]->receiver . '</b></td>
//                                 </tr>
//                                 <tr>
//                                     <td>Tujuan</td>
//                                     <td>:</td>
//                                     <td><b>' . $get_data_detail[0]->kec . '&nbsp;-&nbsp;' . $get_data_detail[0]->city . '&nbsp;-&nbsp;' . $get_data_detail[0]->province . '</b></td>
//                                 </tr>
//                                 <tr>
//                                     <td>Alamat Lengkap</td>
//                                     <td>:</td>
//                                     <td><b>' . $get_data_detail[0]->address . '</b></td>
//                                 </tr>
//                             </table>
//                         </div>
//                     ';
// }

$html_credit = '';
// if ($get_data_detail[0]->credit_status) {
//     $html_credit = '
//     <div class="col-md-6 p-10 border border-radius-5 mb-10 pull-right">
//     <h3>Keterangan Piutang:</h3>
//     <table class="table">
//     <tr>
//     <td width="200px">Kode Piutang</td>
//     <td width="10px">:</td>
//     <td><b>' . $get_data_detail[0]->credit_code . '</b></td>
//     </tr>
//     <tr>
//     <td>Penganggung Jawab</td>
//     <td>:</td>
//     <td><b>' . $get_data_detail[0]->responsible_name . '</b></td>
//     </tr>
//     <tr>
//     <td>Jumlah Piutang</td>
//     <td>:</td>
//     <td><b>Rp.' . number_format($get_data_detail[0]->credit_price_current, 0, '.', '.') . '</b></td>
//     </tr>
//     <tr>
//     <td>Jatuh Tempo</td>
//     <td>:</td>
//     <td><b>' . $get_data_detail[0]->credit_deadline . '</b></td>
//     </tr>
//     <tr>
//     <td>Catatan</td>
//     <td>:</td>
//     <td><b>' . $get_data_detail[0]->credit_note . '</b></td>
//     </tr>
//     </table>
//     </div>
//     ';
// }

//get data here
$no = 0;
$html_tr = '';
foreach ($get_data_detail as $data_detail) {
    $no++;
    //count base qty buy 

    if ($data_detail->conversion_name) {
        $label_qty_buy = '';
        $unit_value = $data_detail->qty % $data_detail->conversion_qty;
        $conversion_value = ($data_detail->qty - $unit_value) / $data_detail->conversion_qty;

        if ($conversion_value > 0) {
            $conversion_qty = $data_detail->conversion_qty * $conversion_value;
            $label_qty_buy .= $conversion_value . ' ' . $data_detail->conversion_name . '( ' . $conversion_qty . ' ' . $data_detail->unit_name . ')' . '<br>';
        }
        if ($unit_value > 0) {
            $label_qty_buy .= $unit_value . ' ' . $data_detail->unit_name;
        }
    } else {
        $label_qty_buy = $data_detail->qty . ' ' . $data_detail->unit_name;
    }


    $label_discount = '';
    if ($data_detail->price_discount > 0) {
        $discount_per_item = $data_detail->price_discount / $data_detail->qty;
        if ($data_detail->discount > 0) {
            $label_discount = $data_detail->discount . ' %  / ' . $data_detail->unit_name . ' <br> ( <del>Rp.' . number_format($data_detail->price_discount, 0, '.', '.') . '</del> )';
        } else {
            $label_discount = 'Rp.' . number_format($discount_per_item, 0, '.', '.') . '/ ' . $data_detail->unit_name . ' <br> ( <del>Rp.' . number_format($data_detail->price_discount, 0, '.', '.') . '</del> )';
        }
    }

    $html_tr .= '
   <tr>
       <td>' . $no . '</td>	
       <td>' . $data_detail->product_code . '</td>
       <td>' . $data_detail->name . '</td>
       <td>' . number_format($data_detail->price, 0, '.', '.') . '</td>
       <td>' . $label_qty_buy . '</td>
       <td>' . $label_discount . '</td>
       <td>' . number_format($data_detail->total_price, 0, '.', '.') . '</td>
   </tr>
   ';
} //end foreach
$html_tr .= '
    <tr>
            <td colspan="6" class="text-right">Total Pembelian</td>
            <td>: <b>Rp.' . number_format($get_data_detail[0]->grand_total_sales, 0, '.', '.') . '</b></td>
    </tr>
    <tr>
        <td colspan="6" class="text-right">PPN ' . $get_data_detail[0]->ppn . ' %</td>
        <td>: <b> Rp.' . number_format($get_data_detail[0]->ppn_price, 0, '.', '.') . '</b></td>
    </tr>
    <tr>
        <td colspan="6" class="text-right">PPH ' . $get_data_detail[0]->pph . ' %</td>
        <td>: <b> Rp.' . number_format($get_data_detail[0]->pph_price, 0, '.', '.') . '</b></td>
    </tr>
    <tr>
        <td colspan="6" class="text-right">GRAND TOTAL</td>
        <td>: <b> Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</b></td>
    </tr>
';

$data_html = '
<table class="table">
   <thead>
       <tr>
           <th>No</th>
           <th>Kode</th>
           <th>nama</th>
           <th>Harga Satuan</th>
           <th>Jumlah Beli</th>
           <th>Diskon</th>
           <th>Total</th>
       </tr>
   </thead>
   <tbody>' . $html_tr . '</tbody>
</table>
<hr>
' . $html_delivery . $html_credit;
echo $data_html;
