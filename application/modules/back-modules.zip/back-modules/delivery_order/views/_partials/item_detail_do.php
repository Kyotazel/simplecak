<?php
$btn_payment = '';




$array_status = [
    0 => '<label class="label label-warning">Menunggu Konfirmasi</label>',
    1 => '<label class="label label-success">SO Diproses</label>',
    2 => '<label class="label label-default">SO Dikirim</label>',
    3 => '<label class="label label-default">SO Diterima</label>',
    4 => '<label class="label label-default">SO Dibatalakan</label>'
];
$array_ongkir_type = [
    1 => 'LOCO',
    2 => 'FRANCO'
];

$btn_act = '';

$data['id_sales'] = $data_so->id;
$html_detail = $this->load->view('_partials/item_detail_so', $data, true);

?>

<div style="width:100%;" class="col-12 html_detail_so_<?= $data_so->id; ?>">
    <input type="hidden" name="so_choose[]" value="<?= $data_so->id; ?>">
    <div class="row">
        <h2 class="mb-3 col-6">
            <span class="badge badge-light tx-20 badge-pill">NOMOR SO : <strong><?= $data_so->code; ?></strong></span>
        </h2>
        <div class="col-6 row">
        </div>
    </div>
    <div class="row" style="align-items:baseline;">
        <div class="col-md-12 row mb-2">
            <div class="row col-12 border-dashed">
                <div class="col">
                    <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_so->customer_name; ?></b></div>
                    <p class="tx-12">
                        <?= $data_so->customer_address; ?>
                    </p>
                </div>
                <div class="col-auto align-self-center ">
                    <div class="feature mt-0 mb-0">
                        <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 row">
            <div class="row text-right">
                <div class="p-2 border-dashed col-4">
                    <small>Sub Total (SI) : &nbsp;</small>
                    <h5 class=" m-0 p-0 total_po">Rp.<?= number_format($data_so->grand_total, 0, '.', '.'); ?></h5>
                </div>
                <div class="p-2 border-dashed col-4">
                    <small>Total Diskon : &nbsp;</small>
                    <h5 class="m-0 p-0 total_po">Rp.<?= number_format($data_so->total_discount_product, 0, '.', '.'); ?></h5>
                </div>
                <div class="p-2 border-dashed col-4">
                    <small>Pajak PPN : &nbsp;</small>
                    <h5 class="m-0 p-0 total_po">Rp.<?= number_format($data_so->ppn_price, 0, '.', '.'); ?></h5>
                </div>
                <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                    <div class="mt-1 d-block text-left" style="width:200px;">
                        <small>Status : </small> <span class="badge badge-light"><?= $array_status[$data_so->status]; ?></span>
                    </div>
                    <small style="width:200px;">Tanggal SO : <b><?= Modules::run('helper/change_date', $data_so->date, '-'); ?></b></small>
                    &nbsp;&nbsp;|&nbsp;&nbsp;
                    <small style="width:100px;">Total SO : &nbsp;</small>
                    <h3 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_so->grand_total_sales, 0, '.', '.'); ?></h3>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12 mt-3">

    <div class="text-right">
        <?= $btn_act; ?>
        <a data-toggle="collapse" class="btn btn btn-light btn-rounded" href="#collapse_<?= $data_so->id; ?>" role="button" aria-expanded="true" aria-controls="collapseExample"><i class="fa fa-tv"></i> Detail</a>
    </div>
</div>
<div class="col-12 collapse" id="collapse_<?= $data_so->id; ?>">
    <?= $html_detail; ?>
</div>