<?php

$html_note_reject = '';

$array_status = [
    0 => '<label class="label label-warning">Menunggu Penerimaan</label>',
    1 => '<label class="label label-success">Telah Diterima</label>',
    2 => '<label class="label label-default">Dibatalkan</label>'
];
?>
<style>
    .datepicker {
        z-index: 1000 !important;
    }
</style>
<form class="form-do">
    <div class="row">

        <div class="col-8 d-flex">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">Detail SO : </h3>
                </div>
                <div class="card-body">
                    <h2 class="mb-3"><span class="badge badge-light tx-20 badge-pill">Daftar SO Pengiriman</span> : <strong></strong> <a href="javascript:void(0)" class="btn btn-primary btn_choose_so btn-rounded"><i class="fa fa-file"></i> Pilih SO</a> </h2>
                    <div class="row">
                        <div class="col-md-12 ">
                            <table class="table table-bordered table_detail_request">
                                <thead>
                                    <tr>
                                        <th>SO</th>
                                    </tr>
                                </thead>
                                <tbody class="view_so_choose">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">Keterangan Pengiriman :</h3>
                </div>
                <div class="card-body">
                    <h2 class="mb-3 badge badge-light tx-20 badge-pill">NOMOR DO : <strong><?= $code_so; ?></strong></h2>
                    <div class="row">
                        <div class="form-group col-12">
                            <label for="">Pilih Driver</label>
                            <select name="id_employee" class="form-control chosen" id="">
                                <?php
                                foreach ($option_employee as $item_employee) {
                                    echo '
                                            <option value="' . $item_employee->id . '">' . $item_employee->name . '</option>
                                        ';
                                }
                                ?>
                            </select>
                            <span class="help-block notif_id_employee"></span>
                        </div>
                        <div class="form-group col-12">
                            <label for="">Pilih Transportasi</label>
                            <select name="id_transport" class="form-control chosen" id="">
                                <?php
                                foreach ($option_transport as $item_data) {
                                    echo '
                                            <option value="' . $item_data->id . '">' . $item_data->plat_nomor . ' - ' . $item_data->nama_transport . '</option>
                                        ';
                                }
                                ?>
                            </select>
                            <span class="help-block notif_id_employee"></span>
                        </div>
                        <div class="form-group col-12">
                            <label for="">Pilih Tanggal Kirim</label>
                            <input class="form-control bg-white datepicker" name="date" readonly>
                        </div>
                        <div class="col-12 text-right">
                            <button class="btn btn-primary-gradient bt_save btn-rounded">
                                simpan Pengiriman
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>


</form>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>