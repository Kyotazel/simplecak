<div class="table-responsive">
    <table class="table t-shadow table_request" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>SO</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_so as $item_po) {
                $counter++;

                $data['data_so'] = $item_po;
                $html_detail = $this->load->view('_partials/item_so', $data, TRUE);
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $html_detail . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>