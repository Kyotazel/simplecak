<div class="table-responsive">
    <table class="table t-shadow table_request" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>DO</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_so as $item_po) {
                $counter++;


                $array_query = [
                    'select' => '
                        SUM(DISTINCT tb_sales.grand_total_sales) AS total_invoice,
                        COUNT(DISTINCT tb_sales.id) AS count_invoice,
                        COUNT(DISTINCT tb_sales.id_member) AS count_customer
                    ',
                    'from' => 'tb_sales',
                    'join' => [
                        'mst_customer,tb_sales.id_member = mst_customer.id,left',
                        'tb_delivery_has_so,tb_sales.id = tb_delivery_has_so.id_sales,left'
                    ],
                    'where' => [
                        'tb_delivery_has_so.id_delivery' => $item_po->id
                    ],
                    'order_by' => 'tb_sales.id, DESC'
                ];
                $get_data = Modules::run('database/get', $array_query)->row();

                $data['resume_so'] = $get_data;
                $data['data_do'] = $item_po;
                $html_detail = $this->load->view('_partials/item_do', $data, TRUE);
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $html_detail . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>