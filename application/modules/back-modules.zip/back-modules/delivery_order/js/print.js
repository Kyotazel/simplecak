var url_controller_print = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/print_data/';

$(document).ready(function () {
    
});


$(document).on('click', '.btn_print_manifest', function () { 
    showLoading();
    var data_print = $(this).data('print');
    $.ajax({
        url: url_controller_print+'print_manifest/?token='+_token_user,
        type: "POST",
        data: {'data':data_print},
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            $('.html_respon_print').html(data.html_respon);
            $('#modal_print').modal('show');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
	});//end ajax
});


// $(document).on('click', '.btn_pdf_loading_list', function () { 
//     showLoading();
//     var data_print = $(this).data('print');
//     $.ajax({
//         url: url_controller_print+'print_loading_list/?token='+_token_user,
//         type: "POST",
//         data: {'data':data_print},
//         dataType :"JSON",
//         success: function (data) {
//             hideLoading();
//             $('.html_respon_print').html(data.html_respon);
//             $('#modal_print').modal('show');
//         },
//         error:function(jqXHR, textStatus, errorThrown)
//         {
//             hideLoading();
//         }
// 	});//end ajax
// });

// $(document).on('click', '.btn_pdf_ro', function () { 
//     showLoading();
//     var data_print = $(this).data('print');
//     $.ajax({
//         url: url_controller_print+'print_ro/?token='+_token_user,
//         type: "POST",
//         data: {'data':data_print},
//         dataType :"JSON",
//         success: function (data) {
//             hideLoading();
//             $('.html_respon_print').html(data.html_respon);
//             $('#modal_print').modal('show');
//         },
//         error:function(jqXHR, textStatus, errorThrown)
//         {
//             hideLoading();
//         }
// 	});//end ajax
// });


// $(document).on('click', '.btn_pdf_bol', function () { 
//     showLoading();
//     var data_print = $(this).data('print');
//     $.ajax({
//         url: url_controller_print+'print_pdf_bol/?token='+_token_user,
//         type: "POST",
//         data: {'data':data_print},
//         dataType :"JSON",
//         success: function (data) {
//             hideLoading();
//             $('.html_respon_print').html(data.html_respon);
//             $('#modal_print').modal('show');
//         },
//         error:function(jqXHR, textStatus, errorThrown)
//         {
//             hideLoading();
//         }
// 	});//end ajax
// });
