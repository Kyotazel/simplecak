<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Print_data extends BackendController
{
    var $module_name        = 'transaction';
    var $module_directory   = 'transaction';
    var $module_js          = ['transaction', 'print'];
    var $app_data           = [];


    public function __construct()
    {

        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function print_manifest()
    {
        $data_print = $this->input->post('data');
        $this->session->set_userdata('print_data', $data_print);
        $url_data = Modules::run('helper/create_url', 'delivery_order/print_data/export_pdf_manifest');
        $html_iframe = '
            <div class="col-12 p-0">
                <iframe name="iframe1" style="width: 100%;min-height:900px;border-style: none" src="' . $url_data . '"></iframe>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_iframe]);
    }
    public function export_pdf_manifest()
    {
        error_reporting(0);
        ob_clean();

        $data_print =  json_decode($this->encrypt->decode($this->session->userdata('print_data')), TRUE);

        $data['company'] = [
            'name' => Modules::run('database/find', 'app_setting', ['field' => 'company_name'])->row()->value,
            'company_tagline' => Modules::run('database/find', 'app_setting', ['field' => 'company_tagline'])->row()->value,
            'company_email' => Modules::run('database/find', 'app_setting', ['field' => 'company_email'])->row()->value,
            'company_number_phone' => Modules::run('database/find', 'app_setting', ['field' => 'company_number_phone'])->row()->value,
            'company_address' => Modules::run('database/find', 'app_setting', ['field' => 'company_address'])->row()->value,
            'company_logo' => Modules::run('database/find', 'app_setting', ['field' => 'company_logo'])->row()->value
        ];

        $data['delivery_order'] = $data_print['data_do'];
        $data['list_SO'] = $data_print['list_so'];
        $data['data_print'] =  $data_print;
        ob_start();
        $this->load->view('print/pdf_manifest', $data);
        //print_r($html);
        //exit;
        $html = ob_get_contents();
        ob_end_clean();
        require_once('../assets/plugin/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en', true, 'UTF-8', array(2, 2, 2, 2));
        $pdf->WriteHTML($html);
        $pdf->Output('PO' . $data['data_request']['code'] . '.pdf', 'R');
    }

    public function print_loading_list()
    {
        $data_print = $this->input->post('data');
        $this->session->set_userdata('print_data', $data_print);
        $url_data = Modules::run('helper/create_url', 'transaction/print_data/export_loading_list');
        $html_iframe = '
            <div class="col-12 p-0">
                <iframe name="iframe1" style="width: 100%;min-height:900px;border-style: none" src="' . $url_data . '"></iframe>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_iframe]);
    }
    public function export_loading_list()
    {
        error_reporting(0);
        ob_clean();

        $data['category_teus']   = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'category_teus'])->row()->value, TRUE);
        $data['category_countainer']  = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'countainer_category'])->row()->value, TRUE);
        $data['booking_status']  = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'booking_status'])->row()->value, TRUE);
        $data['category_service']     = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'category_service'])->row()->value, TRUE);
        $data['category_unit_lc']     = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'category_unit_lc'])->row()->value, TRUE);

        $data_print =  json_decode($this->encrypt->decode($this->session->userdata('print_data')), TRUE);
        $data['list_countainer'] = $data_print['list_container'];
        $data['empty_container'] = $data_print['empty_container'];
        $data['voyage'] = $data_print['voyage'];
        $data['company'] = $data_print['company'];

        $data['data_print'] =  $data_print;
        //print_r($data['data_profile']);
        //exit;
        ob_start();
        $this->load->view('print/pdf_loading_list', $data);
        //print_r($html);
        //exit;
        $html = ob_get_contents();
        ob_end_clean();
        require_once('../assets/plugin/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', [210, 330], 'en', true, 'UTF-8', array(2, 2, 2, 2));
        $pdf->WriteHTML($html);
        $pdf->Output('LOADING_LIST - ' .  $data['voyage']['code'] . '.pdf', 'R');
    }

    public function print_ro()
    {
        $data_print = $this->input->post('data');
        $this->session->set_userdata('print_data', $data_print);
        $url_data = Modules::run('helper/create_url', 'transaction/print_data/export_pdf_ro');
        $html_iframe = '
            <div class="col-12 p-0">
                <iframe name="iframe1" style="width: 100%;min-height:900px;border-style: none" src="' . $url_data . '"></iframe>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_iframe]);
    }
    public function export_pdf_ro()
    {
        error_reporting(0);
        ob_clean();

        $data['category_teus']   = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'category_teus'])->row()->value, TRUE);
        $data['category_countainer']  = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'countainer_category'])->row()->value, TRUE);

        $data_print =  json_decode($this->encrypt->decode($this->session->userdata('print_data')), TRUE);
        $data['data_detail'] = $data_print['data_detail'];
        $data['voyage'] = $data_print['voyage'];
        $data['company'] = $data_print['company'];
        $data['data_ro'] = $data_print['data_ro'];

        $data['data_print'] =  $data_print;
        //print_r($data['data_profile']);
        //exit;
        ob_start();
        $this->load->view('print/pdf_ro', $data);
        //print_r($html);
        //exit;
        $html = ob_get_contents();
        ob_end_clean();
        require_once('../assets/plugin/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en', true, 'UTF-8', array(5, 5, 5, 5));
        $pdf->WriteHTML($html);
        $pdf->Output('RO-' .  $data['data_ro']['ro_number'] . '.pdf', 'R');
    }

    public function print_pdf_bol()
    {
        $data_print = $this->input->post('data');
        $this->session->set_userdata('print_data', $data_print);
        $url_data = Modules::run('helper/create_url', 'transaction/print_data/export_bol');
        $html_iframe = '
            <div class="col-12 p-0">
                <iframe name="iframe1" style="width: 100%;min-height:900px;border-style: none" src="' . $url_data . '"></iframe>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_iframe]);
    }
    public function export_bol()
    {
        error_reporting(0);
        ob_clean();

        $data['category_teus']   = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'category_teus'])->row()->value, TRUE);
        $data['category_countainer']  = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'countainer_category'])->row()->value, TRUE);
        $data['booking_status']  = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'booking_status'])->row()->value, TRUE);
        $data['category_service']     = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'category_service'])->row()->value, TRUE);
        $data['category_unit_lc']     = json_decode(Modules::run('database/find', 'app_module_setting', ['field' => 'category_unit_lc'])->row()->value, TRUE);

        $data_print =  json_decode($this->encrypt->decode($this->session->userdata('print_data')), TRUE);

        $data['data_bs'] = $data_print['data_bs'];
        $data['data_countainer_bs'] = $data_print['data_countainer_bs'];
        $data['company'] = $data_print['company'];

        $data['data_print'] =  $data_print;
        ob_start();
        $this->load->view('print/pdf_bol', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('../assets/plugin/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', [210, 330], 'en', true, 'UTF-8', array(2, 2, 2, 2));
        $pdf->WriteHTML($html);
        $pdf->Output('LOADING_LIST - ' .  $data['voyage']['code'] . '.pdf', 'R');
    }
}
