<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Delivery_order extends BackendController
{
    var $module_name        = 'delivery_order';
    var $module_directory   = 'delivery_order';
    var $module_js          = ['delivery_order', 'print'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "SALES INVOICE";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = 'tb_delivery';
        $simbol = 'DO';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function list_data_request()
    {

        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $id_customer = $this->input->post('id_customer');
        $status = $this->input->post('status');



        $array_where = [];
        $array_where_in = [];

        // $array_where['tb_sales.status'] = 0;

        if ($date_from) {
            $array_where['tb_delivery.date >='] = $date_from;
        }
        if ($date_to) {
            $array_where['tb_delivery.date <='] = $date_to;
        }
        // if ($id_customer) {
        //     $array_where_in['tb_sales.id_member'] = $id_customer;
        // }
        // if ($status) {
        //     $array_where['tb_sales.status'] = $status;
        // }


        $array_query = [
            'select' => '
                tb_delivery.*,
                mst_employee.name AS employee_name,
                mst_transport.plat_nomor,
                mst_transport.nama_transport AS transport_name
            ',
            'from' => 'tb_delivery',
            'join' => [
                'mst_employee, tb_delivery.id_driver = mst_employee.id, left',
                'mst_transport, tb_delivery.id_transport = mst_transport.id, left'
            ]
        ];

        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }

        $get_data = Modules::run('database/get', $array_query)->result();

        $data_po['data_so'] = $get_data;
        $html_po = $this->load->view('view_search_result', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }

    public function confirm_so()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $status = $this->input->post('status');
        $confirm = 2;


        if ($status == 1) {
            $confirm = 1;

            $get_so = Modules::run('database/find', 'tb_sales', ['id' => $id])->row();
            $member = Modules::run('database/find', 'mst_customer', ['id' => $get_so->id_member])->row();

            $deadline = date('Y-m-d', strtotime('+' . $member->top_nota . ' days', strtotime($get_so->date))); //operasi penjumlahan tanggal sebanyak 6 hari

            $desc = 'Piutang SO : ' . $get_so->code;
            $array_insert = [
                'id_transaction' => $id,
                'invoice_code' => $get_so->code,
                'description' => $desc,
                'price' => $get_so->grand_total_sales,
                'rest_credit' => $get_so->grand_total_sales,
                'date' => $get_so->date,
                'deadline' => $deadline,
                'id_customer' => $get_so->id_member
            ];
            Modules::run('credit/insert_credit', $array_insert);
        }
        $array_update = [
            'is_confirm' => $confirm,
            'status' => $status
        ];
        Modules::run('database/update', 'tb_sales', ['id' => $id], $array_update);
        echo json_encode(['status' => TRUE]);
    }

    public function add()
    {
        $this->app_data['option_employee'] = Modules::run('database/find', 'mst_employee', ['isDeleted' => 'N'])->result();
        $this->app_data['option_transport'] = Modules::run('database/find', ' mst_transport', ['isDeleted' => 'N'])->result();
        $this->app_data['tax_ppn'] = Modules::run('helper/get_setting', 'ppn_tax')->value;
        $this->app_data['code_so'] = $this->get_code();

        $this->app_data['page_title'] = "Tambah Data Pengadaan";
        $this->app_data['view_file'] = 'add_delivery';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_so()
    {
        $list_exception = $this->input->post('list_so');
        $array_query = [
            'select' => '
                tb_sales.*,
                mst_customer.code AS customer_code,
                mst_customer.name AS customer_name,
                mst_customer.address AS customer_address,
            ',
            'from' => 'tb_sales',
            'join' => [
                'mst_customer,tb_sales.id_member = mst_customer.id,left'
            ],
            'where' => [
                'tb_sales.status' => 1
            ],
            'group_by' => 'tb_sales.id',
            'order_by' => 'tb_sales.id, DESC'
        ];

        if (!empty($list_exception)) {
            $array_query['where_not_in']['tb_sales.id'] = $list_exception;
        }

        $get_data = Modules::run('database/get', $array_query)->result();

        $data_po['data_so'] = $get_data;
        $html_po = $this->load->view('view_list_so', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }

    public function get_supplier()
    {
        Modules::run('security/is_ajax');
        $get_supplier = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        $data['data_supplier'] = $get_supplier;
        $html_respon = $this->load->view('list_supplier', $data, TRUE);
        echo json_encode(['html_respon' => $html_respon, 'status' => TRUE]);
    }

    public function get_current_supplier()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_supplier = Modules::run('database/find', 'mst_vendor', ['id' => $id])->row();
        $html_respon = '
            <div class="row col-12 border-dashed">
                <div class="col">
                    <div class=" mt-2 mb-2 text-primary"><b>' . $get_supplier->name . '</b></div>
                    <p class="tx-12">' . $get_supplier->address . '</p>
                </div>
                <div class="col-auto align-self-center ">
                    <div class="feature mt-0 mb-0">
                        <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                    </div>
                </div>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }


    public function save()
    {

        $so_choose = $this->input->post('so_choose');
        $code = $this->get_code();
        $id_employee   = $this->input->post('id_employee');
        $id_transport   = $this->input->post('id_transport');
        $date = Modules::run('helper/change_date', $this->input->post('date'), '-');

        $array_insert = [
            'code' => $code,
            'id_driver' => $id_employee,
            'id_transport' => $id_transport,
            'date' => $date
        ];
        Modules::run('database/insert', 'tb_delivery', $array_insert);
        $main_data = Modules::run('database/find', 'tb_delivery', ['code' => $code])->row();
        foreach ($so_choose as $id_so) {
            $array_insert = [
                'id_delivery' => $main_data->id,
                'id_sales' => $id_so
            ];
            Modules::run('database/insert', 'tb_delivery_has_so', $array_insert);
            //update status so
            $array_update_so = ['status' => 2];
            Modules::run('database/update', 'tb_sales', ['id' => $id_so], $array_update_so);
        }

        $array_respon = [
            'status' => TRUE,
            'id' => urlencode($this->encrypt->encode($main_data->id))
        ];
        echo json_encode($array_respon);
    }

    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $array_query = [
            'select' => '
                tb_delivery.*,
                mst_employee.name AS employee_name,
                mst_transport.plat_nomor,
                mst_transport.nama_transport AS transport_name
            ',
            'from' => 'tb_delivery',
            'join' => [
                'mst_employee, tb_delivery.id_driver = mst_employee.id, left',
                'mst_transport, tb_delivery.id_transport = mst_transport.id, left'
            ],
            'where' => [
                'tb_delivery.id' => $id
            ]
        ];
        $main_data = Modules::run('database/get', $array_query)->row();

        $this->app_data['data_do'] = $main_data;
        $this->app_data['list_so'] = Modules::run('database/find', 'tb_delivery_has_so', ['id_delivery' => $id])->result();

        $this->app_data['page_title'] = "Detail Delivery Order";
        $this->app_data['view_file'] = 'detail_do';
        echo Modules::run('template/main_layout', $this->app_data);
    }
}
