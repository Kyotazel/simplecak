<div class="row">
    <div class="col-md-12 row">
        <div class="col-8">
            <h4 class="m-0 p-0">Daftar Biaya Operasional Voyage</h4>
            <small class="text-muted">Silahkan drag item untuk merubah urutan</small>
        </div>
        <div class="col-4 text-right ">
            <a href="javascript:void(0)" class="btn btn-primary-gradient btn_add_pattern_cost"><i class="fa fa-plus-circle"></i> Tambah Data</a>
        </div>
        <div class="template_cost col-12 mt-2">
        </div>
    </div>
</div>



<div class="modal fade" tabindex="-1" id="modal_form_cost">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <form id="form-data-cost">
                <div class="modal-body">
                    <div class="row">
                        <div class="form-group col-12">
                            <label>Nama Biaya</label>
                            <input type="text" class="form-control" name="name" />
                            <span class="help-block notif_name text-danger"></span>
                        </div>
                        <div class="form-group col-12">
                            <label>Barang Vendor</label>
                            <select name="category_stuff" class="form-control" id="">
                                <option value="">Pilih Barang</option>
                                <?php
                                foreach ($vendor_stuff as $item_stuff) {
                                    echo '
                                            <option value="' . $item_stuff->id . '">' . $item_stuff->name . '</option>
                                        ';
                                }
                                ?>
                            </select>
                            <span class="help-block notif_category_stuff text-danger"></span>
                        </div>
                        <div class="form-group col-12">
                            <label>Vendor</label>
                            <select name="vendor" class="form-control" id="">

                            </select>
                            <span class="help-block notif_vendor text-danger"></span>
                        </div>
                        <div class="form-group col-12">
                            <label>Biaya</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Rp.</span>
                                </div>
                                <input class="form-control form-control-lg bg-white rupiah" name="price" placeholder="" min="0" type="text">
                            </div>
                            <span class="help-block notif_price text-danger"></span>
                        </div>
                        <div class="form-group col-12">
                            <label>Deskripsi</label>
                            <textarea name="description" class="form-control" rows="5"></textarea>
                            <span class="help-block notif_description text-danger"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success btn_save_cost"><i class="fa fa-save"></i> Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>