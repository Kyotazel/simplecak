<div class="row">
    <div class="col-md-12 row">
        <div class="col-8">
            <h4 class="m-0 p-0">Daftar Operasional Awak Kapal</h4>
            <small class="text-muted">Silahkan drag item untuk merubah urutan</small>
        </div>
        <div class="col-4 text-right">
            <a href="javascript:void(0)" class="btn btn-primary-gradient btn_add_pattern_employee"><i class="fa fa-plus-circle"></i> Tambah Data</a>
        </div>
        <div class="template_employee mt-2 col-12"></div>
    </div>
</div>


<div class="modal fade" tabindex="-1" id="modal_form_employee">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <form id="form-data-employee">
                <div class="modal-body">
                    <div class="row">
                        <div class="form-group col-8">
                            <label>Nama Jabatan</label>
                            <input type="text" class="form-control" name="name" />
                            <span class="help-block notif_name text-danger"></span>
                        </div>
                        <div class="form-group col-4">
                            <label>QTY</label>
                            <input type="number" class="form-control" name="qty" />
                            <span class="help-block notif_qty text-danger"></span>
                        </div>
                        <div class="form-group col-12">
                            <label>Upah Bonus</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Rp.</span>
                                </div>
                                <input class="form-control form-control-lg bg-white rupiah" name="bonus_fee" placeholder="" min="0" type="text">
                            </div>
                            <span class="help-block notif_bonus_fee text-danger"></span>
                        </div>
                        <div class="form-group col-12">
                            <label>Upah Lembur</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Rp.</span>
                                </div>
                                <input class="form-control form-control-lg bg-white rupiah" name="overtime_fee" placeholder="" min="0" type="text">
                            </div>
                            <span class="help-block notif_overtime_fee text-danger"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success btn_save_employee"><i class="fa fa-save"></i> Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>