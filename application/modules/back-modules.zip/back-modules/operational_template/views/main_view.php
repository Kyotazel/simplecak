<div class="card">
    <div class="card-header">
        <h3 class="card-title m-0">Template Operasional</h3>
    </div>
    <div class="card-body">
        <div class="panel panel-primary tabs-style-2">
            <div class=" tab-menu-heading">
                <div class="tabs-menu1">
                    <!-- Tabs -->
                    <ul class="nav panel-tabs main-nav-line">
                        <li><a href="#tab4" class="nav-link active" data-toggle="tab"><i class="fa fa-users"></i> Operasional Awak Kapal</a></li>
                        <li><a href="#tab5" class="nav-link" data-toggle="tab"> <i class="fa fa-minus"></i> Biaya Operasional Voyage </a></li>
                        <!-- <li><a href="#tab6" class="nav-link" data-toggle="tab">Tab 03</a></li> -->
                    </ul>
                </div>
            </div>
            <div class="panel-body tabs-menu-body main-content-body-right border">
                <div class="tab-content">
                    <div class="tab-pane active" id="tab4">

                        <div class="col-8">

                        </div>

                        <?php
                        $data['cek'] = '';
                        $this->load->view('view_template_employee', $data);
                        ?>
                    </div>
                    <div class="tab-pane " id="tab5">
                        <?php
                        $this->load->view('view_template_cost', $data);
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>