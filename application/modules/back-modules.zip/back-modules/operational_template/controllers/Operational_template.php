<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Operational_template extends BackendController
{
    var $module_name        = 'operational_template';
    var $module_directory   = 'operational_template';
    var $module_js          = ['operational_template'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['vendor_stuff'] = Modules::run('database/find', 'mst_vendor_stuff', ['isDeleted' => 'N'])->result();
        $this->app_data['page_title'] = "Template operasional";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data_pattern_employee()
    {
        Modules::run('security/is_ajax');

        $html_item = '';
        $get_data = Modules::run('database/get', ['from' => 'tb_pattern_operational_employee', 'where' => ['isDeleted' => 'N'], 'order_by' => 'sort'])->result();
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $btn_delete     = Modules::run('security/delete_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-danger btn_delete_employee"><i class="las la-trash"></i> </a>');
            $btn_edit     = Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-info btn_edit_employee"><i class="las la-pen"></i> </a>');

            $html_item .= '
                <li class="main-menu usd_item_drag border-dashed" data-id="' . $data_table->id . '">
                    <div class="menu-container row ">
                        <div for="" class="col-md-2 slide mb-0 d-flex align-items-center">
                            <h4>' . $data_table->name . '</h4>
                        </div>
                        <div for="" class="col-md-2 slide mb-0 ">
                            <small>Jumlah Pegawai :</small>
                            <label for="" class="p-2 border-dashed d-block">
                            ' . $data_table->qty . ' pegawai
                            </label>
                        </div>
                        <div class="col-md-6 d-flex">
                            <div class="" style="width:50%;">
                                <small>Upah Lembur (Per voyage) :</small>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Rp.</span>
                                    </div>
                                    <input class="form-control bg-white rupiah" value="' . number_format($data_table->overtime_fee, 0, '.', '.') . '" readonly="">
                                </div>
                            </div>
                            <div class="" style="width:50%;">
                                <small class="ml-2">Upah Bonus (Per voyage)</small>
                                <div class="input-group ml-2">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Rp.</span>
                                    </div>
                                    <input class="form-control bg-white rupiah" value="' . number_format($data_table->bonus_fee, 0, '.', '.') . '" readonly="">
                                </div>
                            </div>
                        </div>
                        <nav class="contact-info col-md-2 text-right d-flex align-items-center">
                            ' . $btn_edit . $btn_delete . '
                        </nav>
                    </div>
                </li>
            ';
        }
        if (empty($get_data)) {
            $html_item = '
                <li class="main-menu usd_item_drag p-2" style="border:none;">
                    <div class="col-12 text-center">
                        <div class="plan-card text-center">
                            <i class="fas fa-info plan-icon text-primary"></i>
                            <h6 class="text-muted mt-2">Belum ada data template operasional</h6>
                        </div>
                    </div>
                </li>
            ';
        }
        $html_respon = '
        <ul class="list-group usd_list">
            ' . $html_item . '
        </ul>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function update_sort_employee()
    {
        Modules::run('security/is_ajax');
        $list_id = $this->input->post('list_id');
        $counter = 0;
        foreach ($list_id as $id_item) {
            $counter++;
            Modules::run('database/update', 'tb_pattern_operational_employee', ['id' => $id_item], ['sort' => $counter]);
        }
        echo json_encode(['status' => TRUE]);
    }


    private function validate_save()
    {
        Modules::run('security/is_ajax');
        $data = array();

        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->input->post('id');
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        } else {
            if (strlen($this->input->post('name')) < 5) {
                $data['error_string'][] = 'min 5 karakter';
                $data['inputerror'][] = 'name';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('qty') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'qty';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_pattern_employee()
    {
        $this->validate_save();
        $name    = $this->input->post('name');
        $qty   = $this->input->post('qty');
        $bonus_fee    = str_replace('.', '', $this->input->post('bonus_fee'));
        $overtime_fee    = str_replace('.', '', $this->input->post('overtime_fee'));
        $get_max_sort = $this->db->select('MAX(sort) AS max')->get('tb_pattern_operational_employee')->row();
        $next_sort = $get_max_sort->max + 1;

        $array_insert = [
            'name' => $name,
            'qty' => $qty,
            'bonus_fee' => $bonus_fee,
            'overtime_fee' => $overtime_fee,
            'sort' => $next_sort,
            'isDeleted' => 'N',
            'created_by' => $this->session->userdata('us_id')
        ];
        Modules::run('database/insert', 'tb_pattern_operational_employee', $array_insert);
        echo json_encode(['status' => true]);
    }

    public function get_data_employee()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_data = Modules::run('database/find', 'tb_pattern_operational_employee', ['id' => $id])->row();
        echo json_encode($get_data);
    }

    public function update_pattern_employee()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $name    = $this->input->post('name');
        $qty   = $this->input->post('qty');
        $bonus_fee    = str_replace('.', '', $this->input->post('bonus_fee'));
        $overtime_fee    = str_replace('.', '', $this->input->post('overtime_fee'));

        $array_update = [
            'name' => $name,
            'qty' => $qty,
            'bonus_fee' => $bonus_fee,
            'overtime_fee' => $overtime_fee
        ];
        Modules::run('database/update', 'tb_pattern_operational_employee', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }

    public function delete_data_pattern_employee()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));

        $array_update = ['isDeleted' => 'Y'];
        Modules::run('database/update', 'tb_pattern_operational_employee', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }


    public function list_data_pattern_cost()
    {
        Modules::run('security/is_ajax');

        $array_query = [
            'select' => '
                tb_pattern_operational_cost.*,
                mst_vendor.name As vendor_name,
                mst_vendor_stuff.name AS stuff_name
            ',
            'from' => 'tb_pattern_operational_cost',
            'join' => [
                'mst_vendor, tb_pattern_operational_cost.id_vendor=mst_vendor.id, left',
                'mst_vendor_stuff, tb_pattern_operational_cost.id_vendor_stuff = mst_vendor_stuff.id, left'
            ],
            'where' => [
                'tb_pattern_operational_cost.isDeleted' => 'N'
            ],
            'order_by' => 'tb_pattern_operational_cost.sort'
        ];
        $get_data = Modules::run('database/get', $array_query)->result();

        $no = 0;
        $data = [];
        $html_item = '';
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $btn_delete     = Modules::run('security/delete_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-danger btn_delete_cost"><i class="las la-trash"></i> </a>');
            $btn_edit     = Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-info btn_edit_cost"><i class="las la-pen"></i> </a>');

            $html_item .= '
                <li class="main-menu usd_item_drag2 border-dashed" data-id="' . $data_table->id . '">
                    <div class="menu-container row ">
                        <div for="" class="col-md-2 slide mb-0 d-flex align-items-center">
                            <h4>' . $data_table->name . '</h4>
                        </div>
                        <div for="" class="col-md-2 slide mb-0 ">
                            <small><i class="fa fa-user"></i> Vendor :</small>
                            <label for="" class="p-2 border-dashed d-block">
                            ' . $data_table->vendor_name . '
                            </label>
                        </div>
                        <div for="" class="col-md-3 slide mb-0 ">
                            <small><i class="fa fa-user"></i> Barang Vendor :</small>
                            <label for="" class="p-2 border-dashed d-block">
                            ' . $data_table->stuff_name . '
                            </label>
                        </div>
                        <div class="col-md-3 d-flex">
                            <div class="" >
                                <small>Biaya :</small>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Rp.</span>
                                    </div>
                                    <input class="form-control bg-white rupiah" value="' . number_format($data_table->price, 0, '.', '.') . '" readonly="">
                                </div>
                            </div>
                        </div>
                        <nav class="contact-info col-md-2 text-right d-flex align-items-center">
                            ' . $btn_edit . $btn_delete . '
                        </nav>
                    </div>
                </li>
            ';
        }
        if (empty($get_data)) {
            $html_item = '
                <li class="main-menu usd_item_drag p-2" style="border:none;">
                    <div class="col-12 text-center">
                        <div class="plan-card text-center">
                            <i class="fas fa-info plan-icon text-primary"></i>
                            <h6 class="text-muted mt-2">Belum ada data template operasional</h6>
                        </div>
                    </div>
                </li>
            ';
        }

        $html_respon = '
        <ul class="list-group usd_list2">
            ' . $html_item . '
        </ul>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function update_sort_cost()
    {
        Modules::run('security/is_ajax');
        $list_id = $this->input->post('list_id');

        $counter = 0;
        foreach ($list_id as $id_item) {
            $counter++;
            Modules::run('database/update', 'tb_pattern_operational_cost', ['id' => $id_item], ['sort' => $counter]);
        }
        echo json_encode(['status' => TRUE]);
    }

    public function get_vendor($id_stuff, $selected_id = 0)
    {
        Modules::run('security/is_ajax');
        // $id_stuff = $this->input->post('id');

        $array_query = [
            'from' => 'mst_vendor_has_stuff',
            'join' => [
                'mst_vendor, mst_vendor_has_stuff.id_vendor = mst_vendor.id, left'
            ],
            'where' => [
                'mst_vendor_has_stuff.id_vendor_stuff' => $id_stuff,
                'mst_vendor.isDeleted' => 'N'
            ],
            'group_by' => 'mst_vendor.id'
        ];
        $get_data = Modules::run('database/get', $array_query)->result();
        $html_respon = ' <option value="">Pilih Vendor</option> ';
        foreach ($get_data as $item_data) {
            $selected = $item_data->id == $selected_id ? 'selected' : '';
            $html_respon .= '
                <option ' . $selected . ' value="' . $item_data->id . '">' . $item_data->name . '</option>
            ';
        }
        if ($selected_id > 0) {
            return $html_respon;
        } else {
            $array_respon = ['status' => TRUE, 'html_respon' => $html_respon];
            echo json_encode($array_respon);
        }
    }

    private function validate_save_cost()
    {
        Modules::run('security/is_ajax');
        $data = array();

        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->input->post('id');
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        } else {
            if (strlen($this->input->post('name')) < 5) {
                $data['error_string'][] = 'min 5 karakter';
                $data['inputerror'][] = 'name';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('category_stuff') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'category_stuff';
            $data['status'] = FALSE;
        }
        if ($this->input->post('vendor') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'vendor';
            $data['status'] = FALSE;
        }
        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }
        if ($this->input->post('description') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'description';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_pattern_cost()
    {

        $this->validate_save_cost();
        $name    = $this->input->post('name');
        $category_stuff   = $this->input->post('category_stuff');
        $vendor   = $this->input->post('vendor');
        $price    = str_replace('.', '', $this->input->post('price'));
        $description   = $this->input->post('description');
        $get_max_sort = $this->db->select('MAX(sort) AS max')->get('tb_pattern_operational_cost')->row();
        $next_sort = $get_max_sort->max + 1;

        $array_insert = [
            'name' => $name,
            'id_vendor_stuff' => $category_stuff,
            'id_vendor' => $vendor,
            'price' => $price,
            'description' => $description,
            'sort' => $next_sort,
            'isDeleted' => 'N',
            'created_by' => $this->session->userdata('us_id')
        ];
        Modules::run('database/insert', 'tb_pattern_operational_cost', $array_insert);
        echo json_encode(['status' => true]);
    }

    public function get_data_cost()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_data = Modules::run('database/find', 'tb_pattern_operational_cost', ['id' => $id])->row();
        $get_option_vendor = $this->get_vendor($get_data->id_vendor_stuff, $get_data->id_vendor);
        $get_data->vendor_option = $get_option_vendor;
        echo json_encode($get_data);
    }

    public function update_pattern_cost()
    {
        Modules::run('security/is_ajax');
        $this->validate_save_cost();
        $id = $this->input->post('id');
        $name    = $this->input->post('name');
        $category_stuff   = $this->input->post('category_stuff');
        $vendor   = $this->input->post('vendor');
        $price    = str_replace('.', '', $this->input->post('price'));
        $description   = $this->input->post('description');

        $array_update = [
            'name' => $name,
            'id_vendor_stuff' => $category_stuff,
            'id_vendor' => $vendor,
            'price' => $price,
            'description' => $description
        ];
        Modules::run('database/update', 'tb_pattern_operational_cost', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }

    public function delete_data_pattern_cost()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));

        $array_update = ['isDeleted' => 'Y'];
        Modules::run('database/update', 'tb_pattern_operational_cost', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }

    // public function print()
    // {
    //     $encrypt_data_search = $this->encrypt->decode($this->input->post('search'));
    //     $data_search = json_decode($encrypt_data_search);


    //     $vendor_stuff    = $data_search->vendor_stuff;

    //     $array_query = [
    //         'select' => '
    //             mst_vendor.*,
    //             GROUP_CONCAT(mst_vendor_stuff.name) AS vendor_stuff_list
    //         ',
    //         'from' => 'mst_vendor',
    //         'where' => ['mst_vendor.isDeleted' => 'N'],
    //         'join' => [
    //             'mst_vendor_has_stuff, mst_vendor.id = mst_vendor_has_stuff.id_vendor, left',
    //             'mst_vendor_stuff, mst_vendor_has_stuff.id_vendor_stuff = mst_vendor_stuff.id , left'
    //         ],
    //         'order_by' => 'id, DESC',
    //         'group_by' => 'mst_vendor.id'
    //     ];
    //     if (!empty($vendor_stuff)) {
    //         $array_query['where_in']['mst_vendor_has_stuff.id_vendor_stuff'] = $vendor_stuff;
    //     }
    //     $get_data = Modules::run('database/get', $array_query)->result();

    //     if ($this->input->post('print_excel')) {
    //         $this->export_excel($get_data);
    //     }
    //     if ($this->input->post('print_pdf')) {
    //         $this->export_pdf($get_data);
    //     }
    // }

    // public function export_excel($data)
    // {
    //     error_reporting(0);
    //     $this->load->library("PHPExcel");
    //     //membuat objek
    //     $objPHPExcel = new PHPExcel();
    //     $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
    //     $sheet = $objPHPExcel->getActiveSheet();
    //     //set column 
    //     $sheet->getColumnDimension('A')->setWidth('5');
    //     $sheet->getColumnDimension('B')->setWidth('30');
    //     $sheet->getColumnDimension('C')->setWidth('30');
    //     $sheet->getColumnDimension('D')->setWidth('30');
    //     $sheet->getColumnDimension('E')->setWidth('0');
    //     $sheet->getColumnDimension('F')->setWidth('50');

    //     //bold style 
    //     $sheet->getStyle("A1:F2")->getFont()->setBold(true);
    //     $styleThinBlackBorderOutline = array(
    //         'borders' => array(
    //             'allborders' => array(
    //                 'style' => PHPExcel_Style_Border::BORDER_THIN,
    //                 'color' => array('argb' => 'FF000000'),
    //             ),
    //         ),
    //     );

    //     // //marge and center
    //     $sheet->mergeCells('A1:F2');
    //     $sheet->getStyle('A1:F2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    //     $sheet->getStyle('A1:F2')->getFont()->setSize(18);
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA KONTAINER');
    //     $sheet->getStyle('A3:F3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

    //     //sheet table resume 
    //     $from = "A3"; // or any value
    //     $to = "F3"; // or any value
    //     $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'NAMA');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'EMAIL');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'NO.TELP');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'ALAMAT');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'JENIS BARANG');
    //     $sheet_number_resume = 3;
    //     $no = 0;

    //     $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)
    //         ->applyFromArray($styleThinBlackBorderOutline);
    //     $sheet->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)->applyFromArray(
    //         array(
    //             'fill' => array(
    //                 'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //                 'color' => array('rgb' => '366092')
    //             ),
    //             'font'  => array(
    //                 'bold'  => true,
    //                 'color' => array('rgb' => 'FFFFFF'),
    //                 'size'  => 12
    //             )
    //         )
    //     );

    //     foreach ($data as $data_table) {

    //         $get_stuff = explode(',', $data_table->vendor_stuff_list);

    //         $sheet_number_resume++;
    //         $no++;
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->name);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_table->email);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->number_phone);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->address);

    //         $sheet_before = $sheet_number_resume;
    //         $sheet_detail = $sheet_number_resume;
    //         foreach ($get_stuff as $item_stuff) {
    //             if ($item_stuff == '') {
    //                 continue;
    //             }
    //             $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_detail, '- ' . $item_stuff);
    //             $sheet_detail++;
    //         }
    //         $sheet_number_resume = $sheet_number_resume + count($get_stuff);
    //         $sheet->mergeCells('A' . $sheet_before . ':A' . ($sheet_number_resume - 1));
    //         $sheet->mergeCells('B' . $sheet_before . ':B' . ($sheet_number_resume - 1));
    //         $sheet->mergeCells('C' . $sheet_before . ':C' . ($sheet_number_resume - 1));
    //         $sheet->mergeCells('D' . $sheet_before . ':D' . ($sheet_number_resume - 1));
    //         $sheet->mergeCells('E' . $sheet_before . ':E' . ($sheet_number_resume - 1));
    //         $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_before . ':F' . ($sheet_number_resume - 1))
    //             ->applyFromArray($styleThinBlackBorderOutline);
    //         $sheet_number_resume -= 1;
    //     }
    //     //Set Title
    //     $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
    //     //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
    //     $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    //     //Header
    //     header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    //     header("Cache-Control: no-store, no-cache, must-revalidate");
    //     header("Cache-Control: post-check=0, pre-check=0", false);
    //     header("Pragma: no-cache");
    //     header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    //     //Nama File
    //     header('Content-Disposition: attachment;filename="LAPORAN DATA VENDOR PER ' . date('d-m-Y') . '.xlsx"');
    //     //Download
    //     $objWriter->save("php://output");
    // }

    // public function export_pdf($data_vendor)
    // {
    //     error_reporting(0);
    //     ob_clean();
    //     $data['data_vendor'] = $data_vendor;
    //     ob_start();
    //     $this->load->view('pdf_vendor', $data);
    //     $html = ob_get_contents();
    //     ob_end_clean();
    //     require_once('../assets/plugin/html2pdf/html2pdf.class.php');
    //     $pdf = new HTML2PDF('L', 'A4', 'en', true, 'UTF-8', array(5, 5, 5, 5));
    //     $pdf->WriteHTML($html);
    //     $pdf->Output('LAPORAN DATA KONTAINER PER -' . date('d-m-Y') . '.pdf', 'D');
    // }
}
