var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var id_use = 0;
var table_employee;
var table_cost;

$(document).ready(function () {
    // var type = $('.container_list').data('type');
    // list_data();
    // $('#category_vendor').chosen();
    // $('#vendor_stuff_search').chosen();
    // $('#modal_form_cost').modal('show');

    // table_employee = $('#table_data_employee').DataTable({
    //     "ajax": {
    //         "url": url_controller+"list_data_pattern_employee"+'/?token='+_token_user,
    //         "type": "POST",
    //     }
    // });
    list_data_pattern_employee();

    // table_cost = $('#table_data_cost').DataTable({
    //     "ajax": {
    //         "url": url_controller+"list_data_pattern_cost"+'/?token='+_token_user,
    //         "type": "POST",
    //     }
    // });
    list_data_pattern_cost();

});

function reload_table(){
    table_employee.ajax.reload(null, false); //reload datatable ajax
    table_cost.ajax.reload(null,false); //reload datatable ajax 
}

function list_data_pattern_employee() {
    showLoading();
    var formData = new FormData($('.form-search')[0]);
    $.ajax({
        url: url_controller+'list_data_pattern_employee/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            $('.template_employee').html(data.html_respon);
            list = $('.usd_list');
            list.sortable({
                tolerance: "pointer",
                items: ".usd_item_drag",
                connectWith: '.usd_list',
                placeholder: 'placeholder',
                update: function (event, ui) {
                    update_sort_employee(ui.item);
                }
            });
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            swal.close();
            $('.btn_search').button('reset');
        }
	});//end ajax
}

function list_data_pattern_cost() {
    showLoading();
    var formData = new FormData($('.form-search')[0]);
    $.ajax({
        url: url_controller+'list_data_pattern_cost/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            $('.template_cost').html(data.html_respon);
            list = $('.usd_list2');
            list.sortable({
                tolerance: "pointer",
                items: ".usd_item_drag2",
                connectWith: '.usd_list2',
                placeholder: 'placeholder',
                update: function (event, ui) {
                    update_sort_cost(ui.item);
                }
            });
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            swal.close();
            $('.btn_search').button('reset');
        }
	});//end ajax
}

function update_sort_employee(selector) {
    var id_current = selector.data('id');
    var list_id = [];
    selector.closest('.usd_list').children('.usd_item_drag').each(function () {
        var id_slider = $(this).data('id');
        list_id.push(id_slider)
    });
    console.log(list_id);
    

    $.ajax({
        url: url_controller+'update_sort_employee'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'list_id':list_id},
        success: function(data){
            if(data.status){
                notif({
                    msg: "<b>Sukses :</b> Data berhasil diupdate",
                    type: "success"
                });
            } 
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
        }
    
    });//end ajax
}

function update_sort_cost(selector) {
    var id_current = selector.data('id');
    var list_id = [];
    selector.closest('.usd_list2').children('.usd_item_drag2').each(function () {
        var id_slider = $(this).data('id');
        list_id.push(id_slider)
    });
    console.log(list_id);
    

    $.ajax({
        url: url_controller+'update_sort_cost'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'list_id':list_id},
        success: function(data){
            if(data.status){
                notif({
                    msg: "<b>Sukses :</b> Data berhasil diupdate",
                    type: "success"
                });
            } 
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
        }
    
    });//end ajax
}

$('.btn_add_pattern_employee').click(function () {
    save_method = 'add';
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    $('#form-data-employee')[0].reset();
	$('.modal-title').text('TAMBAH DATA');
    $('#modal_form_employee').modal('show');
});

$('.btn_save_employee').click(function (e) {
    e.preventDefault();
    showLoading();
    // swal.showLoading();
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    // save_method = $(this).data('method');
	  //defined form
    var formData = new FormData($('#form-data-employee')[0]);
    var url;
    if(save_method=='add'){
        url = 'save_pattern_employee';
    }else{
        url = 'update_pattern_employee';
        formData.append('id', id_use);
    }
    $.ajax({
        url: url_controller+url+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                notif({
                    msg: "<b>Sukses :</b> Data berhasil disimpan",
                    type: "success"
                });
                $('#modal_form_employee').modal('hide');
                list_data_pattern_employee();
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    $('.notif_'+data.inputerror[i]).parent().addClass('has-danger');
                    $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                }
            }
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
	});//end ajax
});

$(document).on('click', '.btn_edit_employee', function () {
    // swal.showLoading();
    showLoading();
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    id = $(this).data('id');
    save_method = 'update';
    $.ajax({
        url: url_controller+'get_data_employee'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            hideLoading();
            id_use = data.id;
            $('[name="name"]').val(data.name);
            $('[name="qty"]').val(data.qty);
            $('[name="bonus_fee"]').val(money_function(data.bonus_fee.toString()));
            $('[name="overtime_fee"]').val(money_function(data.overtime_fee.toString()));
            $('#modal_form_employee').modal('show');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }

    });//end ajax

});


$(document).on('click', '.btn_delete_employee', function () {
    id = $(this).data('id');
    swal({
        title: "Apakah anda yakin?",
        text: "data akan dihapus!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: url_controller+'delete_data_pattern_employee'+'/?token='+_token_user,
                type: "POST",
                dataType: "JSON",
                data:{'id':id},
                success: function(data){
                    if (data.status) {
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil dihapus",
                            type: "success"
                        });
                        list_data_pattern_employee();
                    } 
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                }

            });//end ajax
        }
    });
    
});



// ========================================================================== COST =============================================================
$('.btn_add_pattern_cost').click(function () {
    save_method = 'add';
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    $('#form-data-cost')[0].reset();
	$('.modal-title').text('TAMBAH DATA');
    $('#modal_form_cost').modal('show');
});

$(document).on('change', '[name="category_stuff"]', function () { 
    var id = $(this).val();
    $.ajax({
        url: url_controller+'get_vendor/'+id+'?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function(data){
            if (data.status) {
                $('[name="vendor"]').html(data.html_respon);
            } 
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
        }

    });//end ajax
});

$('.btn_save_cost').click(function (e) {
    e.preventDefault();
    showLoading();
    // swal.showLoading();
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    // save_method = $(this).data('method');
	  //defined form
    var formData = new FormData($('#form-data-cost')[0]);
    var url;
    if(save_method=='add'){
        url = 'save_pattern_cost';
    }else{
        url = 'update_pattern_cost';
        formData.append('id', id_use);
    }
    $.ajax({
        url: url_controller+url+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                notif({
                    msg: "<b>Sukses :</b> Data berhasil disimpan",
                    type: "success"
                });
                $('#modal_form_cost').modal('hide');
                list_data_pattern_cost();
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    $('.notif_'+data.inputerror[i]).parent().addClass('has-danger');
                    $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                }
            }
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
	});//end ajax
});

$(document).on('click', '.btn_edit_cost', function () {
    // swal.showLoading();
    showLoading();
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    id = $(this).data('id');
    save_method = 'update';
    $.ajax({
        url: url_controller+'get_data_cost'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            hideLoading();
            id_use = data.id;
            $('[name="name"]').val(data.name);
            $('[name="category_stuff"]').val(data.id_vendor_stuff);
            $('[name="vendor"]').html(data.vendor_option);
            $('[name="price"]').val(money_function(data.price.toString()));
            $('[name="description"]').val(data.description);
            $('#modal_form_cost').modal('show');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
    });//end ajax
});

$(document).on('click', '.btn_delete_cost', function () {
    id = $(this).data('id');
    swal({
        title: "Apakah anda yakin?",
        text: "data akan dihapus!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: url_controller+'delete_data_pattern_cost'+'/?token='+_token_user,
                type: "POST",
                dataType: "JSON",
                data:{'id':id},
                success: function(data){
                    if (data.status) {
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil dihapus",
                            type: "success"
                        });
                        list_data_pattern_cost();
                    } 
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                }

            });//end ajax
        }
    });
    
});



$(document).on('keyup', '.rupiah', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});


function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

if (ribuan) {
    separator = sisa ? '.' : '';
    rupiah += separator + ribuan.join('.');
}

rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}
