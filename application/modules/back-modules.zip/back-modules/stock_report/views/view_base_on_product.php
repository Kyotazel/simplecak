<?php
$this->load->view('data_stock_report/form');
?>

<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <h4>Hasil Pencarian</h4>
    </div>
    <div class="card-body">
        <div class="col-md-6">
            <table style="width:100%;" style="font-size:20px;">
                <?php
                echo '
                    <tr>
                      <td width="50px">Range</td>
                      <td width="10px">:</td>
                      <td>' . $array_range['date_from'] . '&nbsp;&nbsp;s/d&nbsp;&nbsp;' . $array_range['date_to'] . '</td>
                    </tr>
                    <tr>
                      <td width="50px">Barang</td>
                      <td width="10px" align="center">:</td>
                      <td>' . $array_range['product'] . '</td>
                    </tr>
                  ';

                ?>
            </table>
        </div>
        <div class="col-md-6">
            <form method="POST" action="<?php echo base_url('stock_report/print_base_on_product'); ?>">
                <input type="hidden" name="array_range" value="<?php echo str_replace('"', "'", json_encode($array_range)); ?>">
                <input type="hidden" name="last_query" value="<?php echo $this->db->last_query(); ?>">
                <button type="submit" class="btn btn-default pull-right"><i class="fa fa-print"></i> cetak Laporan</button>
            </form>
        </div>
        <span class="clearfix"></span>
        <hr>
        <table class="table table_list table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Tanggal</th>
                    <th>Stok Lama</th>
                    <th>Sisa</th>
                    <th>Stok Baru</th>
                    <th>Harga / unit</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // print_r($data_result);
                function count_stock_result($stock, $qty_unit, $unit_name, $base_unit_name)
                {
                    if ($stock != false) {
                        $base_unit_val = $stock % $qty_unit;
                        //count unit val
                        $unit_val     = ($stock - $base_unit_val) / $qty_unit;
                        // stock current
                        $stock_current = '';
                        if ($unit_val > 0) {
                            $stock_current .= number_format($unit_val, 0, '.', '.') . '&nbsp;' . $unit_name;
                        }
                        if ($base_unit_val > 0) {
                            if ($unit_val > 0) {
                                $stock_current .= '<br>';
                            }
                            $stock_current .= number_format($base_unit_val, 0, '.', '.') . '&nbsp;' . $base_unit_name;
                        }
                    } else {
                        $stock_current = '0&nbsp;' . $base_unit_name;
                    }

                    return $stock_current;
                }

                //array date
                $array_data_post = array();


                $no = 0;
                $total_price_buy = 0;
                foreach ($data_result as $data_table) {
                    $total_price_buy += $data_table->total_price;
                    $no++;
                    //create date 
                    $date_explode = explode('-', $data_table->date);
                    $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];

                    echo '
                          <tr>
                            <td>' . $no . '</td>
                            <td>' . $data_table->code . '</td>
                            <td>' . $date_html . '</td>
                            <td>' . number_format($data_table->old_stock, 0, '.', '.') . '&nbsp;' . $data_table->unit_name . '</td>
                            <td>' . count_stock_result($data_table->margin, $data_table->qty_unit, $data_table->unit_name, $data_table->base_unit_name) . '</td>
                            <td>' . number_format($data_table->new_stock, 0, '.', '.') . '&nbsp;' . $data_table->unit_name . '</td>
                            <td>' . number_format($data_table->unit_price) . '/&nbsp;' . $data_table->unit_name . '</td>
                            <td>' . number_format($data_table->total_price, 0, '.', '.') . '</td>
                          </tr>
                        ';
                }

                echo '
                        <tfoot>
                          <tr>
                            <td colspan="7" align="center"><b>TOTAL UANG PEMBELIAN</b></td>
                             <td > <b>Rp ' . number_format($total_price_buy, 0, '.', '.') . '</b></td>
                          </tr>

                        </tfoot>
                       ';

                ?>
        </table>

    </div>
    <!-- /.box-body -->

</div>
<script type="text/javascript" src="<?php echo base_url('assets/assets_admin/'); ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>function_toast.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('.table_list').DataTable();
</script>