<?php
$this->load->view('data_stock_report/form');
?>


<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <h4>Hasil Pencarian</h4>
    </div>
    <div class="card-body">
        <div class="col-md-6">
            <table style="width:100%;" style="font-size:20px;">
                <?php
                echo '
                		<tr>
		                  <td width="50px">Range</td>
		                  <td width="10px" align="center">:</td>
		                  <td>' . $array_range['date_from'] . '&nbsp;&nbsp;s/d&nbsp;&nbsp;' . $array_range['date_to'] . '</td>
		                </tr>
		                <tr>
		                  <td width="50px">Barang</td>
		                  <td width="5px">:</td>
		                  <td>' . $array_range['product'] . '</td>
		                </tr>
                	';

                ?>
            </table>
        </div>
        <div class="col-md-6">
            <form method="POST" action="<?php echo base_url('stock_report/print_all_item'); ?>">
                <input type="hidden" name="array_range" value="<?php echo str_replace('"', "'", json_encode($array_range)) ?>">
                <input type="hidden" name="last_query" value="<?php //echo $this->db->last_query(); 
                                                                ?>">
                <button type="submit" class="btn btn-default pull-right"><i class="fa fa-print"></i> cetak Laporan</button>
            </form>
        </div>
        <span class="clearfix"></span>
        <hr>
        <table class="table table_list table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Stok</th>
                    <th>tanggal</th>
                    <th>Total Item</th>
                    <th>Grand Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 0;
                $grand_total_money_buy = 0;
                foreach ($data_result as $data_table) {
                    $no++;
                    $grand_total_money_buy += $data_table->grand_total;
                    $date_explode = explode('-', $data_table->date);
                    $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
                    echo '
                          <tr>
                            <td>' . $no . '</td>
                            <td>' . $data_table->code . '</td>
                            <td>' . $date_html . '</td>
                            <td>' . number_format($data_table->counter_result, 0, '.', '.') . ' Barang' . '</td>
                            <td>Rp ' . number_format($data_table->grand_total, 0, '.', '.') . '</td>
                            <td><a class="btn btn-sm btn-primary-gradient" href="javascript:void(0)" title="detail stok opname" onclick="detail_stock(' . "'" . $data_table->id . "'" . ')"><i class="fa fa-list"></i> Detail</a></td>
                          </tr>
                          ';
                }
                echo '
                        <tfoot>
                         <tr>
                           <td align="center" colspan="4"><b>TOTAL UANG PEMBELIAN</b></td>
                           <td colspan="2"><b>Rp ' . number_format($grand_total_money_buy, 0, '.', '.') . ' </b></td>
                        </tr>
                       </tfoot>
                        ';

                ?>

        </table>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal_detail" data-backdrop="static">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="content-html-detail"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<script type="text/javascript" src="<?php echo base_url('assets/assets_admin/'); ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>function_toast.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets/assets_admin/'); ?>js_use/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('.table_list').DataTable();
    var controller = 'stock/';
    var base_url = '<?php echo base_url(); ?>' + controller;

    function detail_stock(id) {
        // $('#modal_detail').modal('show');

        showLoading();
        $('.modal-title').text('DETAIL STOK');
        // var formData = new FormData($('.form-stock-choosen')[0]);
        $.ajax({
            url: base_url + "get_detail_stock/" + id,
            type: "GET",
            dataType: "HTML",
            success: function(data) {
                hideLoading();
                $('.content-html-detail').html(data);
                // $('.table_detail').DataTable();
                // notif_success('cek');
                $('#modal_detail').modal('show');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('error process');
                showLoading();
            }
        });
    }
</script>