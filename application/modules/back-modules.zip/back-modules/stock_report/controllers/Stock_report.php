<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stock_report extends CI_Controller
{
    var $location = 'data_stock_report/';
    var $module_name = 'stock_report';

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }


    public function index()
    {
        $data['data_member'] = $this->db->query("select id,name from tb_member order by id DESC")->result();
        $data['data_product'] = $this->db->query("select id,name from tb_product order by id DESC")->result();
        $data['tagline_page'] = "LAPORAN STOK / PEMBELIAN";
        $data['view_file'] = $this->location . 'form';
        $this->load->view('template/media_admin', $data);
    }

    public function change_to_sql_date($date)
    {
        $date_explode = explode('-', $date);
        $date_sql = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        return $date_sql;
    }

    public function validate_input()
    {
        $status = false;
        $date_from     = $this->input->post('date_from');
        $date_to     = $this->input->post('date_to');

        if ($date_from == '') {
            $this->session->set_flashdata('error_date_from', 'harus disi dulu');
            $status = TRUE;
        }
        if ($date_to == '') {
            $this->session->set_flashdata('error_date_to', 'harus disi dulu');
            $status = TRUE;
        }

        if ($status == TRUE) {
            redirect(base_url($this->module_name));
        }
    }

    public function get_report()
    {
        $data['data_member'] = $this->db->query("select id,name from tb_member order by id DESC")->result();
        $data['data_product'] = $this->db->query("select id,name from tb_product order by id DESC")->result();
        $this->validate_input();
        $date_from     = $this->change_to_sql_date($this->input->post('date_from'));
        $date_to     = $this->change_to_sql_date($this->input->post('date_to'));
        // $id_member 	= $this->input->post('id_member');
        $id_product = $this->input->post('id_product');
        $range_product = 'SEMUA BARANG';
        $range_member = 'SEMUA MEMBER';

        $where_form = " where a.date BETWEEN '$date_from' AND '$date_to' ";

        if (!empty($id_product)) {
            // $where_form.=" AND a.id_product = '$id_product' ";
            //get dta product choosen
            $get_data_product_choosen = $this->db->query("select name from tb_product where id = '$id_product' ")->row_array();
            $range_product = $get_data_product_choosen['name'];
            $where_form .= " AND b.id_product ='$id_product' ";

            //get data


        }
        $array_range = array(
            'date_from' => $this->input->post('date_from'),
            'date_to' => $this->input->post('date_to'),
            'product' => $range_product,
            'id_product' => $id_product
        );

        $get_data = $this->db->query("SELECT a.*, COUNT(b.id) as counter_result,
									  b.old_stock,
									  b.margin,
									  b.new_stock,
									  b.unit_price,
									  b.total_price,
									  c.name,
									  c.qty_unit,
									  d.name as unit_name,
									  e.name as base_unit_name
									   FROM tb_stock_opname a 
									LEFT JOIN tb_detail_stock_opname b on  b.id_stock_opname = a.id 
									LEFT JOIN tb_product c on b.id_product = c.id 
									LEFT JOIN tb_unit d on c.id_unit = d.id 
									LEFT JOIN tb_base_unit e on d.id_base_unit = e.id
									" . $where_form . " GROUP by a.id order by a.id ")->result();
        $data['array_range'] = $array_range;
        $data['data_result'] = $get_data;

        // $data['data_result'] = $get_data_report;
        if (!empty($id_product)) {
            $view_file = 'view_base_on_product';
        } else {
            $view_file = 'view_all_item';
        }
        $data['tagline_page'] = "LAPORAN STOK / PEMBELIAN";
        $data['view_file'] = $this->location . $view_file;
        $this->load->view('template/media_admin', $data);
    }

    public function print_all_item()
    {
        // if($this->input->post('last_query')==''){
        // 	redirect(base_url('sales_report'));
        // }
        ob_clean();
        $data_range = json_decode(str_replace("'", '"', $this->input->post('array_range')));
        $date_from_sql     = $this->change_to_sql_date($data_range->date_from);
        $date_to_sql     = $this->change_to_sql_date($data_range->date_to);

        $get_data = $this->db->query("
									select a.*,b.code,b.date as date_stock,b.grand_total,c.code as code_product,c.name as product_name,c.qty_unit,d.name as unit_name,e.name as base_unit_name
										from tb_detail_stock_opname a
										left join tb_stock_opname b on a.id_stock_opname = b.id 
										left join tb_product c on a.id_product = c.id
										left join tb_unit d on c.id_unit = d.id 
										left join tb_base_unit e on d.id_base_unit = e.id
                                        WHERE b.date BETWEEN '$date_from_sql' AND '$date_to_sql'
									")->result();
        $data['data_result'] = $get_data;
        $data['data_range'] = json_decode(str_replace("'", '"', $this->input->post('array_range')));

        ob_start();
        $this->load->view('print_stock/print_all_item', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('./assets/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en');
        $pdf->WriteHTML($html);
        $pdf->Output('laporan pembelian (' . date('d-m-Y') . ').pdf', 'D');
    }

    public function print_base_on_product()
    {
        // if($this->input->post('last_query')==''){
        // 	redirect(base_url('sales_report'));
        // }
        $query = $this->input->post('last_query');
        $get_data = $this->db->query($query)->result();
        $data['data_range'] =  $this->input->post('array_range');
        ob_clean();
        $data['data_result'] = $get_data;
        ob_start();
        $this->load->view('print_stock/print_base_on_product', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('./assets/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en');
        $pdf->WriteHTML($html);
        $pdf->Output('laporan pembelian (' . date('d-m-Y') . ').pdf', 'D');
    }
}
