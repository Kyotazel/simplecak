var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/maintenance';
var save_method;
var id_use;
$(document).ready(function () {
    // $('#modal-form').modal('show');
    // alert('ok');
    
});



$(document).on('click', '.btn_repair_stock', function (e) {
	e.preventDefault();
	Swal.fire({
		title: 'Apakah anda yakin?',
		text: "data ini akan Disimpan",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Ya, Lanjutkan',
		cancelButtonText: 'Batal'
	}).then((result) => {
		if (result.value) {
			$(this).button('loading');
            var data_current = $(this).data('jsonstock');
            var store_update = $(this).data('storeupdate');
            var warehouse_update = $(this).data('warehouseupdate');
			$.ajax({
				url: controller+'/do_repair_stock',
				type: "POST",
				data: {'data_current':data_current,'store_update':store_update,'warehouse_update':warehouse_update},
				dataType :"JSON",
				success: function(data){
					if (data.status) {
						Swal.fire(
							'BERHASIL!',
							'Data Berhasil Disimpan!',
							'success'
                        );
                        location.reload();
					} else{
						for (var i = 0; i < data.inputerror.length; i++)
						{
							$('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
							$('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
						}
					}
					$('.btn_repair_stock').button('reset');
				},
				error:function(jqXHR, textStatus, errorThrown)
				{
					$('.btn_repair_stock').button('reset');
					alert_error('something wrong');
				}
            });//end ajax
		}
	})
});


$('.btn-delete-cashier').click(function (e) {
    e.preventDefault();
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan Dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $(this).button('loading');
            $('.form-group').removeClass('has-error');
            $('.help-block').empty();
            //defined form
            var formData = new FormData($('.form-delete')[0]);
	   
            $.ajax({
                url: controller + '/delete_cashier_report',
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    if (data.status) {
                        Swal.fire(
                            'BERHASIL!',
                            'Data Berhasil Dihapus!',
                            'success'
                        );
                        location.reload();
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                            $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                        }
                    }
                    $('.btn-delete-cashier').button('reset');
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $('.btn-delete-cashier').button('reset');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    });
})


$('.btn-recapitulation').click(function (e) {
    e.preventDefault();
    $(this).button('loading');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-recapitulation')[0]);

    $.ajax({
        url: controller + '/get_recapitulation',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon_recapitulation').html(data.html_respon);
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            $('.btn-recapitulation').button('reset');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn-recapitulation').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_save_recapitulation', function (e) {
    e.preventDefault();
    $(this).button('loading');
    var data_accounting = $(this).data('accounting');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('.modal-title').text('KOREKSI KEMBALI');
    //defined form
    var formData = new FormData($('.form-payment')[0]);
    formData.append('data_accounting', data_accounting);
    $.ajax({
        url: controller + '/review_payment',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('#modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            $('.btn_save_recapitulation').button('reset');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_save_recapitulation').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
});

    // $('.btn_save_recapitulation').click(function (e) {
    //     e.preventDefault();
    //     $(this).button('loading');
    //     var data_accounting = $(this).data('accounting');
    //     $('.form-group').removeClass('has-error');
    //     $('.help-block').empty();
    //     $('.modal-title').text('KOREKSI KEMBALI');
    //     //defined form
    //     var formData = new FormData($('.form-payment')[0]);
    //     formData.append('data_accounting', data_accounting);
    //     $.ajax({
    //         url: controller + '/review_payment',
    //         type: "POST",
    //         data: formData,
    //         contentType: false,
    //         processData: false,
    //         dataType: "JSON",
    //         success: function (data) {
    //             if (data.status) {
    //                 $('#modal-form').modal('show');
    //                 $('.html_respon_modal').html(data.html_respon);
    //             } else {
    //                 for (var i = 0; i < data.inputerror.length; i++) {
    //                     $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
    //                     $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
    //                 }
    //             }
    //             $('.btn_save').button('reset');
    //         },
    //         error: function (jqXHR, textStatus, errorThrown) {
    //             $('.btn_save').button('reset');
    //             alert_error('something wrong');
    //         }
    //     });//end ajax
    // });

$(document).on('click', '.btn_do_save_recapitulation', function () {
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan Disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $(this).button('loading');
            var formData = new FormData($('.form-payment')[0]);
            $.ajax({
                url: controller + '/save_recapitulation',
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    if (data.status) {
                        $('.cover_payment').html(data.html_respon);
                        $('#modal-form').modal('hide');
                        $('.html_respon_modal').html(data.html_respon);
                        get_invoice(data.id);
                        Swal.fire(
                            'BERHASIL!',
                            'Data Berhasil Disimpan!',
                            'success'
                        );
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                            $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                        }
                    }
                    $('.btn_do_save_recapitulation').button('reset');
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $('.btn_do_save_recapitulation').button('reset');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});



$(document).on('click', '.btn_unsales_hpp', function (e) {
    e.preventDefault();
    $(this).button('loading');
    var data_accounting = $(this).data('accounting');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('.modal-title').text('KOREKSI KEMBALI');
    //defined form
    var formData = new FormData($('.form-unsales-hpp')[0]);
    $.ajax({
        url: controller + '/review_unsales_hpp',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon').html(data.html_respon);
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            $('.btn_unsales_hpp').button('reset');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_unsales_hpp').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_repair_hpp', function (e) {
	e.preventDefault();
	Swal.fire({
		title: 'Apakah anda yakin?',
		text: "data ini akan Disimpan",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Ya, Lanjutkan',
		cancelButtonText: 'Batal'
	}).then((result) => {
		if (result.value) {
			$(this).button('loading');
            var data_current = $(this).data('repair');
			$.ajax({
				url: controller+'/do_repair_hpp',
				type: "POST",
				data: {'data_current':data_current},
				dataType :"JSON",
                success: function (data) {
                    $('.btn_repair_hpp').button('reset');
					if (data.status) {
						Swal.fire(
							'BERHASIL!',
							'Data Berhasil Disimpan!',
							'success'
                        );
                        location.reload();
					} else{
						for (var i = 0; i < data.inputerror.length; i++)
						{
							$('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
							$('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
						}
					}
					$('.btn_repair_hpp').button('reset');
				},
				error:function(jqXHR, textStatus, errorThrown)
				{
					$('.btn_repair_hpp').button('reset');
					alert_error('something wrong');
				}
            });//end ajax
		}
	})
});



$(document).on('keyup', '.money_only', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}