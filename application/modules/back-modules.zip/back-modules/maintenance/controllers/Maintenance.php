<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Maintenance extends CI_Controller
{
    var $location = 'maintenanace/';
    var $tb_name = 'tb_maintenance';
    var $module_name = 'maintenance';
    var $js_page = 'maintenance';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        // $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = $this->tb_name;
        $simbol = 'SP';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from $db_name ")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }


    public function index()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "AKSES MAINTENANCE";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin', $data);
    }

    public function repair_stock()
    {
        $get_data_stock = $this->db->query("
            SELECT
            tb_product.id AS id_product_current,
            tb_product.name AS product_name,
            tb_detail_stock.id_product,
            tb_detail_stock.unit_price,
            tb_barcode_product.barcode,
            tb_product.stock AS stock_current,
            tb_product_has_conversion.qty AS qty_conversion,
            GROUP_CONCAT(DISTINCT tb_detail_stock.id,'-',tb_detail_stock.new_stock,'-',tb_detail_stock.unit_price,'-',tb_detail_stock.id_conversion_unit,'-',tb_detail_stock.stock_rest order by tb_detail_stock.id) AS list_stock,
            GROUP_CONCAT(DISTINCT tb_detail_sales.id,'-',tb_detail_sales.qty) AS list_sales,
            SUM(DISTINCT tb_detail_sales.qty) AS qty_sales,
            SUM(DISTINCT tb_detail_stock.new_stock) AS qty_stock,
            SUM(DISTINCT tb_detail_stock.stock_rest) AS stock_rest_current
            FROM tb_product
            LEFT JOIN tb_detail_sales ON tb_product.id = tb_detail_sales.id_product
            LEFT JOIN tb_detail_stock ON tb_product.id = tb_detail_stock.id_product
            LEFT JOIN tb_stock ON tb_detail_stock.id_stock_opname = tb_stock.id
            LEFT JOIN tb_barcode_product ON tb_barcode_product.id_product = tb_product.id
            LEFT JOIN tb_product_has_conversion ON tb_detail_stock.id_conversion_unit = tb_product_has_conversion.id
            WHERE tb_stock.id_account_warehouse = 0 
            GROUP BY tb_product.id
            ")->result();

        $data['data_stock'] = $get_data_stock;


        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "REPAIR STORE STOCK";
        $data['view_file'] = $this->location . 'view_repair_stock';
        $this->load->view('template/media_admin', $data);
    }

    public function do_repair_stock()
    {
        $data_current = json_decode($this->encrypt->decode($this->input->post('data_current')));
        $store_update = json_decode($this->encrypt->decode($this->input->post('store_update')));
        $warehouse_update = json_decode($this->encrypt->decode($this->input->post('warehouse_update')));

        $this->db->trans_start();
        foreach ($data_current as $id_stock => $item_current) {
            $this->model->update(array('id' => $id_stock), $item_current, 'tb_detail_stock');
        }
        foreach ($store_update as $item_update_store) {
            $this->model->update(array('id' => $item_update_store->id_product), ['stock' => $item_update_store->stock_rest], 'tb_product');
        }
        foreach ($warehouse_update as $item_warehouse_update) {
            $this->model->update(array('id' => $item_warehouse_update->id_product), ['stock_warehouse' => $item_warehouse_update->stock_rest], 'tb_product');
        }

        $this->db->trans_complete();
        if ($this->db->trans_status() == false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }

        echo json_encode(['status' => TRUE]);
    }

    public function repair_stock_warehouse()
    {
        $get_data_stock = $this->db->query("
        SELECT
        tb_product.id AS id_product_current,
        tb_product.name AS product_name,
        tb_product.stock_warehouse AS stock_current,
        tb_barcode_product.barcode,
        GROUP_CONCAT(DISTINCT tb_detail_stock.id,'-',tb_detail_stock.new_stock,'-',tb_detail_stock.unit_price,'-',tb_detail_stock.id_conversion_unit,'-',tb_detail_stock.stock_rest  order by tb_detail_stock.id) AS list_stock,
        GROUP_CONCAT(DISTINCT stock_send.id,'-',stock_send.new_stock) AS list_stock_send
        FROM tb_product
        INNER JOIN tb_detail_stock ON tb_product.id = tb_detail_stock.id_product
        INNER JOIN tb_stock ON tb_detail_stock.id_stock_opname = tb_stock.id
        LEFT JOIN tb_barcode_product ON tb_barcode_product.id_product = tb_product.id
        LEFT JOIN tb_detail_stock AS stock_send ON tb_product.id = stock_send.id_product
        left JOIN tb_stock AS main_stock_send ON stock_send.id_stock_opname = main_stock_send.id AND main_stock_send.id_account_warehouse = 0
        WHERE tb_stock.id_account_warehouse > 0 
        GROUP BY tb_product.id
        ")->result();
        $data['data_stock'] = $get_data_stock;



        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "REPAIR warehouse STOCK";
        $data['view_file'] = $this->location . 'view_repair_stock_warehouse';
        $this->load->view('template/media_admin', $data);
    }

    public function repair_hpp()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "REPAIR CASHIER REPORT";
        $data['view_file'] = $this->location . 'repair_hpp';
        $this->load->view('template/media_admin', $data);
    }

    private function change_date($date)
    {
        $date_explode = explode('-', $date);
        $date_return = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        return $date_return;
    }

    private function validate_search()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date_from') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_from';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function delete_cashier_report()
    {
        $this->validate_search();
        $date_from = $this->change_date($this->input->post('date_from'));
        $date_to   = $this->change_date($this->input->post('date_to'));

        $get_data_recapitulation = $this->db->where(['date>=' => $date_from, 'date<=' => $date_to])->get('tb_sales_recapitulation')->result();
        $this->db->trans_start();
        foreach ($get_data_recapitulation as $item_recapitulation) {
            $id_recapitulation = $item_recapitulation->id;
            $array_item_sales = explode(',', $item_recapitulation->list_id_sales);
            $array_item_deposito = explode(',', $item_recapitulation->list_id_deposito);
            $array_item_usage = explode(',', $item_recapitulation->list_id_usage);
            foreach ($array_item_sales as $id_sales) {
                $this->model->update(array('id' => $id_sales), ['report_status' => 0, 'grand_total_hpp' => $grand_total_hpp], 'tb_sales');
            }
            foreach ($array_item_deposito as $id_deposito) {
                $this->model->update(array('id' => $id_deposito), ['report_status' => 0], 'tb_deposito');
            }
            foreach ($array_item_usage as $id_usage) {
                $this->model->update(array('id' => $id_usage), ['status' => 0], 'tb_usage');
            }

            $this->model->delete(array('id' => $id_recapitulation), 'tb_sales_recapitulation');
        }
        $this->db->select('
                    tb_detail_sales.id_sales,
                    GROUP_CONCAT(tb_detail_sales.qty,"-",tb_product.main_price) AS list_price,
                    SUM(tb_product.main_price * tb_detail_sales.qty) AS grand_total_hpp
                ');
        $this->db->from('tb_detail_sales');
        $this->db->join('tb_product', 'tb_detail_sales.id_product = tb_product.id', 'left');
        $this->db->join('tb_sales', 'tb_detail_sales.id_sales = tb_sales.id', 'left');
        $this->db->where(['tb_sales.report_status' => 0]);
        $this->db->group_by('tb_detail_sales.id_sales');
        $get_data_product = $this->db->get()->result();
        $grand_total_hpp = 0;
        foreach ($get_data_product as $item_hpp) {
            $this->model->update(array('id' => $item_hpp->id_sales), ['grand_total_hpp' => $item_hpp->grand_total_hpp], 'tb_sales');
        }
        //delete jurnal 
        $array_status_act = [6, 7, 8];
        foreach ($array_status_act as $status_act) {
            $this->model->delete(array('status_act' => $status_act, 'date>=' => $date_from, 'date<=' => $date_to), 'tb_book_account_has_detail');
        }

        $this->db->trans_complete();
        if ($this->db->trans_status() == false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }
        echo json_encode(array('status' => TRUE));
    }

    private function validate_recapitulation()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function get_recapitulation()
    {
        $this->validate_recapitulation();
        $date   = $this->change_date($this->input->post('date'));
        $data['date_report'] = $date;
        $count_data_sales       = $this->db->select('
            SUM(tb_sales.cash_payment) AS sum_cash_payment,
            SUM(tb_sales.rest_payment) AS sum_rest_payment,
            SUM(tb_sales.deposito_payment) sum_deposito_payment,
            SUM(tb_sales.point_payment) AS sum_point_payment,
            SUM(tb_sales.credit_price) AS sum_credit_price,
            SUM(tb_sales.grand_total) AS sum_grand_total,
            SUM(tb_sales.grand_total_real_price) AS sum_grand_total_real_price,
            SUM(tb_sales.grand_total_sales) AS sum_grand_total_sales,
            SUM(tb_sales.pph_price) AS sum_total_pph_price,
            SUM(tb_sales.ppn_price) AS sum_total_ppn_price,
            SUM(tb_sales.grand_total_hpp) AS sum_grand_total_hpp,
            SUM(tb_sales.total_discount_product) AS sum_grand_total_discount,
            SUM(tb_sales.total_member_discount) AS sum_grand_total_member_discount,
            SUM(tb_sales.deposito_payment) AS sum_deposito_payment,
            SUM(tb_sales.point_payment) AS sum_point_payment,
            SUM(tb_sales.new_point) AS sum_new_point,
            COUNT(tb_sales.id) AS count_invoice,
            GROUP_CONCAT(tb_sales.id) AS list_id_sales
            ')->from('tb_sales')
            ->where(['tb_sales.report_status' => 0, 'tb_sales.date' => $date])->get()->row();

        $count_data_deposito    = $this->db->select('
            SUM(total) AS sum_deposit,
            SUM(administration) AS sum_admin,
            SUM(price_top_up) AS sum_deposit_only,
            COUNT(tb_deposito.id)AS total_invoice,
            COUNT(distinct tb_deposito.id_member) AS total_member,
            GROUP_CONCAT(tb_deposito.id) AS list_deposito
            ')->where(['report_status' => 0, 'status' => 1, 'tb_deposito.date' => $date])->get('tb_deposito')->row();

        $get_data_usage = $this->db->select('SUM(price) AS price_usage, GROUP_CONCAT(id) AS list_id_usage')->where(['DATE(created_date)' => $date, 'status' => 0])->get('tb_usage')->row();
        $data['data_money_usage'] = $get_data_usage;

        $data['data_user'] = $this->db->where(['id' => $this->session->userdata('us_id')])->get('tb_user')->row();
        $data['data_sales'] = $count_data_sales;
        $data['data_deposit'] = $count_data_deposito;
        $get_user = $this->db->where(['id' => $this->session->userdata('us_id')])->get('tb_user')->row();
        $data['capital_money'] = $get_user->capital_money;

        $html_respon = $this->load->view($this->location . 'html_form_recapitulation', $data, TRUE);
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function validate_insert_recapitulation()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function review_payment()
    {
        $this->validate_insert_recapitulation();
        $data_recapitulation = json_decode($this->encrypt->decode($this->input->post('data_recapitulation')), TRUE);
        $price  = str_replace('.', '', $this->input->post('price'));
        $note   = $this->input->post('note');

        $margin = $price - $data_recapitulation['total_price'];

        $html_respon = '
        <div class="col-md-4 text-center form-group border p-20  border-radius-5">
        <small>Total uang (Penjualan + TOP UP )</small>
        <h1 class="text-bold text-green">Rp.' . number_format($data_recapitulation['total_price'], 0, '.', '.') . '</h1>
        </div>
        <div class="col-md-4 text-center form-group border  p-20  border-radius-5">
        <small>Nominal Setor</small>
        <h1 class="text-bold text-green">Rp.' . number_format($price, 0, '.', '.') . '</h1>
        </div>
        <div class="col-md-4 text-center form-group border p-20  border-radius-5">
        <small>Selisih</small>
        <h1 class="text-bold text-green">Rp.' . number_format($margin, 0, '.', '.') . '</h1>
        </div>
        <div class="col-md-12 p-10 text-right">
        <small>(*klik untuk simpan)</small>
        <a href="javascript:void(0)" class="btn btn-success btn_do_save_recapitulation"><i class="fa fa-save"></i> Simpan Data</a>
        </div>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save_recapitulation()
    {
        $this->validate_insert_recapitulation();

        $this->db->trans_start();
        $data_recapitulation = json_decode($this->encrypt->decode($this->input->post('data_recapitulation')), TRUE);

        $price  = str_replace('.', '', $this->input->post('price'));
        $note   = $this->input->post('note');
        $margin = $price - $data_recapitulation['total_price'];
        $data_recapitulation['total_price_report'] = $price;
        $data_recapitulation['margin'] = $margin;
        $data_recapitulation['note'] = $note;
        $data_recapitulation['sales_date'] = $data_recapitulation['date'];

        $data_accounting = json_decode($this->encrypt->decode($this->input->post('data_accounting')));

        $this->model->insert('tb_sales_recapitulation', $data_recapitulation);

        //update sales
        $array_update_sales = ['report_status' => TRUE];
        $this->model->update(array('report_status' => 0, 'date' => $data_recapitulation['date']), $array_update_sales, 'tb_sales');
        //update deposito
        $this->model->update(array('report_status' => 0, 'status' => 1, 'date' => $data_recapitulation['date']), $array_update_sales, 'tb_deposito');
        //update usage
        $this->model->update(array('status' => 0, 'DATE(created_date)' => $data_recapitulation['date']), ['status' => 1], ' tb_usage');
        $html_respon = '
        <div class="p-20 bg-warning text-center border-radius-5">
        <h2><i class="fa fa-check"></i> DATA REKAPITULASI BERHASIL DISIMPAN !</h2>
        </div>
        ';
        $get_max_id = $this->db->select('MAX(id) AS max_id')->get('tb_sales_recapitulation')->row();

        //insert to accountant
        $this->insert_to_accountant($data_accounting, $get_max_id->max_id);
        $this->db->trans_complete();
        if ($this->db->trans_status() == false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }

        $array_respon = [
            'id' => $get_max_id->max_id,
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    private function insert_to_accountant($array_accountant, $id_recapitulation)
    {
        $date_use = $array_accountant->date;
        $account_sales   = json_decode($this->db->where(['field' => 'book_account_sales'])->get('tb_setting')->row()->value);

        //insert debit and credit to account reception
        $description = 'Pendapatan penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $status_act = 6;
        // $cash_payment = $account_sales->credit_sales_income - 
        if ($array_accountant->grand_total_income) {
            //minus piutang
            if ($array_accountant->grand_total_piutang) {
                $array_accountant->grand_total_income = $array_accountant->grand_total_income - $array_accountant->grand_total_piutang;
            }
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_sales_income,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->grand_total_income,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_sales_income,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->grand_total_sales,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        $total_discount = $array_accountant->grand_total_discount + $array_accountant->grand_total_member_discount;

        if ($total_discount) {
            //insert jurnal bonus
            $description = 'Potongan penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_bonus,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $total_discount,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        if ($array_accountant->grand_total_piutang) {
            //insert piutang
            $description = 'Piutang penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_piutang,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->grand_total_piutang,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //hpp sales
        if ($array_accountant->grand_total_hpp) {
            $description = 'Hpp penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_hpp,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->grand_total_hpp,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_hpp,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->grand_total_hpp,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //ppn
        if ($array_accountant->ppn_price) {
            $description = 'Pajak PPN penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_ppn,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->ppn_price,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_ppn,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->ppn_price,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //pph
        if ($array_accountant->pph_price) {
            $description = 'Pajak PPH penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_pph,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->pph_price,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_pph,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->pph_price,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //deposito payment 
        if ($array_accountant->deposit_payment) {
            $description = 'Pemakaian Deposito di penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_deposito,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->deposit_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_deposito,
                    'description' => $description,
                    'date' => $date_use,
                    'credit' => 0,
                    'debit' => $array_accountant->deposit_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //Poin payment 
        if ($array_accountant->point_payment) {
            $description = 'Pemakaian Poin di penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_point,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->point_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_point,
                    'description' => $description,
                    'date' => $date_use,
                    'credit' => 0,
                    'debit' => $array_accountant->point_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        $status_act = 7;
        // new deposit
        if ($array_accountant->deposito_in) {
            $description = 'Top Up Deposito tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_deposito,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->deposito_in,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_deposito,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->deposito_in,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );

            //deposito administration
            $description = 'administrasi Deposito tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_deposito_income,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->administration_deposito,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_deposito_income,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => 0,
                    'credit' => $array_accountant->administration_deposito,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //new point
        $status_act = 8;
        if ($array_accountant->new_point) {
            $description = 'Poin Baru di penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_point,
                    'description' => $description,
                    'date' => $date_use,
                    'debit' => $array_accountant->new_point,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_point,
                    'description' => $description,
                    'date' => $date_use,
                    'credit' => $array_accountant->new_point,
                    'debit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }
    }

    public function repair_unsales_hpp()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Perbaikan Hpp Tidak Terdaftar";
        $data['view_file'] = $this->location . 'view_unsales_hpp';
        $this->load->view('template/media_admin', $data);
    }

    public function review_unsales_hpp()
    {
        $date_from  = $this->change_date($this->input->post('date_from'));
        $date_to    = $this->change_date($this->input->post('date_to'));

        $this->db->select('
            tb_sales.*,
            SUM(tb_detail_sales.qty * tb_detail_sales.main_price) AS total_hpp
        ');
        $this->db->from('tb_sales');
        $this->db->join('tb_detail_sales', 'tb_sales.id = tb_detail_sales.id_sales', 'left');
        $this->db->where(['tb_sales.date>=' => $date_from, 'tb_sales.date<=' => $date_to]);
        $this->db->having(' SUM(tb_detail_sales.qty * tb_detail_sales.main_price) != tb_sales.grand_total_hpp');
        $this->db->group_by('tb_sales.id');
        $get_data = $this->db->get()->result();

        $data['data_sales'] = $get_data;
        $html_respon = $this->load->view($this->location . 'search_unsales_hpp', $data, TRUE);

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function do_repair_hpp()
    {
        $data_current = json_decode($this->encrypt->decode($this->input->post('data_current')), TRUE);
        $this->db->trans_start();
        foreach ($data_current as $id_sales => $item_data) {
            if ($item_data['rest_hpp'] < 0) {
                continue;
            }
            $this->insert_unsales_hpp($item_data['rest_hpp'], $item_data['date'], $item_data['code']);
            //update hpp
            $array_update = ['grand_total_hpp' => $item_data['hpp']];
            $this->model->update(array('id' => $id_sales), $array_update, 'tb_sales');
        }
        $this->db->trans_complete();
        if ($this->db->trans_status() == false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }
        echo json_encode(['status' => TRUE]);
    }

    private function insert_unsales_hpp($grand_total_hpp, $date, $code)
    {
        $account_sales   = json_decode($this->db->where(['field' => 'book_account_sales'])->get('tb_setting')->row()->value);
        //hpp sales
        $status_act = 6;
        $description = 'perbaikan Hpp penjualan kode nota : ' . $code;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->model->insert(
            'tb_book_account_has_detail',
            [
                'id_book_account' => $account_sales->debit_hpp,
                'description' => $description,
                'date' => $date,
                'debit' => $grand_total_hpp,
                'credit' => 0,
                'status_act' => $status_act,
                'id_recapitulation' => 0,
                'token' => $token
            ]
        );
        $this->model->insert(
            'tb_book_account_has_detail',
            [
                'id_book_account' => $account_sales->credit_hpp,
                'description' => $description,
                'date' => $date,
                'debit' => 0,
                'credit' => $grand_total_hpp,
                'status_act' => $status_act,
                'id_recapitulation' => 0,
                'token' => $token
            ]
        );
    }
}
