<?php
$btn_payment = '';
if ($data_debt->status == FALSE) {
    $btn_payment = '
                        <a href="' . base_url('admin/debt/add_payment?data=' . urlencode($this->encrypt->encode($data_debt->id))) . '" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Tambah Data Pembayaran</a>
                    ';
}

if (strtotime($data_debt->deadline) < strtotime(date('Y-m-d'))) {
    //expired
    $label_expired = '<label class="text-danger text-bold font-weight-bold">Telah Jatuh Tempo</label>';
} else {
    //expired
    $label_expired = '<label class="text-success text-bold font-weight-bold">Belum Jatuh Tempo</label>';
}
?>
<div class="card">
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h4 class="page-title mb-1">Pembayaran Hutang</h4>
            </div>
            <div class="col-md-4">
                <div class="float-right d-md-block">

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-10 mt-10 html_resume_debt ">
                <div class="card-footer text-center border bg-gray-100">
                    <h5>Keterangan Hutang</h5>
                </div>

                <div class="card border shadow-none">
                    <table class="table">
                        <tr>
                            <td width="150px">Kode</td>
                            <td width="5px">:</td>
                            <td><b><?= $data_debt->code; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Invoice</td>
                            <td width="5px">:</td>
                            <td><b><?= $data_debt->invoice_code; ?></b></td>
                        </tr>
                        <tr>
                            <td>Nominal</td>
                            <td>:</td>
                            <td>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                    </div>
                                    <input type="text" class="form-control form-control-sm bg-white" readonly value="<?= number_format($data_debt->price, 0, '.', '.'); ?>">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>Sisa Tanggungan</td>
                            <td>:</td>
                            <td>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                    </div>
                                    <input type="text" class="form-control form-control-sm bg-white" readonly value="<?= number_format($data_debt->rest_debt, 0, '.', '.'); ?>">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>Vendor</td>
                            <td>:</td>
                            <td><b><?= $data_debt->member_name ? $data_debt->member_name : '-'; ?></b></td>
                        </tr>
                        <tr>
                            <td>Tanggal Hutang</td>
                            <td>:</td>
                            <td><?= Modules::run('helper/date_indo', $data_debt->date, '-'); ?> <b>s/d </b><?= Modules::run('helper/date_indo', $data_debt->deadline, '-'); ?></td>
                        </tr>
                        <tr>
                            <td>Status</td>
                            <td>:</td>
                            <td><b><?= $data_debt->status ? '<label class="text-primary font-weight-bold">Telah Lunas</label>' : '<label class="text-danger font-weight-bold">Belum Lunas</label>'; ?></b></td>
                        </tr>
                        <tr>
                            <td>Status Jatuh Tempo</td>
                            <td>:</td>
                            <td><b><?= $label_expired; ?></b></td>
                        </tr>
                    </table>
                    <label>Deskripsi:</label>
                    <div class="border p-2">
                        <p>
                            <?= $data_debt->description; ?>
                        </p>
                    </div>
                </div>

            </div>
            <div class="col-md-8">
                <!-- <h3 class="text-green mb-10">Form Pembayaran :</h3> -->

                <form class="form-horizontal form_payment">
                    <div class="col-md-12 text-right">
                        <a href="<?= base_url('admin/debt/detail?data=' . urlencode($this->encrypt->encode($data_debt->id))); ?>" class="btn btn-primary btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                    </div>
                    <div class="col-md-12 text-center mb-3">
                        <small class="text-center">sisa Tanggungan :</small>
                        <h2 class="text-red p-10 shadow div_center" style="width:300px;margin:0 auto;">Rp.<?= number_format($data_debt->rest_debt, 0, '.', '.'); ?></h2>
                    </div>
                    <div class="col-md-12 mb-1">
                        <div class="form-group row mb-1">
                            <label for="inputEmail3" class="col-sm-3 control-label">Nominal Pembayaran</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon" style="font-size:20px;">Rp.</span>
                                    <input type="text" class="form-control form-control-lg money_only" name="price" style="font-size:20px;">
                                </div>
                                <span class="help-block text-danger notif_price"></span>
                            </div>
                        </div>
                        <div class="form-group row mb-1">
                            <label for="inputPassword3" class="col-sm-3 control-label">Keterangan</label>

                            <div class="col-sm-9">
                                <textarea name="note" class="form-control" rows="8"></textarea>
                                <span class="help-block text-danger"></span>
                            </div>
                        </div>
                        <div class="form-group text-right">
                            <small>(*Klik untuk simpan data)</small>
                            <button type="submit" data-id="<?= $this->encrypt->encode($data_debt->id); ?>" class="btn btn-primary btn_preview">Simpan Data Pembayaran</button>
                        </div>
                    </div>
                </form>


                <?php
                if ($data_debt->status == 2) {
                    echo '
                            <div class="col-md-12 mb-10">
                                <hr>
                                <h2 class="text-center text-muted" >PIUTANG <b>' . $data_debt->code . '</b> TELAH DIBATALKAN </h2>
                                <hr>
                            </div>
                            <div class="col-md-4 mt-10">
                                <label>Keterangan Pembatalan:</label>
                                <table class="table">
                                    <tr>
                                        <td width="150px">Tanggal Dibatalkan </td>
                                        <td width="5px">:</td>
                                        <td><b>' . $data_debt->updated_date . '</b></td>
                                    </tr>
                                    <tr>
                                    <td>Dibatlakan Oleh</td>
                                    <td>:</td>
                                    <td><b>' . $data_debt->user_name . '</b></td>
                                </tr>
                                </table>
                            </div>
                            <div class="col-md-8 mt-10">
                                <label>Catatan Pembatalan:</label>
                                <div class="p-10 border border-radius-5">' . $data_debt->reject_note . '</div>
                            </div>
                            <div class="col-md-12 text-right">
                                <a href="' . base_url('admin/debt') . '" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Lihat Data Hutang</a>
                            </div>
                        ';
                }
                ?>
                <div class="col-md-12 mt-10">
                    <h5 class="text-green mb-10 card-footer">Detail Angsuran :</h5>
                    <div class="table-responsive">
                        <table class="table table_payment">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kode Pembayaran</th>
                                    <th>Tanggal Pembayaran</th>
                                    <th>Jumlah Tagihan</th>
                                    <th>Jumlah Dibayar</th>
                                    <th>Sisa Tanggungan</th>
                                    <th>Catatan</th>
                                    <th>status</th>
                                    <th>Petugas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 0;
                                foreach ($data_detail as $item_detail) {
                                    $counter++;
                                    $label_status = $item_detail->status ? '<label class="label label-success">Lunas</label>' : '<label class="label label-warning">Belum Lunas</label>';
                                    echo '
                                            <tr>
                                                <td>' . $counter . '</td>
                                                <td>' . $item_detail->code . '</td>
                                                <td>' . $item_detail->date . '</td>
                                                <td>Rp.' . number_format($item_detail->debt_price, 0, '.', '.') . '</td>
                                                <td>Rp.' . number_format($item_detail->payment_price, 0, '.', '.') . '</td>
                                                <td>Rp.' . number_format($item_detail->rest_debt, 0, '.', '.') . '</td>
                                                <td>' . $item_detail->note . '</td>
                                                <td>' . $label_status . '</td>
                                                <td>' . $item_detail->user_name . '</td>
                                            </tr>
                                        ';
                                }
                                if (empty($data_detail)) {
                                    echo '
                                            <tr>
                                                <td colspan="10" class="text-center">
                                                    <div class="bg-empty-data"></div>
                                                    <h3 class="text-center text-muted">Tidak ada data pembayaran</h3>
                                                </td>
                                            </tr>
                                        ';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-right mt-10">
                        <a href="<?= base_url('admin/debt'); ?>" class="btn btn-primary btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="max-width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="p-10 border-radius-5 html_resume_debt_modal"></div>
                        </div>
                        <div class="col-md-6">
                            <h2 class="text-center">Preview Pembayaran</h2>
                            <div class="col-md-12 text-center">
                                <small class="text-center">sisa Tanggungan :</small>
                                <h5 class="text-red  shadow div_center" style="width:300px;margin:0 auto;">Rp.<?= number_format($data_debt->rest_debt, 0, '.', '.'); ?></h5>
                            </div>
                            <div class="col-md-12 html_payment_preview"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>