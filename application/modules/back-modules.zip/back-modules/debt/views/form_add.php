<div class="card">
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h4 class="page-title mb-1">Tambah Data Hutang</h4>
            </div>
            <div class="col-md-8">
                <div class="float-right d-md-block">
                    <div class="dropdown">
                        <a href="<?= base_url('admin/debt/history_debt'); ?>" class="btn btn-light btn-rounded">
                            <i class="mdi mdi-laptop mr-1"></i> Lihat Riwayat Hutang
                        </a>
                        <a href="<?= base_url('admin/debt/history_payment'); ?>" class="btn btn-light btn-rounded">
                            <i class="mdi mdi-laptop mr-1"></i> Lihat Riwayat Pembayaran
                        </a>

                    </div>
                </div>
            </div>
        </div>
        <form class="form-input-credit">
            <div class="row">
                <div class="col-md-5 row">
                    <h5 class="text-green ">*Data Hutang</h5>
                    <div class="form-group col-md-12">
                        <label>No. Invoice Vendor</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="validationTooltipUsernamePrepend"><i class="mdi mdi-laptop"></i></span>
                            </div>
                            <input type="text" class="form-control form-control-lg " name="invoice" style="font-size:20px;">
                        </div>
                        <span class="help-block text-danger notif_price"></span>
                    </div>
                    <div class="form-group col-md-12">
                        <label>Masukan Nominal Hutang</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="validationTooltipUsernamePrepend">Rp.</span>
                            </div>
                            <input type="text" class="form-control form-control-lg money_only" name="price" style="font-size:20px;">
                        </div>
                        <span class="help-block text-danger notif_price"></span>
                    </div>
                    <h5 class="text-green ">*Vendor Hutang</h5>
                    <div class="form-group col-md-12">
                        <label>Pilih Vendor</label>
                        <select name="id_vendor" class="form-control">
                            <?= $html_option_member; ?>
                        </select>
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Tanggal Piutang</label>
                        <input type="text" class="form-control datepicker_form bg-white" data-language="en" readonly name="date">
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Tanggal Jatuh Tempo</label>
                        <input type="text" class="form-control datepicker_form bg-white" data-language="en" readonly name="due_date">
                        <span class="help-block text-danger"></span>
                    </div>
                </div>
                <div class="col-md-7">
                    <h5 class="text-green ">*Keterangan Hutang</h5>
                    <div class="form-group">
                        <label>Keterangan :</label>
                        <textarea name="note" class="form-control" rows="12"></textarea>
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="form-group  row">
                        <div class="col-6">
                            <a href="<?= base_url('debt'); ?>" class="btn btn-primary"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                        </div>
                        <div class="col-6 text-right">
                            <small>(*klik untuk simpan data)</small>
                            <button class="btn btn-primary btn_save" type="submit">Simpan Data hutang</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>