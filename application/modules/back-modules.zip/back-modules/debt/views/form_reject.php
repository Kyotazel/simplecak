<?php
if (strtotime($data_credit->deadline) < strtotime(date('Y-m-d'))) {
    //expired
    $label_expired = '<label class="label label-warning">Telah Jatuh Tempo</label>';
} else {
    //expired
    $label_expired = '<label class="label label-success">Belum Jatuh Tempo</label>';
}
?>

<div class="col-md-5">
    <div class="p-10 border-radius-5 shadow_div">
        <table class="table">
            <tr>
                <td width="150px">Kode</td>
                <td width="5px">:</td>
                <td><b><?= $data_credit->code; ?></b></td>
            </tr>
            <tr>
                <td>Nominal</td>
                <td>:</td>
                <td><b>Rp.<?= number_format($data_credit->price, 0, '.', '.'); ?></b></td>
            </tr>
            <tr>
                <td>Sisa Tanggungan</td>
                <td>:</td>
                <td><b>Rp.<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?></b></td>
            </tr>
            <tr>
                <td>Penanggung Jawab</td>
                <td>:</td>
                <td><b><?= $data_credit->name; ?></b></td>
            </tr>
            <tr>
                <td>Member</td>
                <td>:</td>
                <td><b><?= $data_credit->member_name ? $data_credit->member_name : '-'; ?></b></td>
            </tr>
            <tr>
                <td>Kode Penjualan</td>
                <td>:</td>
                <td><b><?= $data_credit->sales_code ? $data_credit->sales_code : '-'; ?></b></td>
            </tr>
            <tr>
                <td>Tanggal Hutang</td>
                <td>:</td>
                <td><b><?= $data_credit->date; ?></b></td>
            </tr>
            <tr>
                <td>Status</td>
                <td>:</td>
                <td><b><?= $data_credit->status ? '<label class="label label-success">Telah Lunas</label>' : '<label class="label label-warning">Belum Lunas</label>'; ?></b></td>
            </tr>
            <tr>
                <td>Status Jatuh Tempo</td>
                <td>:</td>
                <td><b><?= $label_expired; ?></b></td>
            </tr>
        </table>
        <label>Catatan:</label>
        <div class="p-10 bg-info">
            <p>
                <?= $data_credit->note; ?>
            </p>
        </div>
    </div>
</div>

<div class="col-md-7">
    <!-- <h3 class="text-green mb-10">Form Pembayaran :</h3> -->
    <form class="form-horizontal form_reject">
        <div class="col-md-12 text-center mb-10">
            <small class="text-center">sisa Tanggungan :</small>
            <h2 class="text-red p-10 shadow div_center" style="width:300px;">Rp.<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?></h2>
        </div>
        <div class="col-md-12 mt-10">
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Keterangan Dibatalkan</label>
                <div class="col-sm-9">
                    <textarea name="note" class="form-control" rows="8"></textarea>
                    <span class="help-block"></span>
                </div>
            </div>
            <div class="form-group text-right">
                <small>(*Klik untuk simpan data)</small>
                <button type="submit" data-id="<?= $this->encrypt->encode($data_credit->id); ?>" class="btn btn-success btn_save_reject">Lanjutkan Pembatalan</button>
            </div>
        </div>
    </form>
</div>