<div class="col-md-12">
    <table class="table table-hover table_history" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>kode</th>
                <th>Kode Invoice</th>
                <th>Tanggal Hutang</th>
                <th>Sebelum Dibayar</th>
                <th>Setelah Dibayar</th>
                <th>Tgl Pembayaran</th>
                <th>Status piutang</th>
                <th>Petugas</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            $array_list_data = [];
            foreach ($data_debt as $item_debt) {
                $array_pattern = [];
                $counter++;
                $label_status  = $item_debt->status ? '<label class="text-primary font-weight-bold">Lunas</label>' : '<label class="font-weight-bold">Belum Lunas</label>';
                $text_status = $item_debt->status ? 'Lunas' : 'Belum Lunas';


                echo '
                    <tr>
                        <td>' . $counter . '</td>
                        <td>' . $item_debt->code . '</td>
                        <td>' . $item_debt->invoice_code . '</td>
                        <td>' . Modules::run('helper/date_indo', $item_debt->date_debt, '-') . '</td>
                        <td class="border">
                            <small>Jumlah Hutang :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($item_debt->price_debt, 0, '.', '.') . '">
                            </div>
                            <small>Sisa Hutang :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($item_debt->debt_price, 0, '.', '.') . '">
                            </div>
                        </td>
                        <td class="border">
                            <small>Jumlah Pembayaran :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($item_debt->payment_price, 0, '.', '.') . '">
                            </div>
                            <small>Sisa tanggungan :</small>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($item_debt->rest_debt, 0, '.', '.') . '">
                            </div>
                        </td>
                        <td>' . Modules::run('helper/date_indo', $item_debt->date, '-') . '</td>
                        <td>' . $label_status . '</td>
                        <td>' . $item_debt->user_name . '</td>
                    </tr>
                ';

                $array_pattern = [
                    'invoice' => $item_debt->invoice_code,
                    'tanggal_hutang' => $item_debt->date_debt,
                    'total_hutang' => $item_debt->price_debt,
                    'sisa_hutang' => $item_debt->debt_price,
                    'jumlah_bayar' => $item_debt->payment_price,
                    'sisa_tanggugan' => $item_debt->rest_debt,
                    'tanggal_bayar' => $item_debt->date,
                    'status_hutang' => $text_status
                ];
                $array_list_data['data_print'][] = $array_pattern;
            }
            $array_list_data['param'] = $params;
            $data_print = $this->encrypt->encode(json_encode($array_list_data));

            ?>
        </tbody>
    </table>
    <div class="mt-3 text-right">
        <form method="POST" action="<?= base_url('admin/debt/print_payment'); ?>">
            <input type="hidden" name="data_print" value="<?= $data_print; ?>">
            <small>(*klik untuk cetak)</small>
            <button type="submit" class="btn btn-primary">CETAK EXCEL</button>
        </form>
    </div>


</div>