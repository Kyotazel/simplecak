<!-- <div class="card-header text-right">
    <small>(*Klik untuk tambah piutang)</small>
    <a href="<?= base_url('credit/add'); ?>" class="btn btn-success btn_link"><i class="fa fa-credit-card"></i> Tambah Data Hutang</a>
</div> -->

<div class="col-md-12">
    <!-- Custom Tabs -->
    <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_0" data-toggle="tab"><i class="fa fa-file-o"></i> Belum Lunas</a></li>
            <li><a href="#tab_1" data-toggle="tab"><i class="fa fa-check"></i> Telah Lunas</a></li>
            <li><a href="#tab_2" data-toggle="tab"><i class="fa fa-close"></i> Dibatalkan</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="tab_0">
                <div class="table-responsive">
                    <table class="table table-hover table_paid" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>kode</th>
                                <th>Kode Penjualan</th>
                                <th>Nominal Hutang</th>
                                <th>Jumlah Angsuran</th>
                                <th>Total Nominal Angsuran</th>
                                <th>Sisa Pembayaran</th>
                                <th>Tgl Hutang</th>
                                <th>Tgl Jatuh Tempo</th>
                                <th>Status Jatuh Tempo</th>
                                <th>Member</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="tab_1">
                <div class="table-responsive">
                    <table class="table table-hover table_has_paid" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>kode</th>
                                <th>Kode Penjualan</th>
                                <th>Nominal Hutang</th>
                                <th>Jumlah Angsuran</th>
                                <th>Total Nominal Angsuran</th>
                                <th>Sisa Pembayaran</th>
                                <th>Tgl Hutang</th>
                                <th>Tgl Pembayaran Terakhir</th>
                                <th>Member</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="tab_2">
                <div class="table-responsive">
                    <table class="table table-hover table_reject" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>kode</th>
                                <th>Kode Penjualan</th>
                                <th>Nominal Hutang</th>
                                <th>Tgl Hutang</th>
                                <th>Member</th>
                                <th>Tanggal Dibatalkan</th>
                                <th>Dibatalkan Oleh</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- /.tab-content -->
    </div>
    <!-- nav-tabs-custom -->
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>