<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Debt extends CommonController
{
    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    var $module_name = 'debt';
    var $module_directory = 'debt';
    var $module_js = ['debt'];
    var $app_data = [];

    private function _init()
    {
        $this->app_data['module_js']  = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function get_code()
    {
        $number_text = 0;
        $simbol = 'DB';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_debt")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_debt WHERE id IN(SELECT MAX(id) FROM tb_debt)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function get_payment_code()
    {
        $number_text = 0;
        $simbol = 'PD';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select max(code) as max_code from tb_debt_has_payment")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function index()
    {
        // $data['view_file']      = "main_view";
        // $data['title']          = "Data Hutang"; // untuk header pada bagian atas data
        // $data['subtitle']       = "Data Hutang"; // untuk subtitle pada bagian atas data
        // $data['module']         = $this->module; //variable module untuk di controller template/media   
        // $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        // $data['page_title']     = 'Data Hutang'; // untuk title pada tab

        // echo Modules::run('template/media_admin', $data);

        $this->app_data['page_title']     = "Data Hutang";
        $this->app_data['view_file']     = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        // $db_name = $this->tb_name;
        $this->db->select('
            tb_debt.*,
            COUNT(tb_debt_has_payment.id) AS count_paid,
            mst_vendor.name AS member_name,
            mst_vendor.name AS member_name,
            st_user.username AS user_name
            ');
        $this->db->from('tb_debt');
        $this->db->join('tb_debt_has_payment', 'tb_debt.id = tb_debt_has_payment.id_debt', 'left');
        $this->db->join('mst_vendor', 'tb_debt.id_vendor = mst_vendor.id  ', 'left');
        $this->db->join('st_user', 'tb_debt.created_by = st_user.id ', 'left');
        $this->db->where(['tb_debt.status' => 0]);
        $this->db->order_by('tb_debt.id', 'DESC');
        $this->db->group_by('tb_debt.id');
        $get_data = $this->db->get()->result();

        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {

            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            if (strtotime(date('Y-m-d')) > strtotime($data_table->deadline)) {
                //expired
                $label_expired = '<label class="text-danger font-weight-bold">Telah Jatuh Tempo</label>';
            } else {
                //expired
                $label_expired = '<label class="text-primary font-weight-bold">Belum Jatuh Tempo</label>';
            }
            //reject button
            $btn_reject = '';
            // if ($data_table->count_paid == 0 && $data_table->sales_code == '') {
            //     $btn_reject = ' <li><a href="javascript:void(0)" class="btn_reject" data-id="' . $id_encrypt . '"><i class="fa fa-close"></i> Batalkan Hutang</a></li>';
            // };


            $tgl1 = strtotime($data_table->date);
            $tgl2 = strtotime(date('Y-m-d'));
            $jarak = $tgl2 - $tgl1;
            $hari = $jarak / 60 / 60 / 24;

            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->invoice_code;
            $row[] = ' 
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                            </div>
                            <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($data_table->price, 0, '.', '.') . '">
                        </div>
                    ';
            $row[] = '
                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                    </div>
                    <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($data_table->total_payment, 0, '.', '.') . '">
                </div>
                <small>Jml Angsuran :</small> <span class="badge badge-primary"> ' . $data_table->count_paid . ' Kali</span>
            ';
            // $row[] = 'Rp.' . number_format($data_table->total_payment, 0, '.', '.');
            $row[] = '
                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                    </div>
                    <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($data_table->rest_debt, 0, '.', '.') . '">
                </div>
            ';
            $row[] = '<span class="badge badge-primary">Tgl Hutang</span><br>' . Modules::run('helper/date_indo',  $data_table->date, '-') . '<span class="badge badge-primary">Tgl Jatuh Tempo</span><br>' . Modules::run('helper/date_indo',  $data_table->deadline, '-');
            $row[] =  $hari;
            $row[] = $label_expired;
            $row[] = $data_table->member_name;
            $row[] = '

                    <div class="btn-group mt-1 mr-1">
                        <a class="btn btn-primary" href="' . base_url('admin/debt/detail?data=' . urlencode($id_encrypt)) . '" class="btn btn-default btn_link">Detail</a>
                        <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        </button>
                        <div class="dropdown-menu" x-placement="top-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(76px, -174px, 0px);">
                            <a class="dropdown-item" href="' . base_url('admin/debt/add_payment?data=' . urlencode($id_encrypt)) . '"><i class="fa fa-send"></i> Masukan Pembayaran</a>
                        </div>
                    </div>
            ';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }


    public function add()
    {
        $get_data_member = $this->db->select('id AS id ,name')->where(['isDeleted' => 'N'])->order_by('name')->get('mst_vendor')->result();
        $html_option_member = '<option value="">Tidak ada</option>';
        foreach ($get_data_member as $item_member) {
            $id_member_encrypt = $this->encrypt->encode($item_member->id);
            $html_option_member .= '<option value="' . $id_member_encrypt . '">' . $item_member->name . '</option>';
        }
        $this->app_data['html_option_member'] = $html_option_member;

        // $data['view_file']      = "form_add";
        // $data['title']          = "Tambah Data Hutang"; // untuk header pada bagian atas data
        // $data['subtitle']       = "Tambah Data Hutang"; // untuk subtitle pada bagian atas data
        // $data['module']         = $this->module; //variable module untuk di controller template/media   
        // $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        // $data['page_title']     = 'Tambah Data Hutang'; // untuk title pada tab

        // echo Modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "Tambah Data Hutang";
        $this->app_data['view_file']     = 'form_add';
        echo Modules::run('template/main_layout', $this->app_data);
    }
    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }
        if (!empty($_POST['price'])) {
            $price = $this->input->post('price');
            $price = str_replace('.', '', $price);
            $price = (int) $price;
            if ($price <=  0) {
                $data['error_string'][] = 'tidak boleh 0';
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }
        }
        // if ($this->input->post('responsible_name') == '') {
        //     $data['error_string'][] = 'harus diisi';
        //     $data['inputerror'][] = 'responsible_name';
        //     $data['status'] = FALSE;
        // }
        if ($this->input->post('note') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'note';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }
        if ($this->input->post('due_date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'due_date';
            $data['status'] = FALSE;
        }
        if ($this->input->post('id_vendor') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'id_vendor';
            $data['status'] = FALSE;
        }
        if ($this->input->post('note') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'note';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();

        $invoice    = $this->input->post('invoice');
        $code       = $this->get_code();
        $price     = $this->input->post('price');
        $price     = str_replace('.', '', $price);
        $id_vendor = $this->encrypt->decode($this->input->post('id_vendor'));
        $note       = $this->input->post('note');
        $date = Modules::run('helper/change_date', $this->input->post('date'), '-');
        $due_date = Modules::run('helper/change_date', $this->input->post('due_date'), '-');
        //insert data
        $array_insert = array(
            'code' => $code,
            'invoice_code' => $invoice,
            'id_vendor' => $id_vendor ? $id_vendor : 0,
            'description' => $note,
            'price' => $price,
            'date' => $date,
            'rest_debt' => $price,
            'deadline' => $due_date,
            'note' => $note,
            'created_by' => $this->session->userdata('usr_id')
        );
        Modules::run('database/insert', 'tb_debt', $array_insert);
        //insert data accounting
        $get_id_debt = $this->db->where(['code' => $code])->get('tb_debt')->row();
        $array_data = ['total_hutang' => $price, 'kode_hutang' => $invoice, 'id_hutang' => $get_id_debt->id];
        Modules::run('accounting/insert_transaction_debt', $array_data);

        echo json_encode(array('status' => TRUE));
    }

    public function add_payment()
    {
        $id = $this->encrypt->decode($this->input->get('data'));

        $this->db->select('
            tb_debt.*,
            COUNT(tb_debt_has_payment.id) AS count_paid,
            mst_vendor.name AS member_name,
            mst_vendor.name AS member_name,
            st_user.username AS user_name
        ');
        $this->db->from('tb_debt');
        $this->db->join('tb_debt_has_payment', 'tb_debt.id = tb_debt_has_payment.id_debt', 'left');
        $this->db->join('mst_vendor', 'tb_debt.id_vendor = mst_vendor.id  ', 'left');
        $this->db->join('st_user', 'tb_debt.created_by = st_user.id ', 'left');
        $this->db->where(['tb_debt.id' => $id]);
        $this->db->order_by('tb_debt.id', 'DESC');
        $this->db->group_by('tb_debt.id');

        $get_data = $this->db->get()->row();
        $this->app_data['data_debt'] = $get_data;
        //get detail
        $this->db->select('
            tb_debt_has_payment.*,
            st_user.username AS user_name
            ');
        $this->db->from('tb_debt_has_payment');
        $this->db->join('st_user', 'tb_debt_has_payment.created_by = st_user.id', 'left');
        $this->db->where(['tb_debt_has_payment.id_debt' => $id]);
        $get_data_detail = $this->db->get()->result();

        $this->app_data['data_detail'] = $get_data_detail;


        // echo modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "Pembayaran Hutang";
        $this->app_data['view_file']     = 'form_payment';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function validate_save_payment()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }
        if (!empty($_POST['price'])) {
            $price = $this->input->post('price');
            $price = str_replace('.', '', $price);
            $price = (int) $price;
            if ($price <=  0) {
                $data['error_string'][] = 'tidak boleh 0';
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }

            $id   = $this->encrypt->decode($this->input->post('id'));
            $get_debt = $this->db->where(['id' => $id])->get('tb_debt')->row();
            if ($price > $get_debt->rest_debt) {
                $data['error_string'][] = 'Maksimal Rp.' . number_format($get_debt->rest_debt, 0, '.', '.');
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('note') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'note';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }
    public function preview_save_payment()
    {
        $this->validate_save_payment();
        $id     = $this->encrypt->decode($this->input->post('id'));
        $price  = $this->input->post('price');
        $price  = str_replace('.', '', $price);
        $note   = $this->input->post('note');
        $get_price = $this->db->where(['id' => $id])->get('tb_debt')->row();

        if ($price >= $get_price->rest_debt) {
            $label_status   = '<label class="label label-success">LUNAS</label>';
            $rest_payment   = $price - $get_price->rest_debt;
            $rest_debt    = 0;
        } else {
            $label_status   = '<label class="label label-warning">BELUM LUNAS</label>';
            $rest_payment   = 0;
            $rest_debt    = $get_price->rest_debt - $price;
        }

        $html_respon = '
        <div class="col-md-12 p-10 mt-3">
            <div class="card box-solid">
                <div class="card-header with-border">
                    <h5 class="card-title">Pembayaran :</h5>
                </div>
                <div class="card-body no-padding">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <div class="media my-2">
                                
                                <div class="media-body">
                                    <p class="text-muted mb-2">Dibayar</p>
                                    <h5 class="mb-0">Rp.' . number_format($price, 0, '.', '.') . '</h5>
                                </div>
                                <div class="icons-lg ml-2 align-self-center">
                                    <span class="uim-svg" style=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em"><path class="uim-quaternary" d="M12,14.19531a1.00211,1.00211,0,0,1-.5-.13379l-9-5.19726a1.00032,1.00032,0,0,1,0-1.73242l9-5.19336a1.00435,1.00435,0,0,1,1,0l9,5.19336a1.00032,1.00032,0,0,1,0,1.73242l-9,5.19726A1.00211,1.00211,0,0,1,12,14.19531Z"></path><path class="uim-tertiary" d="M21.5,11.13184,19.53589,9.99847,12.5,14.06152a1.0012,1.0012,0,0,1-1,0L4.46411,9.99847,2.5,11.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path><path class="uim-primary" d="M21.5,15.13184l-1.96411-1.13337L12.5,18.06152a1.0012,1.0012,0,0,1-1,0L4.46411,13.99847,2.5,15.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path></svg></span>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media my-2">
                                <div class="media-body">
                                    <p class="text-muted mb-2">Sisa Tagihan </p>
                                    <h5 class="mb-0">Rp.' . number_format($rest_debt, 0, '.', '.') . '</h5>
                                </div>
                                <div class="icons-lg ml-2 align-self-center">
                                    <span class="uim-svg" style=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em"><path class="uim-quaternary" d="M12,14.19531a1.00211,1.00211,0,0,1-.5-.13379l-9-5.19726a1.00032,1.00032,0,0,1,0-1.73242l9-5.19336a1.00435,1.00435,0,0,1,1,0l9,5.19336a1.00032,1.00032,0,0,1,0,1.73242l-9,5.19726A1.00211,1.00211,0,0,1,12,14.19531Z"></path><path class="uim-tertiary" d="M21.5,11.13184,19.53589,9.99847,12.5,14.06152a1.0012,1.0012,0,0,1-1,0L4.46411,9.99847,2.5,11.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path><path class="uim-primary" d="M21.5,15.13184l-1.96411-1.13337L12.5,18.06152a1.0012,1.0012,0,0,1-1,0L4.46411,13.99847,2.5,15.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path></svg></span>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media my-2">
                                <div class="media-body">
                                    <p class="text-muted mb-2">Status Lunas</p>
                                    <h5 class="mb-0">' . $label_status . '</h5>
                                </div>
                                <div class="icons-lg ml-2 align-self-center">
                                    <span class="uim-svg" style=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em"><path class="uim-quaternary" d="M12,14.19531a1.00211,1.00211,0,0,1-.5-.13379l-9-5.19726a1.00032,1.00032,0,0,1,0-1.73242l9-5.19336a1.00435,1.00435,0,0,1,1,0l9,5.19336a1.00032,1.00032,0,0,1,0,1.73242l-9,5.19726A1.00211,1.00211,0,0,1,12,14.19531Z"></path><path class="uim-tertiary" d="M21.5,11.13184,19.53589,9.99847,12.5,14.06152a1.0012,1.0012,0,0,1-1,0L4.46411,9.99847,2.5,11.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path><path class="uim-primary" d="M21.5,15.13184l-1.96411-1.13337L12.5,18.06152a1.0012,1.0012,0,0,1-1,0L4.46411,13.99847,2.5,15.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path></svg></span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="no-padding no-margin">
                    <label>Catatan:</label>
                <div class="border p-2 border-radius-5">
                    <p>' . $note . '</p>
                </div>
            </div>
        </div>
        <div class="col-md-12 text-center p-2">
            <button class="btn btn-primary btn-block btn_save_payment" data-id="' . $this->encrypt->encode($id) . '">Simpan Pembayaran</button>
        </div>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save_payment()
    {
        $this->validate_save_payment();
        $id     = $this->encrypt->decode($this->input->post('id'));
        $price  = $this->input->post('price');
        $price  = str_replace('.', '', $price);
        $note   = $this->input->post('note');
        $get_price = $this->db->where(['id' => $id])->get('tb_debt')->row();
        $code = $this->get_payment_code();

        if ($price >= $get_price->rest_debt) {
            $status_payment  = TRUE;
            $rest_payment   = $price - $get_price->rest_debt;
            $rest_debt    = 0;
            $payment_value  = $get_price->rest_debt;
        } else {
            $status_payment  = FALSE;
            $rest_payment   = 0;
            $rest_debt    = $get_price->rest_debt - $price;
            $payment_value  = $get_price->rest_debt - $rest_debt;
        }
        //insert payment
        $array_insert_payment = [
            'code' => $code,
            'id_debt' => $id,
            'debt_price' => $get_price->rest_debt,
            'payment_price' => $payment_value,
            'rest_debt' => $rest_debt,
            'payment_value' => $price,
            'rest_payment_value' => $rest_payment,
            'date' => date('Y-m-d'),
            'note' => $note,
            'status' => $status_payment,
            'created_by' => $this->session->userdata('usr_id')
        ];
        Modules::run('database/insert', 'tb_debt_has_payment', $array_insert_payment);
        //updated debt
        $total_payment = $get_price->price - $rest_debt;
        $array_update_debt = [
            'total_payment' => $total_payment,
            'rest_debt' => $rest_debt,
            'status' => $status_payment,
            'updated_by' => $this->session->userdata('usr_id')
        ];
        Modules::run('database/update', 'tb_debt', ['id' => $id], $array_update_debt);

        //insert to accoutant
        $get_payment_id = $this->db->select('id')->where(['code' => $code])->get('tb_debt_has_payment')->row();
        $get_debt = $this->db->where(['id' => $id])->get('tb_debt')->row();
        $array_insert_accounting = ['total_bayar' => $payment_value, 'id_payment' => $get_payment_id->id, 'kode_hutang' => $get_debt->invoice_code];
        Modules::run('accounting/insert_payment_debt', $array_insert_accounting);

        //create array respon 
        $array_respon = [
            'id_encrypt' => urlencode($this->encrypt->encode($id)),
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function delete_payment()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_payment = $this->db->where(['id' => $id])->get('tb_debt_has_payment')->row();
        $get_debt = $this->db->where(['id' => $get_payment->id_debt])->get('tb_debt')->row();

        $total_payment  = $get_debt->total_payment - $get_payment->payment_value;
        $rest_debt    = $get_debt->rest_debt + $get_payment->payment_value;

        Modules::run('database/delete', 'tb_debt_has_payment', ['id' => $id]);
        Modules::run('database/delete', 'tb_book_account_has_detail', ['id_transaction' => $id, 'status_act' => 6]);
        $array_update = [
            'total_payment' => $total_payment,
            'rest_debt' => $rest_debt
        ];
        Modules::run('database/update', 'tb_debt', ['id' => $get_debt->id], $array_update);
        echo json_encode(['status' => TRUE]);
    }


    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
            tb_debt.*,
            COUNT(tb_debt_has_payment.id) AS count_paid,
            mst_vendor.name AS member_name,
            mst_vendor.name AS member_name,
            st_user.username AS user_name
        ');
        $this->db->from('tb_debt');
        $this->db->join('tb_debt_has_payment', 'tb_debt.id = tb_debt_has_payment.id_debt', 'left');
        $this->db->join('mst_vendor', 'tb_debt.id_vendor = mst_vendor.id  ', 'left');
        $this->db->join('st_user', 'tb_debt.created_by = st_user.id ', 'left');
        $this->db->where(['tb_debt.id' => $id]);
        $this->db->order_by('tb_debt.id', 'DESC');
        $this->db->group_by('tb_debt.id');

        $get_data = $this->db->get()->row();
        $this->app_data['data_debt'] = $get_data;
        //get detail
        $this->db->select('
            tb_debt_has_payment.*,
            st_user.username AS user_name
        ');
        $this->db->from('tb_debt_has_payment');
        $this->db->join('st_user', 'tb_debt_has_payment.created_by = st_user.id', 'left');
        $this->db->where(['tb_debt_has_payment.id_debt' => $id]);
        $get_data_detail = $this->db->get()->result();


        $this->app_data['data_detail'] = $get_data_detail;

        $this->app_data['page_title']     = "Detail Hutang";
        $this->app_data['view_file']     = 'view_detail';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_form_reject()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $this->db->select('
            tb_debt.*,
            COUNT(tb_debt_has_payment.id) AS count_paid,
            tb_member.name AS member_name,
            tb_user.name AS user_name
            ');
        $this->db->from('tb_debt');
        $this->db->join('tb_sales', 'tb_debt.sales_code = tb_sales.code', 'left');
        $this->db->join('tb_debt_has_payment', 'tb_debt.id = tb_debt_has_payment.id_debt', 'left');
        $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
        $this->db->join('tb_user', 'tb_debt.created_by = tb_user.id', 'left');
        $this->db->where(['tb_debt.id' => $id]);
        $this->db->order_by('tb_debt.id', 'DESC');
        $this->db->group_by('tb_debt.id');
        $get_data = $this->db->get()->row();
        $data['data_debt'] = $get_data;

        $html_respon = $this->load->view($this->location . 'form_reject', $data, TRUE);
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function save_reject()
    {
        $id     =  $this->encrypt->decode($this->input->post('id'));
        $note   = $this->input->post('note');
        $array_update = [
            'status' => 2,
            'reject_note' => $note,
            'updated_by' => $this->session->userdata('usr_id')
        ];
        $this->model->update(array('id' => $id), $array_update, 'tb_debt');
        echo json_encode(['status' => TRUE]);
    }
    public function history_debt()
    {
        // $array_status = [
        //     0 => 'Belum Lunas',
        //     1 => 'Telah Lunas',
        //     2 => 'Dibatalkan'
        // ];
        $array_status = [
            0 => 'Belum Lunas',
            1 => 'Telah Lunas'
        ];
        $html_option_status = '<option value="">semua status</option>';
        foreach ($array_status as $key_status => $item_status) {
            $html_option_status .= '<option value="' . $this->encrypt->encode($key_status) . '">' . $item_status . '</option>';
        }
        $this->app_data['html_option_status'] = $html_option_status;

        $this->app_data['page_title']     = "Riwayat Hutang";
        $this->app_data['view_file']     = 'form_history_debt';
        echo Modules::run('template/main_layout', $this->app_data);
    }
    public function validate_get_history_debt()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $type = $this->input->post('type_search');
        if ($type == 1) {
            if ($this->input->post('date_from') == '' && $this->input->post('date_to') == '') {
                $data['error_string'][] = 'salah satu harus diisi';
                $data['inputerror'][] = 'date_from';
                $data['status'] = FALSE;

                $data['error_string'][] = 'salah satu harus diisi';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        } else {
            if ($this->input->post('code') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'code';
                $data['status'] = FALSE;
            }
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function get_history_debt()
    {
        $this->validate_get_history_debt();
        $type_search    = $this->input->post('type_search');
        $type           = $this->input->post('type');
        $code           = $this->input->post('code');
        $status = $this->encrypt->decode($this->input->post('status'));
        $status_expired = $this->input->post('status_expired');


        if ($type_search == 1) {

            $date_from      = $this->input->post('date_from');
            $date_to        = $this->input->post('date_to');

            $date_from_sql = '';
            if ($date_from) {
                $explode_date_from = explode('-', $date_from);
                $date_from_sql = $explode_date_from[2] . '-' . $explode_date_from[1] . '-' . $explode_date_from[0];
                $array_where['tb_debt.date >='] = $date_from_sql;
            }
            $date_to_sql = '';
            if ($date_to) {
                $explode_date_to = explode('-', $date_to);
                $date_to_sql = $explode_date_to[2] . '-' . $explode_date_to[1] . '-' . $explode_date_to[0];
                $array_where['tb_debt.date <='] = $date_to_sql;
            }

            if ($status != '') {
                $array_where['tb_debt.status'] = $status;
            }

            if ($status_expired) {
                if ($status_expired == 1) {
                    $array_where['tb_debt.deadline > '] = date('Y-m-d');
                    $array_where['tb_debt.status'] = 0;
                }

                if ($status_expired == 2) {
                    $array_where['tb_debt.deadline < '] = date('Y-m-d');
                    $array_where['tb_debt.status'] = 0;
                }
            }

            $this->db->select('
            tb_debt.*,
            COUNT(tb_debt_has_payment.id) AS count_paid,
            mst_vendor.name AS member_name,
            mst_vendor.name AS member_name,
            st_user.username AS user_name
            ');
            $this->db->from('tb_debt');
            $this->db->join('tb_debt_has_payment', 'tb_debt.id = tb_debt_has_payment.id_debt', 'left');
            $this->db->join('mst_vendor', 'tb_debt.id_vendor = mst_vendor.id  ', 'left');
            $this->db->join('st_user', 'tb_debt.created_by = st_user.id ', 'left');
            $this->db->where($array_where);
            $this->db->order_by('tb_debt.id', 'DESC');
            $this->db->group_by('tb_debt.id');
            $get_data = $this->db->get()->result();

            $data['data_debt'] = $get_data;
            $data['data_param'] = ['date_from' => $date_from_sql, 'date_to' => $date_to_sql, 'status_lunas' => $status, 'status_expired' => $status_expired];
            $html_respon = $this->load->view('view_search_result_list', $data, TRUE);
        } else {
            //base on code
            $code = $this->input->post('code');
            $id = $this->encrypt->decode($this->input->get('data'));
            $this->db->select('
                tb_debt.*,
                COUNT(tb_debt_has_payment.id) AS count_paid,
                mst_vendor.name AS member_name,
                mst_vendor.name AS member_name,
                st_user.username AS user_name
            ');
            $this->db->from('tb_debt');
            $this->db->join('tb_debt_has_payment', 'tb_debt.id = tb_debt_has_payment.id_debt', 'left');
            $this->db->join('mst_vendor', 'tb_debt.id_vendor = mst_vendor.id  ', 'left');
            $this->db->join('st_user', 'tb_debt.created_by = st_user.id ', 'left');
            $this->db->where(['tb_debt.invoice_code' => $code]);
            $this->db->order_by('tb_debt.id', 'DESC');
            $this->db->group_by('tb_debt.id');

            $get_data = $this->db->get()->row();
            $data['data_debt'] = $get_data;
            //get detail
            $this->db->select('
            tb_debt_has_payment.*,
            st_user.username AS user_name
            ');
            $this->db->from('tb_debt_has_payment');
            $this->db->join('st_user', 'tb_debt_has_payment.created_by = st_user.id', 'left');
            $this->db->where(['tb_debt_has_payment.id_debt' => $get_data->id]);
            $get_data_detail = $this->db->get()->result();

            $data['data_detail'] = $get_data_detail;

            if (empty($get_data)) {
                $html_respon = '
                <div class="bg-empty-data"></div>
                <h3 class="text-center text-muted text-capitalize">data tidak ditemukan</h3>
                <h5 class="text-center mt-10 text-muted">Kode Hutang <b> ' . $code . '</b> Tidak ditemukan</h5>
                ';
            } else {
                $html_respon = $this->load->view('view_search_result_item', $data, TRUE);
            }
        }
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function history_payment()
    {
        $this->app_data['page_title']     = "Riwayat Data Pembayaran";
        $this->app_data['view_file']     = 'form_history_payment';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_history_payment()
    {
        $this->validate_get_history_debt();
        $type_search    = $this->input->post('type_search');
        $type           = $this->input->post('type');
        $code           = $this->input->post('code');
        $status = $this->encrypt->decode($this->input->post('status'));
        $date_from = '';
        $date_to = '';

        if ($type_search == 1) {
            $date_from      = $this->input->post('date_from');
            $date_to        = $this->input->post('date_to');

            $text_title = '';

            $date_from_sql = '';
            if ($date_from) {
                $explode_date_from = explode('-', $date_from);
                $date_from_sql = $explode_date_from[2] . '-' . $explode_date_from[1] . '-' . $explode_date_from[0];
                $array_where['tb_debt_has_payment.date >='] = $date_from_sql;
            }
            $date_to_sql = '';
            if ($date_to) {
                $explode_date_to = explode('-', $date_to);
                $date_to_sql = $explode_date_to[2] . '-' . $explode_date_to[1] . '-' . $explode_date_to[0];
                $array_where['tb_debt_has_payment.date <='] = $date_to_sql;
            }
        } else {
            $array_where = [
                'tb_debt.invoice_code' => $code
            ];
        }
        //get data payment
        $this->db->select(
            '
            tb_debt_has_payment.*,
            tb_debt.price AS price_debt,
            tb_debt.date AS date_debt,
            tb_debt.code AS debt_code,
            tb_debt.invoice_code,
            st_user.username AS user_name
            '
        );
        $this->db->from('tb_debt_has_payment');
        $this->db->join('tb_debt', 'tb_debt_has_payment.id_debt = tb_debt.id', 'left');
        $this->db->join('st_user', 'tb_debt_has_payment.created_by = st_user.id ', 'left');
        $this->db->where($array_where);
        $get_data = $this->db->get()->result();
        $data['data_debt'] = $get_data;
        $data['params'] = ['date_from' => $date_from, 'date_to' => $date_to];
        $html_respon = $this->load->view('view_search_payment_list', $data, TRUE);


        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function print_debt()
    {
        $data_print = $this->encrypt->decode($this->input->post('data'));
        $array_print = json_decode($data_print, TRUE);
        $data_print = $array_print['data_print'];
        $spesification = $array_print['param'];
        $text_title_period = '';

        if ($spesification['date_from']) {
            $text_title_period = 'PER TANGGAL AWAL : ' . Modules::run('helper/date_indo', $spesification['date_from'], '-');
        }

        if ($spesification['date_to']) {
            $text_title_period = 'PER TANGGAL AKHIR : ' . Modules::run('helper/date_indo', $spesification['date_to']);
        }

        if ($spesification['date_from'] && $spesification['date_to']) {
            $text_title_period = 'PERIODE : ' . Modules::run('helper/date_indo', $spesification['date_from']) . ' s/d ' . Modules::run('helper/date_indo', $spesification['date_to'], '-');
        }


        $data_resume = $array_print['resume'];
        $array_status = [
            0 => 'BELUM LUNAS',
            1 => 'TELAH LUNAS'
        ];
        $status_lunas = isset($array_status[$spesification['status_lunas']]) && $spesification['status_lunas'] != ''  ? $array_status[$spesification['status_lunas']] : 'SEMUA';
        // $status_lunas 


        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('50');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:K2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:K2');
        $sheet->getStyle('A1:K2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:K2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA HUTANG');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:K3');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', $text_title_period . ' | STATUS LUNAS : ' . $status_lunas);
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "F4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE INVOICE');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'VENDOR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'JATUH TEMPO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'TOTAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F4', 'TELAH DIBAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G4', 'JML ANGSURAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H4', 'HUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I4', 'UMUR (hr)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J4', 'STATUS LUNAS');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K4', 'STATUS JATUH TEMPO');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_print as $item_print) {

            $status_lunas_text = $item_print['status_lunas'] ? 'LUNAS' : 'BELUM LUNAS';

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['invoice_code']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $item_print['tgl_hutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($item_print['customer']));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $item_print['tgl_jatuh_tempo']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['total_hutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $item_print['total_bayar']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $item_print['total_angsuran']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $item_print['sisa_hutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume,  $item_print['usia']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $status_lunas_text);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $sheet_number_resume, $item_print['status_jatuh_tempo']);

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $sheet->mergeCells('A' . $sheet_number_resume . ':D' . $sheet_number_resume);
        $sheet->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'RESUME');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_resume['total_hutang']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_resume['telah_bayar']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_resume['jumlah_angsuran']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_resume['belum_bayar']);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->getFont()->setBold(true);

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA HUTANG  ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_list_data()
    {

        $this->db->select('
            tb_debt.*,
            COUNT(tb_debt_has_payment.id) AS count_paid,
            mst_vendor.name AS member_name,
            mst_vendor.name AS member_name,
            st_user.username AS user_name
            ');
        $this->db->from('tb_debt');
        $this->db->join('tb_debt_has_payment', 'tb_debt.id = tb_debt_has_payment.id_debt', 'left');
        $this->db->join('mst_vendor', 'tb_debt.id_vendor = mst_vendor.id  ', 'left');
        $this->db->join('st_user', 'tb_debt.created_by = st_user.id ', 'left');
        $this->db->where(['tb_debt.status' => 0]);
        $this->db->order_by('tb_debt.id', 'DESC');
        $this->db->group_by('tb_debt.id');
        $get_data = $this->db->get()->result();

        $text_title_period = 'PER TANGGAL AKHIR : ' . Modules::run('helper/date_indo', date('Y-m-d'), '-');

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('50');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:K2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:K2');
        $sheet->getStyle('A1:K2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:K2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA HUTANG');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:K3');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', $text_title_period . ' | STATUS LUNAS : BELUM LUNAS');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "F4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE INVOICE');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'VENDOR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'JATUH TEMPO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'TOTAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F4', 'TELAH DIBAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G4', 'JML ANGSURAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H4', 'HUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I4', 'UMUR (hr)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J4', 'STATUS LUNAS');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K4', 'STATUS JATUH TEMPO');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        $total_hutang = 0;
        $total_bayar = 0;
        $jumlah_angsuran = 0;
        $total_sisa = 0;

        foreach ($get_data as $data_table) {
            $status_lunas_text = $data_table->status ? 'LUNAS' : 'BELUM LUNAS';
            $status_jatuh_tempo = '';
            if (strtotime($data_table->deadline) <= strtotime(date('Y-m-d'))) {
                $status_jatuh_tempo = $data_table->status ? '-' : 'Telah Jatuh Tempo';
            } else {
                $status_jatuh_tempo = $data_table->status ? '-' : 'Belum Jatuh Tempo';
            }

            $tgl1 = strtotime($data_table->date);
            $tgl2 = strtotime(date('Y-m-d'));
            $jarak = $tgl2 - $tgl1;
            $hari = $jarak / 60 / 60 / 24;

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $data_table->invoice_code);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->date);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($data_table->member_name));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->deadline);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->price);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->total_payment);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_table->count_paid);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->rest_debt);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume,  $hari);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $status_lunas_text);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $sheet_number_resume, $status_jatuh_tempo);

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);

            $total_hutang += $data_table->price;
            $total_bayar += $data_table->total_payment;
            $jumlah_angsuran += $data_table->count_paid;
            $total_sisa += $data_table->rest_debt;
        }
        $sheet_number_resume++;
        $sheet->mergeCells('A' . $sheet_number_resume . ':D' . $sheet_number_resume);
        $sheet->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'RESUME');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $total_hutang);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $total_bayar);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $jumlah_angsuran);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $total_sisa);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->getFont()->setBold(true);


        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA HUTANG  ' . $text_title_period . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_payment()
    {
        $data = json_decode($this->encrypt->decode($this->input->post('data_print')), TRUE);
        $data_print = $data['data_print'];
        $spesification = $data['param'];



        $text_title_period = '';


        if ($spesification['date_from']) {
            $text_title_period = 'PER TANGGAL AWAL : ' . $spesification['date_from'];
        }

        if ($spesification['date_to']) {
            $text_title_period = 'PER TANGGAL AKHIR : ' . $spesification['date_to'];
        }
        if ($spesification['date_from'] && $spesification['date_to']) {
            $text_title_period = 'PERIODE : ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'];
        }

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('50');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:K2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:H2');
        $sheet->getStyle('A1:H2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:H2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA HUTANG');
        $sheet->getStyle('A3:H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:H3');
        $sheet->getStyle('A3:H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', $text_title_period);
        $sheet->getStyle('A3:H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "H4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE INVOICE');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL HUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'TOTAL HUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'SISA HUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'PEMBAYARAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F4', 'SISA HUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G4', 'TANGGAL BAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H4', 'STATUS HUTANG');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':H' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':H' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_print as $item_print) {

            // $status_lunas_text = $item_print['status_lunas'] ? 'LUNAS' : 'BELUM LUNAS';

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['invoice']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $item_print['tanggal_hutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume,  $item_print['total_hutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $item_print['sisa_hutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['jumlah_bayar']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $item_print['sisa_tanggugan']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $item_print['tanggal_bayar']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $item_print['status_hutang']);

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':H' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA HUTANG  ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function import()
    {
        $data['view_file']      = "form_import";
        $data['title']          = "Import Hutang"; // untuk header pada bagian atas data
        $data['subtitle']       = "Import Hutang"; // untuk subtitle pada bagian atas data
        $data['module']         = $this->module; //variable module untuk di controller template/media   
        $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        $data['page_title']     = 'Import Hutang'; // untuk title pada tab

        echo modules::run('template/media_admin', $data);
    }

    public function validate_do_import_data()
    {
        Modules::run('security/is_ajax');
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->encrypt->decode($this->input->post('id'));
        if ($_FILES['upload']['name'] == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'upload';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    private function do_upload_file()
    {
        $config['upload_path']          = realpath(APPPATH . '../uploads/about');
        $config['allowed_types']        = 'csv';
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('upload')) //upload and validate
        {
            $data['inputerror'][] = 'upload';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            return $this->upload->data('file_name');
        }
    }

    public function do_import_data()
    {
        $file_name = $this->do_upload_file();
        $file_content = fopen('uploads/about/' . $file_name, "r");
        $counter = 0;
        $array_data_csv = [];
        while (($data_csv = fgetcsv($file_content, 1000, ",")) !== FALSE) {

            $counter++;
            if ($counter == 1) {
                continue;
            }
            if ($data_csv[0] == '') {
                continue;
            }

            $invoice_code = $data_csv[0];
            $invoice_date = $data_csv[1];
            $customer     = $data_csv[2];
            $due_date     = $data_csv[3];
            $price        = $data_csv[4];
            $rest_price   = $data_csv[5];

            $id_customer = 0;
            $get_member = $this->db->where(['nama' => $customer])->get('mst_vendor')->row();
            if (!empty($get_member)) {
                $id_customer = $get_member->Idcust;
            }

            $array_data_csv[] = [
                'invoice_code' => $invoice_code,
                'invoice_date' => $invoice_date,
                'customer' => $customer,
                'id_customer' => $id_customer,
                'due_date' => $due_date,
                'price' => $price,
                'rest_price' => $rest_price
            ];
        }
        $data['data_csv'] = $array_data_csv;
        $html_respon = $this->load->view('view_import_result', $data, TRUE);


        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save_import_data()
    {
        Modules::run('security/is_ajax');
        $data_csv = json_decode($this->encrypt->decode($this->input->post('data')));
        foreach ($data_csv as $item_csv) {
            $code = $this->get_code();
            $description = 'Import Manual tanggal ' . date('d-m-Y') . '. Hutang AN: ' . $item_csv->customer;

            $check_invoice = $this->db->where(['invoice_code' => $item_csv->invoice_code])->get('tb_debt')->row();
            if (!empty($check_invoice)) {
                continue;
            }
            $array_insert = [
                'invoice_code' => $item_csv->invoice_code,
                'code' => $code,
                'description' => $description,
                'price' => $item_csv->price,
                'total_payment' => ($item_csv->price - $item_csv->rest_price),
                'rest_debt' => $item_csv->rest_price,
                'date' => $item_csv->invoice_date,
                'deadline' => $item_csv->due_date,
                'id_customer' => $item_csv->id_customer
            ];
            Modules::run('database/insert', 'tb_debt', $array_insert);
        }
        echo json_encode(['status' => TRUE]);
    }


    // ================================================= API FUNCTION ==============================================
    public function insert_debt($data)
    {
        $code = $this->get_code();

        //['invoice','','deskripsi','hutang','tanggal_hutang','tanggal_jatuh_tempo','id_vendor']
        $invoice        = isset($data['invoice']) ? $data['invoice'] : '';
        $id_vendor      = isset($data['id_vendor']) ? $data['id_vendor'] : '';
        $hutang         = isset($data['hutang']) ? $data['hutang'] : '';
        $tanggal_hutang = isset($data['tanggal_hutang']) ? $data['tanggal_hutang'] : '';
        $tanggal_jatuh_tempo    = isset($data['tanggal_jatuh_tempo']) ? $data['tanggal_jatuh_tempo'] : '';
        $deskripsi              = isset($data['deskripsi']) ? $data['deskripsi'] : '';
        $id_transaction         = isset($data['id_transaksi']) ? $data['id_transaksi'] : 0;
        $category_transaction   = isset($data['kategori_transaksi']) ? $data['kategori_transaksi'] : 0;

        $array_insert = [
            'invoice_code' => $invoice,
            'code' => $code,
            'description' => $deskripsi,
            'price' => $hutang,
            'rest_debt' => $hutang,
            'date' => $tanggal_hutang,
            'deadline' => $tanggal_jatuh_tempo,
            'id_vendor' => $id_vendor,
            'id_transaction' => $id_transaction,
            'category_transaction' => $category_transaction,
        ];
        Modules::run('database/insert', 'tb_debt', $array_insert);
    }

    public function delete_debt($data)
    {
        $id_transaction         = isset($data['id_transaksi']) ? $data['id_transaksi'] : 0;
        $category_transaction   = isset($data['kategori_transaksi']) ? $data['kategori_transaksi'] : 0;

        Modules::run('database/delete', 'tb_debt', [
            'id_transaction' => $id_transaction,
            'category_transaction' => $category_transaction
        ]);
    }

    public function test()
    {
        $data = [
            'invoice' => 'S-909-09090',
            'id_vendor' => 90,
            'hutang' => 9000000,
            'tanggal_hutang' => date('Y-m-d'),
            'tanggal_jatuh_tempo' => date('Y-m-d'),
            'deskripsi' => 'hutang pembelian barang',
        ];
        echo Modules::run('debt/insert_debt', $data);
    }
}
