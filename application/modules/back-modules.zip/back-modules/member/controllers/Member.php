<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Member extends BackendController
{
    var $module_name        = 'member';
    var $module_directory   = 'member';
    var $module_js          = ['member'];
    var $app_data           = [];

    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }
    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['member_type'] = $this->db->where(['type' => 1])->get('tb_member_category')->result();
        $this->app_data['member_class'] = $this->db->where(['type' => 2])->get('tb_member_category')->result();

        $this->app_data['page_title']   = 'Data Member';
        $this->app_data['view_file']    = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function list_data()
    {
        $get_all_data = $this->db->query("select * from tb_member order by id DESC");

        $this->db->select('tb_member.*,tb_member_category.name AS category_name');
        $this->db->from('tb_member');
        $this->db->join('tb_member_category', 'tb_member.id_category_member = tb_member_category.id', 'left');
        $this->db->order_by('tb_member.id', 'DESC');
        $get_all_data = $this->db->get();



        $data = array();
        $no = 0;
        foreach ($get_all_data->result() as $data_table) {
            $no++;
            //create date 
            $date_explode = explode('-', $data_table->date);
            $date_view = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];

            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->name;
            $row[] = $data_table->number_phone;
            $row[] = $data_table->address;
            $row[] = $data_table->max_due_date . ' HARI';
            $row[] = number_format($data_table->max_debt, 0, '.', '.');
            $row[] = number_format($data_table->point, 0, '.', '.');
            $row[] = number_format($data_table->total_deposito, 0, '.', '.');
            $row[] = $data_table->category_name;
            $row[] = $date_view;
            $row[] = '<a class="btn btn-sm btn-primary-gradient" href="javascript:void(0)" title="Edit" onclick="edit_member(' . "'" . $data_table->id . "'" . ')"><i class="glyphicon glyphicon-pencil"></i> edit</a>
				  <a class="btn btn-sm btn-danger-gradient btn-rounded" href="javascript:void(0)" title="Hapus" onclick="delete_member(' . "'" . $data_table->id . "'" . ')"><i class="glyphicon glyphicon-trash"></i> delete</a>';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }
        if (strlen($this->input->post('no_hp')) < 10 or strlen($this->input->post('no_hp')) > 13) {
            $data['error_string'][] = 'jumlah nomor telfon salah';
            $data['inputerror'][] = 'no_hp';
            $data['status'] = FALSE;
        }
        if ($this->input->post('no_hp') == '') {
            $data['error_string'][] = 'nomor telefon harus diisi';
            $data['inputerror'][] = 'no_hp';
            $data['status'] = FALSE;
        } else {
            $get_data = $this->db->where(['number_phone' => $this->input->post('no_hp')])->get('tb_member')->row();
            if (!empty($get_data)) {
                $data['error_string'][] = 'nomor telefon talah dipakai';
                $data['inputerror'][] = 'no_hp';
                $data['status'] = FALSE;
            }
        }

        if ($this->input->post('address') == '') {
            $data['error_string'][] = 'alamat harus diisi';
            $data['inputerror'][] = 'address';
            $data['status'] = FALSE;
        }

        if ($this->input->post('max_debt') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'max_debt';
            $data['status'] = FALSE;
        }
        if ($this->input->post('max_due_date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'max_due_date';
            $data['status'] = FALSE;
        }


        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {

        $this->validate_insert();
        $code         = '';
        $member_category         = $this->input->post('member_category');
        $max_debt         = $this->input->post('max_debt');
        $max_due_date         = $this->input->post('max_due_date');
        $name         = $this->input->post('name');
        $address     = $this->input->post('address');
        $no_hp         = $this->input->post('no_hp');
        $username   = $no_hp;
        $password = 'member';
        $password = hash('sha512', $password . config_item('encryption_key'));

        //insert data
        $array_insert = array(
            'code' => $code,
            'id_category_member' => $member_category,
            'name' => $name,
            'address' => $address,
            'number_phone' => $no_hp,
            'max_debt' => $max_debt,
            'max_due_date' => $max_due_date,
            'date' => date('Y-m-d'),
            'username' => $username,
            'password' => $password,
            'created_by' => $this->session->userdata('us_id')
        );
        // $this->model->insert($this->tb_name, $array_insert);
        Modules::run('database/insert', 'tb_member', $array_insert);
        //this code for cashier
        $get_data_current = $this->db->query("select id from tb_member where code = '$code' ")->row_array();
        echo json_encode(array('status' => TRUE, 'id_member' => $get_data_current['id']));
    }

    public function get_edit($id)
    {
        $get_data = $this->model->find(array('id' => $id), $this->tb_name)->row_array();
        echo json_encode($get_data);
    }
    public function update()
    {
        $this->validate_insert();
        $id         = $this->input->post('id');
        $name         = $this->input->post('name');
        $address     = $this->input->post('address');
        $no_hp         = $this->input->post('no_hp');
        $member_category         = $this->input->post('member_category');
        $max_debt         = $this->input->post('max_debt');
        $max_due_date         = $this->input->post('max_due_date');
        //insert data
        $array_update = array(
            'name' => $name,
            'address' => $address,
            'number_phone' => $no_hp,
            'date' => date('Y-m-d'),
            'max_debt' => $max_debt,
            'max_due_date' => $max_due_date,
            'id_category_member' => $member_category,
            'updated_by' => $this->session->userdata('us_id')
        );
        $this->model->update(array('id' => $id), $array_update, $this->tb_name);
        echo json_encode(array('status' => TRUE));
    }
    public function delete($id)
    {
        $this->model->delete(array('id' => $id), $this->tb_name);
        echo json_encode(array('status' => TRUE));
    }
}
