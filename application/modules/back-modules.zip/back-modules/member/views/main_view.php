<div class="row">
    <div class="col-lg-12 col-xl-12 col-md-12 container_list">
        <div class="card">
            <div class="card-body">
                <div class="mb-3 row">
                    <h3 class="col-md-8 text-uppercase">DAFTAR CUSTOMER</h3>
                    <div class="col-md-4 text-right">
                        <?= Modules::run('security/create_access', '<a href="javascript:void(0)" id="add_button" title="add data" class="btn btn-primary btn-rounded" onclick="add_user()"> <i class="fa fa-plus-circle"></i> Tambah Data</a>'); ?>
                    </div>
                </div>
                <div class="table-responsive border-top userlist-table">
                    <table id="table_user" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>No.telp</th>
                                <th>Alamat</th>
                                <th>Batas Jatuh Tempo</th>
                                <th>Batas Hutang</th>
                                <th>Point Pembelian</th>
                                <th>Saldo Deposito</th>
                                <th>Kategori Member</th>
                                <th>Tanggal Daftar</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <div class="text-right pt-3">
                    <form class="form-print" method="POST" action="<?= Modules::run('helper/create_url', 'division/print'); ?>">
                        <small>(*klik untuk export)</small>
                        <button type="submit" name="print_excel" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-excel"></i> Cetak Excel</button>
                        <button type="submit" name="print_pdf" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-pdf"></i> Cetak PDF</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- end main content-->

<div class="modal" id="modal_member">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <form role="form" id="form_member">
                    <input type="hidden" name="id">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Kategori Member</label>
                            <select name="member_category" class="form-control">
                                <?php
                                foreach ($data_category_member as $item_member_category) {
                                    echo '<option value="' . $item_member_category->id . '">' . $item_member_category->name . '</option>';
                                }
                                ?>
                            </select>
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="masukan nama..">
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nomor HP</label>
                            <input type="text" class="form-control" name="no_hp" id="no_hp" onkeyup="number_only('no_hp')" maxlength="13" placeholder="masukan nama..">
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Alamat</label>
                            <textarea class="form-control" name="address"></textarea>
                            <span class="help-block"></span>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Jumlah Maksimal Hutang (Rp)</label>
                            <input type="text" class="form-control" name="max_debt" id="max_debt" onkeyup="number_only('max_debt')" maxlength="13" placeholder="masukan maksimal Hutang..">
                            <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Jumlah Maksimal jatuh tempo (Hari)</label>
                            <input type="text" class="form-control" name="max_due_date" id="max_due_date" onkeyup="number_only('max_due_date')" maxlength="13" placeholder="masukan maksimal jatuh tempo..">
                            <span class="help-block"></span>
                        </div>
                        <div class="card-footer">
                            <button type="button" onclick="save()" class="btn btn-lg btn-primary pull-right"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>