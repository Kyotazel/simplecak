var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var id_use = 0;
var table;



$(document).ready(function() {
    table = $('#table_user').DataTable({
        "ajax": {
            "url": url_controller + "list_data",
            "type": "POST"
        }
    });
})
//end document ready 

function reload_table() {
    table.ajax.reload(null, false); //reload datatable ajax 
}

function add_user() {
    save_method = 'add'
    $('#form_member')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('.modal-title').text('Form Member');
    $('#modal_member').modal('show');
}

function save() {
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    showLoading();
    var url;
    if (save_method == 'add') {
        url = url_controller + "save";
    } else {
        url = url_controller + "update";
    }
    //defined form
    var formData = new FormData($('#form_member')[0]);
    $.ajax({
        url: url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                // $('#modal_user').modal('hide');
                $('#modal_member').modal('hide');
                hideLoading();
                reload_table();
                show_success_message('data berhasil disimpan!');
            } else {
                hideLoading();
                $('#modal_member').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }

        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('error process');
        }

    });

}

function edit_member(id) {
    $('.help-block').empty();
    save_method = 'update';
    $('.form_title').text('update member');
    $('#form_member')[0].reset();
    $('.form-group').removeClass('has-error');
    $('help-block').empty();
    // $('.not-update').empty();
    // var urlupdate = url_controller+""
    $.ajax({
        url: url_controller + "get_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            $('[name="id"]').val(data.id);
            $('[name="name"]').val(data.name);
            $('[name="no_hp"]').val(data.number_phone);
            $('[name="address"]').val(data.address);
            $('[name="member_category"]').val(data.id_category_member);
            $('[name="max_debt"]').val(data.max_debt);
            $('[name="max_due_date"]').val(data.max_due_date);
            $('#modal_member').modal('show');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('error process');
        }
    });
}



function delete_member(id) {
    if (confirm('Are you sure delete this data?')) {
        showLoading();
        // ajax delete data to database
        $.ajax({
            url: url_controller + "delete/" + id,
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                //if success
                hideLoading();
                reload_table();
                show_success_message('data berhasil dihapus..!');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('Error deleting data');
            }
        });

    }
}


$('.btn_syncron').click(function() {
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "pastikan device tetap terhubung internet",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $('#modal-form').modal('show');
            $.ajax({
                url: base + 'syncron_database/do_syncron_member',
                type: "POST",
                dataType: "JSON",
                success: function(data) {
                    if (data.status) {
                        $('.text-last-update').text(data.last_update);
                        Swal.fire(
                            'SUCCESS!',
                            'Sinkronisasi database telah selesai!',
                            'success'
                        );
                        $('#modal-form').modal('hide');

                    } else {
                        $('#modal-form').modal('hide');
                        Swal.fire(
                            'NO INTERNET CONNECTION',
                            'Koneksi Internet Tidak Tersedia',
                            'error'
                        );
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    $('#modal-form').modal('hide');
                    show_error_message('something wrong');
                }
            }); //end ajax
        }
    });
});

//additional function
function number_only(id_name) {
    var qty = $("#" + id_name).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $("#" + id_name).val(clean_word);
}