<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Employee extends BackendController
{
    var $module_name        = 'employee';
    var $module_directory   = 'employee';
    var $module_js          = ['employee'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['position_employee'] = Modules::run('database/find', 'mst_employee_position', ['isDeleted' => 'N'])->result();
        $this->app_data['division_employee'] = Modules::run('database/find', 'mst_employee_division', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "Data Pegawai";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        Modules::run('security/is_ajax');

        $position_search = $this->input->post('position_search');
        $division_search = $this->input->post('division_search');
        $array_where['mst_employee.isDeleted'] = 'N';
        $array_where_in = [];
        if (!empty($position_search)) {
            $array_where_in['mst_employee.id_mst_position'] = $position_search;
        }
        if (!empty($division_search)) {
            $array_where_in['mst_employee.id_mst_division'] = $division_search;
        }
        $array_search = [
            'position_search' => $position_search,
            'division_search' => $division_search
        ];
        $array_query = [
            'select' => '
                mst_employee.*,
                mst_employee_division.name AS division_name,
                mst_employee_position.name AS position_name
            ',
            'from' => 'mst_employee',
            'join' => [
                'mst_employee_division, mst_employee.id_mst_division = mst_employee_division.id, left',
                'mst_employee_position, mst_employee.id_mst_position = mst_employee_position.id, left'
            ],
            'where' => $array_where,
            'order_by' => 'mst_employee.id, DESC'
        ];
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }

        $get_data = Modules::run('database/get', $array_query)->result();
        $no = 0;
        $data = [];
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $btn_delete     = Modules::run('security/delete_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-danger btn_delete"><i class="las la-trash"></i> </a>');
            $btn_edit     = Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-info btn_edit"><i class="las la-pen"></i> </a>');
            $active = $data_table->isActive == 'Y' ? 'on' : '';

            $image = $data_table->image ? base_url('upload/employee/' . $data_table->image) : base_url('assets/themes/valex/img/faces/3.jpg');
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = '
                    <div class="main-img-user avatar-md d-block">
                        <img alt="avatar" class="rounded-circle" src="' . $image . '">
                    </div>
                ';
            $row[] = '<label class="m-0 text-bold text-capitalize">' . $data_table->name . '</label> <br><small class="p-1 border d-block mt-1 rounded">' . $data_table->employee_number . '</small> ';
            $row[] = $data_table->birth_place . ' , ' . Modules::run('helper/date_indo', $data_table->birth_date, '-');
            $row[] = $data_table->email;
            $row[] = $data_table->number_phone;
            $row[] = $data_table->address;
            $row[] =  '<span class="badge badge-info">' . $data_table->position_name . '</span>';
            $row[] = '<span class="badge badge-info">' . $data_table->division_name . '</span>';
            $row[] = '
                        <div class="main-toggle-group-demo">
                            <div data-id="' . $data_table->id . '" class="main-toggle main-toggle-dark change_status ' . $active . '"><span></span></div>
                        </div>
                    ';
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );

        $array_respon = ['search' => $this->encrypt->encode(json_encode($array_search)), 'list' => $ouput];

        echo json_encode($array_respon);
    }


    private function validate_save()
    {
        Modules::run('security/is_ajax');
        $data = array();

        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->input->post('id');
        if ($this->input->post('code') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'code';
            $data['status'] = FALSE;
        } else {
            if (strlen($this->input->post('code')) < 5) {
                $data['error_string'][] = 'min 5 karakter';
                $data['inputerror'][] = 'code';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }
        if ($this->input->post('birth_place') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'birth_place';
            $data['status'] = FALSE;
        }
        if ($this->input->post('birth_date') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'birth_date';
            $data['status'] = FALSE;
        }
        if ($this->input->post('position') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'position';
            $data['status'] = FALSE;
        }
        if ($this->input->post('division') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'division';
            $data['status'] = FALSE;
        }
        if ($this->input->post('address') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'address';
            $data['status'] = FALSE;
        }
        if ($this->input->post('number_phone') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'number_phone';
            $data['status'] = FALSE;
        }
        if ($this->input->post('email') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'email';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_save();
        $code    = $this->input->post('code');
        $name    = $this->input->post('name');
        $birth_place    = $this->input->post('birth_place');
        $birth_date    = Modules::run('helper/change_date', $this->input->post('birth_date'), '-');
        $position    = $this->input->post('position');
        $division    = $this->input->post('division');
        $address    = $this->input->post('address');
        $number_phone    = $this->input->post('number_phone');
        $email    = $this->input->post('email');
        $active_status    = $this->input->post('active_status');

        $array_insert = [
            'id_mst_position' => $position,
            'id_mst_division' => $division,
            'employee_number' => $code,
            'name' => $name,
            'birth_date' => $birth_date,
            'birth_place' => $birth_place,
            'email' => $email,
            'number_phone' => $number_phone,
            'address' => $address,
            'isActive' => $active_status,
            'created_by' => $this->session->userdata('us_id')
        ];

        if ($_FILES['media']['name'] != '') {
            $array_insert['image'] = $this->upload_image();
        }

        Modules::run('database/insert', 'mst_employee', $array_insert);
        echo json_encode(['status' => true]);
    }

    public function get_data()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_data = Modules::run('database/find', 'mst_employee', ['id' => $id])->row();
        $get_data->birth_date = Modules::run('helper/change_date', $get_data->birth_date, '-');
        echo json_encode($get_data);
    }

    private function upload_image()
    {
        $config['upload_path']          = realpath(APPPATH . '../upload/employee');
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('media')) //upload and validate
        {
            $data['inputerror'][] = 'upload_banner';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            $upload_data = $this->upload->data();
            $image_name = $upload_data['file_name'];
            return $image_name;
        }
    }

    public function update()
    {
        Modules::run('security/is_ajax');
        $this->validate_save();

        $id     = $this->input->post('id');
        $code    = $this->input->post('code');
        $name    = $this->input->post('name');
        $birth_place    = $this->input->post('birth_place');
        $birth_date    = Modules::run('helper/change_date', $this->input->post('birth_date'), '-');
        $position    = $this->input->post('position');
        $division    = $this->input->post('division');
        $address    = $this->input->post('address');
        $number_phone    = $this->input->post('number_phone');
        $email    = $this->input->post('email');
        $active_status    = $this->input->post('active_status');

        $array_update = [
            'id_mst_position' => $position,
            'id_mst_division' => $division,
            'employee_number' => $code,
            'name' => $name,
            'birth_date' => $birth_date,
            'birth_place' => $birth_place,
            'email' => $email,
            'number_phone' => $number_phone,
            'address' => $address,
            'isActive' => $active_status,
            'updated_by' => $this->session->userdata('us_id')
        ];

        if ($_FILES['media']['name'] != '') {
            $array_update['image'] = $this->upload_image();
        }

        Modules::run('database/update', 'mst_employee', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }

    public function delete_data()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        $array_update = ['isDeleted' => 'Y'];
        Modules::run('database/update', 'mst_employee', ['id' => $id], $array_update);
        echo json_encode(['status' => true]);
    }

    public function update_status()
    {
        Modules::run('security/is_ajax');
        $status = $this->input->post('status') ? 'Y' : 'N';
        $id = $this->input->post('id');

        Modules::run('database/update', 'mst_employee', ['id' => $id], ['isActive' => $status]);
        echo json_encode(['status' => TRUE]);
    }


    public function print()
    {
        $encrypt_data_search = $this->encrypt->decode($this->input->post('search'));
        $data_search = json_decode($encrypt_data_search);


        $position_search = $data_search->position_search;
        $division_search = $data_search->division_search;
        $array_where['mst_employee.isDeleted'] = 'N';
        $array_where_in = [];
        if (!empty($position_search)) {
            $array_where_in['mst_employee.id_mst_position'] = $position_search;
        }
        if (!empty($division_search)) {
            $array_where_in['mst_employee.id_mst_division'] = $division_search;
        }
        $array_query = [
            'select' => '
                mst_employee.*,
                mst_employee_division.name AS division_name,
                mst_employee_position.name AS position_name
            ',
            'from' => 'mst_employee',
            'join' => [
                'mst_employee_division, mst_employee.id_mst_division = mst_employee_division.id, left',
                'mst_employee_position, mst_employee.id_mst_position = mst_employee_position.id, left'
            ],
            'where' => $array_where,
            'order_by' => 'mst_employee.id, DESC'
        ];
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }
        $get_data = Modules::run('database/get', $array_query)->result();

        if ($this->input->post('print_excel')) {
            $this->export_excel($get_data);
        }
        if ($this->input->post('print_pdf')) {
            $this->export_pdf($get_data);
        }
    }

    public function export_excel($data)
    {
        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('5');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('30');
        $sheet->getColumnDimension('D')->setWidth('30');
        $sheet->getColumnDimension('E')->setWidth('25');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('40');
        $sheet->getColumnDimension('H')->setWidth('15');
        $sheet->getColumnDimension('I')->setWidth('15');
        $sheet->getColumnDimension('J')->setWidth('10');

        //bold style 
        $sheet->getStyle("A1:J2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:J2');
        $sheet->getStyle('A1:J2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:J2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA PEGAWAI');
        $sheet->getStyle('A3:J3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A3"; // or any value
        $to = "J3"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'NO.PEGAWAI');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'NAMA LENGKAP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'TTL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'EMAIL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'NO.TELP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G3', 'ALAMAT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H3', 'JABATAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I3', 'DIVISI');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J3', 'STATUS');
        $sheet_number_resume = 3;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data as $data_table) {
            $active = $data_table->isActive == 'Y' ? 'Aktif' : 'Non-Aktif';
            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->employee_number);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_table->name);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume,  $data_table->birth_place . ' , ' . Modules::run('helper/date_indo', $data_table->birth_date, '-'));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->email);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->number_phone);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_table->address);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->position_name);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume, $data_table->division_name);

            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $active);
            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA PEGAWAI PER ' . date('d-m-Y') . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function export_pdf($data_countainer)
    {
        error_reporting(0);
        ob_clean();
        $data['data_employee'] = $data_countainer;
        //print_r($data['data_profile']);
        //exit;
        ob_start();
        $this->load->view('pdf_employee', $data);
        //print_r($html);
        //exit;
        $html = ob_get_contents();
        ob_end_clean();
        require_once('../assets/plugin/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('L', 'A4', 'en', true, 'UTF-8', array(5, 5, 5, 5));
        $pdf->WriteHTML($html);
        $pdf->Output('LAPORAN DATA PEGAWAI PER -' . date('d-m-Y') . '.pdf', 'D');
    }
}
