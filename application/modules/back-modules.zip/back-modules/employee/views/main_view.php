<div class="row">
    <div class="col-lg-12 col-xl-12 col-md-12 container_list">
        <div class="card">
            <div class="card-body">
                <div class="mb-3 row">
                    <h3 class="col-md-8">DAFTAR PEGAWAI</h3>
                    <div class="col-md-4 text-right">
                        <?= Modules::run('security/create_access', '<a href="javascript:void(0)" class="btn btn-primary-gradient btn_add"> <i class="fa fa-plus-circle"></i> Tambah Data</a>'); ?>
                    </div>
                </div>
                <form class="form-search">
                    <div class="row border pt-2 pb-2 rounded">
                        <div class="col-md-4">
                            <label for="">Jabatan Pegawai</label>
                            <select name="position_search[]" class="form-control" id="employee_position" multiple>
                                <?php
                                foreach ($position_employee as $item) {
                                    echo '
                                            <option value="' . $item->id . '">' . strtoupper($item->name) . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="">Devisi Pegawai</label>
                            <select name="division_search[]" class="form-control" id="employee_division" multiple>
                                <?php
                                foreach ($division_employee as $item) {
                                    echo '
                                        <option value="' . $item->id . '">' . strtoupper($item->name) . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>

                        <div class="col-md-1">
                            <label for="">&nbsp;</label><br>
                            <button type="submit" class="btn btn-primary btn_search"><i class="mdi mdi-search"></i> Cari</button>
                        </div>

                    </div>
                </form>
                <div class="table-responsive border-top userlist-table mt-2">
                    <table id="table_data" class="table table-bordered dt-responsive nowrap table-hover" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <th style="width: 5%;">No</th>
                            <th>Gambar</th>
                            <th>NAMA LENGKAP</th>
                            <th>TTL</th>
                            <th>EMAIL</th>
                            <th>NO.TELP</th>
                            <th style="width: 25%;">ALAMAT</th>
                            <th>JABATAN</th>
                            <th>DEVISI</th>
                            <th>Status Aktif</th>
                            <th style="width: 10%;"></th>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div class="text-right pt-3">
                    <form class="form-print" method="POST" action="<?= Modules::run('helper/create_url', 'employee/print'); ?>">
                        <small>(*klik untuk export)</small>
                        <button type="submit" name="print_excel" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-excel"></i> Cetak Excel</button>
                        <button type="submit" name="print_pdf" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-pdf"></i> Cetak PDF</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- end main content-->

<div class="modal fade" tabindex="-1" id="modal_form">
    <div class="modal-dialog" style="max-width: 50%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form id="form-data">
                    <input type="hidden" name="id" id="id" />
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label>Upload</label>
                            <input type="file" class="form-control" name="media" />
                            <span class="help-block notif_media"></span>
                        </div>
                        <div class="form-group col-md-8">
                            <label>Nomor Pegawai</label>
                            <input type="text" class="form-control" name="code" />
                            <span class="help-block notif_code"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control" name="name" />
                            <span class="help-block notif_name"></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Tempat lahir</label>
                            <input type="text" class="form-control" name="birth_place" />
                            <span class="help-block notif_birth_place"></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Tanggal lahir</label>
                            <input type="text" readonly class="bg-white form-control datepicker" name="birth_date" />
                            <span class="help-block notif_birth_date"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Jabatan Pegawai</label>
                            <select name="position" class="form-control">
                                <option value="">- PILIH JABATAN -</option>
                                <?php
                                foreach ($position_employee as $item) {
                                    echo '
                                            <option value="' . $item->id . '">' . strtoupper($item->name) . '</option>
                                        ';
                                }
                                ?>
                            </select>
                            <span class="help-block notif_position"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Devisi Pegawai</label>
                            <select name="division" class="form-control">
                                <option value="">- PILIH DEVISI -</option>
                                <?php
                                foreach ($division_employee as $item) {
                                    echo '
                                        <option value="' . $item->id . '">' . strtoupper($item->name) . '</option>
                                        ';
                                }
                                ?>
                            </select>
                            <span class="help-block notif_division"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <label>Alamat</label>
                            <textarea name="address" class="form-control" rows="5"></textarea>
                            <span class="help-block notif_address"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>No.telp</label>
                            <input type="text" class="form-control" name="number_phone" />
                            <span class="help-block notif_number_phone"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Email</label>
                            <input type="text" class="form-control" name="email" />
                            <span class="help-block notif_email"></span>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Status Aktif</label>
                            <select name="active_status" class="form-control">
                                <option value="Y">Aktif</option>
                                <option value="N">Non-Aktif</option>
                            </select>
                            <span class="help-block notif_active_status"></span>
                        </div>
                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success btn_save"><i class="fa fa-save"></i> Simpan Data</button>
            </div>
        </div>
    </div>
</div>