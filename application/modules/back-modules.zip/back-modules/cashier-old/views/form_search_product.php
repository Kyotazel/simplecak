<?php
$status = isset($status_add) ? TRUE : FALSE;
?>
<div class="col-md-12">
    <form class="form-input">
        <div class="col-md-12 row">
            <div class="col-md-3">
                <label>Kategori Produk</label>
                <input type="hidden" name="status" value="<?= $status; ?>">
                <select name="id_category" class="form-control">
                    <option value="">TIDAK ADA</option>
                    <?php
                    foreach ($data_main_category as $item_main_category) {
                        echo '<option value="' . $this->encrypt->encode($item_main_category->id) . '">' . $item_main_category->name . '</option>';
                    }
                    ?>
                </select>
                <span class="help-block" style="color:red;"></span>
            </div>
            <div class="col-md-3">
                <label>Merk</label>
                <select name="id_merk" class="form-control">
                    <option value="">TIDAK ADA</option>
                    <?php
                    foreach ($data_merk as $item_merk) {
                        echo '<option value="' . $this->encrypt->encode($item_merk->id) . '">' . $item_merk->name . '</option>';
                    }
                    ?>
                </select>
                <span class="help-block" style="color:red;"></span>
            </div>
            <div class="col-md-3">
                <label>Barcode</label>
                <input type="text" class="form-control search_product" name="barcode">
                <span class="help-block" style="color:red;"></span>
            </div>
            <div class="col-md-3">
                <label>Nama Produk</label>
                <input type="text" class="form-control search_product" name="name">
                <span class="help-block" style="color:red;"></span>
            </div>
            <span class="clearfix"></span>
            <div class="col-md-12 pull-right text-right" style="padding:0 !important;margin:0 !important;">
                <button type="submit" class="btn btn-rounded btn-primary btn_search"> <i class="fa fa-search"></i> Cari Data </button>
            </div>
        </div>

    </form>
</div>
<!-- /.box-body -->
<span class="clearfix"></span>
<hr>
<div class="html_respon">
    <h1 class="text-center text-gray">ISILAH FORM PENCARIAN TERLEBIH DAHULU</h1>
</div>