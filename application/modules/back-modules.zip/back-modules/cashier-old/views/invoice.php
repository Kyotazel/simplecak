<?php
$company_name    = Modules::run('database/find', 'app_setting', ['field' => 'company_name'])->row()->value;
$company_tagline    = Modules::run('database/find', 'app_setting', ['field' => 'company_tagline'])->row()->value;
$company_email    = Modules::run('database/find', 'app_setting', ['field' => 'company_email'])->row()->value;
$company_address    = Modules::run('database/find', 'app_setting', ['field' => 'company_address'])->row()->value;
$company_number_phone    = Modules::run('database/find', 'app_setting', ['field' => 'company_number_phone'])->row()->value;

$get_ppn        = $this->db->where(['field' => 'tax_ppn'])->get('app_module_setting')->row()->value;
?>
<style>
    #invoice-POS {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, "Times New Roman", Georgia, serif;
        padding-right: 15px;
    }

    p {
        margin: 0;
        padding: 0;
    }

    .itemtext {
        font-size: 10px;
    }

    .small_text {
        font-size: 8px;
    }

    h3,
    h2,
    h5,
    h4 {
        padding: 0;
        margin: 0;
    }

    tr {
        padding: 0px;
        margin: 0px;
        line-height: 13px;
    }
</style>

<div id="invoice-POS">
    <center id="top">
        <div class="logo"></div>
        <div class="info">
            <img style="width:50px !important;" src="<?= base_url('upload/profile/' . $get_profile->image); ?>" alt="">
            <h3><?= $company_name; ?></h3>
            <p class="itemtext">" <?= $company_tagline ?> "</p>
            <p align="center" class="small_text"><?= $company_address . ' | ' . $company_email; ?></p>
        </div>
        <!--End Info-->
    </center>
    <!--End InvoiceTop-->
    <br>

    <div id="mid">
        <div class="info">
            <!-- <p>
                Address : street city, state 0000</br>
                Email : JohnDoe@gmail.com</br>
            </p> -->
            <table>
                <tr>
                    <td width="50px;" class="itemtext">No.Nota</td>
                    <td width="5px" class="itemtext">:</td>
                    <td class="itemtext"><?= $data_sales->code . ' / ' . $data_sales->created_date; ?></td>
                </tr>
                <tr>
                    <td width="50px;" class="itemtext">Kasir</td>
                    <td width="5px" class="itemtext">:</td>
                    <td class="itemtext"><?= $data_sales->user_name; ?></td>
                </tr>
            </table>
        </div>
    </div>
    <!--End Invoice Mid-->
    <div id="bot">
        <div id="table">
            <table style="width: 100%;">
                <tr>
                    <td colspan="2">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <?php
                $counter = 0;
                foreach ($data_detail as $item_detail) {
                    // print_r($item_detail);
                    // exit;
                    $counter++;
                    $product_name = $item_detail->product_name;
                    if ($item_detail->id_conversion_unit) {
                        $qty_unit_sales         = $item_detail->qty % $item_detail->conversion_qty;
                        $conversion_qty_sales   = ($item_detail->qty - $qty_unit_sales) / $item_detail->conversion_qty;
                        $label_qty = '';
                        if ($conversion_qty_sales > 0) {
                            $label_qty .= $conversion_qty_sales . $item_detail->conversion_name;
                        }
                        if ($qty_unit_sales > 0) {
                            $label_qty .= "<br>" . $qty_unit_sales . $item_detail->unit_name;
                        }
                    } else {
                        $label_qty = $item_detail->qty . $item_detail->unit_name;
                    }
                    $price_item = number_format($item_detail->price, 0, '.', '.');
                    $total_price_item = number_format($item_detail->total_price, 0, '.', '.');

                    $additional_price_html = '';
                    if ($item_detail->price < $item_detail->product_price) {
                        $total_discount = ($item_detail->product_price - $item_detail->price) * $item_detail->qty;
                        $additional_price_html = '<br><span style="float:right;">(Hemat ' . number_format($total_discount, 0, '.', '.') . ' )</span>';
                    }


                    $html_item = '
                                    <div>
                                        <span>' . $product_name . '</span><br>
                                        <span>' . number_format($item_detail->price, 0, '.', '.') . ' X ' . $item_detail->qty . '</span>
                                        <span style="float:right;">' . number_format($item_detail->total_price) . ' </span>
                                        ' . $additional_price_html . '
                                    </div>

                                ';

                    echo '
                        <tr class="service">
                            <td class="itemtext" style="width:8px !important;">
                                ' . $counter . '
                            </td>
                            <td class="itemtext">
                                ' . $html_item . '
                            </td>
                        </tr>
                    ';
                }
                ?>


            </table>

            <table style="width: 100%;">
                <?php
                if ($data_sales->credit_status) {
                    echo '
                        <tr>
                            <td colspan="2">
                                <hr style="border-top: 1px dashed black;">
                            </td>
                        </tr>
                        <tr class="service">
                            <td class="tableitem" style="width: 100px;">
                                <p class="itemtext" align="right"><b>Catatan Hutang:</b></p>
                            </td>
                            <td class="tableitem">
                                <p class="itemtext" align="right"></p>
                            </td>
                        </tr>
                        <tr class="service">
                            <td class="tableitem">
                                <p class="itemtext" align="right"><b>Kode Hutang</b></p>
                            </td>
                            <td class="tableitem">
                                <p class="itemtext" align="right">' . $data_sales->credit_code . '</p>
                            </td>
                        </tr>
                        <tr class="service">
                            <td class="tableitem">
                                <p class="itemtext" align="right"><b>Nominal</b></p>
                            </td>
                            <td class="tableitem">
                                <p class="itemtext" align="right">' . number_format($data_sales->credit_price, 0, '.', '.') . '</p>
                            </td>
                        </tr>
                        <tr class="service">
                            <td class="tableitem">
                                <p class="itemtext" align="right"><b>Jatuh Tempo</b></p>
                            </td>
                            <td class="tableitem">
                                <p class="itemtext" align="right">' . $data_sales->credit_deadline . '</p>
                            </td>
                        </tr>
                    ';
                }
                ?>
            </table>

            <table style="width: 100%;">
                <tr>
                    <td colspan="2">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem">
                        <p class="itemtext" align="right"><b>ITEM</b></p>
                    </td>
                    <td class="tableitem" style="width: 100px;">
                        <p class="itemtext" align="right"><?= $data_sales->count_item . ' ITEM'; ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem">
                        <p class="itemtext" align="right"><b>Grand Total</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_sales->grand_total_sales, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem">
                        <p class="itemtext" align="right"><b>PPN (<?= $get_ppn; ?>%)</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_sales->ppn_price, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem">
                        <p class="itemtext" align="right"><b>Bayar</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_sales->payment, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem">
                        <p class="itemtext" style="float:right;"><b>Kembali</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_sales->rest_payment, 0, '.', '.'); ?></p>
                    </td>
                </tr>
            </table>

        </div>
        <!--End Table-->

        <div id="legalcopy" style="margin-top: 20px;">
            <p class="itemtext" align="center">* <?= $get_profile->footer_note; ?> *</p>
        </div>

    </div>
    <!--End InvoiceBot-->
</div>
<!--End Invoice-->