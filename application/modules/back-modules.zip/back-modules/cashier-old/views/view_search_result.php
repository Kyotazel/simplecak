<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table_data">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>barcode</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th>merk</b></th>
                        <th>Satuan</b></th>
                        <th>STOK</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = $start_no;
                    foreach ($data_product as $data_table) {
                        $data_current = $this->encrypt->encode(json_encode($data_table));
                        $no++;
                        if ($status_add) {
                            $html_btn = '<a href="javascript:void(0)" data-id="' . $data_current . '" class="btn btn-default add_cart_product"> <i class="fa fa-shopping-cart"></i> Masukan Keranjang</a>';
                        } else {
                            $html_btn = '';
                        }

                        echo '
                            <tr>
                                <td>' . $no . '</td>
                                <td>' . $data_table->code . '</td>
                                <td>' . $data_table->barcode . '</td>
                                <td>' . $data_table->name . '</td>
                                <td>' . $data_table->main_category_name . '</td>
                                <td>' . $data_table->merk_name . '</td>
                                <td>' . $data_table->unit_name . '</td>
                                <td>' . $data_table->stock . '</td>
                                <td>' . $html_btn . '</td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-4">
                    <!--Tampilkan pagination-->
                    <?php echo $html_pagination; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.box-body -->
</div>