<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cashier extends BackendController
{
    var $module_name        = 'cashier';
    var $module_directory   = 'cashier';
    var $module_js          = ['cashier'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['get_ppn'] = $this->db->where(['field' => 'ppn_tax'])->get('app_module_setting')->row();

        $this->app_data['get_pph'] = $this->db->where(['field' => 'pph_tax'])->get('app_module_setting')->row();
        $this->app_data['code'] = $this->get_code();
        $this->app_data['date_order'] = date('d-m-Y');

        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();

        $this->app_data['page_title'] = "Daftar Produk";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function get_code()
    {
        $number_text = 0;
        $db_name = 'tb_sales';
        $simbol = 'SL';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function get_code_delivery()
    {
        $number_text = 0;
        $db_name = $this->tb_name;
        $simbol = 'DF';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_delivery")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_delivery WHERE id IN(SELECT MAX(id) FROM tb_delivery)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function get_code_credit()
    {
        $number_text = 0;
        $db_name = $this->tb_name;
        $simbol = 'CD';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_credit")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_credit WHERE id IN(SELECT MAX(id) FROM tb_credit)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }


    public function get_product_auto()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $this->db->trans_off();
            $this->db->trans_start();
            $get_data_product = $this->db->query("select 
                a.id, 
                a.name,
                a.price,
                a.main_price,
                a.stock,
                b.name as unit_name,
                c.barcode
                from tb_product a 
                left join tb_unit b on a.id_unit = b.id
                left join tb_barcode_product c on a.id = c.id_product   
                where a.name like '%$term%' OR c.barcode like '%$term%' LIMIT 10 ")->result();
            $this->db->trans_complete();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->name . ' - ' . $data_product->barcode,
                        'id' => $data_product->id,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_barcode_choosen()
    {
        $barcode = $this->input->post('barcode');
        $data_product = $this->db->query("select 
            a.id, 
            a.name,
            a.price,
            a.main_price,
            a.stock,
            b.name as unit_name
            from tb_product a 
            left join tb_unit b on a.id_unit = b.id
            left join tb_barcode_product d on a.id = d.id_product
            where d.barcode = '$barcode' ")->row();

        if (!empty($data_product)) {
            $array_result = array(
                'label' => $data_product->name,
                'id' => $data_product->id,
                'price' => $data_product->price,
                'main_price' => $data_product->main_price,
                'unit_name' => $data_product->unit_name,
                'stock' => $data_product->stock
            );
            $array_respon = [
                'status' => TRUE,
                'item' => $array_result
            ];
        } else {
            $array_respon = [
                'status' => FALSE
            ];
        }
        echo json_encode($array_respon);
    }

    public function get_all_product()
    {
        $data['status_add'] = TRUE;
        $data['data_main_category'] = $this->db->get('tb_main_category')->result();
        $data['data_merk'] = $this->db->get('tb_merk')->result();
        $html_respon = $this->load->view('form_search_product', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function choose_product_cart()
    {
        $data_current = json_decode($this->encrypt->decode($this->input->post('data_current')));

        if (!empty($data_current)) {
            $array_result = array(
                'label' => $data_current->name,
                'id' => $data_current->id,
                'price' => $data_current->price,
                'main_price' => $data_current->main_price,
                'unit_name' => $data_current->unit_name,
                'stock' => $data_current->stock
            );
            $array_respon = [
                'status' => TRUE,
                'item' => $array_result
            ];
        } else {
            $array_respon = [
                'status' => FALSE
            ];
        }
        echo json_encode($array_respon);
    }

    public function get_unit_request()
    {
        $id = $this->input->post('id');
        $get_data_current = $this->db->where(['id' => $id])->get('tb_product')->row();
        $data_unit = $this->db->where(['id' => $get_data_current->id_unit])->get('tb_unit')->row();
        //get other conversion
        $get_all_conversion = $this->db->where(['id_product' => $id])->order_by('qty')->get('tb_product_has_conversion')->result();
        $array_value = [
            'id' => 0,
            'name' => $data_unit->name,
            'qty' => 1
        ];
        $html_option = '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $data_unit->name . '</option>';
        foreach ($get_all_conversion as $item_conversion) {
            $array_value = [
                'id' => $item_conversion->id,
                'name' => $item_conversion->name,
                'qty' => $item_conversion->qty
            ];
            $html_option .= '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $item_conversion->name . '( ' . $item_conversion->qty . ' ' . $data_unit->name . ' )' . '</option>';
        }

        $array_respon = [
            'html_respon' => $html_option,
            'status' => TRUE,
            'data_product' => $this->encrypt->encode(json_encode($get_data_current))
        ];
        echo json_encode($array_respon);
    }

    public function get_margin_price($id_product, $qty_buy)
    {

        $get_data_margin = $this->db->query("
         SELECT * FROM tb_margin_price WHERE id_product = '$id_product' and qty IN (select MAX(qty)from tb_margin_price where id_product = '$id_product'  AND qty <= '$qty_buy')
        ")->row_array();

        if (empty($get_data_margin)) {
            $get_data_base_unit_price = $this->db->query("SELECT price FROM tb_product WHERE id ='$id_product' ")->row_array();
            $price_return = $get_data_base_unit_price['price'];
        } else {
            $price_return = $get_data_margin['price'];
        }
        return $price_return;
    }

    private function validate_add_item()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // print_r($price);
        // print_r($nett_price);
        // print_r($get_data_product);
        // exit;
        $get_data_product = json_decode($this->encrypt->decode($this->input->post('data_product')), TRUE);

        if (empty($get_data_product)) {
            $data['error_string'][] = 'produk belum dipilih';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }

        if (empty($this->input->post('qty_buy')) || $this->input->post('qty_buy') == 0) {
            $data['error_string'][] = 'tidak boleh kosong / 0';
            $data['inputerror'][] = 'qty';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    private function validate_stock($stock_product, $qty_buy, $unit_name)
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($stock_product < $qty_buy) {
            $data['error_string'][] = 'jumlah stok produk (' . number_format($stock_product, 0, '.', '.') . ' ' . $unit_name . ')';
            $data['inputerror'][] = 'less_stock';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function add_item()
    {
        $this->validate_add_item();
        // print_r($_POST);
        // exit;

        $get_data_product = json_decode($this->encrypt->decode($this->input->post('data_product')), TRUE);
        $unit_conversion  = json_decode($this->encrypt->decode($this->input->post('unit')), TRUE);
        $unit_product     = $this->db->where(['id' => $get_data_product['id_unit']])->get('tb_unit')->row();
        $discount_member = $this->encrypt->decode($this->input->post('discount_member'));

        //data exist
        $array_id_product_axist  = $this->input->post('id_product');
        $array_qty_buy_axist     = $this->input->post('qty_buy_choosen');
        $conversion_choosen      = $this->input->post('conversion_choosen');

        $qty_buy         = $this->input->post('qty_buy');
        $real_qty_buy   = $qty_buy * $unit_conversion['qty'];

        $axist_qty_buy = 0;
        if (!empty($array_id_product_axist)) {
            if (in_array($get_data_product['id'], $array_id_product_axist)) {
                $axist_qty_buy = $array_qty_buy_axist[$get_data_product['id']];
                //replace conversion
                $conversion_choosen_current  =  json_decode($this->encrypt->decode($conversion_choosen[$get_data_product['id']]), TRUE);
                if ($conversion_choosen_current['qty'] > $unit_conversion['qty']) {
                    $unit_conversion = $conversion_choosen_current;
                }
            }
        }

        $real_qty_buy = $real_qty_buy + $axist_qty_buy;
        $this->validate_stock($get_data_product['stock'], $real_qty_buy, $unit_product->name);
        $price_sales    = $this->get_margin_price($get_data_product['id'], $real_qty_buy);

        if ($unit_conversion['id']) {
            $qty_unit = $real_qty_buy % $unit_conversion['qty'];
            $qty_conversion = ($real_qty_buy - $qty_unit) / $unit_conversion['qty'];
            $label_qty_buy = '';
            if ($qty_conversion > 0) {
                $real_qty_unit_conversion = $qty_conversion * $unit_conversion['qty'];
                $label_qty_buy .= number_format($qty_conversion, 0, '.', '.') . ' ' . $unit_conversion['name'] . ' ( ' . number_format($real_qty_unit_conversion, 0, '.', '.') . ' ' . $unit_product->name . ' )<br>';
            }

            if ($qty_unit > 0) {
                $label_qty_buy .= number_format($qty_unit, 0, '.', '.') . ' ' . $unit_product->name;
            }
        } else {
            $label_qty_buy = number_format($real_qty_buy, 0, '.', '.') . ' ' . $unit_product->name;
        }
        $total_price_buy        = $real_qty_buy * $price_sales;
        $total_price_discount   = 0;
        $real_total_price_buy   = $real_qty_buy * $get_data_product['price'];
        if ($price_sales < $get_data_product['price']) {
            $total_price_discount += ($get_data_product['price'] - $price_sales) * $real_qty_buy;
        }


        //decide promo and discount
        $html_discount = '
        <input type="hidden" name="discount_price[' . $get_data_product['id'] . ']" value="0">
        <input type="hidden" name="discount[' . $get_data_product['id'] . ']" value="0">0%
        ';
        $html_promo = ' <input type="hidden" name="bonus[' . $get_data_product['id'] . ']" value="">-';
        $price_discount_event = 0;
        $discount_value = 0;
        $discount_price = 0;
        $label_product_bonus = '';
        $get_fifo_stock_discount = [];
        if ($get_data_product['id_detail_event'] != 0) {
            $id_detail_event = $get_data_product['id_detail_event'];
            $this->db->select('
                tb_event_has_product.*,
                tb_event.type,
                tb_product.name AS product_bonus_name,
                tb_unit.name AS unit_name,
                tb_product.price,
                tb_product.main_price
                ');
            $this->db->from('tb_event_has_product');
            $this->db->join('tb_event', 'tb_event_has_product.id_event = tb_event.id', 'left');
            $this->db->join('tb_product', 'tb_event_has_product.id_bonus_product = tb_product.id', 'left');
            $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
            $this->db->where(['tb_event_has_product.id' => $id_detail_event]);
            $get_event = $this->db->get()->row();

            //discount
            if ($get_event->type == 1) {
                $discount_value = $get_event->discount;
                $price_discount_event = $price_sales * ($discount_value / 100);
                $discount_price = $total_price_buy * ($discount_value / 100);
                $total_price_buy = $total_price_buy - $discount_price;
                $total_price_discount += $discount_price;
                $html_discount = '
                <input type="hidden" name="discount_price[' . $get_data_product['id'] . ']" value="' . $discount_price . '">
                <input type="hidden" name="discount[' . $get_data_product['id'] . ']" value="' . $discount_value . '">
                ' . $discount_value . ' %
                ';
            }
            //promo
            if ($get_event->type == 2) {
                $min_qty_buy = $get_event->min_qty;
                $label_product_bonus = $get_event->product_bonus_name . ' ( ' . $get_event->qty_bonus_product . ' ' . $get_event->unit_name . ' )';
                if ($real_qty_buy >= $min_qty_buy) {
                    $total_price_discount += ($get_event->price * $get_event->qty_bonus_product);
                    $real_total_price_buy += ($get_event->price * $get_event->qty_bonus_product);
                    $html_promo = '
                    <input type="hidden" name="bonus[' . $get_data_product['id'] . ']" value="' . $get_event->product_bonus_name . ' ( ' . $get_event->qty_bonus_product . ' ' . $get_event->unit_name . ' ) ">
                    ' . $label_product_bonus;

                    $get_fifo_stock_discount = ['id' => $get_event->id_bonus_product, 'stock' => $get_event->qty_bonus_product];
                } else {
                    //create button detail
                    $array_data_button = [
                        'product_name' => $get_data_product['name'],
                        'min_qty' => $min_qty_buy,
                        'product_bonus' => $get_event->product_bonus_name,
                        'qty_bonus' => $get_event->qty_bonus_product
                    ];
                    $html_promo = '
                    <input type="hidden" name="bonus[' . $get_data_product['id'] . ']" value="">
                    <a href="javascript:void(0)" data-id="' . $this->encrypt->encode(json_encode($array_data_button)) . '" class="btn btn-success btn_show_promo"><i class="fa fa-tv"></i> Tersedia</a>
                    ';
                }
            }
        }

        //discount member
        $total_price_discount_member = 0;
        if ($discount_member > 0) {
            $price_after_discount = $price_sales - $price_discount_event;
            $advantage_price = $price_after_discount - $get_data_product['main_price'];
            $price_discount_member = $advantage_price * ($discount_member / 100);
            $total_price_discount_member = $real_qty_buy * $price_discount_member;
        }

        $total_price_buy = $total_price_buy - $total_price_discount_member;

        //tax price
        $get_ppn = $this->db->where(['field' => 'ppn_tax'])->get('app_module_setting')->row();
        if ($get_ppn->value > 0) {
            $ppn_value = ($get_ppn->value / 100) * $total_price_buy;
        } else {
            $ppn_value  = 0;
        }
        //cout pph
        $get_pph = $this->db->where(['field' => 'pph_tax'])->get('app_module_setting')->row();
        if ($total_price_buy > $get_pph->params) {
            $pph_value = ($get_pph->value / 100) * $total_price_buy;
        } else {
            $pph_value = 0;
        }
        $total_price_buy_has_tax = $total_price_buy + $pph_value + $ppn_value;

        //get main price and stock id
        $get_fifo_stock = ['id' => $get_data_product['id'], 'stock' => $real_qty_buy];
        $array_detail_sales = [
            'id_product' => $get_data_product['id'],
            'id_conversion_unit' => $unit_conversion['id'],
            'qty' => $real_qty_buy,
            'main_price' => $get_data_product['main_price'],
            'price' => $price_sales,
            'discount' => $discount_value,
            'price_discount' => $discount_price,
            'bonus' => $label_product_bonus,
            'member_discount' => $discount_member,
            'price_member_discount' => $total_price_discount_member,
            'total_price' => $total_price_buy,
            'fifo_stock' => $this->encrypt->encode(json_encode($get_fifo_stock)),
            'fifo_stock_discount' => $this->encrypt->encode(json_encode($get_fifo_stock_discount)),
            'total_real_buy' => $real_total_price_buy,
            'total_discount' => $total_price_discount
        ];
        $data_encrypt_item = $this->encrypt->encode(json_encode($array_detail_sales));

        $data_html  = '';
        $data_html .= '
        <tr class="tr_' . $get_data_product['id'] . '">
        <td>
        ' . $get_data_product['code'] . '
        </td>
        <td>
        ' . $get_data_product['name'] . '
        </td>

        <td>
        ' . number_format($price_sales, 0, '.', '.') . '
        </td>
        <td>
        ' . $label_qty_buy . '
        </td>
        <td>
        ' . number_format($total_price_discount_member, 0, '.', '.') . '
        </td>
        <td>' . $html_discount . '</td>
        <td>
        Rp.' . number_format($total_price_buy, 0, '.', '.') . '
        </td>
        <td>' . $html_promo . '</td>
        <td>
        <input type="hidden" name="id_product[]" value="' . $get_data_product['id'] . '">
        <input type="hidden" name="data_product_choosen[' . $get_data_product['id'] . ']" value="' . $this->input->post('data_product') . '">
        <input type="hidden" name="qty_buy_choosen[' . $get_data_product['id'] . ']" value="' . $real_qty_buy . '">
        <input type="hidden" name="conversion_choosen[' . $get_data_product['id'] . ']" value="' . $this->encrypt->encode(json_encode($unit_conversion)) . '">
        <input type="hidden" class="total_price_item_' . $get_data_product['id'] . '" name="total_price_item[' . $get_data_product['id'] . ']" value="' . $total_price_buy . '">
        <input type="hidden"  name="total_price_discount_member[' . $get_data_product['id'] . ']" value="' . $total_price_discount_member . '">
        <input type="hidden" class="ppn_item_' . $get_data_product['id'] . '" name="ppn_value[' . $get_data_product['id'] . ']" value="' . $ppn_value . '">
        <input type="hidden" class="pph_item_' . $get_data_product['id'] . '" name="ppn_value[' . $get_data_product['id'] . ']" value="' . $pph_value . '">
        <input type="hidden" name="item_sales[]" value="' . $data_encrypt_item . '">
        <button type="button" class="btn btn-danger btn-xs btn-del" onclick="del_tr(' . "'" . $get_data_product['id'] . "'" . ')"><i class="fa fa-times"></i></button>
        </td>
        </tr>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $data_html,
            'id_product' => $get_data_product['id']
        ];
        echo json_encode($array_respon);
    }

    //logic for get price FIFO
    private function get_price_stock_fifo($id_product, $stock)
    {
        $get_data_stock = $this->db->query("
            SELECT
            tb_detail_stock.id,
            tb_stock.id_account_warehouse,
            tb_detail_stock.stock_rest,
            tb_detail_stock.main_price
            FROM tb_detail_stock
            INNER JOIN tb_stock ON tb_detail_stock.id_stock_opname = tb_stock.id
            WHERE tb_detail_stock.stock_rest > 0 AND tb_detail_stock.id_product = '$id_product' AND tb_stock.id_account_warehouse = 0
            ")->result();

        //count_respon
        $temp_stock = $stock;
        $grand_total = 0;
        $array_stock_in = [];
        $array_stock_out = [];
        foreach ($get_data_stock as $item_stock) {

            if ($temp_stock <= 0) {
                continue;
            }

            if ($temp_stock > $item_stock->stock_rest) {
                $grand_total += ($item_stock->stock_rest * $item_stock->main_price);
                //stock out
                $array_stock_out[] = [
                    'id' => $item_stock->id,
                    'stock_rest' => 0
                ];
                $temp_stock -= $item_stock->stock_rest;
            } else {
                $grand_total += ($temp_stock * $item_stock->main_price);
                $stock_rest = $item_stock->stock_rest - $temp_stock;
                //stock out
                $array_stock_out[] = [
                    'id' => $item_stock->id,
                    'stock_rest' => $stock_rest
                ];
                $temp_stock = 0;
            }
        }

        if ($grand_total == 0) {
            $get_product_current = $this->db->where(['id' => $id_product])->get('tb_product')->row();
            $grand_total = $get_product_current->main_price * $stock;
        }

        $array_respon = [
            'grand_total' => $grand_total,
            'stock_out' => $array_stock_out
        ];
        return $array_respon;
    }

    //for pajak
    public function count_grand_total()
    {
        $grand_total = $this->input->post('grand_total');
        //count ppn
        $get_ppn = $this->db->where(['field' => 'ppn_tax'])->get('app_module_setting')->row();
        if ($get_ppn->value > 0) {
            $ppn_value = ($get_ppn->value / 100) * $grand_total;
        } else {
            $ppn_value  = 0;
        }
        //cout pph
        $get_pph = $this->db->where(['field' => 'pph_tax'])->get('app_module_setting')->row();
        if ($grand_total > $get_pph->param) {
            $pph_value = ($get_pph->value / 100) * $grand_total;
        } else {
            $pph_value = 0;
        }
        $grand_total_return = $grand_total + $pph_value + $ppn_value;
        //json respon 
        $array_respon = [
            'ppn' => $ppn_value,
            'pph' => $pph_value,
            'grand_total' => $grand_total_return,
            'grand_total_sales' => $grand_total
        ];
        echo json_encode($array_respon);
    }

    public function get_member()
    {
        $member_code = $this->input->post('member_code');
        $this->db->select('tb_member.*,tb_member_category.name AS category_name,tb_member_category.persentage_discount AS discount_member');
        $this->db->from('tb_member');
        $this->db->join('tb_member_category', 'tb_member.id_category_member = tb_member_category.id', 'left');
        $this->db->where(['tb_member.code' => $member_code]);
        $get_member = $this->db->get()->row();

        if (!empty($get_member)) {
            $count_saldo = $get_member->max_debt - $get_member->total_debt;
            $html_respon = '
            <div class="">
            <input type="hidden" value="' . $get_member->id . '" name="id_member" id="id_member">
            <input type="hidden" value="' . $count_saldo . '" name="debt_saldo" id="debt_saldo">
            <input type="hidden" value="' . $this->encrypt->encode($get_member->discount_member) . '" name="discount_member" id="discount_member">
            <div class="col-md-12 p-10 border border-radius-5">
            <div class="col-md-12 text-center p-10">
            <h2>' . strtoupper($get_member->name) . '</h2>
            <p>' . $get_member->address . '</p>
            <hr style="padding:0;margin:0;">
            </div>
            <span class="clearfix"></span>
            <div class="card-tools pull-right">
            <a  data-toggle="collapse" class="btn btn-default btn-xs" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
            <i class="fa fa-tv"></i> Detail
            </a>
            <a  class="btn btn-default btn_clear_member btn-xs" href="javascript:void(0)">
            <i class="fa fa-trash"></i> Hapus
            </a>
            </div>
            <span class="clearfix"></span>
            <div class="card-body collapse" id="collapseExample">
            <div class="col-md-4 p-10 text-center border-right">
            <small>Deposito</small>
            <h3>Rp.' . number_format($get_member->total_deposito, 0, '.', '.') . '</h3>
            </div>
            <div class="col-md-4 p-10 text-center border-right">
            <small>Point</small>
            <h3>Rp.' . number_format($get_member->point, 0, '.', '.') . '</h3>
            </div>
            <div class="col-md-4 p-10 text-center">
            <small>Piutang</small>
            <h3>Rp.' . number_format($get_member->total_debt, 0, '.', '.') . '</h3>
            </div>
            <hr class="col-md-12">
            <div class="col-md-4 p-10 text-center border-right">
            <small>Saldo Hutang</small>
            <h3>Rp.' . number_format($count_saldo, 0, '.', '.') . '</h3>
            </div>
            <div class="col-md-4 p-10 text-center border-right">
            <small>Jenis Member</small>
            <h3>' . $get_member->category_name . '</h3>
            </div>
            <div class="col-md-4 p-10 text-center">
            <small>Potongan Harga</small>
            <h3>' . number_format($get_member->discount_member, 0, '.', '.') . ' %</h3>
            </div>
            </div>
            </div>
            </div>
            ';

            $array_respon = [
                'status' => TRUE,
                'html_respon' => $html_respon,
                'id_member' => $get_member->id
            ];
        } else {
            $array_respon = [
                'status' => FALSE
            ];
        }

        echo json_encode($array_respon);
    }

    public function get_member_value()
    {
        $id_member = $this->input->post('value');
        $get_data_member = $this->db->where(['id' => $id_member])->get('tb_member')->row();
        $html_total_deposito = '';
        $html_total_point = '';
        $total_deposito = 0;
        $total_point = 0;
        $status_return =  FALSE;
        $status_deposito = FALSE;
        $status_point = FALSE;

        if (empty($get_data_member)) {
            $status_return = FALSE;
            $id_member_current = FALSE;
        } else {
            //point
            if ($get_data_member->point > 0) {
                $status_point = TRUE;
                $html_total_point       = 'Rp.' . number_format($get_data_member->point, 0, '.', '.');
                $total_point            = $get_data_member->point;
            } else {
                $status_point = FALSE;
            }

            if ($get_data_member->total_deposito > 0) {
                $status_deposito = TRUE;
                $html_total_deposito    = 'Rp.' . number_format($get_data_member->total_deposito, 0, '.', '.');
                $total_deposito         = $get_data_member->total_deposito;
            } else {
                $status_deposito = FALSE;
            }

            if ($get_data_member->point > 0 || $get_data_member->total_deposito > 0) {
                $status_return = TRUE;
            } else {
                $status_return = FALSE;
            }
            $id_member_current = TRUE;
        }

        $array_respon = [
            'status' => $status_return,
            'html_total_deposito' => $html_total_deposito,
            'html_total_point' => $html_total_point,
            'total_deposito' => $total_deposito,
            'total_point' => $total_point,
            'status_point' => $status_point,
            'status_deposito' => $status_deposito,
            'id_member' => $id_member_current
        ];

        echo json_encode($array_respon);
    }

    public function get_member_buyer($id)
    {
        if (empty($id)) {
            echo json_encode(array('name' => ''));
        } else {
            $get_data_member = $this->db->query("select name from tb_member where id = '$id' ")->row_array();
            echo json_encode(array('name' => $get_data_member['name']));
        }
    }

    public function get_code_sales()
    {
        echo json_encode(array('code' => $this->get_code()));
    }

    public function get_form()
    {
        $status_delivery    = $this->input->post('status_delivery');
        $status_credit      = $this->input->post('status_credit');
        $grand_total        = $this->input->post('grand_total');
        $payment            = $this->input->post('payment') ? $this->input->post('payment') : 0;
        $rest               = $grand_total - $payment;
        $html_form = '';
        if ($status_delivery == TRUE) {
            $html_form .= '

            <div class="col-md-12 p-10 border border-radius-5">
            <h3 class="mb-10">FORM PENGIRIMAN</h3>
            <div class="col-md-12">
            <div class="col-md-6 form-group">
            <label>Nama Penerima</label>
            <input type="text" name="receiver" class="form-control">
            <span class="help-block"></span>
            </div>
            <div class="col-md-3 form-group">
            <label>No.Telp</label>
            <input type="text" name="number_phone" class="form-control">
            <span class="help-block"></span>
            </div>
            <div class="col-md-3 form-group">
            <label>Kode Pos</label>
            <input type="text" name="postal_code" class="form-control">
            <span class="help-block"></span>
            </div>

            <div class="col-md-4 form-group">
            <label>Kecamatan</label>
            <input type="text" name="kec" class="form-control">
            <span class="help-block"></span>
            </div>
            <div class="col-md-4 form-group">
            <label>Kabupaten / Kota</label>
            <input type="text" name="regency" class="form-control">
            <span class="help-block"></span>
            </div>
            <div class="col-md-4 form-group">
            <label>Provinsi</label>
            <input type="text" name="province" class="form-control">
            <span class="help-block"></span>
            </div>
            <div class="col-md-12 form-group">
            <label>Alamat Lengkap</label>
            <textarea  class="form-control" name="address" rows="5"></textarea>
            <span class="help-block"></span>
            </div>
            </div>
            </div>
            ';
        }

        if ($status_credit == TRUE && $rest > 0) {
            $html_payment = '
            <small><u>PEMBAYARAN</u></small>
            <span class="clearfix"></span>
            <div class="col-md-6 border-payment" align="center">
            <small><u>GRAND TOTAL</u></small>
            <h3 style="color:#00a65a;" class="grand_total_review">Rp.' . number_format($grand_total, 0, '.', '.') . '</h3>
            </div>
            <div class="col-md-6 border-payment" align="center">
            <small><u>BAYAR</u></small>
            <h3 style="color:#00a65a;" class="payment_review">Rp.' . number_format($payment, 0, '.', '.') . '</h3>
            </div>
            <div class="col-md-12 border-payment" align="center">
            <small><u>PIUTANG</u></small>
            <h1 style="color:red;" class="rest_payment_review">Rp.' . number_format($rest, 0, '.', '.') . '</h1>
            </div>
            <span class="clearfix"></span>
            <br>
            <div class="text-center cover_btn_print">
            <small>(*klik untuk simpan data)</small>
            <button type="button" class="btn btn-block btn-lg btn-success" id="btn_save">SIMPAN <b>(F1)</b></button>
            </div>
            ';
        } else {
            $rest = $payment - $grand_total;
            $html_payment = '
            <small><u>PEMBAYARAN</u></small>
            <span class="clearfix"></span>
            <div class="row">
                <div class="col-md-6 border" align="right">
                    <small><u>GRAND TOTAL</u></small>
                    <h3 style="color:#00a65a;" class="grand_total_review">Rp.' . number_format($grand_total, 0, '.', '.') . '</h3>
                </div>
                <div class="col-md-6 border" align="right">
                    <small><u>BAYAR</u></small>
                    <h3 style="color:#00a65a;" class="payment_review">Rp.' . number_format($payment, 0, '.', '.') . '</h3>
                </div>
                <div class="col-md-12 border" align="right">
                    <small><u>KEMBALI</u></small>
                    <h1 style="color:red;" class="rest_payment_review">Rp.' . number_format($rest, 0, '.', '.') . '</h1>
                </div>
            </div>
            <span class="clearfix"></span>
            <br>
            <div class="text-center cover_btn_print">
                <small>(*klik untuk simpan data)</small>
                <button type="button" class="btn btn-block btn-lg btn-primary-gradient btn-rounded" id="btn_save">SIMPAN <b>(F1)</b></button>
            </div>
            ';
        }
        $array_respon = [
            'status' => TRUE,
            'html_payment' => $html_payment,
            'html_form' => $html_form
        ];
        echo json_encode($array_respon);
    }

    public function validate_save_sales()
    {

        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if (isset($_POST['delivery_status'])) {
            $array_required = ['receiver', 'number_phone', 'postal_code', 'kec', 'regency', 'province', 'address'];
            foreach ($array_required as $item_required) {
                if ($this->input->post($item_required) == '') {
                    $data['error_string'][] = 'Harus Di isi';
                    $data['inputerror'][] = $item_required;
                    $data['status'] = FALSE;
                }
            }
        }
        if (isset($_POST['credit_status'])) {
            $arry_required = ['name_responsible', 'expired_date', 'note'];
            foreach ($arry_required as $item_required) {
                if ($this->input->post($item_required) == '') {
                    $data['error_string'][] = 'Harus Di isi';
                    $data['inputerror'][] = $item_required;
                    $data['status'] = FALSE;
                }
            }
        }
        // print_r($data);
        // exit;
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function validate_payment()
    {
        // print_r($_POST);
        // exit;
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $grand_total    = $this->input->post('grand_total');
        $payment        = $this->input->post('total_payment');
        // $list_product   = $this->input->post('data_product_choosen');

        if ($grand_total == '') {
            $data['error_string'][] = 'tidak ada pembelian';
            $data['inputerror'][] = 'notif_btn_payment';
            $data['status'] = FALSE;
        }
        if (!isset($_POST['data_product_choosen'])) {
            $data['error_string'][] = 'tidak ada pembelian';
            $data['inputerror'][] = 'notif_btn_payment';
            $data['status'] = FALSE;
        }

        if (is_numeric($payment) == false) {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'notif_btn_payment';
            $data['status'] = FALSE;
        }

        if (!isset($_POST['credit_status'])) {
            if ($payment == '' || is_numeric($payment) == false) {
                $data['error_string'][] = 'Harus Diisi';
                $data['inputerror'][] = 'notif_btn_payment';
                $data['status'] = FALSE;
            }

            if ($payment < $grand_total) {
                $data['error_string'][] = 'Pembayaran Kurang';
                $data['inputerror'][] = 'notif_btn_payment';
                $data['status'] = FALSE;
            }
        }
        // print_r($data);
        // exit;
        if ($data['status'] == FALSE) {
            echo json_encode($data);
        } else {
            echo json_encode(['status' => TRUE]);
        }
    }

    public function save_sales()
    {
        $this->validate_save_sales();
        // print_r($_POST);
        // exit;
        //for main sales
        $code             = $this->get_code();
        $id_member          = $this->input->post('id_member');
        $get_member_current = $this->db->where(['id' => $id_member])->get('tb_member')->row();
        $grand_total        = $this->input->post('grand_total');
        $grand_total_sales  = $this->input->post('grand_total_sales');
        $ppn_price          = $this->input->post('ppn');
        $ppn                = $this->db->where(['field' => 'ppn_tax'])->get('app_module_setting')->row();
        $pph_price          = $this->input->post('pph');
        $pph                = $this->db->where(['field' => 'pph_tax'])->get('app_module_setting')->row();
        $date_order         = date('Y-m-d');
        $payment            = $this->input->post('payment');
        $payment            = str_replace('.', '', $payment);

        $deposito           = str_replace('.', '', $this->input->post('deposito'));
        $saldo_deposito     = $this->input->post('saldo_deposito');
        $point              = str_replace('.', '', $this->input->post('point'));
        $saldo_point        = $this->input->post('saldo_point');
        $total_payment      = $this->input->post('total_payment');

        $total_member_discount = 0;
        $member_discount = $this->input->post('total_price_discount_member');
        foreach ($member_discount as $item_member_discount) {
            $total_member_discount += $item_member_discount;
        }

        $price_credit = $grand_total - $total_payment;
        if (isset($_POST['credit_status']) && $price_credit > 0) {
            $rest_payment = 0;
            $credit_status = TRUE;
            $price_credit = $price_credit;
        } else {
            $rest_payment   = $total_payment - $grand_total;
            $credit_status = FALSE;
            $price_credit = 0;
        }
        $status_delivery = isset($_POST['delivery_status']) ? TRUE : FALSE;
        //insert to main
        $array_insert_sales = array(
            'code' => $code,
            'id_member' => $id_member,
            'grand_total' => $grand_total,
            'ppn' => $ppn->value,
            'ppn_price' => $ppn_price,
            'pph' => $pph->value,
            'pph_price' => $pph_price,
            'grand_total_sales' => $grand_total_sales,
            'deposito_payment' => $deposito,
            'point_payment' => $point,
            'cash_payment' => $payment,
            'payment' => $total_payment,
            'total_member_discount' => $total_member_discount,
            'rest_payment' => $rest_payment,
            'date' => $date_order,
            'credit_status' => $credit_status,
            'credit_price' => $price_credit,
            'delivery_status' => $status_delivery,
            'created_date' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/insert', 'tb_sales', $array_insert_sales);
        // $this->model->insert('tb_sales', $array_insert_sales);

        $get_id_sales_current = $this->db->query("select id from tb_sales where code = '$code' ")->row_array();
        $array_item_sales = $this->input->post('item_sales');
        //for detail
        $id_sales_current           = $get_id_sales_current['id'];
        $grand_total_hpp            = 0;
        $grand_total_discount       = 0;
        $grand_total_member_discount = 0;
        $grand_total_real_buy       = 0;
        foreach ($array_item_sales as $item_sales) {
            $item_sales_current = json_decode($this->encrypt->decode($item_sales), TRUE);

            $grand_total_discount += $item_sales_current['total_discount'];
            $grand_total_real_buy += $item_sales_current['total_real_buy'];
            $grand_total_member_discount += $item_sales_current['price_member_discount'];

            $fifo_stock = $this->encrypt->decode($item_sales_current['fifo_stock']);
            $fifo_stock_discount = $this->encrypt->decode($item_sales_current['fifo_stock_discount']);

            // print_r($fifo_stock);
            // print_r($fifo_stock_discount);
            // exit;

            unset($item_sales_current['fifo_stock']);
            unset($item_sales_current['total_discount']);
            unset($item_sales_current['total_real_buy']);
            unset($item_sales_current['price_member_discount']);
            unset($item_sales_current['fifo_stock_discount']);

            $item_sales_current['id_sales'] = $get_id_sales_current['id'];
            Modules::run('database/insert', 'tb_detail_sales', $item_sales_current);
            //update  rest stock
            // $get_stock_current = $this->db->query("select stock from tb_product where id = '$id_product' ")->row_array();
            $get_stock_current = $this->db->where(['id' => $item_sales_current['id_product']])->get('tb_product')->row_array();
            $stock_rest = $get_stock_current['stock'] - $item_sales_current['qty'];
            //update stock 
            $array_update_stock = array(
                'stock' => $stock_rest
            );
            Modules::run('database/update', 'tb_product', ['id' => $item_sales_current['id_product']], $array_update_stock);
            // $this->model->update(array('id' => $item_sales_current['id_product']), $array_update_stock, 'tb_product');
            //update fifo stock
            $array_fifo_stock = json_decode($fifo_stock);
            $get_fifo_stock = $this->get_price_stock_fifo($array_fifo_stock->id, $array_fifo_stock->stock);
            $grand_total_hpp += $get_fifo_stock['grand_total'];
            foreach ($get_fifo_stock['stock_out'] as $item_fifo_stock) {
                $array_update_fifo_stock = [
                    'stock_rest' => $item_fifo_stock['stock_rest']
                ];
                Modules::run('database/update', 'tb_detail_stock', ['id' => $item_fifo_stock['id']], $array_update_fifo_stock);
                // $this->model->update(array('id' => $item_fifo_stock['id']), $array_update_fifo_stock, 'tb_detail_stock');
            }

            //discount fifo
            $array_fifo_stock_discount  = json_decode($fifo_stock_discount);
            if (!empty($array_fifo_stock_discount)) {
                $get_fifo_stock_discount    = $this->get_price_stock_fifo($array_fifo_stock_discount->id, $array_fifo_stock_discount->stock);
                $grand_total_hpp += $get_fifo_stock_discount['grand_total'];
                foreach ($get_fifo_stock_discount['stock_out'] as $item_fifo_stock) {
                    $array_update_fifo_stock = [
                        'stock_rest' => $item_fifo_stock['stock_rest']
                    ];
                    // $this->model->update(array('id' => $item_fifo_stock['id']), $array_update_fifo_stock, 'tb_detail_stock');
                    Modules::run('database/update', 'tb_detail_stock', ['id' => $item_fifo_stock['id']], $array_update_fifo_stock);
                }
            }
        }
        //update hpp
        $array_update_hpp = [
            'grand_total_hpp' => $grand_total_hpp,
            'total_member_discount' => $grand_total_member_discount,
            'total_discount_product' => $grand_total_discount,
            'grand_total_real_price' => $grand_total_real_buy

        ];
        // $this->model->update(array('code' => $code), $array_update_hpp, 'tb_sales');
        Modules::run('database/update', 'tb_sales', ['code' => $code], $array_update_hpp);
        //for deposito
        if ($deposito > 0) {
            //insert to detail deposito 
            $rest_deposito = $saldo_deposito - $deposito;
            $array_insert_deposito = [
                'status' => 2,
                'id_member' => $id_member,
                'id_sales' => $id_sales_current,
                'saldo_deposito' => $saldo_deposito,
                'price_use' => $deposito,
                'total_deposito' => $rest_deposito,
                'date' => date('Y-m-d')
            ];
            // $this->model->insert('tb_deposito', $array_insert_deposito);
            Modules::run('database/insert', 'tb_deposito',  $array_insert_deposito);

            //upadate saldo
            $array_update_deposito = [
                'total_deposito' => $rest_deposito
            ];
            // $this->model->update(array('id' => $id_member), $array_update_deposito, 'tb_member');
            Modules::run('database/update', 'tb_sales', ['id' => $id_member], $array_update_deposito);
        }

        // for point
        if ($point > 0) {
            $rest_point = $saldo_point - $point;
            $array_update_point = [
                'point' => $rest_point
            ];
            // $this->model->update(array('id' => $id_member), $array_update_point, 'tb_member');
            Modules::run('database/update', 'tb_member', ['id' => $id_member], $array_update_point);
        }

        //for delivery 
        // if (isset($_POST['delivery_status'])) {
        //     // $array_required = ['receiver', 'number_phone', 'postal_code', 'kec', 'regency', 'province', 'address'];
        //     $receiver = $this->input->post('receiver');
        //     $number_phone = $this->input->post('number_phone');
        //     $postal_code = $this->input->post('postal_code');
        //     $kec = $this->input->post('kec');
        //     $regency = $this->input->post('regency');
        //     $province = $this->input->post('province');
        //     $address = $this->input->post('address');
        //     //prepare for save
        //     $array_save_delivery = [
        //         'code' => $this->get_code_delivery(),
        //         'sales_code' => $code,
        //         'date' => date('Y-m-d'),
        //         'receiver' => $receiver,
        //         'number_phone' => $number_phone,
        //         'city' => $regency,
        //         'province' => $province,
        //         'kec' => $kec,
        //         'address' => $address,
        //         'postal_code' => $postal_code
        //     ];
        //     $this->model->insert('tb_delivery', $array_save_delivery);
        // }

        //for credit
        $price_credit = $grand_total - $payment;
        if (isset($_POST['credit_status']) && $price_credit > 0) {
            $deadline = date('Y-m-d', strtotime("+$get_member_current->max_due_date days", strtotime(date('Y-m-d')))); //operasi penjumlahan tanggal sebanyak 6 hari
            // $note = $this->input->post('note');
            $credit_code = $this->get_code_credit();
            //prepare for save
            $array_save_credit = [
                'code' => $credit_code,
                'id_member' => $get_member_current->id,
                'sales_code' => $code,
                'name' => $get_member_current->name,
                'price' => $price_credit,
                'rest_credit' => $price_credit,
                'date' => date('Y-m-d'),
                'deadline' => $deadline,
                'created_by' => $this->session->userdata('us_id')
            ];
            $this->model->insert('tb_credit', $array_save_credit);
            //update saldo credit
            $total_credit_member = $get_member_current->total_debt + $price_credit;
            $aray_update_credit_member = ['total_debt' => $total_credit_member];
            // $this->model->update(array('id' => $id_member), $aray_update_credit_member, 'tb_member');
            Modules::run('database/update', 'tb_member', ['id' => $id_member], $aray_update_credit_member);
        }
        //cek point
        $new_point =  0;
        if (!empty($id_member)) {
            $get_point =  $this->db->query("
                SELECT MAX(min_price) AS price, point FROM tb_point where min_price < $grand_total
                ")->row();

            if (!empty($get_point)) {
                $get_current_member = $this->db->select('point')->where(['id' => $id_member])->get('tb_member')->row();
                $count_point = $get_point->point + $get_current_member->point;
                $new_point = $get_point->point;
                //update point 
                $array_update_point = ['point' => $count_point];
                $this->model->update(array('id' => $id_member), $array_update_point, 'tb_member');

                //update sales
                $array_update_new_point = [
                    'new_point' => $new_point
                ];
                // $this->model->update(array('code' => $code), $array_update_new_point, 'tb_sales');
                Modules::run('database/update', 'tb_sales', ['code' => $code], $array_update_new_point);
            }
        }
        //print nota
        // $this->cetak_struk($id_sales_current);
        echo json_encode(array('status' => TRUE, 'id' => $id_sales_current));
    }



    // public function cetak_struk($id)
    // {
    //     $this->db->select('
    //         tb_sales.*,
    //         tb_credit.code AS credit_code,
    //         tb_credit.deadline AS credit_deadline,
    //         tb_member.name AS member_name,
    //         st_user.name AS user_name,
    //         COUNT(tb_detail_sales.id) AS count_item
    //     ');
    //     $this->db->from('tb_sales');
    //     $this->db->join('tb_credit', 'tb_sales.code = tb_credit.sales_code', 'left');
    //     $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
    //     $this->db->join('st_user', 'tb_sales.created_by = st_user.id', 'left');
    //     $this->db->join('tb_detail_sales', 'tb_sales.id = tb_detail_sales.id_sales', 'left');
    //     $this->db->group_by('tb_sales.id');
    //     $this->db->where(['tb_sales.id' => $id]);
    //     $get_data = $this->db->get()->row();

    //     $this->db->select('
    //         tb_detail_sales.*,
    //         tb_product.name AS product_name,
    //         tb_unit.name AS unit_name,
    //         tb_product_has_conversion.name AS conversion_name,
    //         tb_product_has_conversion.qty AS conversion_qty
    //     ');
    //     $this->db->from('tb_detail_sales');
    //     $this->db->join('tb_product', 'tb_detail_sales.id_product = tb_product.id', 'left');
    //     $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
    //     $this->db->join('tb_product_has_conversion', 'tb_detail_sales.id_conversion_unit = tb_product_has_conversion.id', 'left');
    //     $this->db->where(['tb_detail_sales.id_sales' => $id]);
    //     $get_data_detail = $this->db->get()->result();
    //     // me-load library escpos
    //     $this->load->library('escpos');
    //     // membuat connector printer ke shared printer bernama "printer_a" (yang telah disetting sebelumnya)
    //     $get_profile    = $this->db->get('tb_profile')->row();
    //     $connector      = new Escpos\PrintConnectors\WindowsPrintConnector($get_profile->printer_name);

    //     // membuat objek $printer agar dapat di lakukan fungsinya
    //     $printer = new Escpos\Printer($connector);
    //     $image_pos  = new Escpos\EscposImage;
    //     $url = 'upload/profile/' . $get_profile->image;
    //     $ticket = $image_pos->load($url, true);

    //     // membuat fungsi untuk membuat 1 baris tabel, agar dapat dipanggil berkali-kali dgn mudah
    //     function buatBaris4Kolom($kolom1, $kolom2, $kolom3, $kolom4)
    //     {
    //         // Mengatur lebar setiap kolom (dalam satuan karakter)
    //         $lebar_kolom_1 = 15;
    //         $lebar_kolom_2 = 8;
    //         $lebar_kolom_3 = 8;
    //         $lebar_kolom_4 = 9;

    //         // Melakukan wordwrap(), jadi jika karakter teks melebihi lebar kolom, ditambahkan \n 
    //         $kolom1 = wordwrap($kolom1, $lebar_kolom_1, "\n", true);
    //         $kolom2 = wordwrap($kolom2, $lebar_kolom_2, "\n", true);
    //         $kolom3 = wordwrap($kolom3, $lebar_kolom_3, "\n", true);
    //         $kolom4 = wordwrap($kolom4, $lebar_kolom_4, "\n", true);

    //         // Merubah hasil wordwrap menjadi array, kolom yang memiliki 2 index array berarti memiliki 2 baris (kena wordwrap)
    //         $kolom1Array = explode("\n", $kolom1);
    //         $kolom2Array = explode("\n", $kolom2);
    //         $kolom3Array = explode("\n", $kolom3);
    //         $kolom4Array = explode("\n", $kolom4);

    //         // Mengambil jumlah baris terbanyak dari kolom-kolom untuk dijadikan titik akhir perulangan
    //         $jmlBarisTerbanyak = max(count($kolom1Array), count($kolom2Array), count($kolom3Array), count($kolom4Array));

    //         // Mendeklarasikan variabel untuk menampung kolom yang sudah di edit
    //         $hasilBaris = array();

    //         // Melakukan perulangan setiap baris (yang dibentuk wordwrap), untuk menggabungkan setiap kolom menjadi 1 baris 
    //         for ($i = 0; $i < $jmlBarisTerbanyak; $i++) {

    //             // memberikan spasi di setiap cell berdasarkan lebar kolom yang ditentukan, 
    //             $hasilKolom1 = str_pad((isset($kolom1Array[$i]) ? $kolom1Array[$i] : ""), $lebar_kolom_1, " ");
    //             $hasilKolom2 = str_pad((isset($kolom2Array[$i]) ? $kolom2Array[$i] : ""), $lebar_kolom_2, " ");

    //             // memberikan rata kanan pada kolom 3 dan 4 karena akan kita gunakan untuk harga dan total harga
    //             $hasilKolom3 = str_pad((isset($kolom3Array[$i]) ? $kolom3Array[$i] : ""), $lebar_kolom_3, " ", STR_PAD_LEFT);
    //             $hasilKolom4 = str_pad((isset($kolom4Array[$i]) ? $kolom4Array[$i] : ""), $lebar_kolom_4, " ", STR_PAD_LEFT);

    //             // Menggabungkan kolom tersebut menjadi 1 baris dan ditampung ke variabel hasil (ada 1 spasi disetiap kolom)
    //             $hasilBaris[] = $hasilKolom1 . " " . $hasilKolom2 . " " . $hasilKolom3 . " " . $hasilKolom4;
    //         }

    //         // Hasil yang berupa array, disatukan kembali menjadi string dan tambahkan \n disetiap barisnya.
    //         return implode($hasilBaris, "\n") . "\n";
    //     }

    //     $printer->initialize();
    //     $printer->setJustification(Escpos\Printer::JUSTIFY_CENTER);
    //     $printer->bitImage($ticket);

    //     // Membuat judul
    //     $printer->initialize();
    //     // $printer->selectPrintMode(Escpos\Printer::MODE_DOUBLE_HEIGHT); // Setting teks menjadi lebih besar
    //     $printer->selectPrintMode(Escpos\Printer::MODE_DOUBLE_WIDTH); // Setting teks menjadi lebih besar
    //     $printer->setJustification(Escpos\Printer::JUSTIFY_CENTER); // Setting teks menjadi rata tengah
    //     $printer->text("\n");
    //     $printer->text("$get_profile->name\n");

    //     // Teks dengan font B
    //     $printer->initialize();
    //     $printer->setJustification(Escpos\Printer::JUSTIFY_CENTER);
    //     $printer->setFont(Escpos\Printer::FONT_B);
    //     $printer->text("$get_profile->address \n");
    //     $printer->text("\n");

    //     // Data transaksi
    //     $printer->initialize();
    //     $printer->text("NO.Nota : $get_data->code\n");
    //     $printer->text("Kasir   : $get_data->user_name\n");
    //     $printer->text("Waktu   : $get_data->created_date\n");
    //     $printer->text("Member  : $get_data->member_name\n");

    //     // Membuat tabel
    //     $printer->initialize(); // Reset bentuk/jenis teks
    //     $printer->text("----------------------------------------\n");
    //     $printer->text(buatBaris4Kolom("Barang", "qty", "Harga", "Subtotal"));
    //     $printer->text("----------------------------------------\n");
    //     foreach ($get_data_detail as $item_detail) {
    //         $product_name = $item_detail->product_name;
    //         if ($item_detail->id_conversion_unit) {
    //             $qty_unit_sales         = $item_detail->qty % $item_detail->conversion_qty;
    //             $conversion_qty_sales   = ($item_detail->qty - $qty_unit_sales) / $item_detail->conversion_qty;
    //             $label_qty = '';
    //             if ($conversion_qty_sales > 0) {
    //                 $label_qty .= $conversion_qty_sales . $item_detail->conversion_name;
    //             }
    //             if ($qty_unit_sales > 0) {
    //                 $label_qty .= "\n" . $qty_unit_sales . $item_detail->unit_name;
    //             }
    //         } else {
    //             $label_qty = $item_detail->qty . $item_detail->unit_name;
    //         }
    //         $price_item = number_format($item_detail->price, 0, '.', '.');
    //         $total_price_item = number_format($item_detail->total_price, 0, '.', '.');

    //         $printer->text(buatBaris4Kolom($product_name, $label_qty, $price_item, $total_price_item));
    //     }


    //     $printer->text("----------------------------------------\n");
    //     $printer->text(buatBaris4Kolom('', '', "ITEM", "$get_data->count_item ITEM"));
    //     $printer->text(buatBaris4Kolom('', '', "Subtotal", number_format($get_data->grand_total_sales, 0, '.', '.')));
    //     $printer->text(buatBaris4Kolom('', '', "PPN($get_data->ppn%)", number_format($get_data->ppn_price, 0, '.', '.')));
    //     $printer->text(buatBaris4Kolom('', '', "Total", number_format($get_data->grand_total, 0, '.', '.')));
    //     $printer->text(buatBaris4Kolom('', '', "Bayar", number_format($get_data->payment, 0, '.', '.')));
    //     $printer->text(buatBaris4Kolom('', '', "Kembali", number_format($get_data->rest_payment, 0, '.', '.')));
    //     $printer->text("\n");
    //     if ($get_data->credit_status) {
    //         $printer->text("----------------------------------------\n");
    //         $printer->text("Catatan Hutang: \n");
    //         $printer->text("Kode Hutang     : $get_data->credit_code\n");
    //         $printer->text("Nominal Hutang  : " . number_format($get_data->credit_price, 0, '.', '.') . " \n");
    //         $printer->text("Jatuh Tempo     : $get_data->credit_deadline \n");
    //         $printer->text("----------------------------------------\n");
    //     }
    //     // Pesan penutup
    //     $printer->initialize();
    //     $printer->text("\n");
    //     $printer->setFont(Escpos\Printer::FONT_B);
    //     $printer->setJustification(Escpos\Printer::JUSTIFY_CENTER);
    //     $printer->text("*$get_profile->footer_note*\n");
    //     $printer->feed(3); // mencetak 5 baris kosong agar terangkat (pemotong kertas saya memiliki jarak 5 baris dari toner)
    //     // $printer->text("\n\n");
    //     $printer->cut();
    //     /* Close printer */
    //     $printer->close();
    //     echo json_encode(array('status' => TRUE));
    //     exit;
    // }

    public function print_nota()
    {
        $id = $this->input->post('id');
        // $id = 1;
        $this->db->select('
            tb_sales.*,
            tb_credit.code AS credit_code,
            tb_credit.deadline AS credit_deadline,
            tb_member.name AS member_name,
            st_user.name AS user_name,
            COUNT(tb_detail_sales.id) AS count_item
            ');
        $this->db->from('tb_sales');
        $this->db->join('tb_credit', 'tb_sales.code = tb_credit.id_transaction', 'left');
        $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
        $this->db->join('st_user', 'tb_sales.created_by = st_user.id', 'left');
        $this->db->join('tb_detail_sales', 'tb_sales.id = tb_detail_sales.id_sales', 'left');
        $this->db->group_by('tb_sales.id');
        $this->db->where(['tb_sales.id' => $id]);
        $get_data = $this->db->get()->row();

        $this->db->select('
            tb_detail_sales.*,
            tb_product.name AS product_name,
            tb_unit.name AS unit_name,
            tb_product_has_conversion.name AS conversion_name,
            tb_product_has_conversion.qty AS conversion_qty,
            tb_product.price AS product_price
            ');
        $this->db->from('tb_detail_sales');
        $this->db->join('tb_product', 'tb_detail_sales.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_detail_sales.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $this->db->where(['tb_detail_sales.id_sales' => $id]);
        $get_data_detail = $this->db->get()->result();



        $data['data_sales'] = $get_data;
        $data['data_detail'] = $get_data_detail;
        // $this->load->view( 'invoice', $data);

        $html_respon = $this->load->view('invoice', $data, TRUE);

        $btn_print = '
        <button type="button" class="btn btn-block btn-lg btn-success btn_print"  onclick="printJS(' . "html_nota" . ', ' . "html" . ')">
        <i class="fa fa-print"></i> Cetak Nota
        </button>
        ';

        $array_respon = [
            'html_respon' => $html_respon,
            'btn_print' => $btn_print,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function show_promo()
    {
        $value_current = $this->encrypt->decode($this->input->post('value'));
        $array_value = json_decode($value_current, TRUE);

        $html_respon = '
        <div class="col-md-12  p-20 ">
        <div class="col-md-12 text-center" style="border:1px solid #00a65a;padding:5px;padding:10px;border-radius:5px;">
        <h2>Min.Beli : <span class="text-bold text-red fa-2x">' . $array_value['min_qty'] . ' PCS</span></h2>
        <hr style="padding:0;margin:3px;">
        <h3 class="text-uppercase text-green"><i class="fa  fa-check-circle-o"></i> ' . $array_value['product_name'] . '</h3>
        </div>
        <div class="col-md-12 text-center" style="border:1px solid #00a65a;padding:5px;padding:10px;border-radius:5px;">
        <h2>Gratis : <span class="text-bold text-red fa-2x">' . $array_value['qty_bonus'] . ' PCS</span></h2>
        <hr style="padding:0;margin:3px;">
        <h3 class="text-uppercase text-green"><i class="fa  fa-check-circle-o"></i> ' . $array_value['product_bonus'] . '</h3>
        </div>
        </div>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }


    //------------------------------------------------- part stock view ---------------------------------------------------
    public function get_stock_current()
    {
        $data['data_main_category'] = $this->db->get('tb_main_category')->result();
        $data['data_merk'] = $this->db->get('tb_merk')->result();
        $html_respon = $this->load->view('form_search_product', $data, TRUE);
        echo $html_respon;
    }

    public function search_data()
    {
        $status         = $this->input->post('status');
        $id_category = $this->encrypt->decode($this->input->post('id_category'));
        $id_merk     = $this->encrypt->decode($this->input->post('id_merk'));
        $barcode     = $this->input->post('barcode');
        $name         = $this->input->post('name');
        $page          = $this->input->post('page');

        $array_where = [];
        if (!empty($barcode)) {
            $array_where['tb_barcode_product.barcode'] = $barcode;
        }
        if (!empty($id_category)) {
            $array_where['tb_product.id_main_category'] = $id_category;
        }
        if (!empty($id_merk)) {
            $array_where['tb_product.id_merk'] = $id_merk;
        }

        $this->db->select('
            tb_product.code,
            tb_product.id,
            tb_product.name,
            tb_product.price,
            tb_product.main_price,
            tb_product.stock,
            tb_product.stock_minimum,
            tb_product.created_date,
            tb_main_category.name AS main_category_name,
            tb_merk.name AS merk_name,
            tb_unit.name AS unit_name,
            tb_barcode_product.barcode AS barcode
            ');
        $this->db->from('tb_product');
        $this->db->join('tb_main_category', 'tb_product.id_main_category = tb_main_category.id', 'left');
        $this->db->join('tb_merk', 'tb_product.id_merk = tb_merk.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_barcode_product', 'tb_product.id = tb_barcode_product.id_product', 'left');
        // $this->db->order_by('tb_product.id', 'DESC');
        if (!empty($array_where)) {
            $this->db->where($array_where);
        }
        if (!empty($name)) {
            $this->db->like('tb_product.name', $name, 'both');
        }
        $limit_data = 50;
        if (empty($array_where) && empty($name)) {
            $data['data_product'] = [];
            $count_all = 0;
            $data['start_no'] = 0;
        } else {
            $query = $this->db->get();
            $main_query = $this->db->last_query();
            $limit_data = 25;
            if (!empty($page) && $page != 'undefined') {
                $start_page = ($page * $limit_data) - $limit_data;
                $data['start_no'] = $start_page;
            } else {
                $start_page = 0;
                $data['start_no'] = 0;
            }

            // count data 
            $get_query = $main_query . ' LIMIT ' . $start_page . ',' . $limit_data;
            $get_data_product = $this->db->query($get_query)->result();
            $data['data_product'] = $get_data_product;
            $count_all = $this->db->query($main_query)->num_rows();
        }

        $num_links = floor($count_all / $limit_data);
        $html_pagination_item = '';
        $counter = 0;
        for ($i = 0; $i < $num_links; $i++) {
            $counter++;
            $active = $page == $counter ? 'active' : '';
            $html_pagination_item .= '<li class="page-item ' . $active . '"><a class="page-link btn_pagination" data-ci-pagination-page="' . $counter . '"  href="javascript:void(0)">' . $counter . '</a></li>';
        }

        $html_pagination = '
        <div class="pagging text-center">
        <nav aria-label="Page navigation example">
        <ul class="pagination">
        ' . $html_pagination_item . '
        </ul>
        </nav>
        </div>
        ';
        $data['html_pagination'] = $html_pagination;
        $data['status_add'] = $status;
        $html_respon = $this->load->view('view_search_result', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }


    //--------------------------------------------------------------- part sales view ---------------------------------------
    public function count_sales_today()
    {
        $date_today = date('Y-m-d');
        $get_all_data_sales = $this->db->query("select COUNT(id) as sales_today from tb_sales where date = '$date_today' ")->row_array();
        echo json_encode(array('count' => $get_all_data_sales['sales_today']));
    }

    public function get_view_sales_today()
    {
        // $db_name = 'tb_product';
        $date_today = date('Y-m-d');
        // $get_sales_today = $this->db->query("select 
        //                                     a.id,
        //                                     a.code,
        //                                     a.date,
        //                                     a.grand_total,
        //                                     a.payment,
        //                                     a.rest_payment,
        //                                     b.name as member_name,
        //                                     c.city,
        //                                     c.province 
        //                                     from tb_sales a
        //                                     left join tb_member b on a.id_member = b.id
        //                                     left join tb_delivery c on a.code = c.sales_code
        //                                     where a.date = '$date_today' order by a.id DESC ");
        $this->db->select('
            tb_sales.*,
            tb_member.name as member_name
            ');
        $this->db->from('tb_sales');
        $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
        $this->db->where(['tb_sales.date' => $date_today]);
        $this->db->order_by('tb_sales.id', 'DESC');
        $get_sales_today = $this->db->get();
        $data_html = '
        <div class="table-responsive">
        <table class="table table_view_sales">
        <thead>
        <tr>
        <th>No</th>
        <th>Kode Nota</th>
        <th>Tanggal</th>
        <th>Grand Total</th>
        <th>bayar</th>
        <th>kembali</th>
        <th>Status Piutang</th>
        <th>Jumlah Piutang</th>
        <th>Member</th>
        <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        ';
        $no = 0;
        foreach ($get_sales_today->result() as $data_table) {
            $no++;
            $date_explode = explode('-', $data_table->date);
            $date_order = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
            $grand_total = number_format($data_table->grand_total, 0, '.', '.');
            $payment = number_format($data_table->payment, 0, '.', '.');
            $rest_payment = number_format($data_table->rest_payment, 0, '.', '.');
            $status_credit = $data_table->credit_status ? '<label class="label label-success">TRUE</label>' : '-';
            $credit_price = $data_table->credit_price > 0 ? 'Rp.' . number_format($data_table->credit_price, 0, '.', '.') : '-';
            $data_html .= '
            <tr>
            <td>' . $no . '</td>
            <td>' . $data_table->code . '</td>
            <td>' . $date_order . '</td>
            <td>' . $grand_total . '</td>
            <td>' . $payment . '</td>
            <td>' . $rest_payment . '</td>
            <td>' . $status_credit . '</td>
            <td>' . $credit_price . '</td>
            <td>' . $data_table->member_name . '</td>
            <td>
            <button type="button" onclick="get_invoice(' . "'" . $data_table->id . "'" . ')" class="btn btn-default"><i class="fa fa-print"></i></button>
            <button type="button" onclick="view_detail_sales(' . "'" . $data_table->id . "'" . ')" class="btn btn-default"><i class="fa fa-list"></i></button>
            </td>
            </tr>
            ';
        }
        $data_html .= '
        </tbody>
        <table>
        </div>
        ';
        echo $data_html;
    }

    public function get_detail_sales($id_sales)
    {
        $get_data_detail = $this->db->query("select a.*,
         b.code as code_sales,
         b.grand_total,
         b.ppn,
         b.ppn_price,
         b.pph,
         b.pph_price,
         b.grand_total_sales,
         b.payment,
         b.rest_payment,
         b.date,
         b.credit_status,
         b.credit_price,
         c.name,
         c.code as product_code,
         c.qty_unit,
         c.code as code_product,
         d.name as unit_name,
         f.name as member_name,
         h.code AS credit_code,
         h.price AS credit_price_current,
         h.note AS credit_note,
         h.deadline AS credit_deadline,
         i.name AS conversion_name,
         i.qty AS conversion_qty
         from tb_detail_sales a 
         left join tb_sales b on a.id_sales = b.id
         left join tb_product c on a.id_product = c.id 
         left join tb_unit d on c.id_unit = d.id 
         left join tb_member f on b.id_member = f.id
         left join tb_credit h on b.code = h.id_transaction 
         left join tb_product_has_conversion i on a.id_conversion_unit = i.id 
         where a.id_sales = '$id_sales'
         ")->result();
        // print_r($get_data_detail[0]);
        // exit;
        $date_order_explode = explode('-', $get_data_detail[0]->date);
        $date_order_html = $date_order_explode[2] . '-' . $date_order_explode[1] . '-' . $date_order_explode[0];
        //status
        $status_credit  = $get_data_detail[0]->credit_status ? '<label class="label label-success">TRUE</label>' : '-';
        $label_credit   = $get_data_detail[0]->credit_price > 0 ? 'Rp.' . number_format($get_data_detail[0]->credit_price, 0, '.', '.') : '-';
        //create html form
        $html_delivery = '';
        // if ($get_data_detail[0]->delivery_status) {
        //     $html_delivery = '
        //                         <div class="col-md-6 p-10  border-radius-5 pull-right">
        //                             <h3>Alamat Tujuan:</h3>
        //                             <table class="table">
        //                                 <tr>
        //                                     <td width="200px">Kode Pengiriman</td>
        //                                     <td width="10px">:</td>
        //                                     <td><b>' . $get_data_detail[0]->delivery_code . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Kepada</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->receiver . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Tujuan</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->kec . '&nbsp;-&nbsp;' . $get_data_detail[0]->city . '&nbsp;-&nbsp;' . $get_data_detail[0]->province . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Alamat Lengkap</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->address . '</b></td>
        //                                 </tr>
        //                             </table>
        //                         </div>
        //                     ';
        // }

        $html_credit = '';
        if ($get_data_detail[0]->credit_status) {
            $html_credit = '
            <div class="col-md-6 p-10 border border-radius-5 mb-10 pull-right">
            <h3>Keterangan Piutang:</h3>
            <table class="table">
            <tr>
            <td width="200px">Kode Piutang</td>
            <td width="10px">:</td>
            <td><b>' . $get_data_detail[0]->credit_code . '</b></td>
            </tr>
            <tr>
            <td>Penganggung Jawab</td>
            <td>:</td>
            <td><b>' . $get_data_detail[0]->responsible_name . '</b></td>
            </tr>
            <tr>
            <td>Jumlah Piutang</td>
            <td>:</td>
            <td><b>Rp.' . number_format($get_data_detail[0]->credit_price_current, 0, '.', '.') . '</b></td>
            </tr>
            <tr>
            <td>Jatuh Tempo</td>
            <td>:</td>
            <td><b>' . $get_data_detail[0]->credit_deadline . '</b></td>
            </tr>
            <tr>
            <td>Catatan</td>
            <td>:</td>
            <td><b>' . $get_data_detail[0]->credit_note . '</b></td>
            </tr>
            </table>
            </div>
            ';
        }

        $data_html = '
        <table class="col-md-6">
        <tr>
        <td width="200px" height="30px">Kode</td>
        <td width="5px">:</td>
        <td>' . $get_data_detail[0]->code_sales . '</td>
        </tr>
        <tr>
        <td width="100px" height="30px">Tanggal</td>
        <td width="5px">:</td>
        <td>' . $date_order_html . '</td>
        </tr>
        <tr>
        <td width="100px" height="30px">Member</td>
        <td width="5px">:</td>
        <td>' . $get_data_detail[0]->member_name . '</td>
        </tr>
        </table>
        <table class="col-md-6">
        <tr>
        <td width="200px" height="30px">Grand Total</td>
        <td width="5px">:</td>
        <td>Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</td>
        </tr>
        <tr>
        <td height="30px">Bayar</td>
        <td>:</td>
        <td>Rp.' . number_format($get_data_detail[0]->payment, 0, '.', '.') . '</td>
        </tr>
        <tr>
        <td height="30px">Kembali</td>
        <td>:</td>
        <td>Rp.' . number_format($get_data_detail[0]->rest_payment, 0, '.', '.') . '</td>
        </tr>
        <tr>
        <td height="30px">Status Piutang</td>
        <td>:</td>
        <td>' . $status_credit . '</td>
        </tr>
        <tr>
        <td height="30px">Jumlah Piutang</td>
        <td>:</td>
        <td>' . $label_credit . '</td>
        </tr>
        </table>
        <span class="clearfix"></span>
        <hr>
        <span class="clearfix"></span>
        <table class="table">
        <thead>
        <tr>
        <th>No</th>
        <th>Kode</th>
        <th>nama</th>
        <th>Harga Satuan</th>
        <th>Jumlah Beli</th>
        <th>Diskon</th>
        <th>Bonus</th>
        <th>Total</th>
        </tr>
        </thead>
        <tbody>
        ';
        //get data here
        $no = 0;
        foreach ($get_data_detail as $data_detail) {
            $no++;
            //count base qty buy 

            if ($data_detail->conversion_name) {
                $label_qty_buy = '';
                $unit_value = $data_detail->qty % $data_detail->conversion_qty;
                $conversion_value = ($data_detail->qty - $unit_value) / $data_detail->conversion_qty;

                if ($conversion_value > 0) {
                    $conversion_qty = $data_detail->conversion_qty * $conversion_value;
                    $label_qty_buy .= $conversion_value . ' ' . $data_detail->conversion_name . '( ' . $conversion_qty . ' ' . $data_detail->unit_name . ')' . '<br>';
                }
                if ($unit_value > 0) {
                    $label_qty_buy .= $unit_value . ' ' . $data_detail->unit_name;
                }
            } else {
                $label_qty_buy = $data_detail->qty . ' ' . $data_detail->unit_name;
            }

            $data_html .= '
            <tr>
            <td>' . $no . '</td>	
            <td>' . $data_detail->product_code . '</td>
            <td>' . $data_detail->name . '</td>
            <td>' . number_format($data_detail->price, 0, '.', '.') . '</td>
            <td>' . $label_qty_buy . '</td>
            <td>' . $data_detail->discount . '% ( Rp.' . number_format($data_detail->price_discount, 0, '.', '.') . ' )' . '</td>
            <td>' . $data_detail->bonus . '</td>
            <td>' . number_format($data_detail->total_price, 0, '.', '.') . '</td>
            </tr>
            ';
        } //end foreach
        $data_html .= '
        <tr>
        <td colspan="7" class="text-right">Total Pembelian</td>
        <td>:</td>
        <td><b>Rp.' . number_format($get_data_detail[0]->grand_total_sales, 0, '.', '.') . '</b></td>
        </tr>
        <tr>
        <td colspan="7" class="text-right">PPN ' . $get_data_detail[0]->ppn . ' %</td>
        <td>:</td>
        <td><b> Rp.' . number_format($get_data_detail[0]->ppn_price, 0, '.', '.') . '</b></td>
        </tr>
        <tr>
        <td colspan="7" class="text-right">PPH ' . $get_data_detail[0]->pph . ' %</td>
        <td>:</td>
        <td><b> Rp.' . number_format($get_data_detail[0]->pph_price, 0, '.', '.') . '</b></td>
        </tr>
        <tr>
        <td colspan="7" class="text-right">GRAND TOTAL</td>
        <td>:</td>
        <td><b> Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</b></td>
        </tr>
        ';

        $data_html .= '
        </tbody>
        </table>
        <hr>
        ' . $html_delivery . $html_credit . '
        <div class="col-md-12" align="right">
        <button type="button" onclick="get_invoice(' . "'" . $id_sales . "'" . ')" class="btn btn-default"><i class="fa fa-print"></i> Cetak Nota</button>
        </div>
        ';
        echo $data_html;
    }

    public function get_discount()
    {
        $type = $this->input->post('type');
        //get detail
        $this->db->select('
            tb_event_has_product.*,
            tb_product.code AS code_product,
            tb_product.name AS product_name,
            tb_product.price AS price_product,
            product_bonus.name AS product_bonus_name
            ');
        $this->db->from('tb_product');
        $this->db->join('tb_event_has_product', 'tb_event_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_event', 'tb_event_has_product.id_event = tb_event.id', 'left');
        $this->db->join('tb_product AS product_bonus', 'tb_event_has_product.id_bonus_product = product_bonus.id', 'left');
        $this->db->where(['tb_event.type' => $type, 'tb_product.id_detail_event >' => 0, 'tb_event.status' => 1]);
        $get_detail_event = $this->db->get()->result();
        $html_tr = '';
        $counter = 0;
        if ($type == 1) {
            foreach ($get_detail_event as $item_detail) {
                $counter++;
                $html_tr .= '
                <tr>
                <td width="20px">' . $counter . '</td>
                <td>' . $item_detail->code_product . '</td>
                <td>' . $item_detail->product_name . '</td>
                <td>Rp.' . number_format($item_detail->price_product, 0, '.', '.') . '</td>
                <td>' . $item_detail->discount . ' %</td>
                </tr>
                ';
            }

            $html_respon = '
            <div class="col-md-12 p-10">
            <div class="table-responsive">
            <table class="table table-striped table-event">
            <thead>
            <tr>
            <th>No</th>
            <th>Kode Produk</th>
            <th>Nama Produk</th>
            <th>Jual satuan</th>
            <th>Diskon</th>
            </tr>
            </thead>
            <tbody>
            ' . $html_tr . '
            </tbody>
            </table>
            </div>
            </div>

            ';
        } else {

            foreach ($get_detail_event as $item_detail) {
                $counter++;
                $html_tr .= '
                <tr>
                <td width="20px">' . $counter . '</td>
                <td>' . $item_detail->code_product . '</td>
                <td>' . $item_detail->product_name . '</td>
                <td>Rp.' . number_format($item_detail->price_product, 0, '.', '.') . '</td>
                <td>' . $item_detail->min_qty . ' PCS</td>
                <td>' . $item_detail->product_bonus_name . '</td>
                <td>' . $item_detail->qty_bonus_product . ' PCS</td>
                </tr>
                ';
            }

            $html_respon = '
            <div class="col-md-12 p-10">
            <div class="table-responsive">
            <table class="table table-striped table-event">
            <thead>
            <tr>
            <th>No</th>
            <th>Kode Produk</th>
            <th>Nama Produk</th>
            <th>Jual satuan</th>
            <th>Min.Pembelian</th>
            <th>Produk Bonus</th>
            <th>Jml.Bonus</th>
            </tr>
            </thead>
            <tbody>
            ' . $html_tr . '
            </tbody>
            </table>
            </div>
            </div>
            ';
        }

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }
}
