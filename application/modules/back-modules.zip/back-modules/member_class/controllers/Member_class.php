<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Member_class extends BackendController
{
    var $module_name        = 'member_class';
    var $module_directory   = 'member_class';
    var $module_js          = ['member_class'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['page_title'] = "Kelas member";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        $get_all_data = $this->db->order_by('id', 'DESC')->where(['type' => 2])->get('tb_member_category');
        $data = array();
        $no = 0;
        foreach ($get_all_data->result() as $data_table) {
            $btn_edit = Modules::run('security/edit_access', '<a class="btn btn-sm btn-rounded btn-warning-gradient" href="javascript:void(0)" title="Edit" onclick="edit_unit(' . "'" . $data_table->id . "'" . ')"><i class="glyphicon glyphicon-pencil"></i> edit</a>');
            $btn_delete = Modules::run('security/delete_access', '<a class="btn btn-sm btn-rounded btn-danger-gradient" href="javascript:void(0)" title="Hapus" onclick="delete_unit(' . "'" . $data_table->id . "'" . ')"><i class="glyphicon glyphicon-trash"></i> delete</a>');

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();
        //insert data
        $name         = $this->input->post('name');
        $array_insert = array(
            'name' => $name,
            'type' => 2,
            'created_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/insert', 'tb_member_category', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    public function get_edit($id)
    {
        $get_data = Modules::run('database/find', 'tb_member_category', ['id' => $id])->row_array();
        echo json_encode($get_data);
    }

    public function update()
    {
        $this->validate_insert();
        $id         = $this->input->post('id');
        //insert data
        $name         = $this->input->post('name');
        $persentage   = $this->input->post('persentage');
        $array_update = array(
            'name' => $name,
            'persentage_discount' => $persentage,
            'updated_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/update', 'tb_member_category', ['id' => $id], $array_update);
        echo json_encode(array('status' => TRUE));
    }

    public function delete($id)
    {
        Modules::run('database/delete', 'tb_member_category', ['id' => $id]);
        echo json_encode(array('status' => TRUE));
    }
}
