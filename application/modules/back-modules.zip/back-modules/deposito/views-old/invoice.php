<?php
$get_profile    = $this->db->get('tb_profile')->row();
$get_ppn        = $this->db->where(['field' => 'ppn'])->get('tb_setting')->row()->value;
?>
<style>
    #invoice-POS {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, "Times New Roman", Georgia, serif;

    }

    p {
        margin: 0;
        padding: 0;
    }

    .itemtext {
        font-size: 12px;
    }

    .small_text {
        font-size: 8px;
    }

    h3,
    h2,
    h5,
    h4 {
        padding: 0;
        margin: 0;
    }

    tr {
        padding: 0px;
        margin: 0px;
        line-height: 13px;
    }
</style>

<div id="invoice-POS">
    <center id="top">
        <div class="logo"></div>
        <div class="info">
            <img style="width:50px !important;" src="<?= base_url('upload/profile/' . $get_profile->image); ?>" alt="">
            <h3><?= $get_profile->name; ?></h3>
            <p class="itemtext">" <?= $get_profile->tagline; ?> "</p>
            <p align="center" class="small_text"><?= $get_profile->address . ' | ' . $get_profile->email; ?></p>
        </div>
        <!--End Info-->
    </center>
    <!--End InvoiceTop-->
    <br>

    <div id="mid">
        <div class="info">
            <!-- <p>
                Address : street city, state 0000</br>
                Email : JohnDoe@gmail.com</br>
            </p> -->
            <table>
                <tr>
                    <td width="50px;" class="itemtext">No.Nota</td>
                    <td width="5px" class="itemtext">:</td>
                    <td class="itemtext"><?= $data_deposito->code . ' / ' . $data_deposito->created_date; ?></td>
                </tr>
                <tr>
                    <td width="50px;" class="itemtext">Kasir</td>
                    <td width="5px" class="itemtext">:</td>
                    <td class="itemtext"><?= $data_deposito->user_name; ?></td>
                </tr>
                <tr>
                    <td width="50px;" class="itemtext">Member</td>
                    <td width="5px" class="itemtext">:</td>
                    <td class="itemtext"><?= $data_deposito->member_name; ?></td>
                </tr>
            </table>
        </div>
    </div>
    <!--End Invoice Mid-->
    <div id="bot">
        <div id="table">
            <table style="width: 100%;">
                <tr>
                    <td colspan="3">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="tabletitle" style="margin-bottom: 15px !important;">
                    <td class="item" align="left" style="width:50%;">
                        <h5 align="left">Nominal Topup:</h5>
                    </td>
                    <td class="Rate" align="right" style="width:50%;">
                        <h4 align="right"><?= number_format($data_deposito->price_top_up, 0, '.', '.'); ?></h4>
                    </td>
                </tr>

                <tr>
                    <td colspan="3">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="right"><b>Grand Total</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_deposito->price_top_up, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="right"><b>Administrasi</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_deposito->administration, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="right"><b>Bayar</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_deposito->payment, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="right"><b>Kembali</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_deposito->rest, 0, '.', '.'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        <!--End Table-->

        <div id="legalcopy" style="margin-top: 20px;">
            <p class="itemtext" align="center">* <?= $get_profile->footer_note; ?> *</p>
        </div>

    </div>
    <!--End InvoiceBot-->
</div>
<!--End Invoice-->