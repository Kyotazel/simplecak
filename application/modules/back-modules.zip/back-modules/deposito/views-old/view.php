<div class="card">
    <div class="card-body">
        <div class="col-md-4 form-group">
            <label for="">*Masukan Kode member</label>
            <input class="form-control form-control-lg " name="member_code">
            <span class="help-block text-red"></span>
        </div>
        <div class="col-md-3">
            <label for="">&nbsp;</label><br>
            <button class="btn btn-success btn_search"><i class="fa fa-search"></i> Cari Data</button>
        </div>
        <div class="col-md-5" align="right">
            <label for=""><i class="fa fa-shopping-bag"></i> Data Hari ini</label><br>
            <button type="button" class="btn btn-default btn_view_member"><i class="fa fa-list-alt"></i> Saldo Deposito Member <b>(F3)</b></button>
            <button type="button" class="btn btn-default btn_view_top_up"><i class="fa fa-history"></i> <label class="order_today"></label> TOP UP hari ini <b>(F4)</b></button>
        </div>
    </div>
</div>

<div class="html_respon">
</div>

<span class="clearfix"></span>
<div class="col-md-8 bg-white d-none" id="html_nota">
</div>
<div class="col-md-4 d-none">
    <button type="button" class="btn_print" onclick="printJS('html_nota', 'html')">
        Print Form
    </button>
</div>

<div class="modal" id="modal-detail">
    <div class="modal-dialog" style="width:60%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal_datail"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>