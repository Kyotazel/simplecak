<?php
// print_r($price_deposito);
?>
<div class="card">
    <div class="card-header">
        <label style="font-size:15px;" class="col-md-3 label label-info"><i class="fa fa fa-cart-arrow-down"></i> TOP UP Hari Ini</label>
        <div class="col-md-4">
            <label><i class="fa fa-circle text-red"></i> Bayar = <span class="text-red">(Ctrl + Enter)</span></label> &nbsp;|
            <label><i class="fa fa-circle text-red"></i> Simpan = <span class="text-red">(F1)</span></label> &nbsp;
        </div>
    </div>
    <div class="card-body">
        <form class="form-horizontal form-input" method="POST">
            <div class="col-md-12">
                <div class="col-md-4">
                    <div style="padding:10px" class="text-center">
                        <small>Saldo Deposit Member:</small>
                        <h1>Rp.<?= number_format($data_member->total_deposito, 0, '.', '.'); ?></h1>
                    </div>
                    <input type="hidden" name="id_member" value="<?= $this->encrypt->encode($data_member->id); ?>">
                    <br>
                    <table class="table">
                        <tr>
                            <td width="200px">Kode Member</td>
                            <td width="5px">:</td>
                            <td><b><?= $data_member->code; ?></b></td>
                        </tr>
                        <tr>
                            <td>Nama Member</td>
                            <td>:</td>
                            <td><b><?= ucfirst($data_member->name); ?></b></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><b><?= ucfirst($data_member->address); ?></b></td>
                        </tr>
                        <tr>
                            <td>Tanggal Daftar</td>
                            <td>:</td>
                            <td><b><?= ucfirst($data_member->date); ?></b></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-7" style="border:1px solid #00a65a;padding:5px;margin-left:30px;margin-right:10px;padding:10px;border-radius:5px;">
                    <div class="col-md-12">
                        <label for="inputPassword3" class="col-sm-3 control-label">Nominal Deposit</label>
                        <div class="col-sm-6">
                            <div class="col-md-12 form-group">
                                <select name="price_top_up" class="form-control" style="font-size:20px;height:40px;" id="">
                                    <option value="">-pilih nominal top Up-</option>
                                    <?php
                                    foreach ($price_deposito as $item_deposito) {
                                        echo '
                                                <option value="' . $this->encrypt->encode($item_deposito) . '">Rp.' . number_format($item_deposito, 0, '.', '.') . '</option>
                                            ';
                                    }
                                    ?>
                                </select>
                                <span class="help-block notif_btn_payment" style="color:red;"></span>
                            </div>
                            <div class="col-md-6 text-left">
                                <label class="text-muted label_ppn">Admin =</label> <span class="text-ppn">Rp.<?= number_format($price_admin->value, 0, '.', '.'); ?></span>
                            </div>
                        </div>
                    </div>
                    <span class="clearfix"></span>
                    <hr>
                    <div class="col-md-12" align="center" style="margin-bottom:10px;">
                        <input type="hidden" name="grand_total" id="grand_total">
                        <input type="hidden" name="grand_total_sales" id="grand_total_sales">
                        <input type="hidden" name="ppn" id="ppn">
                        <input type="hidden" name="pph" id="pph">
                        <input type="hidden" name="all_item" id="all_item">
                        <h5 class="headline text-green col-md-12">GRAND TOTAL :</h5>
                        <h1 class="headline text-green col-md-12" id="grand_total_shown">Rp.0<b></b></h1>
                    </div>
                    <div class="col-md-12" align="center">
                        <label for="inputPassword3" class="col-sm-3 control-label">Bayar</label>
                        <div class="col-sm-6">
                            <div class="col-md-12 form-group">
                                <input type="text" class="form-control money_only" name="payment" id="payment" style="height:40px;font-size:20px;" placeholder="Rp..">
                                <span class="help-block notif_btn_payment" style="color:red;"></span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-lg btn-success btn_payment"> Bayar</button>
                            <small class="block">shortcut : <b>Enter</b></small>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end col md-12 -->
        </form>
    </div>
</div>

<div class="modal" id="modal_view_sales" data-backdrop="static">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">RESUME SALES</h4>
            </div>
            <div class="card-body pad">
                <div class="view_sales_today"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>