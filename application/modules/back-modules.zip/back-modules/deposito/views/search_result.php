<div class="table-responsive border-top userlist-table mt-2">
    <table id="table_data" class="table table-bordered dt-responsive nowrap t-shadow" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
        <thead>
            <th style="width: 5%;">No</th>
            <th>Gambar</th>
            <th style="width: 30%;">ID</th>
            <th style="width: 30%;">NAMA LENGKAP</th>
            <th>KTP & NPWP</th>
            <th>TYPE & CLASS</th>
            <th>TOP</th>
            <th>LIMIT</th>
            <th style="width: 10%;"></th>
        </thead>
        <tbody>
            <?php
            $no = 0;
            $html_tr = '';
            foreach ($data_customer as $data_table) {
                $id_encrypt = $this->encrypt->encode($data_table->id);
                $btn_delete     = Modules::run('security/delete_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-danger btn_delete"><i class="las la-trash"></i> </a>');
                $btn_edit     = Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-info btn_edit"><i class="las la-pen"></i> </a>');
                $active = $data_table->isActive == 'Y' ? 'on' : '';

                $image = $data_table->image ? base_url('upload/customer/' . $data_table->image) : base_url('assets/themes/valex/img/faces/3.jpg');
                $no++;
                $html_td = '';
                // $row = array();
                $html_td .= ' <td>' . $no . '</td> ';
                $html_td .= '<td>
                                <div class="main-img-user avatar-md d-block">
                                    <img alt="avatar" class="rounded-circle" src="' . $image . '">
                                </div>
                            </td>';
                $html_td .= '<td>' . $data_table->code . '</td>';
                $html_td .= '
                            <td>
                                <div class="row col-12 border-dashed" style="white-space:initial;width:300px;">
                                    <div class="col">
                                        <div class=" mt-2 mb-2 text-primary"><b>' . strtoupper($data_table->name) . '</b></div>
                                        <p class="tx-11" style="white-space:initial;">' . $data_table->address . '</p>
                                    </div>
                                    <div class="col-auto align-self-center ">
                                        <div class="feature mt-0 mb-0">
                                            <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label for="" class="d-block m-0 col-12 border-right">
                                        <small class="text-muted"><i class="fa fa-circle"></i> Email :</small>
                                        <small>' . $data_table->email . '</small>
                                    </label>
                                    <label for="" class="d-block m-0 col-6 mt-12">
                                        <small class="text-muted"><i class="fa fa-circle"></i> Telp :</small>
                                        <small>' . $data_table->number_phone . '</small>
                                    </label>
                                </div>
                            </td>
                            ';
                $html_td .= '
                        <td>
                            <div class="p-2 border-dashed">
                                <small class="text-muted">KTP :</small><br>
                                ' . $data_table->ktp . '
                            </div>
                            <div class="p-2 border-dashed">
                                <small class="text-muted">NPWP :</small><br>
                                ' . $data_table->npwp . '
                            </div>
                        </td>
                    ';
                $html_td .= '
                        <td>
                            <div class="input-group" style="width:200px;">
                                <div class="input-group-prepend">
                                    <div class="input-group-text font-weight-bold" style="width:60px";>
                                        Type
                                    </div>
                                </div>
                                <input type="text" readonly value="' . $data_table->member_type_name . '"  class="form-control bg-white border-dashed font-weight-bold">
                            </div>
                            <div class="input-group" style="width:200px;">
                                <div class="input-group-prepend">
                                    <div class="input-group-text font-weight-bold" style="width:60px";>
                                        Class
                                    </div>
                                </div>
                                <input type="text" readonly value="' . $data_table->member_class_name . '"  class="form-control bg-white border-dashed font-weight-bold">
                            </div>
                        </td>
                    ';
                $html_td .= '
                        <td>
                            <div class="input-group" style="width:200px;">
                                <div class="input-group-prepend">
                                    <div class="input-group-text font-weight-bold" style="width:80px";>
                                        Nota
                                    </div>
                                </div>
                                <input type="text" readonly value="' . $data_table->top_nota . ' HARI"  class="form-control bg-white border-dashed font-weight-bold">
                            </div>
                            <div class="input-group" style="width:200px;">
                                <div class="input-group-prepend">
                                    <div class="input-group-text font-weight-bold" style="width:80px";>
                                        Internal
                                    </div>
                                </div>
                                <input type="text" readonly value="' . $data_table->top_internal . ' HARI"  class="form-control bg-white border-dashed font-weight-bold">
                            </div>
                        </td>';
                $html_td .= '
                        <td>
                            <div class="input-group" style="width:200px;">
                                <div class="input-group-prepend">
                                    <div class="input-group-text font-weight-bold">
                                        Rp.
                                    </div>
                                </div>
                                <input type="text" readonly value="' . number_format($data_table->credit_limit, 0, '.', '.') . '"  class="form-control bg-white border-dashed font-weight-bold">
                            </div>
                        </td>
                    ';
                $row[] .= ' <td>' . $btn_edit . $btn_delete . ' </td>';
                $html_tr .= ' <tr>' . $html_td . '</tr> ';
            }
            echo $html_tr;
            ?>
        </tbody>
    </table>
</div>