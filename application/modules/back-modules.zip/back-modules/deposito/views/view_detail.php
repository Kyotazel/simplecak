<div class="container">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5>Detail Saldo</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <small>Data Customer:</small>
                    <div class="row col-12 border-dashed">
                        <div class="col">
                            <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_customer->name; ?></b></div>
                            <p class="tx-12">
                                <?= $data_customer->address; ?> </p>
                        </div>
                        <div class="col-auto align-self-center ">
                            <div class="feature mt-0 mb-0">
                                <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="p-2 shadow-2 text-center">
                        <small>Total Saldo :</small>
                        <h2>Rp.<?= number_format($data_customer->saldo, 0, '.', '.'); ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table id="table-data-deposito" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Kode Invoice</th>
                                    <th>Debit / Credit</th>
                                    <th>Saldo Akhir</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 0;
                                foreach ($data_deposito as $item_deposito) {
                                    if ($item_deposito->status == 1) {
                                        $sign = '+';
                                        $class = 'text-success';
                                    }
                                    if ($item_deposito->status == 2) {
                                        $sign = '-';
                                        $class = 'text-danger';
                                    }
                                    $counter++;
                                    echo '

                                            <tr>
                                                <td>' . $counter . '</td>
                                                <td>' . Modules::run('helper/date_indo', $item_deposito->date, '-') . '</td>
                                                <td>' . $item_deposito->invoice_code . '</td>
                                                <td>
                                                    <span class="' . $class . '">' . $sign . ' Rp.' . number_format($item_deposito->price, 0, '.', '.') . '</span>
                                                </td>
                                                <td class="font-weight-bold">Rp.' . number_format($item_deposito->total_deposito, 0, '.', '.') . '</td>
                                            </tr>
                                        
                                        ';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>