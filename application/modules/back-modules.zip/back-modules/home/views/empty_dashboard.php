<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-center align-items-center" style="min-height: 500px;">
            <div class="col-12 text-center">
                <div class="plan-card text-center">
                    <i class="fas fa-tv plan-icon text-primary "></i>
                    <h6 class="text-drak text-uppercase mt-2">HAK AKSES " <span class="badge badge-light tx-20"> <?= $this->session->userdata('us_credetial_name'); ?></span> " BELUM MEMILIKI DASHBOARD</h6>
                    <small class="text-muted">silahkan hubungi admin untuk membuat dashboard hak akses ini.</small>
                </div>
            </div>
        </div>
    </div>
</div>