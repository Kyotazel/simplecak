<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <a href="<?php echo base_url('stock_opname') ?>" class="btn btn-default pull-right btn_link"><i class="fa fa-list"></i> Data Stok Opname</a>
    </div>

    <div class="card-body">
        <form method="POST" id="form_stock_opname">
            <div class="col-md-12">
                <div class="form-group col-md-4">
                    <label>Kode Stok Opname</label>
                    <input type="text" class="form-control" value="<?php echo $code ?>" name="code" id="code" readonly style="background-color:#fff;">
                </div>
                <div class="form-group col-md-8">
                    <label>Catatan Stok Opname</label>
                    <textarea class="form-control" id="note" name="note" placeholder="masukan catatan untuk stok opname anda (optional)">
                    </textarea>
                </div>
            </div>
            <span class="clearfix"></span>
            <hr>
            <div class="col-md-12">
                <input type="hidden" name="data_product">
                <div class="col-md-2 form-group">
                    <label>Barcode Barang</label>
                    <input type="text" class="form-control" id="barcode" name="barcode">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-3 form-group">
                    <label>Nama Produk</label>
                    <input type="text" id="product-name" class="form-control" name="product_name">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-2 form-group">
                    <label>Total Stok</label>
                    <input type="text" class="form-control bg-white" readonly name="total_stock">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-2 form-group">
                    <label>Stok Sistem</label>
                    <input type="text" class="form-control bg-white" readonly name="stock">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-2 form-group">
                    <label>Stok Baru</label>
                    <input type="text" class="form-control number_only" name="qty">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-1 form-group">
                    <label>&nbsp;</label><br>
                    <a href="javascript:void(0)" class="btn btn-default btn_add_item"><i class="fa fa-plus-circle"></i> Tambah</a>
                    <span class="help-block"></span>
                </div>
            </div>
            <span class="clearfix"></span>
            <hr>
            <table class="table  table-striped">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Produk</th>
                        <th>Stok Jurnal</th>
                        <th width="200px">Stok Baru</th>
                    </tr>
                </thead>
                <tbody class="tbody_item">
                </tbody>
            </table>
        </form>
        <div class="text-right">
            <small>(*klik untuk simpan data)</small>
            <button type="button" class="btn btn-success btn-lg review_stock_opname"><i class="fa fa-save"></i> Simpan Data</button>
        </div>
    </div>
    <!-- /.box-body -->

</div>


<div class="modal" id="modal_stock_review">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="html-content-stock"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>