var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/stock_opname/';
var save_method;
var table_request;
var table_reject;
var table_receive;
var id_use;
var all_item;

$(document).ready(function() {
    // $('#modal_stock_review').modal('show');
    table = $('#table_list').DataTable({
        "ajax": {
            "url": controller + "list_stock_opname",
            "type": "POST"
        }
    });

    $('#note').val('');
    $('#note').focus();
})

$(document).on('change', '#barcode', function (e) {
    e.preventDefault();
    
    $(".form_stock_opname").submit(function (e) {
        return false;
    });

    var barcode_current = $(this).val();
        $.ajax({
            url: controller + '/get_barcode_choosen/',
            type: "POST",
            dataType: "JSON",
            data:{'barcode':barcode_current},
            success: function (ui) {
                if (ui.status) {
                    
                    $('#product-name').val(ui.item.label);
                    get_unit_request(ui.item.id);
                    $('[name="qty"]').focus();
                    $('[name="stock"]').val(ui.item.stock);
                    $('[name="unit"]').val(ui.item.unit_name);
                } else {
                    alert_error('barang tidak ditemukan');
                }
                
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    })

$('#product-name').autocomplete({
    source: controller + "/get_product_auto",
    select: function(event, ui) {
        event.preventDefault();
        console.log(ui.item);
        $('#product-name').val(ui.item.label);
        get_unit_request(ui.item.id);
        $('[name="qty"]').focus();
        $('[name="stock"]').val(ui.item.stock);
        $('[name="unit"]').val(ui.item.unit_name);
    }
});

function get_unit_request(id) {
    $.ajax({
	    url: controller+'/get_unit_request',
	    type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            $('[name="total_stock"]').val(data.total_stock);
            $('[name="data_product"]').val(data.data_product);
            if (data.total_stock == 0) {
                Swal.fire(
                    'BELUM ADA STOK!',
                    data.name+ ' belum ter stok !',
                    'error'
                );

                $('#product-name').val('');
                $('#barcode').val('');
                $('[name="qty"]').val('');
                $('[name="total_stock"]').val('');
                $('[name="data_product"]').val('');
                $('[name="stock"]').val('');
                $('[name="unit"]').val('');
                $('#barcode').focus();
            }
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_add_product').button('reset');
	       alert_error('something wrong');
	      }
	  });//end ajax
}

$(document).on('keypress', '[name="qty"]', function (event) {
    if (event.keyCode === 13) { 
        $('.btn_add_item').click();
    } 
});

$('.btn_add_item').click(function () {
    var data_product = $('[name="data_product"]').val();
    var unit = $('[name="unit"]').val();
    var qty = $('[name="qty"]').val();

    if (data_product == '' || unit == '' || qty == '') {
        alert_error('lengkapi data');
    } else {
        $.ajax({
            url: controller+'/add_item_product',
            type: "POST",
            dataType: "JSON",
            data:{'data_product':data_product,'unit':unit,'qty':qty},
            success: function (data) {
                $('.html_no_data').remove();
                var chek_tr = $('.tr_' + data.id).length;
                if (chek_tr) {
                    $('.tr_' + data.id).remove();
                }
                $('.tbody_item').append(data.html_respon);
                $('#product-name').val('');
                $('#barcode').val('');
                $('[name="qty"]').val('');
                $('[name="unit"]').html('');
                $('[name="total_stock"]').val('');
                $('[name="data_product"]').val('');
                $('[name="stock"]').val('');
                $('[name="unit"]').val('');
                $('#barcode').focus();
            },
              error:function(jqXHR, textStatus, errorThrown)
              {
               alert_error('something wrong');
              }
          });//end ajax
    }    
})

$(document).on('click', '.btn_cancel', function (e) {
    e.preventDefault();
    $(this).parent().parent().remove();
    var count_tr = $('.tbody_item').has('tr').length;
    if (count_tr == 0) {
        $('.tbody_item').html('<tr class="html_no_data"><td colspan="8" class="text-center"><h3 class="text-center text-muted mb-10">Pilihlah Data Produk Stok Barang</h3></td></tr>');
    }
})


function detail_stock(id) {
    showLoading();
    $('.modal-title').text('DETAIL STOK OPNAME');
    // var formData = new FormData($('.form-stock-choosen')[0]);
    $.ajax({
        url: controller + "get_detail_stock/" + id,
        type: "GET",
        dataType: "HTML",
        success: function(data) {
            hideLoading();
            $('.content-html-detail').html(data);
            // $('.table_detail').DataTable();
            // notif_success('cek');
            $('#modal_detail').modal('show');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('error process');
showLoading();
        }
    });
}


$('.review_stock_opname').click(function () {
    $('.help-block').empty();
    // showLoading();
    //defined form
    var formData = new FormData($('#form_stock_opname')[0]);
    var hmtl_item = $('.tbody_item').html();
    $('.modal-title').text('CEK KEMBALI');
    formData.append('html_item', hmtl_item);
    $.ajax({
        url: controller + 'review_stock',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html-content-stock').html(data.html_respon);
                $('#modal_stock_review').modal('show');
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    if (data.inputerror[i] == 'product') {
                        Swal.fire(
                            'Produk Kosong',
                            'produk belum dipilih',
                            'warning'
                        );
                    } else {
                        $('.' + data.inputerror[i]).parent().addClass('has-error');
                        $('.' + data.inputerror[i]).next().text(data.error_string[i]);
                    }
                }
            }

        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert('error process');
showLoading();
        }
    });
});

$('[name="qty"]').keyup(function () {
    var value_qty = parseInt(delete_dot_value($(this).val()));
    var value_stock = parseInt($('[name="total_stock"]').val());
    if (value_qty > value_stock) {
        $(this).val('');
        alert_error('maksimal ' + value_stock);
    }
});

function delete_dot_value(value) {
    var array_value = value.split('.');
    var count_array = array_value.length;
    payment_value = value;
    for (var i = 0; i < count_array; i++) {
        payment_value = payment_value.replace('.', '');
    };
    return payment_value;
}

$(document).on('click', '.btn_save', function () {
    $('.help-block').empty();
    // showLoading();
    //defined form
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            var formData = new FormData($('#form_stock_opname')[0]);
            $.ajax({
                url: controller + 'save',
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function(data) {
                    if (data.status) {
                        window.location.href = controller;
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            if (data.inputerror[i] == 'product') {
                                Swal.fire(
                                    'Produk Kosong',
                                    'produk belum dipilih',
                                    'warning'
                                );
                            } else {
                                $('.' + data.inputerror[i]).parent().addClass('has-error');
                                $('.' + data.inputerror[i]).next().text(data.error_string[i]);
                            }
                        }
                    }

                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert_error('error process');
                }
            });
        }
    })

    
})

// function get_html_review() {
//     var code_html = $('#code').val();
//     var note_html = $('#note').val();
//     $('.modal-title').text('Koreksi Kembali');
//     var formData = new FormData($('#form_stock_opname')[0]);
//     $.ajax({
//         url: controller + 'get_html_review',
//         type: "POST",
//         data: formData,
//         contentType: false,
//         processData: false,
//         dataType: "HTML",
//         success: function(data) {
//             $('#code_html').html(code_html);
//             $('#note_html').html(note_html);
//             $('.html-content-stock').html(data);
//             $('#modal_stock_review').modal('show');
//         },
//         error: function(jqXHR, textStatus, errorThrown) {
//             alert('error process');
showLoading();
//         }

//     });
// }

$('.table-data').on('keyup', '.number_type', function() {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});

// $('.number_type').keyup(function(){
//   var new_val = money_function($(this).val());
//   $(this).val(new_val);
// })

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
})

// $('.save_stock_opname').click(function() {
//     $('#modal_stock_review').modal('hide');
//     showLoading();
//     var formData = new FormData($('#form_stock_opname')[0]);
//     $.ajax({
//         url: controller + 'save',
//         type: "POST",
//         data: formData,
//         contentType: false,
//         processData: false,
//         dataType: "JSON",
//         success: function(data) {
//             hideLoading();
//             if (data.status) {
//                 notif_success('data berhasil disimpan');
//                 window.location.href = controller;
//             } else {
//                 for (var i = 0; i < data.inputerror.length; i++) {
//                     // $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
//                     $('.' + data.inputerror[i]).text(data.error_string[i]);
//                 }
//             }

//         },
//         error: function(jqXHR, textStatus, errorThrown) {
//             alert('error process');
showLoading();
//         }

//     });
// })