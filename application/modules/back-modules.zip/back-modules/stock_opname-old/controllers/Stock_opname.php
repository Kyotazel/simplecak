<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stock_opname extends CI_Controller
{
    var $location = 'data_stock_opname/';
    var $tb_name = 'tb_stock_correct';
    var $module_name = 'stock_opname';
    var $js_page = 'stock_opname';

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = $this->tb_name;
        $simbol = get_string_code($this->module_name);
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from $db_name")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }


    public function index()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Stok Opname";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin', $data);
    }
    public function list_stock_opname()
    {
        $db_name = $this->tb_name;
        $get_all_data = $this->db->query("select * from $this->tb_name order by id DESC");
        $data = array();
        $no = 0;
        foreach ($get_all_data->result() as $data_table) {
            $date_explode = explode('-', $data_table->date);
            $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $date_html;
            if ($data_table->note == '') {
                $row[] = '-';
            } else {
                $row[] = $data_table->note;
            }
            $row[] = '<a class="btn btn-sm btn-primary-gradient" href="javascript:void(0)" title="detail stock opname" onclick="detail_stock(' . "'" . $data_table->id . "'" . ')"><i class="fa fa-list"></i> Detail</a>';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function add()
    {
        $data['js_page'] =  $this->js_page;
        $data['code'] = $this->get_code();
        $data['tagline_page'] = "Stok Opname";
        $data['view_file'] = $this->location . 'add';
        $this->load->view('template/media_admin', $data);
    }

    public function get_product_auto()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                                                    a.id, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
                                                    where a.name like '%$term%' LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->name,
                        'id' => $data_product->id,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_barcode_choosen()
    {
        $barcode = $this->input->post('barcode');
        $data_product = $this->db->query("select 
                                                    a.id, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id 
                                                    left join tb_barcode_product d on a.id = d.id_product
                                                    where d.barcode = '$barcode' ")->row();

        if (!empty($data_product)) {
            $array_result = array(
                'label' => $data_product->name,
                'id' => $data_product->id,
                'price' => $data_product->price,
                'main_price' => $data_product->main_price,
                'unit_name' => $data_product->unit_name,
                'stock' => $data_product->stock
            );
            $array_respon = [
                'status' => TRUE,
                'item' => $array_result
            ];
        } else {
            $array_respon = [
                'status' => FALSE
            ];
        }
        echo json_encode($array_respon);
    }

    public function get_unit_request()
    {
        $id = $this->input->post('id');
        $get_data_current = $this->db->where(['id' => $id])->get('tb_product')->row();
        $data_unit = $this->db->where(['id' => $get_data_current->id_unit])->get('tb_unit')->row();
        //get alla stock
        $this->db->select('
            SUM(tb_detail_stock.new_stock) AS total_stock
        ');
        $this->db->from('tb_detail_stock');
        $this->db->join('tb_stock', 'tb_detail_stock.id_stock_opname = tb_stock.id', 'left');
        $this->db->where(['tb_detail_stock.id_product' => $id, 'tb_stock.id_account_warehouse ' => 0]);
        $get_stock = $this->db->get()->row();
        $total_stock = $get_stock->total_stock ? $get_stock->total_stock : 0;

        //get other conversion
        $get_all_conversion = $this->db->where(['id_product' => $id])->order_by('qty')->get('tb_product_has_conversion')->result();
        $array_value = [
            'id' => 0,
            'name' => $data_unit->name,
            'qty' => 1
        ];
        $html_option = '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $data_unit->name . '</option>';
        foreach ($get_all_conversion as $item_conversion) {
            $array_value = [
                'id' => $item_conversion->id,
                'name' => $item_conversion->name,
                'qty' => $item_conversion->qty
            ];
            $html_option .= '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $item_conversion->name . '</option>';
        }

        $array_respon = [
            'html_respon' => $html_option,
            'status' => TRUE,
            'name' => $get_data_current->name,
            'total_stock' => $total_stock,
            'data_product' => $this->encrypt->encode(json_encode($get_data_current))
        ];
        echo json_encode($array_respon);
    }


    public function add_item_product()
    {
        $get_data_product = json_decode($this->encrypt->decode($this->input->post('data_product')));
        $unit_name = $this->input->post('unit');
        $qty = $this->input->post('qty');

        $html_respon = '
                                <tr class="tr_' . $get_data_product->id . '">
                                    <td>' . $get_data_product->code . '</td>
                                    <td>' . $get_data_product->name . '</td>
                                    <td>' . $get_data_product->stock . ' ' . $unit_name . '</td>
                                    <td>' . $qty . ' ' . $unit_name . '</td>
                                    <td>
                                        <input type="hidden" name="old_stock[' . $get_data_product->id . ']" value="' . $get_data_product->stock . '">
                                        <input type="hidden" name="qty_item[' . $get_data_product->id . ']" value="' . $qty . '">
                                        <a href="javascript:void(0)" class="btn btn-danger btn_cancel"><i class="fa fa-close"></i></a>
                                    </td>
                                </tr>
                            ';

        $array_respon = [
            'id' => $get_data_product->id,
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }


    // public function count_stock_result($stock, $qty_unit, $unit_name, $base_unit_name)
    // {
    //     if ($stock != false) {
    //         $base_unit_val = $stock % $qty_unit;
    //         //count unit val
    //         $unit_val         = ($stock - $base_unit_val) / $qty_unit;
    //         // stock current
    //         $stock_current = '';
    //         if ($unit_val > 0) {
    //             $stock_current .= number_format($unit_val, 0, '.', '.') . '&nbsp;' . $unit_name;
    //         }
    //         if ($base_unit_val > 0) {
    //             if ($unit_val > 0) {
    //                 $stock_current .= '<br>';
    //             }
    //             $stock_current .= number_format($base_unit_val, 0, '.', '.') . '&nbsp;' . $base_unit_name;
    //         }
    //     } else {
    //         $stock_current = '0&nbsp;' . $base_unit_name;
    //     }

    //     return $stock_current;
    // }

    // public function list_product()
    // {
    //     $get_all_data = $this->db->query("select a.id,a.code,a.name,a.stock,a.qty_unit,b.name as unit_name, c.name as base_unit_name from tb_product a 
    // 										left join tb_unit b on a.id_unit = b.id
    // 										left join tb_base_unit c on b.id_base_unit = c.id
    // 										 order by a.id DESC");
    //     $data = array();
    //     $no = 0;
    //     foreach ($get_all_data->result() as $data_table) {
    //         $no++;
    //         $row = array();
    //         $row[] = $no;
    //         $row[] = $data_table->code;
    //         $row[] = $data_table->name;
    //         $row[] = $data_table->unit_name . '&nbsp;/&nbsp;' . number_format($data_table->qty_unit, 0, '.', '.') . '&nbsp;' . $data_table->base_unit_name;

    //         $row[] = $this->count_stock_result($data_table->stock, $data_table->qty_unit, $data_table->unit_name, $data_table->base_unit_name);
    //         $row[] = '
    // 					<input type="hidden" name="qty_unit[' . $data_table->id . ']" value="' . $data_table->qty_unit . '">
    // 					<input type="hidden" name="base_unit_name[' . $data_table->id . ']" value="' . $data_table->base_unit_name . '">
    // 					<div class="col-md-12">
    // 						<div class="form-group col-md-12">
    // 				            <div class="input-group date">
    // 				                <input type="text" class="form-control pull-right number_type"  name="stock_unit[' . $data_table->id . ']">
    // 				            <div class="input-group-addon">
    // 				            	<i class="unit_name">&nbsp;' . $data_table->unit_name . '</i>
    // 				            </div>
    // 				            </div>
    // 				            <span class="help-block" style="color:red;" id="unit_' . $data_table->id . '"></span>
    // 				        <!-- /.input group -->
    // 				        </div>
    // 				        <div class="form-group col-md-12">
    // 				            <div class="input-group date">
    // 				                <input type="text" class="form-control pull-right number_type"  name="stock_base_unit[' . $data_table->id . ']">
    // 				            <div class="input-group-addon">
    // 				            	<i class="unit_name">&nbsp;' . $data_table->base_unit_name . '</i>
    // 				            </div>
    // 				            </div>
    // 				        <!-- /.input group -->
    // 				        </div>
    // 				        <span style="color:red;" class="help-block notification_' . $data_table->id . '" align="center"></span>
    // 			        </div>
    // 					';
    //         $data[] = $row;
    //     }

    //     $ouput = array(
    //         "data" => $data
    //     );
    //     echo json_encode($ouput);
    // }

    public function validate_insert()
    {

        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if (!isset($_POST['qty_item'])) {
            $data['error_string'][] = 'produk belum dipilih';
            $data['inputerror'][] = 'product';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function review_stock()
    {

        $this->validate_insert();
        $html_item = $_POST['html_item'];
        $html_item = str_replace('<a href="javascript:void(0)" class="btn btn-danger btn_cancel"><i class="fa fa-close"></i></a>', '', $html_item);
        $code = $this->input->post('code');
        $note  = $this->input->post('note');
        $html_respon = '
            <div class="col-md-6">
                <table>
                    <tr>
                        <td width="120px">Kode</td>
                        <td width="10px">:</td>
                        <td>' . $code . '</td>
                    </tr>
                    <tr>
                        <td>Catatan</td>
                        <td>:</td>
                        <td>' . $note . '</td>
                    </tr>
                </table>
            </div>
            <div class="col-md-12">
                <hr>
                <table class="table  table-striped">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Produk</th>
                            <th>Stok Jurnal</th>
                            <th width="200px">Stok Baru</th>
                        </tr>
                    </thead>
                    <tbody class="tbody_item">
                        ' . $html_item . '
                    </tbody>
                </table>
            </div>
            <div class="col-md-12 text-right">
                <small>(*klik untuk simpan data)</small>
                <a href="javascript:void(0)" class="btn btn-success btn_save"><i class="fa fa-save"></i> Simpan Data</a>
            </div>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }


    public function save()
    {
        $code = $this->get_code();
        $date = date('Y-m-d');
        $note = $this->input->post('note');
        $array_stock         = $this->input->post('old_stock');
        $array_qty          = $this->input->post('qty_item');
        //insert stock opname
        $array_insert_stock_opname = array(
            'code' => $code,
            'date' => $date,
            'note' => $note,
            'created_date' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('us_id')
        );
        $this->model->insert($this->tb_name, $array_insert_stock_opname);

        $get_data_stock_opname_current = $this->db->query("select id from $this->tb_name where code = '$code' ")->row_array();
        foreach ($array_qty as $key_qty => $val_unit) {
            //key unit = id product
            //count new stock 
            $margin = $array_stock[$key_qty] - $array_qty[$key_qty];
            $array_insert_detail_stock_opname = array(
                'id_stock_correct' => $get_data_stock_opname_current['id'],
                'id_product' => $key_qty,
                'old_stock' => $array_stock[$key_qty],
                'margin' => $margin,
                'new_stock' => $array_qty[$key_qty],
                'created_date' => date('Y-m-d H:i:s'),
                'created_by' => $this->session->userdata('us_id')
            );
            $this->model->insert('tb_detail_stock_correct', $array_insert_detail_stock_opname);
            //update product
            $this->db->select('
                tb_detail_stock.id,
                tb_detail_stock.new_stock,
                tb_detail_stock.stock_rest
            ');
            $this->db->from('tb_detail_stock');
            $this->db->join('tb_stock', 'tb_detail_stock.id_stock_opname = tb_stock.id', 'left');
            $this->db->where(['tb_detail_stock.id_product' => $key_qty, 'tb_stock.id_account_warehouse ' => 0]);
            $this->db->order_by('tb_detail_stock.id', 'DESC');
            $get_stock = $this->db->get()->result();
            $new_stock_current = $array_qty[$key_qty];
            foreach ($get_stock as $item_stock) {
                if ($new_stock_current > $item_stock->new_stock) {
                    $rest = $item_stock->new_stock;
                    $new_stock_current -= $item_stock->new_stock;
                } else {
                    $rest = $new_stock_current;
                    $new_stock_current = 0;
                }
                $this->model->update(array('id' => $item_stock->id), ['stock_rest' => $rest], 'tb_detail_stock');
            }

            $array_update_stock_product = array(
                'stock' => $array_qty[$key_qty]
            );
            $this->model->update(array('id' => $key_qty), $array_update_stock_product, 'tb_product');
        }

        echo json_encode(array('status' => TRUE));
    }

    public function get_detail_stock($id)
    {
        $get_data = $this->db->query("select a.*,
										b.date as date_stock,
										b.note,
										b.code,
										c.name as product_name,
										c.code as product_code,
										c.qty_unit,
										d.name as unit_name,
										e.name as base_unit_name 
										 from tb_detail_stock_correct a 
										left join tb_stock_correct b on a.id_stock_correct = b.id
										left join tb_product c on a.id_product = c.id 
										left join tb_unit d on c.id_unit = d.id 
										left join tb_base_unit e on d.id_base_unit = e.id
										where a.id_stock_correct ='$id' ")->result();
        $data_html = '';
        if (!empty($get_data[0]->date_stock)) {
            $date_explode = explode('-', $get_data[0]->date_stock);
            $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        } else {
            $data_html = '-';
        }

        $data_html .= '
							<div class="col-md-12">
					          <div class="col-md-4">
					              <label>Kode</label>
					              <h4>' . $get_data[0]->code . '</h4>            
					          </div>
					          <div class="col-md-4">
					              <label>Tanggal</label>
					              <h4>' . $date_html . '</h4>            
					          </div>
					          <div class="col-md-4">
					              <label>catatan</label>
					              <p>' . $get_data[0]->note . '</p>            
					          </div>
					        </div>
					        <table class="table table-bordered">
					        	<tr>
					        		<th>No</th>
					        		<th>Kode</th>
					        		<th>Nama</th>
					        		<th>Stok Lama</th>
					        		<th>Stock Baru</th>
					        		<th>Margin</th>
					        	</tr>
						';
        $no = 0;
        foreach ($get_data as $data_table) {
            $no++;
            $data_html .= '
							<tr>
					        		<td>' . $no . '</td>
					        		<td>' . $data_table->product_code . '</td>
					        		<td>' . $data_table->product_name . '</td>
					        		<td>' . $data_table->old_stock . '</td>
					        		<td>' . $data_table->new_stock . '</td>
					        		<td>' . $data_table->margin . '</td>
					        	</tr>
						';
        }
        $data_html .= '</table>';
        echo $data_html;
    }

    //------------------------ print product ------------------------
    public function print_form()
    {
        // $query = $this->input->post('last_query');
        $get_data = $this->db->query("select a.name,a.code,a.stock,a.qty_unit,b.name as unit_name, c.name as base_unit_name from tb_product a 
									  left join tb_unit b on a.id_unit  = b.id 
									  left join tb_base_unit c on b.id_base_unit = c.id ")->result();

        // $data['data_range'] =  $this->input->post('array_range');
        ob_clean();
        $data['data_result'] = $get_data;
        ob_start();
        $this->load->view('print_stock_opname/form_so', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('./assets/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('P', 'A4', 'en');
        $pdf->WriteHTML($html);
        $pdf->Output('FORM STOK OPNAME (' . date('d-m-Y') . ').pdf', 'D');
    }
}
