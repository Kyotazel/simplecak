<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Product extends BackendController
{
    var $module_name        = 'product';
    var $module_directory   = 'product';
    var $module_js          = ['product'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_devision'] = Modules::run('database/find', 'tb_main_category', ['type' => 1])->result();
        $this->app_data['data_category'] =  Modules::run('database/find', 'tb_main_category', ['type' => 2])->result();

        $this->app_data['page_title'] = "Daftar Produk";
        $this->app_data['view_file'] = 'view_search';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = 'tb_product';
        $simbol = 'PR';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from $db_name")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function search_data()
    {

        $id_devision = $this->input->post('id_devision');
        $id_category     = $this->input->post('id_category');
        $code     = $this->input->post('code');
        $name         = $this->input->post('name');
        $page          = $this->input->post('page');



        $array_where = [];
        $array_where_in = [];

        if (!empty($id_devision)) {
            $array_where_in['tb_product.id_main_category'] = $id_devision;
        }

        if (!empty($id_category)) {
            $array_where_in['tb_product.id_sub_category '] = $id_category;
        }
        $limit_data = 25;

        $limit_data = 25;
        if (!empty($page) && $page != 'undefined') {
            $start_page = ($page * $limit_data) - $limit_data;
            $data['start_no'] = $start_page;
        } else {
            $start_page = 0;
            $data['start_no'] = 0;
        }

        $array_query = [
            'select' => '
                tb_product.code,
                tb_product.id,
                tb_product.name,
                tb_product.main_price,
                tb_product.price_1,
                tb_product.price_2,
                tb_product.price_3,
                tb_product.price_4,
                tb_product.stock_minimum,
                tb_product.created_date,
                tb_main_category.name AS devision_name,
                category.name AS category_name,
                subcategory.name AS merk_name,
                tb_unit.name AS unit_name,
                tb_barcode_product.barcode AS barcode
            ',
            'from' => 'tb_product',
            'join' => [
                'tb_main_category , tb_product.id_main_category = tb_main_category.id , left',
                'tb_main_category AS category, tb_product.id_sub_category = category.id , left',
                'tb_main_category AS subcategory, tb_product.id_merk = subcategory.id , left',
                'tb_unit , tb_product.id_unit = tb_unit.id , left',
                'tb_barcode_product , tb_product.id = tb_barcode_product.id_product , left'
            ],
            'limit' => [
                'start' => $start_page,
                'limit' => $limit_data
            ]
        ];

        if (!empty($code)) {
            $array_query['like']['tb_product.code'] = $code . ',both';
        }

        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }
        if (!empty($name)) {
            $array_query['like']['tb_product.name'] = $name . ',both';
        }


        // count data 
        // $get_query = $main_query . ' LIMIT ' . $start_page . ',' . $limit_data;
        $get_data_product = Modules::run('database/get', $array_query)->result();

        $data['data_product'] = $get_data_product;

        //remove limit
        unset($array_query['limit']);
        $array_query['select'] = 'COUNT(tb_product.id) AS count_data';
        $count_all_data = Modules::run('database/get', $array_query)->row();
        $count_all = $count_all_data->count_data;



        $num_links = floor($count_all / $limit_data);
        $html_pagination_item = '';
        $counter = 0;
        for ($i = 0; $i < 20; $i++) {
            $counter++;
            if ($counter > $num_links) {
                continue;
            }
            $active = $page == $counter ? 'active' : '';
            $html_pagination_item .= '<li class="page-item ' . $active . '"><a class="page-link btn_pagination" data-ci-pagination-page="' . $counter . '"  href="javascript:void(0)">' . $counter . '</a></li>';
        }

        $html_pagination = '
        <div class="pagging text-center">
        <nav aria-label="Page navigation example">
        <ul class="pagination">
        ' . $html_pagination_item . '
        </ul>
        </nav>
        </div>
        ';
        $data['html_pagination'] = $html_pagination;



        $html_respon = $this->load->view('view_search_result', $data, TRUE);


        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];



        echo json_encode($array_respon);
    }

    public function generate_barcode($code, $width = 1, $height = 30)
    {
        require '../assets/vendor/autoload.php';
        // This will output the barcode as HTML output to display in the browser
        $generator = new Picqer\Barcode\BarcodeGeneratorHTML();
        $barcode =  $generator->getBarcode($code, $generator::TYPE_CODE_128, $width, $height,);
        // $generator = new Picqer\Barcode\BarcodeGeneratorPNG();
        // $redColor = [255, 0, 0];
        // file_put_contents('barcode.png', $generator->getBarcode('081231723897', $generator::TYPE_CODE_128, 3, 50, $redColor));
        return  $barcode;
    }

    public function all_product()
    {
        $data['data_unit'] = $this->db->get('tb_unit')->result();
        // $data['data_base_unit'] = $this->db->get('tb_base_unit')->result();
        $data['tagline_page'] = "Data Barang";
        $data['js_page'] = $this->js_page;
        $data['view_file'] =  'view';
        $this->load->view('template/media_admin', $data);
    }

    public function add()
    {
        $this->app_data['data_unit'] = $this->db->get('tb_unit')->result();

        $this->app_data['page_title'] = "Tambah Produk";
        $this->app_data['view_file'] = 'form_add';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        $this->db->select('
            tb_product.id,
            tb_product.code,
            tb_product.name,
            tb_product.stock_minimum,
            tb_product.price,
            tb_product.main_price,
            tb_product.created_date,
            tb_main_category.name AS main_category_name,
            tb_merk.name AS merk_name,
            tb_unit.name AS unit_name,
            tb_barcode_product.barcode AS barcode
            ');
        $this->db->from('tb_product');
        $this->db->join('tb_main_category', 'tb_product.id_main_category = tb_main_category.id', 'left');
        $this->db->join('tb_merk', 'tb_product.id_merk = tb_merk.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_barcode_product', 'tb_product.id = tb_barcode_product.id_product', 'left');
        //$this->db->order_by('tb_product.id', 'DESC');

        //get data table serverside
        $column_order = array(null, 'tb_product.name', 'tb_barcode_product.barcode', 'tb_main_category.name'); //field yang ada di table user
        $column_search = array('tb_product.name', 'tb_barcode_product.barcode'); //field yang diizin untuk pencarian
        $order = array('tb_product.id' => 'DESC'); // default order 
        $i = 0;
        foreach ($column_search as $item) // loop column 
        {
            if ($_POST['search']['value']) // if datatable send POST for search
            {
                if ($i === 0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value'], 'after');
                } else {
                    $this->db->or_like($item, $_POST['search']['value'], 'after');
                }
                if (count($column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        // if (isset($_POST['order'])) // here order processing
        // {
        //     $this->db->order_by($column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        // } else if (isset($this->order)) {
        //     $this->db->order_by(key($order), $order[key($order)]);
        // }
        //length data
        if ($_POST['length'] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }

        $get_data_product   = $this->db->get();

        $count_data_current = $get_data_product->num_rows();
        $count_all          = $this->db->get('tb_product')->num_rows();

        $data = array();
        $no = 0;
        $no = $_POST['start'];
        foreach ($get_data_product->result() as $data_table) {

            $persentage = (($data_table->price - $data_table->main_price) / $data_table->main_price) * 100;
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->barcode;
            $row[] = $data_table->name;
            $row[] = $data_table->main_category_name;
            $row[] = $data_table->merk_name;
            $row[] = $data_table->unit_name;
            $row[] = $data_table->stock_minimum;
            $row[] = 'Rp.' . number_format($data_table->main_price, 0, '.', '.');
            $row[] = 'Rp.' . number_format($data_table->price, 0, '.', '.');
            $row[] = ceil($persentage) . '%';
            $row[] = $data_table->created_date;
            $row[] = '<a class="btn btn-info btn_link" href="' . base_url('product/detail?data=' . urlencode($this->encrypt->encode($data_table->id))) . '" title="detail"><i class="fa fa-tv"></i></a>';
            $data[] = $row;
        }
        $ouput = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $count_all,
            "recordsFiltered" => $count_data_current,
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function form_add_category()
    {
        $html_respon = '
            <form class="form-category">
            <div class="col-md-3 form-group">
            <label for="">Kode</label>
            <input type="text" class="form-control" name="code_category">
            <span class="help-block"></span>
            </div>
            <div class="col-md-7 form-group">
            <label for="">Nama Kategori</label>
            <input type="text" class="form-control" name="category_name">
            <span class="help-block"></span>
            </div>
            <div class="col-md-2 form-group">
            <label for="">&nbsp;</label><br>
            <button class="btn btn-primary-gradient btn-rounded btn_save_category"><i class="fa fa-save"></i> Simpan</button>
            </div>
            </form>
            ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function validate_insert_category()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('code_category') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'code_category';
            $data['status'] = FALSE;
        } else {
            $get_data = $this->db->where(['code' => $this->input->post('code_category')])->get('tb_main_category')->row();
            if (!empty($get_data)) {
                $data['error_string'][] = 'Kode Telah Dipakai';
                $data['inputerror'][] = 'code_category';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('category_name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'category_name';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_category()
    {
        $this->validate_insert_category();
        //insert data
        $name         = $this->input->post('category_name');
        $code     = $this->input->post('code_category');
        $array_insert = array(
            'code' => $code,
            'name' => $name,
            'created_by' => $this->session->userdata('us_id')
        );
        $this->model->insert('tb_main_category', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    public function get_main_category()
    {
        $get_last_category = $this->db->select('MAX(id) AS max_id')->get('tb_main_category')->row();
        $html_respon = '<option value="">PILIH KATEGORI</option>';
        $get_all_category = Modules::run('database/find', 'tb_main_category', ['type' => 1])->result();

        foreach ($get_all_category as $item_category) {
            $html_respon .= '<option value="' . $item_category->id . '">' . $item_category->name . '</option>';
        }
        $array_respon = ['status' => TRUE, 'html_respon' => $html_respon];
        echo json_encode($array_respon);
    }

    //------------------ merk -------------------------------
    public function form_add_merk()
    {
        $html_respon = '
            <form class="form-merk">
            <div class="col-md-3 form-group">
            <label for="">Kode</label>
            <input type="text" class="form-control" name="code_merk">
            <span class="help-block"></span>
            </div>
            <div class="col-md-7 form-group">
            <label for="">Nama Merk</label>
            <input type="text" class="form-control" name="merk_name">
            <span class="help-block"></span>
            </div>
            <div class="col-md-2 form-group">
            <label for="">&nbsp;</label><br>
            <button class="btn btn-primary-gradient btn-rounded btn_save_merk"><i class="fa fa-save"></i> Simpan</button>
            </div>
            </form>
            ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function validate_insert_merk()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('code_merk') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'code_merk';
            $data['status'] = FALSE;
        } else {
            $get_data = $this->db->where(['code' => $this->input->post('code_merk')])->get('tb_merk')->row();
            if (!empty($get_data)) {
                $data['error_string'][] = 'Kode Telah Dipakai';
                $data['inputerror'][] = 'code_merk';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('merk_name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'merk_name';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_merk()
    {
        $this->validate_insert_merk();
        //insert data
        $name         = $this->input->post('merk_name');
        $code     = $this->input->post('code_merk');
        $id_main_category = $this->input->post('id_main_category');
        $array_insert = array(
            'code' => $code,
            'name' => $name,
            'id_main_category' => $id_main_category,
            'created_by' => $this->session->userdata('us_id')
        );
        $this->model->insert('tb_merk', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    //---------------------- unit --------------------------
    public function form_add_unit()
    {
        $html_respon = '
            <form class="form-unit">
            <div class="col-md-7 form-group">
            <label for="">Nama Satuan</label>
            <input type="text" class="form-control" name="unit_name">
            <span class="help-block"></span>
            </div>
            <div class="col-md-2 form-group">
            <label for="">&nbsp;</label><br>
            <button class="btn btn-primary-gradient btn-rounded btn_save_unit"><i class="fa fa-save"></i> Simpan</button>
            </div>
            </form>
            ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function validate_insert_unit()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('unit_name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'unit_name';
            $data['status'] = FALSE;
        } else {
            $get_data = $this->db->where(['name' => $this->input->post('unit_name')])->get('tb_unit')->row();
            if (!empty($get_data)) {
                $data['error_string'][] = 'nama Telah Dipakai';
                $data['inputerror'][] = 'unit_name';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_unit()
    {
        $this->validate_insert_unit();
        //insert data
        $name         = $this->input->post('unit_name');
        $array_insert = array(
            'name' => $name,
            'created_by' => $this->session->userdata('us_id')
        );
        $this->model->insert('tb_unit', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    public function get_unit_html()
    {
        $html_respon = '<option value="">PILIH UNIT</option>';
        $get_all_unit = $this->db->order_by('name')->get('tb_unit')->result();
        foreach ($get_all_unit as $item_unit) {
            $html_respon .= '<option value="' . $item_unit->id . '">' . $item_unit->name . '</option>';
        }
        $array_respon = ['status' => TRUE, 'html_respon' => $html_respon];
        echo json_encode($array_respon);
    }
    //------------------------- conversion ---------------------------------
    public function form_conversion()
    {
        $html_respon = '
            <div class="col-md-12 row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control pull-right number_type"  name="conversion_name[]">
                        <span class="help-block"></span>
                        <!-- /.input group -->
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="form-group">
                        <label>Jumlah</label>
                        <div class="input-group date">
                        <input type="text" class="form-control pull-right number_only number_type"  name="conversion_number[]">
                        <div class="input-group-addon">
                        <i class="unit_name"></i>
                    </div>
                </div>
                <span class="help-block"></span>
                <!-- /.input group -->
                </div>
                </div>
                <div class="col-md-1"><label>&nbsp;</label><br><button type="button" class="btn btn-danger clear_conversion" title="hapus"><i class="fa fa-times"></i></button></div>
            </div>
            ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    //---------------------- unit --------------------------
    public function form_add_supplier()
    {
        $html_respon = '
            <form role="form" class="form-supplier">
            <input type="hidden" name="id">
            <div class="card-body">
            <div class="form-group col-md-12">
            <label for="exampleInputEmail1">Nama</label>
            <input type="text" class="form-control" name="supplier_name">
            <span class="help-block"></span>
            </div>
            <div class="form-group col-md-4">
            <label for="exampleInputEmail1">Email</label>
            <input type="text" class="form-control" name="supplier_email">
            <span class="help-block"></span>
            </div>
            <div class="form-group col-md-4">
            <label for="exampleInputEmail1">No.Hp</label>
            <input type="text" class="form-control" name="supplier_number_phone">
            <span class="help-block"></span>
            </div>
            <div class="form-group col-md-4">
            <label for="exampleInputEmail1">Gambar</label>
            <input type="file" class="form-control" name="supplier_upload">
            <span class="help-block"></span>
            </div>
            <div class="form-group col-md-12">
            <label for="exampleInputEmail1">Alamat</label>
            <textarea class="form-control" name="supplier_address"></textarea>
            <span class="help-block"></span>
            </div>
            <div class="form-group col-md-12 text-right">
            <button class="btn btn-primary-gradient btn-rounded btn_save_supplier">Simpan Data</button>
            </div>
            </form>
            ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function validate_insert_supplier()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $id = $this->input->post('id');
        if ($this->input->post('supplier_name') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'supplier_name';
            $data['status'] = FALSE;
        }
        if ($this->input->post('supplier_email') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'supplier_email';
            $data['status'] = FALSE;
        }
        if ($this->input->post('supplier_number_phone') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'supplier_number_phone';
            $data['status'] = FALSE;
        }
        if (empty($id)) {
            if ($_FILES['supplier_upload']['name'] == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'supplier_upload';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('supplier_address') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'supplier_address';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    private function do_upload_image_supplier()
    {
        $config['upload_path']          = realpath(APPPATH . '../upload/supplier');
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        // $config['max_size']             = 100; //set max size allowed in Kilobyte
        // $config['max_width']            = 1000; // set max width image allowed
        // $config['max_height']           = 1000; // set max height allowed
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('supplier_upload')) //upload and validate
        {
            $data['inputerror'][] = 'upload';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            $upload_data = $this->upload->data();
            $config['image_library'] = 'gd2';
            $config['source_image'] = $upload_data['full_path'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['quality'] = '50%';
            // $config['width']= 350;
            $config['height'] = 700;
            $config['new_image'] = $upload_data['full_path'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
            $image_name = $upload_data['file_name'];
            return $this->upload->data('file_name');
        }
    }
    private function get_code_supplier()
    {
        $number_text = 0;

        $simbol = 'SP';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select max(code) as max_code from $db_name ")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function save_supplier()
    {
        $this->validate_insert_supplier();
        $code = $this->get_code_supplier();
        $name   = $this->input->post('supplier_name');
        $email   = $this->input->post('supplier_email');
        $number_phone   = $this->input->post('supplier_number_phone');
        $address   = $this->input->post('supplier_address');
        if (!empty($_FILES['supplier_upload']['name'])) {
            $file_name = $this->do_upload_image_supplier();
        } else {
            $file_name = '';
        }
        // //insert data
        $array_insert = array(
            'code' => $code,
            'name' => $name,
            'number_phone' => $number_phone,
            'email' => $email,
            'image' => $file_name,
            'address' => $address,
            'created_date' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('us_id')
        );
        $this->model->insert('tb_supplier', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    public function get_supplier_html()
    {
        $html_respon = '<option value="">PILIH SUPLIER</option>';
        $get_all_unit = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        foreach ($get_all_unit as $item_unit) {
            $html_respon .= '<option value="' . $item_unit->id . '">' . $item_unit->name . '</option>';
        }
        $array_respon = ['status' => TRUE, 'html_respon' => $html_respon];
        echo json_encode($array_respon);
    }


    public function get_discount_html()
    {
        $html_add = '
        <div class="col-md-12 html_discount row">
            <div class="col-md-4">
                <div class="form-group">
                    <label>Min.Jumlah Beli</label>
                    <div class="input-group date">
                        <input type="text" class="form-control pull-right number_type" name="margin_qty[]">
                        <div class="input-group-addon">
                            <i class="base_unit"></i>
                        </div>
                    </div>
                    <span class="help-block nett_price"></span>
                    <!-- /.input group -->
                </div>
            </div>
            <div class="col-md-7">
                <div class="form-group">
                    <label>Harga Potongan</label>
                    <div class="input-group date">
                        <input type="text" class="form-control pull-right number_type" name="margin_price[]">
                        <div class="input-group-addon">
                            <i class="base_unit"></i>
                        </div>
                    </div>
                    <span class="help-block nett_price"></span>
                    <!-- /.input group -->
                </div>
            </div>
            <div class="col-md-1">
                <br>
                <button type="button" class="btn btn-danger clear_html" title="hapus potongan"><i class="fa fa-times"></i></button>
            </div>
        </div>
        ';
        echo $html_add;
    }

    public function get_sub_category()
    {
        $id = $this->input->post('id');
        $get_sub_category = Modules::run('database/find', 'tb_main_category', ['id_parent' => $id])->result();

        $html_option_subcategory = '<option value="">PILIH KATEGORI</option>';
        foreach ($get_sub_category as $item_sub_category) {
            $html_option_subcategory .= '<option value="' . $item_sub_category->id . '">' . $item_sub_category->name . '</option>';
        }

        $array_respon = [
            'status' => TRUE,
            'option_merk' => $html_option_subcategory
        ];
        echo json_encode($array_respon);
    }

    private function validate_insert()
    {


        //price
        $price = str_replace('.', '', $this->input->post('price'));
        //main price 
        $main_price = str_replace('.', '', $this->input->post('main_price'));
        //main price 
        $main_distributor_price = str_replace('.', '', $this->input->post('main_distributor_price'));

        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }

        if ($this->input->post('unit') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'unit';
            $data['status'] = FALSE;
        }

        if ($this->input->post('main_category') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'main_category';
            $data['status'] = FALSE;
        }
        if ($this->input->post('id_merk') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'id_merk';
            $data['status'] = FALSE;
        }

        // if ($price <= $main_price) {
        //     $data['error_string'][] = 'harga jual harus lebih besar dari harga pokok';
        //     $data['inputerror'][] = 'price';
        //     $data['status'] = FALSE;
        // }

        if ($this->input->post('main_price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'main_price';
            $data['status'] = FALSE;
        }
        if ($this->input->post('price_1') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price_1';
            $data['status'] = FALSE;
        }
        if ($this->input->post('price_2') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price_2';
            $data['status'] = FALSE;
        }
        if ($this->input->post('price_3') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price_3';
            $data['status'] = FALSE;
        }
        if ($this->input->post('price_4') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price_4';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_margin_price($code)
    {
        // $satuan = $this->input->post('satuan');
        $get_product = $this->db->query("select id from tb_product where code = '$code' ")->row_array();
        $nett_price         = str_replace('.', '', $this->input->post('nett_price'));
        $margin_qty = $this->input->post('margin_qty');
        $margin_price = $this->input->post('margin_price');
        $qty_unit = str_replace('.', '', $this->input->post('qty'));
        //del old margin 
        Modules::run('database/delete', 'tb_margin_price', ['id_product' => $get_product['id']]);
        // $this->model->delete(array('id_product' => $get_product['id']), 'tb_margin_price');
        //insert first mmargin
        // $array_insert_first_margin = array(
        //     'id_product' => $get_product['id'],
        //     'qty' => $qty_unit,
        //     'price' => $nett_price,
        //     'created_date' => date('Y-m-d H:i:s'),
        //     'created_by' => $this->session->userdata('us_id')
        // );
        // $this->model->insert('tb_margin_price', $array_insert_first_margin);
        //insert detail
        // print_r($qty_unit);
        // // print_r($margin_price);
        // exit;
        for ($i = 0; $i < count($margin_qty); $i++) {
            // $satuan_current = $satuan[$i];
            // if ($satuan_current == 1) {
            //     $qty_insert = $margin_qty[$i];
            // } else {
            //     $qty_insert = str_replace('.', '', $margin_qty[$i]) * $qty_unit;
            // }
            $qty_insert = $margin_qty[$i];
            $price_insert = str_replace('.', '', $margin_price[$i]);
            //creaate array insert
            $array_insert_margin = array(
                'id_product' => $get_product['id'],
                'qty' => $qty_insert,
                'price' => $price_insert,
                'created_by' => $this->session->userdata('us_id')
            );
            Modules::run('database/insert', 'tb_margin_price', $array_insert_margin);
            // $this->model->insert('tb_margin_price', $array_insert_margin);
        }
    }

    public function show_view_conversion()
    {
        $target     = $this->input->post('target');
        $price_ask  = str_replace('.', '', $this->input->post($target));
        $price_name = $target == 'price' ? 'harga jual' : 'harga pokok';
        if (!isset($_POST['conversion_name'])) {
            $array_respon = [
                'status' => FALSE,
                'message' => 'Form Konversi Belum Ditambah'
            ];
            echo json_encode($array_respon);
            exit();
        }
        if ($price_ask == '') {
            $array_respon = [
                'status' => FALSE,
                'message' => $price_name . ' Belum Diisi'
            ];
            echo json_encode($array_respon);
            exit();
        }

        $array_conversion_name      = $this->input->post('conversion_name');
        $array_conversion_number    = $this->input->post('conversion_number');
        $html_tr = '';
        foreach ($array_conversion_name as $key_conversion => $value) {
            $number_current     = $array_conversion_number[$key_conversion];
            $name_current       = $array_conversion_name[$key_conversion];
            if (!empty($number_current) && !empty($name_current)) {
                $price_current      = $price_ask * $number_current;
                $html_tr .= '
                <tr>
                <td>' . $name_current . '</td>
                <td>' . $number_current . '</td>
                <td>Rp.' . number_format($price_current, 0, '.', '.') . '</td>
                </tr>
                ';
            }
        }

        $html_tr = $html_tr == '' ? '<tr><td colspan="3"><h2 class="text-center text-muted">FORM KONVERSI BELUM TERISI</h2></td></tr>' : $html_tr;

        $html_respon = '
        <div class="col-md-12">
        <table class="table">
        <thead>
        <tr>
        <th>Nama Konversi</th>
        <th>Jumlah</th>
        <th>Harga</th>
        </tr>
        </thead>
        <tbody>' . $html_tr . '</tbody>
        </table>
        </div>
        ';

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }


    public function save()
    {
        // exit;
        $this->validate_insert();
        //------ insert data -------

        //price
        $price_1 = str_replace('.', '', $this->input->post('price_1'));
        $price_2 = str_replace('.', '', $this->input->post('price_2'));
        $price_3 = str_replace('.', '', $this->input->post('price_3'));
        $price_4 = str_replace('.', '', $this->input->post('price_4'));

        $kubikasi         = $this->input->post('kubikasi');
        $long_cm         = $this->input->post('long_cm');
        $width_cm         = $this->input->post('width_cm');
        $height_cm         = $this->input->post('height_cm');
        $weight         = $this->input->post('weight');

        $main_price = str_replace('.', '', $this->input->post('main_price'));

        $code         = $this->input->post('code');
        $name         = $this->input->post('name');
        $barcode      = $this->input->post('barcode');
        $unit         = $this->input->post('unit');
        $description = $this->input->post('description');
        $id_merk      = $this->input->post('id_merk');
        $main_category = $this->input->post('main_category');
        $stock_min = $this->input->post('min_stock');
        $id_supplier = $this->input->post('id_supplier');

        //for detail
        $array_conversion_name      = $this->input->post('conversion_name');
        $array_conversion_number    = $this->input->post('conversion_number');

        $array_insert = array(
            'code' => $code,
            'id_main_category' => $main_category,
            'id_sub_category ' => $id_merk,
            'id_unit' => $unit,
            'id_supplier' => $id_supplier,
            'name' => $name,
            'last_stock_price' => $main_price,
            'main_price' => $main_price,
            'price_1' => $price_1,
            'price_2' => $price_2,
            'price_3' => $price_3,
            'price_4' => $price_4,
            'cubic' => $kubikasi,
            'long_cm' => $long_cm,
            'width_cm' => $width_cm,
            'height_cm' => $height_cm,
            'weight' => $weight,
            'stock_minimum' => $stock_min,
            'description' => $description,
            'date' => date('Y-m-d'),
            'created_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/insert', 'tb_product', $array_insert);

        //get product crrent 
        $get_id_product = $this->db->select('id')->where(['code' => $code])->get('tb_product')->row();
        //insert margin price 
        // $this->save_margin_price($code);
        //insert barcode
        if (!empty($barcode)) {
            $array_insert_barcode = [
                'id_product' => $get_id_product->id,
                'barcode' => !empty($barcode) ? $barcode : $code
            ];
            Modules::run('database/insert', 'tb_barcode_product', $array_insert_barcode);
        }
        //insert conversion
        if (!empty($array_conversion_name)) {
            foreach ($array_conversion_number as $key_conversion => $item_conversion) {
                $array_insert_conversion = [
                    'id_product' => $get_id_product->id,
                    'name' => $array_conversion_name[$key_conversion],
                    'qty' => $array_conversion_number[$key_conversion]
                ];
                // $this->model->insert('tb_product_has_conversion', $array_insert_conversion);
                Modules::run('database/insert', 'tb_product_has_conversion', $array_insert_conversion);
            }
        }

        $array_respon = [
            'status' => TRUE,
            'id_encrypt' => urlencode($this->encrypt->encode($get_id_product->id))
        ];
        echo json_encode($array_respon);
    }

    public function detail()
    {
        $id_product = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
            tb_product.*,
            product_devision.name AS product_devision_name,
            tb_unit.name AS unit_name,
            mst_vendor.name AS supplier_name,
            product_category.name AS product_category_name,
            product_merk.name AS sub_category_name,
            st_user.name AS user_name
            ');
        $this->db->from('tb_product');
        $this->db->join('tb_main_category AS product_devision', 'tb_product.id_main_category = product_devision.id', 'left');
        $this->db->join('tb_main_category AS product_category', 'tb_product.id_sub_category = product_category.id', 'left');
        $this->db->join('tb_main_category AS product_merk', 'tb_product.id_merk = product_merk.id', 'left');
        $this->db->join('mst_vendor', 'tb_product.id_supplier = mst_vendor.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('st_user', 'tb_product.created_by = st_user.id', 'left');
        $this->db->where(['tb_product.id' => $id_product]);
        $get_data_product = $this->db->get()->row();


        $this->app_data['data_product'] = $get_data_product;

        //get conversion
        $get_conversion = $this->db->where(['id_product' => $id_product])->order_by('qty')->get('tb_product_has_conversion')->result();
        $this->app_data['data_conversion'] = $get_conversion;
        //get barcode
        $get_barcode = $this->db->where(['id_product' => $id_product])->get('tb_barcode_product')->result();
        $this->app_data['data_barcode'] = $get_barcode;
        //get margin price
        $get_margin_price = $this->db->where(['id_product' => $id_product])->get('tb_margin_price')->result();
        $this->app_data['data_margin_price'] = $get_margin_price;
        // print_r($get_margin_price);
        $this->app_data['data_barcode'] = $this->db->where(['id_product' => $id_product])->get('tb_barcode_product')->row();
        // exit;

        $this->app_data['page_title'] = "DETAIL PRODUK";
        $this->app_data['view_file'] = 'view_detail';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_margin_html($id)
    {
        $get_margin_product = $this->db->query("select a.*,b.qty_unit from tb_margin_price a left join tb_product b on a.id_product = b.id where id_product  = '$id'  ")->result();
        $data_html = '';
        foreach ($get_margin_product as $data_margin) {
            $margin_show = $data_margin->qty;
            if ($margin_show == 1) {
                continue;
            }
            $data_html .= '
            <div class="col-md-12 html_discount">
            <div class="col-md-4">
            <div class="form-group">
            <label>Jumlah</label>
            <div class="input-group date">
            <input type="text" class="form-control pull-right number_type" value="' . number_format($margin_show, 0, '.', '.') . '" name="margin_qty[]">
            <div class="input-group-addon">
            <i class="base_name"></i>
            </div>
            </div>
            <span class="help-block nett_price"></span>
            <!-- /.input group -->
            </div>
            </div>
            <div class="col-md-7">
            <div class="form-group">
            <label>Harga Potongan</label>
            <div class="input-group date">
            <input type="text" class="form-control pull-right number_type" value="' . number_format($data_margin->price, 0, '.', '.') . '"  name="margin_price[]">
            <div class="input-group-addon">
            <i class="base_name"></i>
            </div>
            </div>
            <span class="help-block nett_price"></span>
            <!-- /.input group -->
            </div>
            </div>
            <label>clear</label>
            <div class="col-md-1"><button type="button" class="btn btn-danger clear_html" title="hapus potongan"><i class="fa fa-times"></i></button></div>  
            </div>
            ';
        }
        echo $data_html;
    }

    public function form_edit_main()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $data_product = $this->db->where(['id' => $id])->get('tb_product')->row();

        $get_all_category = $this->db->order_by('name')->where(['type' => 1])->get('tb_main_category')->result();
        $get_category         = $this->db->where(['id_parent' => $data_product->id_main_category])->where(['type' => 2])->get('tb_main_category')->result();
        $get_merk         = $this->db->where(['type' => 3])->get('tb_main_category')->result();
        $get_all_unit     = $this->db->get('tb_unit')->result();
        $get_all_supplier = $this->db->where(['isDeleted' => 'N'])->get('mst_vendor')->result();



        //html category
        $html_main_category = '';
        foreach ($get_all_category as $item_category) {
            $selected = $item_category->id == $data_product->id_main_category ? 'selected' : '';
            $html_main_category .= '
            <option ' . $selected . ' value="' . $item_category->id . '">' . $item_category->name . '</option>
            ';
        }
        //html merk
        $html_category = '<option value="">TIDAK ADA</option>';
        foreach ($get_category as $item_merk) {
            $selected = $item_merk->id == $data_product->id_merk ? 'selected' : '';
            $html_category .= '
            <option ' . $selected . ' value="' . $item_merk->id . '">' . $item_merk->name . '</option>
            ';
        }

        //html merk
        $html_merk = '<option value="">TIDAK ADA</option>';
        foreach ($get_merk as $item_merk) {
            $selected = $item_merk->id == $data_product->id_merk ? 'selected' : '';
            $html_merk .= '
            <option ' . $selected . ' value="' . $item_merk->id . '">' . $item_merk->name . '</option>
            ';
        }

        //html unit
        $html_unit = '';
        foreach ($get_all_unit as $item_unit) {
            $selected = $item_unit->id == $data_product->id_unit ? 'selected' : '';
            $html_unit .= '
            <option ' . $selected . ' value="' . $item_unit->id . '">' . $item_unit->name . '</option>
            ';
        }
        //html unit
        $html_supplier = '<option value="">TIDAK ADA</option>';
        foreach ($get_all_supplier as $item_supplier) {
            $selected = $item_supplier->id == $data_product->id_supplier ? 'selected' : '';
            $html_supplier .= '
            <option ' . $selected . ' value="' . $item_supplier->id . '">' . $item_supplier->name . '</option>
            ';
        }

        $html_respon = '
        
        <form class="form_update_main">
            <div class="row">
                <div class="col-md-8 form-group">
                    <label for="">Nama Produk</label>
                    <input type="text" name="name" value="' . $data_product->name . '" class="form-control">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-4 form-group">
                    <label for="">Stok Minimum</label>
                    <input type="text" name="stock_minimum" value="' . $data_product->stock_minimum . '" class="form-control">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-4 form-group">
                    <label for="">Devisi</label>
                    <select name="main_category" id="main_category" class="form-control">' . $html_main_category . '</select>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-4 form-group">
                    <label for="">Kategori</label>
                    <select name="sub_category" class="form-control">' . $html_category . '</select>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-4 form-group">
                    <label for="">Sub-Kategori</label>
                    <select name="id_merk" class="form-control">' . $html_merk . '</select>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-6 form-group">
                    <label for="">Satuan Barang</label>
                    <select name="id_unit" class="form-control">' . $html_unit . '</select>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-6 form-group">
                    <label for="">Supplier</label>
                    <select name="id_supplier" class="form-control">' . $html_supplier . '</select>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-12 form-group">
                    <label for="">Keterangan</label>
                    <textarea name="description" class="form-control" cols="30" rows="5">' . $data_product->description . '</textarea>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-12 text-right">
                    <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($data_product->id) . '" class="btn btn-primary-gradient btn-rounded btn_update_main"><i class="fa fa-save"></i> Simpan Data</a>
                </div>
            </div>
        </form>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function validate_update_main()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }

        if ($this->input->post('id_unit') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'id_unit';
            $data['status'] = FALSE;
        }

        if ($this->input->post('main_category') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'main_category';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function update_main()
    {
        $this->validate_update_main();

        $id         = $this->encrypt->decode($this->input->post('id'));
        $name         = $this->input->post('name');
        $unit         = $this->input->post('id_unit');
        $description = $this->input->post('description');
        $id_merk = $this->input->post('id_merk');
        $id_subcategory = $this->input->post('sub_category');
        $main_category = $this->input->post('main_category');
        $stock_min = $this->input->post('stock_minimum') > 0 ? $this->input->post('stock_minimum') : 0;
        $id_supplier = $this->input->post('id_supplier');
        //insert data
        $array_update = array(
            'name' => $name,
            'stock_minimum' => $stock_min,
            'id_main_category' => $main_category,
            'id_sub_category ' => $id_subcategory,
            'id_merk ' => $id_merk,
            'id_unit' => $unit,
            'id_supplier' => $id_supplier,
            'description' => $description,
            'updated_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/update', 'tb_product', ['id' => $id], $array_update);
        // $this->model->update(array('id' => $id), $array_update, 'tb_product');
        //upadate margin
        echo json_encode(array('status' => TRUE));
    }

    public function form_add_conversion()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $data_product = $this->db->where(['id' => $id])->get('tb_product')->row();
        $unit_name = $this->db->where(['id' => $data_product->id_unit])->get('tb_unit')->row();

        $html_respon = '
        <form class="form_add_conversion">
        <div class="col-md-12 main_additional_form">
        <div class="col-md-4">
        <div class="form-group">
        <label>Nama</label>
        <input type="text" class="form-control pull-right number_type"  name="conversion_name[]">
        <span class="help-block conversion_name_notif"></span>
        <!-- /.input group -->
        </div>
        </div>
        <div class="col-md-7">
        <div class="form-group">
        <label>Jumlah</label>
        <div class="input-group date">
        <input type="text" class="form-control pull-right number_type"  name="conversion_number[]">
        <div class="input-group-addon">
        <i class="unit_name">' . $unit_name->name . '</i>
        </div>
        </div>
        <span class="help-block conversion_number_notif"></span>
        <!-- /.input group -->
        </div>
        </div>
        </div>
        <div class="col-md-12 cover-conversion-form"></div>
        <div class="col-md-12 text-right">
        <button type="button" class="btn btn-default btn_add_form_conversion" data-name="' . $unit_name->name . '"><i class="fa fa-plus-circle"></i> Tambah Form</button>
        <button type="submit" data-id="' . $this->encrypt->encode($data_product->id) . '" class="btn btn-primary-gradient btn-rounded btn_save_conversion"><i class="fa fa-save"></i> Simpan Data</button>
        </div>
        </form>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function get_pattern_form_conversion()
    {
        $unit_name = $this->input->post('name');
        $html_respon = '
        <div class="col-md-12">
        <div class="col-md-4">
        <div class="form-group">
        <label>Nama</label>
        <input type="text" class="form-control pull-right number_type"  name="conversion_name[]">
        <span class="help-block"></span>
        <!-- /.input group -->
        </div>
        </div>
        <div class="col-md-7">
        <div class="form-group">
        <label>Jumlah</label>
        <div class="input-group date">
        <input type="text" class="form-control pull-right number_type"  name="conversion_number[]">
        <div class="input-group-addon">
        <i class="unit_name">' . $unit_name . '</i>
        </div>
        </div>
        <span class="help-block"></span>
        <!-- /.input group -->
        </div>
        </div>
        <div class="col-md-1">
        <label for="">&nbsp;</label><br>
        <a href="javascript:void(0)" class="btn btn-danger btn_cancel_form"><i class="fa fa-times"></i></a>
        </div>
        </div>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }



    private function validate_save_additional_conversion()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $arrray_conversion_name = $this->input->post('conversion_name');
        $arrray_conversion_number = $this->input->post('conversion_number');
        if ($arrray_conversion_name[0] == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'conversion_name_notif';
            $data['status'] = FALSE;
        }
        if ($arrray_conversion_number[0] == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'conversion_number_notif';
            $data['status'] = FALSE;
        }


        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_additional_conversion()
    {
        $this->validate_save_additional_conversion();
        $arrray_conversion_name = $this->input->post('conversion_name');
        $arrray_conversion_number = $this->input->post('conversion_number');
        $id_product = $this->encrypt->decode($this->input->post('id'));

        foreach ($arrray_conversion_name as $key_name => $value_name) {
            if (!empty($arrray_conversion_name[$key_name]) && !empty($arrray_conversion_number[$key_name])) {
                //array insert
                $array_insert = [
                    'id_product' => $id_product,
                    'name' => $arrray_conversion_name[$key_name],
                    'qty' => $arrray_conversion_number[$key_name]
                ];

                $this->model->insert('tb_product_has_conversion', $array_insert);
            }
        }

        $array_respon = [
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function form_edit_conversion()
    {
        $id = $this->encrypt->decode($this->input->post('id'));

        $this->db->select('
            tb_product_has_conversion.*,
            tb_unit.name AS unit_name
            ');
        $this->db->from('tb_product_has_conversion');
        $this->db->join('tb_product', 'tb_product_has_conversion.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->where(['tb_product_has_conversion.id' => $id]);
        $get_data_current = $this->db->get()->row();


        $html_respon = '
        <form class="form_add_conversion">
        <div class="col-md-12 main_additional_form">
        <div class="col-md-4">
        <div class="form-group">
        <label>Nama</label>
        <input type="text" class="form-control pull-right number_type"  name="conversion_name" value="' . $get_data_current->name . '">
        <span class="help-block conversion_name_notif"></span>
        <!-- /.input group -->
        </div>
        </div>
        <div class="col-md-7">
        <div class="form-group">
        <label>Jumlah</label>
        <div class="input-group date">
        <input type="text" class="form-control pull-right number_type"  name="conversion_number" value="' . $get_data_current->qty . '">
        <div class="input-group-addon">
        <i class="unit_name">' . $get_data_current->unit_name . '</i>
        </div>
        </div>
        <span class="help-block conversion_number_notif"></span>
        <!-- /.input group -->
        </div>
        </div>
        </div>
        <div class="col-md-12 cover-conversion-form"></div>
        <div class="col-md-12 text-right">
        <button type="submit" data-id="' . $this->encrypt->encode($get_data_current->id) . '" class="btn btn-primary-gradient btn-rounded btn_update_conversion"><i class="fa fa-save"></i> Simpan Data</button>
        </div>
        </form>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function update_additional_conversion()
    {
        $conversion_name = $this->input->post('conversion_name');
        $conversion_number = $this->input->post('conversion_number');
        $id = $this->encrypt->decode($this->input->post('id'));

        $array_update = array(
            'name' => $conversion_name,
            'qty' => $conversion_number
        );
        $this->model->update(array('id' => $id), $array_update, 'tb_product_has_conversion');
        //upadate margin
        echo json_encode(array('status' => TRUE));
    }

    public function delete_conversion()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $this->model->delete(array('id' => $id), 'tb_product_has_conversion');
        echo json_encode(array('status' => TRUE));
    }

    public function form_edit_price()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $this->db->select('
            tb_product.*,
            tb_unit.name AS unit_name
            ');
        $this->db->from('tb_product');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->where(['tb_product.id' => $id]);
        $get_data_current = $this->db->get()->row();

        $html_respon = '
            <form class="form_update_price">
                <div class="col-md-12 main_additional_form row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Harga Pokok</label>
                            <div class="input-group date">
                                <input type="text" class="form-control pull-right money_only" name="main_price" value="' . number_format($get_data_current->main_price, 0, '.', '.') . '">
                                <div class="input-group-addon">
                                    <i class="unit_name">' . $get_data_current->unit_name . '</i>
                                </div>
                            </div>
                            <span class="help-block main_price"></span>
                            <!-- /.input group -->
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Harga Jual</label>
                            <div class="input-group date">
                                <input type="text" class="form-control pull-right money_only" name="price" value="' . number_format($get_data_current->price, 0, '.', '.') . '">
                                <div class="input-group-addon">
                                    <i class="unit_name">' . $get_data_current->unit_name . '</i>
                                </div>
                            </div>
                            <span class="help-block price"></span>
                            <!-- /.input group -->
                        </div>
                    </div>
                </div>
                <div class="col-md-12 cover-conversion-form"></div>
                <div class="col-md-12 text-right">
                    <button type="submit" data-id="' . $this->encrypt->encode($get_data_current->id) . '" class="btn btn-primary-gradient btn-rounded btn_update_price"><i class="fa fa-save"></i> Simpan Data</button>
                </div>
            </form>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function validate_update_price()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $price = str_replace('.', '', $this->input->post('price'));
        $main_price = str_replace('.', '', $this->input->post('main_price'));

        if ($price < $main_price) {
            $data['error_string'][] = 'harga jual salah';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }
        if ($this->input->post('main_price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'main_price';
            $data['status'] = FALSE;
        }


        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function update_price()
    {
        $this->validate_update_price();
        $id = $this->encrypt->decode($this->input->post('id'));
        $price = str_replace('.', '', $this->input->post('price'));
        $main_price = str_replace('.', '', $this->input->post('main_price'));

        $array_update = array(
            'price' => $price,
            'main_price' => $main_price
        );
        Modules::run('database/update', 'tb_product', ['id' => $id], $array_update);
        // $this->model->update(array('id' => $id), $array_update, 'tb_product');
        //upadate margin
        echo json_encode(array('status' => TRUE));
    }

    public function form_add_margin()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $data_product = $this->db->where(['id' => $id])->get('tb_product')->row();
        $unit_name = $this->db->where(['id' => $data_product->id_unit])->get('tb_unit')->row();

        $html_respon = '
        <div class="col-md-6 p-20 border border-radius-5 text-center">
        <label for="">Harga Pokok :</label>
        <h2>Rp.' . number_format($data_product->main_price, 0, '.', '.') . '</h2>
        </div>
        <div class="col-md-6 p-20 border border-radius-5 text-center">
        <label for="">Harga Jual :</label>
        <h2>Rp.' . number_format($data_product->price, 0, '.', '.') . '</h2>
        </div>
        <span class="clearfix"></span>
        <hr>
        <form class="form_add_conversion">
        <div class="col-md-12 main_additional_form">
        <div class="col-md-4">
        <div class="form-group">
        <label>Min Jumlah Pembelian</label>
        <input type="text" class="form-control pull-right number_only"  name="min_qty[]">
        <span class="help-block min_qty"></span>
        <!-- /.input group -->
        </div>
        </div>
        <div class="col-md-7">
        <div class="form-group">
        <label>Harga Jual</label>
        <div class="input-group date">
        <input type="text" class="form-control pull-right number_type money_only"  name="price[]">
        <div class="input-group-addon">
        <i class="unit_name">' . $unit_name->name . '</i>
        </div>
        </div>
        <span class="help-block price"></span>
        <!-- /.input group -->
        </div>
        </div>
        </div>
        <div class="col-md-12 cover-conversion-form"></div>
        <div class="col-md-12 text-right">
        <button type="button" class="btn btn-default btn_add_form_margin" data-name="' . $unit_name->name . '"><i class="fa fa-plus-circle"></i> Tambah Form</button>
        <button type="submit" data-id="' . $this->encrypt->encode($data_product->id) . '" class="btn btn-primary-gradient btn-rounded btn_save_margin"><i class="fa fa-save"></i> Simpan Data</button>
        </div>
        </form>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function get_pattern_form_margin()
    {
        $unit_name = $this->input->post('name');
        $html_respon = '
        <div class="col-md-12">
        <div class="col-md-4">
        <div class="form-group">
        <label>Min Jumlah Pembelian</label>
        <input type="text" class="form-control pull-right number_only"  name="min_qty[]">
        <span class="help-block"></span>
        <!-- /.input group -->
        </div>
        </div>
        <div class="col-md-7">
        <div class="form-group">
        <label>Harga Jual</label>
        <div class="input-group date">
        <input type="text" class="form-control pull-right money_only"  name="price[]">
        <div class="input-group-addon">
        <i class="unit_name">' . $unit_name . '</i>
        </div>
        </div>
        <span class="help-block"></span>
        <!-- /.input group -->
        </div>
        </div>
        <div class="col-md-1">
        <label for="">&nbsp;</label><br>
        <a href="javascript:void(0)" class="btn btn-danger btn_cancel_form"><i class="fa fa-times"></i></a>
        </div>
        </div>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function validate_save_additional_margin()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_product = $this->db->where(['id' => $id])->get('tb_product')->row();

        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $arrray_min_qty = $this->input->post('min_qty');
        $arrray_price = $this->input->post('price');
        if (str_replace('.', '', $arrray_price[0]) > $get_product->price || str_replace('.', '', $arrray_price[0]) <= $get_product->main_price) {
            $data['error_string'][] = 'harga harus diantara harga pokok dan harga jual';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($arrray_min_qty[0] == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'min_qty';
            $data['status'] = FALSE;
        }
        if ($arrray_price[0] == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_additional_margin()
    {
        $this->validate_save_additional_margin();
        $arrray_min_qty = $this->input->post('min_qty');
        $arrray_price = $this->input->post('price');
        $id_product = $this->encrypt->decode($this->input->post('id'));

        $get_product = $this->db->where(['id' => $id_product])->get('tb_product')->row();

        foreach ($arrray_min_qty as $key => $value) {
            if (!empty($arrray_min_qty[$key]) && !empty($arrray_price[$key])) {
                //array insert
                if (str_replace('.', '', $arrray_price[$key]) > $get_product->main_price && str_replace('.', '', $arrray_price[$key]) < $get_product->price) {
                    $array_insert = [
                        'id_product' => $id_product,
                        'price' => str_replace('.', '', $arrray_price[$key]),
                        'qty' => $arrray_min_qty[$key]
                    ];
                    $this->model->insert(' tb_margin_price', $array_insert);
                }
            }
        }

        $array_respon = [
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function form_edit_margin()
    {
        $id = $this->encrypt->decode($this->input->post('id'));

        $this->db->select('
            tb_margin_price.*,
            tb_product.price AS price_product,
            tb_product.main_price AS main_price_product,
            tb_unit.name AS unit_name
            ');
        $this->db->from('tb_margin_price');
        $this->db->join('tb_product', 'tb_margin_price.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->where(['tb_margin_price.id' => $id]);
        $get_data_current = $this->db->get()->row();

        $array_price = ['price' => $get_data_current->price_product, 'main_price' => $get_data_current->main_price_product];

        $html_respon = '
        <div class="row">
            <div class="col-md-6 p-20 border border-radius-5 text-center">
                <label for="">Harga Pokok :</label>
                <h2>Rp.' . number_format($get_data_current->main_price_product, 0, '.', '.') . '</h2>
            </div>
            <div class="col-md-6 p-20 border border-radius-5 text-center">
                <label for="">Harga Jual :</label>
                <h2>Rp.' . number_format($get_data_current->price_product, 0, '.', '.') . '</h2>
            </div>
        </div>
        <span class="clearfix"></span>
        <hr>
        <form class="form_update_margin">
            <div class="col-md-12 main_additional_form row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Min Jumlah Pembelian</label>
                        <div class="input-group date">
                            <input type="text" class="form-control pull-right number_only" value="' . $get_data_current->qty . '" name="min_qty">
                            <div class="input-group-addon">
                                <i class="unit_name">' . $get_data_current->unit_name . '</i>
                            </div>
                        </div>
                        <!-- /.input group -->
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="form-group">
                        <label>Harga Jual</label>
                        <div class="input-group date">
                            <input type="text" class="form-control pull-right number_type money_only" value="' . number_format($get_data_current->price, 0, '.', '.') . '" name="price">
                            <div class="input-group-addon">
                                <i class="unit_name">' . $get_data_current->unit_name . '</i>
                            </div>
                        </div>
                        <span class="help-block price"></span>
                        <!-- /.input group -->
                    </div>
                </div>
            </div>
            <div class="col-md-12 cover-conversion-form"></div>
            <div class="col-md-12 text-right">
                <button type="submit" data-price="' . $this->encrypt->encode(json_encode($array_price)) . '" data-id="' . $this->encrypt->encode($get_data_current->id) . '" class="btn btn-primary-gradient btn-rounded btn_update_margin"><i class="fa fa-save"></i> Simpan Data</button>
            </div>
        </form>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function validate_update_additional_margin()
    {
        $price_current = json_decode($this->encrypt->decode($this->input->post('price_current')));
        $id = $this->encrypt->decode($this->input->post('id'));
        // $get_product = $this->db->where(['id' => $id])->get('tb_product')->row();


        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $min_qty = $this->input->post('min_qty');
        $price = $this->input->post('price');
        if (str_replace('.', '', $price) > $price_current->price || str_replace('.', '', $price) <= $price_current->main_price) {
            $data['error_string'][] = 'harga harus diantara harga pokok dan harga jual';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($min_qty == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'min_qty';
            $data['status'] = FALSE;
        }
        if ($price == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function update_additional_margin()
    {
        $this->validate_update_additional_margin();
        $min_qty = $this->input->post('min_qty');
        $price = $this->input->post('price');
        $id = $this->encrypt->decode($this->input->post('id'));

        $array_update = array(
            'qty' => str_replace('.', '', $min_qty),
            'price' => str_replace('.', '', $price)
        );
        // $this->model->update(array('id' => $id), $array_update, 'tb_margin_price');
        Modules::run('database/update', 'tb_margin_price', ['id' => $id], $array_update);
        //upadate margin
        echo json_encode(array('status' => TRUE));
    }

    public function delete_margin()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $this->model->delete(array('id' => $id), 'tb_margin_price');
        echo json_encode(array('status' => TRUE));
    }

    public function form_edit_barcode()
    {
        $status = $this->input->post('status');
        $id = $this->encrypt->decode($this->input->post('id'));
        if ($status == 'update') {
            $get_data_barcode = $this->db->where(['id' => $id])->get('tb_barcode_product')->row();
            $name = $get_data_barcode->barcode;
        } else {
            $name = '';
        }

        $html_respon = '
        <form class="form_update_barcode">
            <div class="col-md-12 row">
                <div class="col-md-8">
                    <div class="form-group">
                    <label>Barcode</label>
                    <input type="text" class="form-control pull-right" value="' . $name . '"  name="barcode">
                    <span class="help-block barcode"></span>
                </div>
                </div>
                <div class="col-md-4">
                    <label for="">&nbsp;</label><br>
                    <button type="submit"  data-id="' . $this->encrypt->encode($id) . '" data-status="' . $status . '" class="btn btn-primary-gradient btn-rounded btn_update_barcode"><i class="fa fa-save"></i> Simpan Data</button>
                </div>
            </div>
        
        </form>
        ';
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function validate_update_barcode()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('barcode') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'barcode';
            $data['status'] = FALSE;
        } else {
            $barcode = $this->input->post('barcode');
            $get_barcode_axist = $this->db->where(['barcode' => $barcode])->get('tb_barcode_product')->row();
            if (!empty($get_barcode_axist)) {
                $data['error_string'][] = 'barcode telah dipakai';
                $data['inputerror'][] = 'barcode';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }
    public function update_barcode()
    {
        $this->validate_update_barcode();
        $status = $this->input->post('status');
        $barcode = $this->input->post('barcode');
        $id = $this->encrypt->decode($this->input->post('id'));

        if ($status == 'update') {
            $array_update = array(
                'barcode' => $barcode
            );
            Modules::run('database/update', 'tb_barcode_product', ['id' => $id], $array_update);
            // $this->model->update(array('id' => $id), $array_update, 'tb_barcode_product');
        } else {
            $array_insert = array(
                'barcode' => $barcode,
                'id_product' => $id
            );
            // $this->model->insert('tb_barcode_product', $array_insert);
            Modules::run('database/insert', 'tb_barcode_product', $array_insert);
        }
        //upadate margin
        echo json_encode(array('status' => TRUE));
    }

    public function delete()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        //cek to sales 
        $count_sales = $this->db->where(['id_product' => $id])->get('tb_detail_sales')->num_rows();
        $count_request = $this->db->where(['id_product' => $id])->get(' tb_request_has_product')->num_rows();
        if ($count_sales > 0 || $count_request > 0) {
            echo json_encode(array('status' => FALSE));
        } else {
            $this->model->delete(array('id_product' => $id), 'tb_margin_price');
            $this->model->delete(array('id_product' => $id), ' tb_product_has_conversion');
            $this->model->delete(array('id' => $id), 'tb_product');
            echo json_encode(array('status' => TRUE));
        }
    }

    //additional function
    public function get_unit()
    {
        $id = $this->input->get('id');
        $get_data = $this->db->where(['id' => $id])->get('tb_unit')->row_array();
        if (empty($get_data)) {
            $get_data['name'] = '';
        }
        echo json_encode($get_data);
    }

    public function get_base_unit($id)
    {
        $get_data = $this->db->where(['id' => $id])->get('tb_base_unit')->row_array();
        echo json_encode($get_data);
    }

    //----------------------------------------------------------- import data -------------------------------------------------------------------
    private function do_upload_file()
    {
        $config['upload_path']          = 'upload/product';
        $config['allowed_types']        = 'csv';
        // $config['max_size']             = 100; //set max size allowed in Kilobyte
        // $config['max_width']            = 1000; // set max width image allowed
        // $config['max_height']           = 1000; // set max height allowed
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('upload')) //upload and validate
        {
            $data['inputerror'][] = 'upload';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            return $this->upload->data('file_name');
        }
    }

    public function import()
    {
        $data['data_unit'] = $this->db->get('tb_unit')->result();
        // $data['data_base_unit'] = $this->db->get('tb_base_unit')->result();
        $data['tagline_page'] = "IMPORT DATA BARANG";
        $data['js_page'] = $this->js_page;
        $data['view_file'] =  'view_import';
        $this->load->view('template/media_admin', $data);
    }

    public function do_import_data()
    {
        $file_name = $this->do_upload_file();
        $file_content = fopen('upload/product/' . $file_name, "r");
        $counter = 0;
        $array_data_csv = [];
        $array_list_barcode = [];
        while (($data_csv = fgetcsv($file_content, 1000, ",")) !== FALSE) {
            $counter++;
            if ($counter == 1) {
                continue;
            }
            if ($data_csv[0] == '') {
                continue;
            }

            $barcode        = $data_csv[0];
            $product_name   = $data_csv[1];
            $code_category  = $data_csv[2];
            $code_merk      = $data_csv[3];
            $unit_name      = $data_csv[4];
            $main_price     = $data_csv[5];
            $price          = $data_csv[6];
            $min_stock      = $data_csv[7];
            $supplier_code  = $data_csv[8];
            $description    = $data_csv[9];

            $html_error = '';
            $status_error = false;
            //get data 
            if ($code_category) {
                $code_category_current  = $this->db->where(['code' => $code_category])->get('tb_main_category')->row();
                if (!empty($code_category_current)) {
                    $category_name = $code_category_current->name;
                    $id_category   = $code_category_current->id;
                } else {
                    $category_name = '';
                    $id_category   = 0;
                    $status_error = TRUE;
                    $html_error .= '- Kode kategori tidak terdaftar <br>';
                }
            } else {
                $category_name = '';
                $id_category   = 0;
                $status_error = TRUE;
                $html_error .= '- Kode kategori Harus Disis <br>';
            }

            //get merk 
            $id_merk = 0;
            $merk_name = '';
            if ($code_merk) {
                $code_merk_current  = $this->db->where(['code' => $code_merk])->get('tb_merk')->row();
                if (!empty($code_merk_current)) {
                    $merk_name = $code_merk_current->name;
                    $id_merk = $code_merk_current->id;
                } else {
                    $id_merk = 0;
                    $merk_name = '';
                    $status_error = TRUE;
                    $html_error .= '- Kode Merk tidak terdaftar <br>';
                }
            }

            //get merk 
            if (!empty($unit_name)) {
                $code_unit_current  = $this->db->where(['name' => $unit_name])->get('tb_unit')->row();
                if (!empty($code_unit_current)) {
                    $unit_name_current = $code_unit_current->name;
                    $id_unit            = $code_unit_current->id;
                } else {
                    $id_unit            = 0;
                    $unit_name_current = '';
                    $status_error = TRUE;
                    $html_error .= '- nama satuan tidak terdaftar <br>';
                }
            } else {
                $id_unit            = 0;
                $unit_name_current = '';
                $status_error = TRUE;
                $html_error .= '- nama satuan Harus Diisi <br>';
            }

            //get Supplier 
            $supplier_name = '';
            $id_supplier    = 0;
            if ($supplier_code) {
                $get_supplier  = $this->db->where(['code' => $supplier_code])->get('tb_supplier')->row();
                if (!empty($get_supplier)) {
                    $supplier_name = $get_supplier->name;
                    $id_supplier    = $get_supplier->id;
                } else {
                    $supplier_name = '';
                    $id_supplier    = 0;
                    $status_error = TRUE;
                    $html_error .= '- Kode Suplier tidak terdaftar <br>';
                }
            }

            if (empty($product_name)) {
                $status_error = TRUE;
                $html_error .= '- nama prosuk harus diisi <br>';
            }
            if (empty($main_price)) {
                $status_error = TRUE;
                $html_error .= '- harga pokok harus diisi <br>';
            }
            if (empty($price)) {
                $status_error = TRUE;
                $html_error .= '- harga Jual harus diisi <br>';
            }

            //barcode
            if (!empty($barcode)) {
                $get_barcode = $this->db->where(['barcode' => $barcode])->get('tb_barcode_product')->row();
                if (!empty($get_barcode)) {
                    $status_error = TRUE;
                    $html_error .= '- barcode telah dipakai <br>';
                }

                if (in_array($barcode, $array_list_barcode)) {
                    $status_error = TRUE;
                    $html_error .= '- barcode Duplikat <br>';
                }
                $array_list_barcode[] = $barcode;
            }

            $array_data_csv[] = [
                'barcode' => $barcode,
                'name' => $product_name,
                'id_category' => $id_category,
                'category_name' => $category_name,
                'id_unit' => $id_unit,
                'unit_name' => $unit_name_current,
                'id_supplier' => $id_supplier,
                'supplier_name' => $supplier_name,
                'id_merk' => $id_merk,
                'merk_name' => $merk_name,
                'price' => $price,
                'main_price' => $main_price,
                'min_stock' => $min_stock,
                'description' => $description,
                'error_status' => $status_error,
                'html_error' => $html_error
            ];
        }
        $data['data_csv'] = $array_data_csv;
        $html_respon = $this->load->view('view_import_result', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save_import_data()
    {
        $data_csv = json_decode($this->encrypt->decode($this->input->post('data_csv')));
        $counter = 0;
        foreach ($data_csv as $item_csv) {
            if ($item_csv->error_status) {
                continue;
            }
            $counter++;
            $code_product = $this->get_code();

            $array_insert = [
                'id_account_warehouse' => 0,
                'id_main_category' => $item_csv->id_category,
                'id_merk' => $item_csv->id_merk,
                'id_supplier' => $item_csv->id_supplier,
                'id_unit' => $item_csv->id_unit,
                'code' => $code_product,
                'name' => $item_csv->name,
                'stock_minimum' => $item_csv->min_stock ? $item_csv->min_stock : 0,
                'last_stock_price' => $item_csv->main_price,
                'main_price' => $item_csv->main_price,
                'price' => $item_csv->price,
                'description' => $item_csv->description,
                'date' => date('Y-m-d')
            ];
            //insert db
            $this->model->insert('tb_product', $array_insert);
            //get current data
            //if ($item_csv->barcode) {
            $get_id_current = $this->db->where(['code' => $code_product])->get('tb_product')->row();
            $array_insert_barcode = [
                'barcode' => !empty($item_csv->barcode) ? $item_csv->barcode : $code_product,
                'id_product' => $get_id_current->id
            ];
            $this->model->insert('tb_barcode_product', $array_insert_barcode);
            //}
        }

        $array_respon = [
            'status' => TRUE,
            'counter' => $counter
        ];
        echo json_encode($array_respon);
    }

    public function download_csv()
    {
        force_download('assets/document/template_import_product.csv', NULL);
    }
}
