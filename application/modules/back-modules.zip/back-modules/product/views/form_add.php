<div class="" style="margin-left:8%;margin-right:8%;">
    <div class="card">
        <div class="overlay">
            <i class="fa fa-refresh fa-spin"></i>
        </div>
        <div class="card-header text-right">
            <!-- <button type="button" id="add_button" title="add data" class="btn btn-primary pull-right" onclick="add_product()">
            <i class="fa fa-plus"></i> Tambah Data
        </button> -->
            <a href="<?= Modules::run('helper/create_url', 'product'); ?>" class="btn btn-primary btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
        </div>
        <div class="card-body">
            <form role="form" id="form_product">
                <div class="row">
                    <input type="hidden" name="id">
                    <input type="hidden" name="code">
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="exampleInputEmail1">KODE BARANG</label>
                            <input type="text" class="form-control" name="code" id="barcode" placeholder="masukan Kode Barang..">
                            <span class="help-block text-danger"></span>
                        </div>
                        <div class="form-group col-md-8">
                            <label for="exampleInputEmail1">Nama Barang</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="masukan nama..">
                            <span class="help-block text-danger notif_name"></span>
                        </div>
                        <span class="clearfix"></span>
                        <div class="col-md-12">
                            <hr>
                            <label class="label label-info text-uppercase font-weight-bold">DEVISI & KATEGORI</label>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="exampleInputEmail1">DEVISI BARANG</label>
                            <select name="main_category" class="form-control chosen" id="main_category">
                            </select>
                            <span class="help-block text-danger notif_main_category"></span>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="">&nbsp;</label><br>
                            <!-- <a href="javascript:void(0)" class="btn btn-primary btn_add_category"><i class="fa fa-plus-circle"></i> Tambah</a> -->
                        </div>
                        <div class="form-group col-md-4">
                            <label for="exampleInputEmail1">KATEGORI BARANG</label>
                            <select name="id_merk" class="form-control"></select>
                            <span class="help-block text-danger notif_id_merk"></span>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="">&nbsp;</label><br>
                            <!-- <a href="javascript:void(0)" class="btn btn-primary btn_add_merk"><i class="fa fa-plus-circle"></i> Tambah</a> -->
                        </div>
                        <span class="clearfix"></span>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Satuan</label>
                                <select class="form-control chosen" name="unit" id="unit" onchange="get_unit()">
                                </select>
                                <span class="help-block text-danger notif_unit"></span>
                            </div>
                        </div>
                        <!-- <div class="form-group col-md-2">
                            <label for="">&nbsp;</label><br>
                            <a href="javascript:void(0)" class="btn btn-primary btn_add_unit"><i class="fa fa-plus-circle"></i> Tambah Satuan</a>
                        </div> -->
                        <div class="form-group col-md-2">
                            <label for="">&nbsp;</label><br>
                            <a href="javascript:void(0)" class="btn btn-primary btn_add_conversion"><i class="fa fa-plus-circle"></i> Tambah Konversi</a>
                        </div>
                        <div class="col-md-12 cover-conversion"></div>
                        <span class="clearfix"></span>
                        <div class="col-md-12">
                            <hr>
                            <label class="label label-info font-weight-bold">PENGATURAN HARGA</label>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>HARGA POKOK SATUAN</label>
                                <div class="input-group date">
                                    <input type="text" class="form-control pull-right  money_only" id="main_price" name="main_price">
                                    <div class="input-group-addon">
                                        <i class="unit_name"> </i>
                                    </div>
                                </div>
                                <span class="help-block text-danger notif_main_price"></span>
                                <!-- /.input group -->
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="">&nbsp;</label><br>
                            <a href="javascript:void(0)" class="btn btn-primary btn_view_conversion" data-target="main_price"><i class="fa fa-tv"></i> Lihat Harga Per Konversi</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="text-uppercase">HARGA 1</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  money_only price_count" data-target="1" name="price_1">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_price_1"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Persentase Keuntungan</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  number_only percentage" data-target="price_1" id="persentage_1" name="persentage_1">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger persentage"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="">&nbsp;</label><br>
                                <a href="javascript:void(0)" class="btn btn-primary btn_view_conversion" data-target="price_1"><i class="fa fa-tv"></i> Lihat Harga Per Konversi</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="text-uppercase">HARGA 2</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  money_only price_count" data-target="2" name="price_2">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_price_2"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Persentase Keuntungan</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  number_only percentage" data-target="price_2" id="persentage_2" name="persentage_2">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger persentage"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="">&nbsp;</label><br>
                                <a href="javascript:void(0)" class="btn btn-primary btn_view_conversion" data-target="price_2"><i class="fa fa-tv"></i> Lihat Harga Per Konversi</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="text-uppercase">HARGA 3</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  money_only price_count" data-target="3" name="price_3">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_price_3"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Persentase Keuntungan</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  number_only percentage" data-target="price_3" id="persentage_3" name="persentage_3">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger persentage"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="">&nbsp;</label><br>
                                <a href="javascript:void(0)" class="btn btn-primary btn_view_conversion" data-target="price_3"><i class="fa fa-tv"></i> Lihat Harga Per Konversi</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="text-uppercase">HARGA 4</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  money_only price_count" data-target="4" name="price_4">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_price_4"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Persentase Keuntungan</label>
                                    <div class="input-group date">
                                        <input type="text" class="form-control pull-right  number_only percentage" data-target="price_4" id="persentage_4" name="persentage_4">
                                        <div class="input-group-addon">
                                            <i class="unit_name"> </i>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger persentage"></span>
                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="">&nbsp;</label><br>
                                <a href="javascript:void(0)" class="btn btn-primary btn_view_conversion" data-target="price_4"><i class="fa fa-tv"></i> Lihat Harga Per Konversi</a>
                            </div>
                        </div>

                        <!-- <span class="clearfix"></span>
                        <div class="col-md-12">
                            <hr>
                        </div> -->
                        <!-- <div class="discount_page">
                            <label class="text-uppercase"><u>Potongan Harga</u></label>
                            <span class="clearfix"></span>
                            <div class="html_discount_add"></div>
                        </div> -->
                        <!-- end discounr price -->
                        <!-- <div class="col-md-12">
                            <button type="button" onclick="add_discount()" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Tambah Potongan</button>
                            <hr>
                        </div> -->
                        <span class="clearfix"></span>
                        <div class="col-md-12">
                            <hr>
                            <label class="label label-info text-uppercase font-weight-bold">Stok & supplier</label>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="text-uppercase">Stok Minimal</label>
                                <div class="input-group date">
                                    <input type="text" class="form-control pull-right  money_only" id="min_stock" name="min_stock">
                                    <div class="input-group-addon">
                                        <i class="unit_name"> </i>
                                    </div>
                                </div>
                                <span class="help-block text-danger notif_min_stock"></span>
                                <!-- /.input group -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Supplier Barang</label>
                                <select class="form-control chosen" name="id_supplier" id="id_supplier"></select>
                                <span class="help-block text-danger notif_id_supplier"></span>
                                <!-- /.input group -->
                            </div>
                        </div>
                        <!-- <div class="form-group col-md-2">
                            <label for="">&nbsp;</label><br>
                            <a href="javascript:void(0)" class="btn btn-primary btn_add_supplier"><i class="fa fa-plus-circle"></i> Tambah Supplier</a>
                        </div> -->
                        <span class="clearfix"></span>
                        <div class="col-md-12">
                            <hr>
                            <label class="label label-info text-uppercase font-weight-bold">Berat & Ukuran Barang</label>
                        </div>
                        <div class="form-group col-12 row">
                            <div class="col-md-2">
                                <label for="">Kubikasi (Cm 2)</label>
                                <div class="input-group mb-3">
                                    <input name="kubikasi" class="form-control" type="text">
                                    <div class="input-group-append">
                                        <span class="input-group-text">Cm 2</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label for="">Panjang (Cm)</label>
                                <div class="input-group mb-3">
                                    <input name="long_cm" class="form-control" type="text">
                                    <div class="input-group-append">
                                        <span class="input-group-text">Cm</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label for="">Lebar (Cm)</label>
                                <div class="input-group mb-3">
                                    <input name="width_cm" class="form-control" type="text">
                                    <div class="input-group-append">
                                        <span class="input-group-text">Cm 2</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label for="">Tinggi (Cm)</label>
                                <div class="input-group mb-3">
                                    <input name="height_cm" class="form-control" type="text">
                                    <div class="input-group-append">
                                        <span class="input-group-text">Cm</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label for="">Berat (KG)</label>
                                <div class="input-group mb-3">
                                    <input name="weight" class="form-control" type="text">
                                    <div class="input-group-append">
                                        <span class="input-group-text">Kg</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-12">
                            <label for="exampleInputEmail1" class="text-uppercase">Keterangan</label>
                            <textarea class="form-control" name="description" placeholder="optional...."></textarea>
                            <span class="help-block text-danger"></span>
                        </div>
                        <div class="card-footer col-12 text-right">
                            <button type="submit" class="btn btn-lg btn-primary-gradient btn-rounded pull-right btn_save_product"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                        </div>
                    </div>
            </form>
        </div>
        <!-- /.box-body -->
    </div>
</div>


<div class="modal modal-form">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title-form"></h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal" id="modal_detail_product" data-backdrop="static">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form </h4>
            </div>
            <div class="card-body pad">
                <div class="detail-product-html">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>