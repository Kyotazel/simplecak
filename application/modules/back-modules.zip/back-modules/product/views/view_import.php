<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header text-right">
    </div>
    <div class="card-body">
        <div class="col-md-4 pull-right text-right">
            <a href="<?= base_url('product/add'); ?>" class="btn btn-default btn_link"><i class="fa fa-plus-circle"></i> Tambah Data Produk</a>
            <a href="<?= base_url('product'); ?>" class="btn btn-default btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
        </div>
        <div class="p-10 border col-md-8 border-radius-5">
            <form class="form-import">
                <div class="col-md-6 form-group">
                    <label for="">Upload CSV</label>
                    <input type="file" name="upload" class="form-control">
                    <span class="help-block upload"></span>
                </div>
                <div class="col-md-6">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-success btn_import"><i class="fa fa-send"></i> Import Data</button> ||
                    <a href="<?= base_url('assets/document/template_import_product.csv') ?>" class="btn btn-success"><i class="fa fa-download"></i> Download Template CSV</a>
                </div>
            </form>
        </div>
    </div>
    <!-- /.box-body -->
</div>
<div class="html_respon"></div>