<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header text-right">
        <!-- <button type="button" id="add_button" title="add data" class="btn btn-default pull-right" onclick="add_product()">
            <i class="fa fa-plus"></i> Tambah Data
        </button> -->
        <a href="<?= base_url('product/add'); ?>" class="btn btn-default btn_link"><i class="fa fa-circle-left"></i> kembali</a>
        <a href="<?= base_url('product/add'); ?>" class="btn btn-default btn_link"><i class="fa fa-plus-circle"></i> Tambah Data Produk</a>
        <a href="<?= base_url('product/import'); ?>" class="btn btn-default btn_link"><i class="fa fa-send"></i> Import Produk</a>
    </div>
    <div class="card-body">

        <div class="table-responsive">
            <table id="table_list" class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>barcode</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th>merk</b></th>
                        <th>Satuan</b></th>
                        <th>stok minimal</b></th>
                        <th>harga pokok</th>
                        <th>harga jual</b></th>
                        <th>persentase untung</th>
                        <th>tgl input</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal_detail_product" data-backdrop="static">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form </h4>
            </div>
            <div class="card-body pad">
                <div class="detail-product-html">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>