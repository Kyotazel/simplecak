<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table_data">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>DEVISI</th>
                        <th>KATEGORI</th>
                        <th>SUB-KATEGORI</th>
                        <th>Satuan</th>
                        <th>stok minimal</th>
                        <th>Harga Beli</th>
                        <th>Harga 1</th>
                        <th>Harga 2</th>
                        <th>Harga 3</th>
                        <th>Harga 4</th>
                        <th>tgl input</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = $start_no;
                    foreach ($data_product as $data_table) {

                        // $persentage = (($data_table->price - $data_table->main_price) / $data_table->main_price) * 100;

                        $no++;

                        $barcode = '';
                        // if ($data_table->barcode) {
                        //     $barcode = Modules::run('product/generate_barcode', $data_table->barcode);
                        // }
                        echo '
                            <tr>
                                <td style="vertical-align:middle;">' . $no . '</td>
                                <td class="text-center">
                                    <label for="">' . $data_table->code . '</label>
                                </td>
                                <td style="vertical-align:middle;">' . $data_table->name . '</td>
                                <td style="vertical-align:middle;">' . $data_table->devision_name . '</td>
                                <td style="vertical-align:middle;">' . $data_table->category_name . '</td>
                                <td style="vertical-align:middle;">' . $data_table->merk_name . '</td>
                                <td style="vertical-align:middle;">' . $data_table->unit_name . '</td>
                                <td style="vertical-align:middle;">' . $data_table->stock_minimum . '</td>
                                <td style="vertical-align:middle;">' . $data_table->main_price . '</td>
                                <td style="vertical-align:middle;">' . $data_table->price_1 . '</td>
                                <td style="vertical-align:middle;">' . $data_table->price_2 . '</td>
                                <td style="vertical-align:middle;">' . $data_table->price_3 . '</td>
                                <td style="vertical-align:middle;">' . $data_table->price_4 . '</td>
                                <td style="vertical-align:middle;">' . $data_table->created_date . '</td>
                                <td style="vertical-align:middle;"><a class="btn btn-primary btn-rounded btn_link" href="' . Modules::run('helper/create_url', 'product/detail?data=' . urlencode($this->encrypt->encode($data_table->id))) . '" title="detail"><i class="fa fa-tv"></i></a></td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-4">
                    <!--Tampilkan pagination-->
                    <?php echo $html_pagination; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.box-body -->
</div>