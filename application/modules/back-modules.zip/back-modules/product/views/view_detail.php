<?php
$persentage = (($data_product->price - $data_product->main_price) / $data_product->main_price) * 100;
?>
<div class="">
    <div class="card">
        <div class="overlay">
            <i class="fa fa-refresh fa-spin"></i>
        </div>
        <div class="card-header text-right">
            <!-- <button type="button" id="add_button" title="add data" class="btn btn-light btn-rounded pull-right" onclick="add_product()">
            <i class="fa fa-plus"></i> Tambah Data
        </button> -->
            <a href="javascript:void(0)" class="btn btn-danger btn_delete btn-rounded" data-id="<?= $this->encrypt->encode($data_product->id); ?>"><i class="fa fa-trash"></i> Hapus Data</a> ||
            <a href="<?= Modules::run('helper/create_url', 'product/add'); ?>" class="btn btn-light btn-rounded btn_link"><i class="fa fa-plus-circle"></i> Tambah Data</a> ||
            <a href="<?= Modules::run('helper/create_url', 'product'); ?>" class="btn btn-light btn-rounded btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>

        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-7">
                    <h3 class="p-10"><i class="fa fa-tv"></i> Data Produk</h3>
                    <table class="table">
                        <tr>
                            <td width="150px">Kode Produk</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->code; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Nama Produk</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->name; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Satuan Barang </td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->unit_name; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Devisi </td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->product_devision_name; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Ketegori</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->product_category_name; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Sub-Ketegori</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->sub_category_name; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Stok Minimum</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->stock_minimum; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Suplier</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->supplier_name; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">Kubikasi</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->cubic; ?> CM <sup>3</sup> </b></td>
                        </tr>
                        <tr>
                            <td width="150px">Volume</td>
                            <td width="10px">:</td>
                            <td>
                                <b class="text-uppercase">Panjang : <?= $data_product->long_cm; ?> CM</b>&nbsp; | &nbsp;
                                <b class="text-uppercase">Lebar : <?= $data_product->width_cm; ?> CM</b>&nbsp; | &nbsp;
                                <b class="text-uppercase">Tinggi : <?= $data_product->height_cm; ?> CM</b>&nbsp;
                            </td>
                        </tr>
                        <tr>
                            <td width="150px">Berat</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->weight; ?> KG</b></td>
                        </tr>

                        <tr>
                            <td width="150px">Tanggal Input</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->created_date; ?></b></td>
                        </tr>
                        <tr>
                            <td width="150px">User</td>
                            <td width="10px">:</td>
                            <td><b class="text-uppercase"><?= $data_product->user_name; ?></b></td>
                        </tr>
                    </table>
                    <div class="">
                        <label for="">keterangan produk</label>
                        <p><?= $data_product->description; ?></p>
                    </div>
                    <div class="text-right">
                        <small>(*klik untuk update)</small>
                        <a href="javascript:void(0)" class="btn btn-light btn-rounded btn_edit_main" data-id="<?= $this->encrypt->encode($data_product->id); ?>"><i class="fa fa-edit"></i> Update Data</a>
                    </div>
                    <span class="clearfix"></span>
                    <hr>
                    <h3 class="p-10"><i class="fa fa-tv"></i> Data Konversi Satuan Produk</h3>
                    <table class="table">
                        <thead class="">
                            <th>Nama Satuan</th>
                            <th>Jumlah</th>
                            <th>Total Harga Pokok</th>
                            <th>Total Harga Jual</th>
                            <th>Aksi</th>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($data_conversion as $item_conversion) {
                                $total_main_price = $item_conversion->qty * $data_product->main_price;
                                $total_price = $item_conversion->qty * $data_product->price;
                                echo '
                                <tr>
                                    <td>' . $item_conversion->name . '</td>
                                    <td>' . $item_conversion->qty . ' ' . $data_product->unit_name . '</td>
                                    <td>Rp.' . number_format($total_main_price, 0, '.', '.') . '</td>
                                    <td>Rp.' . number_format($total_price, 0, '.', '.') . '</td>
                                    <td>
                                        <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($item_conversion->id) . '" class="btn btn-light btn-rounded btn_edit_conversion"><i class="fa fa-edit"></i></a>
                                        <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($item_conversion->id) . '" class="btn btn-light btn-rounded btn_del_conversion"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            ';
                            }
                            ?>
                        </tbody>
                    </table>
                    <div class="p-10 text-right">
                        <small>(*klik untuk Tambah Data) </small><a href="javascript:void(0)" data-id="<?= $this->encrypt->encode($data_product->id); ?>" class="btn btn-light btn-rounded btn_add_detail_conversion"><i class="fa fa-plus-circle"></i> Tambah Konversi</a>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="p-3  border-radius-5">
                        <h3 class="p-10"><i class="fa fa-money"></i> Data Harga Produk</h3>
                        <hr>
                        <label for="">Harga Beli :</label>
                        <div class="input-group font-weight-bold" style="width:250px;">
                            <div class="input-group-prepend">
                                <span class="input-group-text font-weight-bold">Rp.</span>
                            </div>
                            <input class="form-control bg-white border-dashed font-weight-bold" readonly type="text" value="<?= number_format($data_product->main_price, 0, '.', '.'); ?>">
                        </div>
                        <hr>
                        <label for="">Harga Jual :</label>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Kt.Harga</th>
                                    <th>Harga</th>
                                    <th>(%) Keuntungan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Harga 1</td>
                                    <td>
                                        <div class="input-group font-weight-bold" style="width:200px;">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text font-weight-bold">Rp.</span>
                                            </div>
                                            <input class="form-control bg-white border-dashed font-weight-bold" readonly type="text" value="<?= number_format($data_product->price_1, 0, '.', '.'); ?>">
                                        </div>
                                    </td>
                                    <td>
                                        <?= round((($data_product->price_1 - $data_product->main_price) / $data_product->main_price) * 100); ?> %
                                    </td>
                                </tr>
                                <tr>
                                    <td>Harga 2</td>
                                    <td>
                                        <div class="input-group font-weight-bold" style="width:200px;">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text font-weight-bold">Rp.</span>
                                            </div>
                                            <input class="form-control bg-white border-dashed font-weight-bold" readonly type="text" value="<?= number_format($data_product->price_2, 0, '.', '.'); ?>">
                                        </div>
                                    </td>
                                    <td>
                                        <?= round((($data_product->price_2 - $data_product->main_price) / $data_product->main_price) * 100); ?> %
                                    </td>
                                </tr>
                                <tr>
                                    <td>Harga 3</td>
                                    <td>
                                        <div class="input-group font-weight-bold" style="width:200px;">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text font-weight-bold">Rp.</span>
                                            </div>
                                            <input class="form-control bg-white border-dashed font-weight-bold" readonly type="text" value="<?= number_format($data_product->price_3, 0, '.', '.'); ?>">
                                        </div>
                                    </td>
                                    <td>
                                        <?= round((($data_product->price_3 - $data_product->main_price) / $data_product->main_price) * 100); ?> %
                                    </td>
                                </tr>
                                <tr>
                                    <td>Harga 4</td>
                                    <td>
                                        <div class="input-group font-weight-bold" style="width:200px;">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text font-weight-bold">Rp.</span>
                                            </div>
                                            <input class="form-control bg-white border-dashed font-weight-bold" readonly type="text" value="<?= number_format($data_product->price_4, 0, '.', '.'); ?>">
                                        </div>
                                    </td>
                                    <td>
                                        <?= round((($data_product->price_4 - $data_product->main_price) / $data_product->main_price) * 100); ?> %
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                        <div class="text-right">
                            <small>(*klik untuk update)</small>
                            <a href="javascript:void(0)" class="btn btn-light btn-rounded btn_edit_price" data-id="<?= $this->encrypt->encode($data_product->id); ?>"><i class="fa fa-edit"></i> Update Data</a>
                        </div>
                    </div>
                    <br>
                    <!-- <div class="p-3  border border-radius-5">
                        <h3 class="p-10"><i class="fa fa-money"></i> Data Potongan Harga Jual</h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Min. Jml.Beli</th>
                                    <th>Harga Jual</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $array_price = ['price' => $data_product->price, 'main_price' => $data_product->main_price];
                                foreach ($data_margin_price as $item_margin) {
                                    echo '
                                        <tr>
                                            <td>' . $item_margin->qty . ' ' . $data_product->unit_name . '</td>
                                            <td>' . number_format($item_margin->price, 0, '.', '.') . '</td>
                                            <td>
                                                <a href="javascript:void(0)" data-price="' . $this->encrypt->encode(json_encode($array_price)) . '" data-id="' . $this->encrypt->encode($item_margin->id) . '" class="btn btn-light btn-rounded btn_edit_margin"><i class="fa fa-edit"></i></a>
                                                <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($item_margin->id) . '" class="btn btn-light btn-rounded btn_del_margin"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    ';
                                }
                                ?>
                            </tbody>
                        </table>
                        <div class="text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-id="<?= $this->encrypt->encode($data_product->id); ?>" class="btn btn-light btn-rounded btn_add_margin"><i class="fa fa-plus-circle"></i> Tambah Data</a>
                        </div>
                    </div> -->
                    <br>
                    <!-- <div class="p-3  border border-radius-5">
                        <h3 class="p-10"><i class="fa fa-barcode"></i> Data Barcode</h3>
                        <h1 class="p-10 shadow border-radius-5 text-center mb-10"><?= isset($data_barcode->barcode) ? $data_barcode->barcode : ''; ?></h1>

                        <div class="text-right">
                            <small>(*klik untuk update data)</small>
                            <?php
                            if (isset($data_barcode->id)) {
                                echo '
                                    <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($data_barcode->id) . '" data-status="update" class="btn btn-light btn-rounded btn_edit_barcode"><i class="fa fa-edit"></i> Update Barcode</a>
                                ';
                            } else {
                                echo '
                                    <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($data_product->id) . '" data-status="add" class="btn btn-light btn-rounded btn_edit_barcode"><i class="fa fa-edit"></i> Update Barcode</a>
                                ';
                            }
                            ?>
                        </div>

                    </div> -->
                </div>
            </div>
        </div>
        <!-- /.box-body -->
    </div>
</div>


<div class="modal modal-form">
    <div class="modal-dialog" style="min-width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>