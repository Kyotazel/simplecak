<?php
$encrypt_data = $this->encrypt->encode(json_encode($data_csv));
?>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>barcode</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Merk</th>
                        <th>Satuan</th>
                        <th>Harga Pokok</th>
                        <th>Harga Jual</th>
                        <th>Stok Minimal</th>
                        <th>Supplier</th>
                        <th>Ket</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $counter = 0;
                    if (!empty($data_csv)) {
                        foreach ($data_csv as $item_csv) {
                            $counter++;
                            $class_error = $item_csv['error_status'] ? 'bg-danger' : '';
                            $html_status = $item_csv['html_error'] ? $item_csv['html_error'] : '<label class="label label-success">VERIFIED</label>';
                            echo '
                                <tr class="' . $class_error . '">
                                    <td>' . $counter . '</td>
                                    <td>' . $item_csv['barcode'] . '</td>
                                    <td>' . $item_csv['name'] . '</td>
                                    <td>' . $item_csv['category_name'] . '</td>
                                    <td>' . $item_csv['merk_name'] . '</td>
                                    <td>' . $item_csv['unit_name'] . '</td>
                                    <td>' . $item_csv['main_price'] . '</td>
                                    <td>' . $item_csv['price'] . '</td>
                                    <td>' . $item_csv['min_stock'] . '</td>
                                    <td>' . $item_csv['supplier_name'] . '</td>
                                    <td>' . $item_csv['description'] . '</td>
                                    <td>
                                        ' . $html_status . '
                                    </td>
                                </tr>
                            ';
                        }
                    } else {
                        echo '
                            <tr>
                                <td colspan="11" class="text-center">
                                    <h2 class="text-center">TIDAK ADA DATA</h2>
                                </td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <span class="clearfix"></span>
        <?php
        if (!empty($data_csv)) {
        ?>
            <div class="col-md-12">
                <form class="form-save-import">
                    <div class="text-right">
                        <input type="hidden" value="<?= $encrypt_data ?>" name="data_csv">
                        <small>*klik untuk simpan data</small>
                        <button class="btn btn-success btn-lg btn_save_import"><i class="fa fa-send"></i> Lanjutkan Simpan Data </button>
                    </div>
                </form>
            </div>
        <?php }; ?>

    </div>
</div>