var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var id_use = 0;
var table;

$(document).ready(function () {
    // $('#modal_detail_product').modal('show');
    // table = $('#table_list').DataTable({
    //     "processing": true, 
    //     "serverSide": true, 
    //     "order": [], 
    //     "ajax": {
    //         "url": url_controller + "list_data",
    //         "type": "POST"
    //     },
    //     "columnDefs": [
    //         { 
    //             "targets": [ 0 ], 
    //             "orderable": false, 
    //         },
    //     ]
    // });
    get_category();
    get_unit_html();
    get_supplier_html();

    $('.chosen').chosen();

})
//end document ready 
function reload_table() {
    table.ajax.reload(null, false); //reload datatable ajax 
}


//--------------------------------- category -------------------------------
$(document).on('change', '#main_category', function() {
    var id_current = $(this).val();
    $.ajax({
        url: url_controller + "get_sub_category",
        type: "POST",
        dataType: "JSON",
        data: {
            'id': id_current
        },
        success: function(data) {
            $('[name="id_merk"]').html(data.option_merk);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})

$(document).on('click', '.btn_add_category', function () {
    showLoading();
    $('.modal-title-form').text('Tambah Data Kategori');
    $.ajax({
        url: url_controller + "form_add_category",
        type: "POST",
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                $('.html_respon_modal').html(data.html_respon);
                $('.modal-form').modal('show');
                $('.btn_add_category');
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})

$(document).on('click', '.btn_save_category', function (e) {
    e.preventDefault();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-category')[0]);
    $.ajax({
        url: url_controller+'save_category',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                // $('#modal_user').modal('hide');
                $('.modal-form').modal('hide');
                notif_success('data berhasil disimpan!');
                get_category();
            } else {
                hideLoading();
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }

        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }

    });
})

function get_category() {
    $.ajax({
        url: url_controller + "get_main_category",
        type: "POST",
        dataType: "JSON",
        success: function(data) {
            // $('.base_name').text(data.base_name);
            $('[name="main_category"]').html(data.html_respon);
            $('[name="main_category"]').val('').trigger("chosen:updated");
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}

//------------------- merk ------------------------------

$(document).on('click', '.btn_add_merk', function () {
    var main_category = $('#main_category').val();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    if (main_category == '') {
        alert_error('pilih kategori terlebih dahulu');
        $('[name="main_category"]').parent().addClass('has-error');
        $('[name="main_category"]').next().text('belum dipilih');
    } else {
        showLoading();
        $('.modal-title-form').text('Tambah Data Merk');
        $.ajax({
            url: url_controller + "form_add_merk",
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                if (data.status) {
                    $('.html_respon_modal').html(data.html_respon);
                    $('.modal-form').modal('show');
                    $('.btn_add_merk');
                } else {
                    alert_error('something wrong');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    }
})

$(document).on('click', '.btn_save_merk', function (e) {
    e.preventDefault();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var id_main_category = $('#main_category').val();
    var formData = new FormData($('.form-merk')[0]);
    formData.append('id_main_category', id_main_category);
    $.ajax({
        url: url_controller+'save_merk',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                // $('#modal_user').modal('hide');
                $('.modal-form').modal('hide');
                notif_success('data berhasil disimpan!');
                $('#main_category').change();
            } else {
                hideLoading();
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }

        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }

    });
})

//-------------------------unit ----------------------------
$(document).on('click', '.btn_add_unit', function () {
    showLoading();
        $('.modal-title-form').text('Tambah Data Satuan');
        $.ajax({
            url: url_controller + "form_add_unit",
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                if (data.status) {
                    $('.html_respon_modal').html(data.html_respon);
                    $('.modal-form').modal('show');
                    $('.btn_add_unit');
                } else {
                    alert_error('something wrong');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
})

$(document).on('click', '.btn_save_unit', function (e) {
    e.preventDefault();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    // var id_main_category = $('#main_category').val();
    var formData = new FormData($('.form-unit')[0]);
    // formData.append('id_main_category', id_main_category);
    $.ajax({
        url: url_controller+'save_unit',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                // $('#modal_user').modal('hide');
                $('.modal-form').modal('hide');
                notif_success('data berhasil disimpan!');
                get_unit_html();
            } else {
                hideLoading();
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }

        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }

    });
})

function get_unit_html() {
    $.ajax({
        url: url_controller + "get_unit_html",
        type: "POST",
        dataType: "JSON",
        success: function(data) {
            // $('.base_name').text(data.base_name);
            $('[name="unit"]').html(data.html_respon);
            $('[name="unit"]').val('').trigger("chosen:updated");
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}

//---------------- conversion -----------------------
$('.btn_add_conversion').click(function () {
    $.ajax({
        url: url_controller + "form_conversion",
        type: "POST",
        dataType: "JSON",
        success: function(data) {
            // $('.base_name').text(data.base_name);
            $('.cover-conversion').append(data.html_respon);
            get_unit();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})

$(document).on('click', '.clear_conversion', function () {
    $(this).parent().parent().remove();
})

//-------------------------Suplier ----------------------------
$(document).on('click', '.btn_add_supplier', function () {
    showLoading();
        $('.modal-title-form').text('Tambah Data Suplier');
        $.ajax({
            url: url_controller + "form_add_supplier",
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                if (data.status) {
                    $('.html_respon_modal').html(data.html_respon);
                    $('.modal-form').modal('show');
                    $('.btn_add_supplier');
                } else {
                    alert_error('something wrong');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
})

$(document).on('click', '.btn_save_supplier', function (e) {
    e.preventDefault();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    // var id_main_category = $('#main_category').val();
    var formData = new FormData($('.form-supplier')[0]);
    // formData.append('id_main_category', id_main_category);
    $.ajax({
        url: url_controller+'save_supplier',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                // $('#modal_user').modal('hide');
                $('.modal-form').modal('hide');
                notif_success('data berhasil disimpan!');
                get_supplier_html();
            } else {
                hideLoading();
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }

        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }

    });
})

function get_supplier_html() {
    $.ajax({
        url: url_controller + "get_supplier_html",
        type: "POST",
        dataType: "JSON",
        success: function(data) {
            // $('.base_name').text(data.base_name);
            $('#id_supplier').html(data.html_respon);
            $("#id_supplier").val('').trigger("chosen:updated");
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}

function add_product() {
    $('.html_discount_add').empty();
    // get_unit();
    get_category();
    get_unit_html();
    // get_base_unit();
    save_method = 'add'
    $('#form_product')[0].reset();
    $('.form-group').removeClass('has-error');
    // $('.help-block').empty();
    $('.modal-title').text('Form Produk');
    $('#modal_product').modal('show');
    // $('#modal_product').modal({backdrop:'static'});
}

$(document).on('keyup', '.price_count', function () {
    var main_price = delete_dot_value($('#main_price').val());
    var target = $(this).data('target');
    var price = delete_dot_value($(this).val());
    // console.log(main_price);
    if (main_price == '' || main_price == 0) {
        alert_error('isi harga pokok dulu');
        $(this).val('');
        return false;
    }

    var advantage = price - main_price;
    var persentage_advantage = (advantage / main_price) * 100;
    if (persentage_advantage <= 0) {
        $('#persentage_'+target).val('0');
    } else {
        $('#persentage_'+target).val(persentage_advantage);
    }
    

});

$(document).on('keyup', '.percentage', function () {

    var main_price = delete_dot_value($('#main_price').val());
    var persentage = delete_dot_value($(this).val());
    var target = $(this).data('target');
    // console.log(main_price);
    if (main_price == '' || main_price == 0) {
        alert_error('isi harga pokok dulu');
        $(this).val('');
        return false;
    }

    var advantage = (persentage/100)*main_price;
    var price = parseInt(main_price) + advantage;
    $('[name="'+target+'"]').val(money_function(String(price)));

});

$(document).on('click', '.btn_view_conversion', function () {
    var target = $(this).data('target');
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    $('.modal-title').text('DATA DETAIL KONVERSI');
    // showLoading();
    //defined form
    var formData = new FormData($('#form_product')[0]);
    formData.append('target', target);
    $.ajax({    
        url: url_controller + "show_view_conversion",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                // $('#modal_user').modal('hide');
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error(data.message);
            } 
            $('.btn_view_conversion');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_view_conversion');
            alert_error('something wrong');
            hideLoading();
        }
    });
})


$('.btn_save_product').click(function (e) {
    e.preventDefault();
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('#form_product')[0]);
    $.ajax({
        url: url_controller + "save",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                // $('#modal_user').modal('hide');
                notif_success('data berhasil disimpan!');
                window.location.href = url_controller + 'detail?data=' + data.id_encrypt;
            } else {
                hideLoading();
                $('#modal_product').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    // $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('.notif_' + data.inputerror[i]).text(data.error_string[i]);

                }
            }
            $('.btn_save_product');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            $('.btn_save_product');
            alert_error('something wrong');
        }
    });
})

$('.btn_edit_main').click(function () {
    var id = $(this).data('id');
    $('.modal-title').text('UPDATE DATA');
    $.ajax({
        url: url_controller + "form_edit_main",
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function(data) {
            //if success
            if (data.status) {
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('something wrong');
        }
    });
})

$(document).on('click', '.btn_update_main', function () {
    showLoading();
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form_update_main')[0]);
    formData.append('id', id_current);
    $.ajax({
        url: url_controller + "update_main",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                window.location.reload();
            } else {
                hideLoading();
                $('#modal_product').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    if (data.inputerror[i] == 'qty' || data.inputerror[i] == 'nett_price' || data.inputerror[i] == 'price' || data.inputerror[i] == 'distributor_price' || data.inputerror[i] == 'distributor_nett_price' || data.inputerror[i] == 'main_price' || data.inputerror[i] == 'main_distributor_price') {
                        $('[name="' + data.inputerror[i] + '"]').parent().parent().addClass('has-error');
                        $('.' + data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                        $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                    }
                }
            }
            $('.btn_update_main');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_update_main');
            alert_error('something wrong');
        }

    });
})

$('.btn_add_detail_conversion').click(function () {
    var id = $(this).data('id');
    $('.modal-title').text('TAMBAH DATA KONVERSI');
    $.ajax({
        url: url_controller + "form_add_conversion",
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function(data) {
            //if success
            if (data.status) {
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('something wrong');
        }
    });
})

$(document).on('click', '.btn_save_conversion', function (e) {
    e.preventDefault();
    showLoading();
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form_add_conversion')[0]);
    formData.append('id', id_current);
    $.ajax({
        url: url_controller + "save_additional_conversion",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                window.location.reload();
            } else {
                hideLoading();
                $('#modal_product').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_save_conversion');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_save_conversion');
            alert_error('something wrong');
        }

    });
});


$(document).on('click', '.btn_add_form_conversion', function () {
    var unit_name = $(this).data('name');
    $.ajax({
        url: url_controller + "get_pattern_form_conversion",
        type: "POST",
        dataType: "JSON",
        data:{'name':unit_name},
        success: function(data) {
            // $('.base_name').text(data.base_name);
            $('.cover-conversion-form').append(data.html_respon);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})

$(document).on('click', '.btn_cancel_form', function () {
    $(this).parent().parent().remove();
})

$(document).on('click', '.btn_edit_conversion', function () {
    var id = $(this).data('id');
    $('.modal-title').text("UPDATE DATA");
    $.ajax({
        url: url_controller + "form_edit_conversion",
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function(data) {
            if (data.status) {
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})


$(document).on('click', '.btn_update_conversion', function (e) {
    e.preventDefault();
    showLoading();
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form_add_conversion')[0]);
    formData.append('id', id_current);
    $.ajax({
        url: url_controller + "update_additional_conversion",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                window.location.reload();
            } else {
                hideLoading();
                $('#modal_product').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_update_conversion');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_update_conversion');
            alert_error('something wrong');
        }

    });
})

$(document).on('click', '.btn_del_conversion', function () {
    var id = $(this).data('id');
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,hapus data',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: url_controller+'/delete_conversion',
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function(data){
                    window.location.reload();
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_del_conversion');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

$(document).on('click', '.btn_edit_price', function () {
    var id = $(this).data('id');
    $('.modal-title').text("UPDATE DATA");
    $.ajax({
        url: url_controller + "form_edit_price",
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function(data) {
            if (data.status) {
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})

$(document).on('click', '.btn_update_price', function (e) {
    e.preventDefault();
    showLoading();
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form_update_price')[0]);
    formData.append('id', id_current);
    $.ajax({
        url: url_controller + "update_price",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                window.location.reload();
            } else {
                hideLoading();
                $('#modal_product').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_update_price');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_update_price');
            alert_error('something wrong');
        }

    });
})


$('.btn_add_margin').click(function () {
    var id = $(this).data('id');
    $('.modal-title').text('TAMBAH DATA POTONGAN HARGA');
    $.ajax({
        url: url_controller + "form_add_margin",
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function(data) {
            //if success
            if (data.status) {
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('something wrong');
        }
    });
})

$(document).on('click', '.btn_save_margin', function (e) {
    e.preventDefault();
    showLoading();
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form_add_conversion')[0]);
    formData.append('id', id_current);
    $.ajax({
        url: url_controller + "save_additional_margin",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                window.location.reload();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_save_margin');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_save_margin');
            alert_error('something wrong');
        }

    });
})


$(document).on('click', '.btn_add_form_margin', function () {
    var unit_name = $(this).data('name');
    $.ajax({
        url: url_controller + "get_pattern_form_margin",
        type: "POST",
        dataType: "JSON",
        data:{'name':unit_name},
        success: function(data) {
            // $('.base_name').text(data.base_name);
            $('.cover-conversion-form').append(data.html_respon);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})

$(document).on('click', '.btn_edit_margin', function () {
    var id = $(this).data('id');
    var price = $(this).data('price');
    $('.modal-title').text("UPDATE DATA");
    $.ajax({
        url: url_controller + "form_edit_margin",
        type: "POST",
        dataType: "JSON",
        data:{'id':id,'price':price},
        success: function(data) {
            if (data.status) {
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})


$(document).on('click', '.btn_update_margin', function (e) {
    e.preventDefault();
    showLoading();
    var price = $(this).data('price');
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form_update_margin')[0]);
    formData.append('id', id_current);
    formData.append('price_current', price);
    $.ajax({
        url: url_controller + "update_additional_margin",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                window.location.reload();
            } else {
                hideLoading();
                $('#modal_product').modal('show');
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_update_margin');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_update_margin');
            alert_error('something wrong');
        }

    });
})

$(document).on('click', '.btn_del_margin', function () {
    var id = $(this).data('id');
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,hapus data',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: url_controller+'/delete_margin',
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function(data){
                    window.location.reload();
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_del_conversion');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})


$('.btn_edit_barcode').click(function () {
    var id = $(this).data('id');
    var status      = $(this).data('status');
    $('.modal-title').text("UPDATE DATA");
    $.ajax({
        url: url_controller + "form_edit_barcode",
        type: "POST",
        dataType: "JSON",
        data:{'id':id,'status':status},
        success: function(data) {
            if (data.status) {
                $('.modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            } else {
                alert_error('something wrong');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
})

$(document).on('click', '.btn_update_barcode', function (e) {
    e.preventDefault();
    showLoading();
    var id_current  = $(this).data('id');
    var status      = $(this).data('status');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    // showLoading();
    //defined form
    var formData = new FormData($('.form_update_barcode')[0]);
    formData.append('id', id_current);
    formData.append('status', status);
    $.ajax({
        url: url_controller + "update_barcode",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                window.location.reload();
            } else {
                hideLoading();
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_update_barcode');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_update_barcode');
            alert_error('something wrong');
            hideLoading();
        }

    });
})

function get_unit() {
    var id = $('#unit').val();
    $.ajax({
        url: url_controller + "get_unit/",
        type: "GET",
        dataType: "JSON",
        data:{'id':id},
        success: function(data) {
            // $('.base_name').text(data.base_name);
            $('.unit_name').text('/ ' + data.name);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}

function get_base_unit() {
    var id = $('[name="base_unit"]').val();
    $.ajax({
        url: url_controller + "get_base_unit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            $('.base_unit').text('/ ' + data.name);
            $('.base_name').text(data.name);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}


$(document).on('click', '.btn_delete', function () {
    var id = $(this).data('id');
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,hapus data',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: url_controller+'/delete',
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function (data) {
                    if (data.status) {
                        window.location.href = url_controller;
                    } else {
                        Swal.fire(
                            'GAGAL',
                            'Data Ini Tidak Boleh Dihapus',
                            'error'
                          )
                    }
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_delete');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

//additional function
function number_only(id_name) {
    var qty = $("#" + id_name).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $("#" + id_name).val(clean_word);
}

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
})

// function add_discount(){

//   // var html_discont = $('.html_discount').html();
//   $('.html_discount_add').append('<div classs = "cover_add">'+html_discont+"</div>");
// } 

function add_discount() {
    // $('.modal-title').text('Tambah Keraanjang Stok')
    $.ajax({
        url: url_controller + "get_discount_html/",
        type: "GET",
        dataType: "HTML",
        success: function(data) {
            $('.html_discount_add').append('<div classs = "cover_add">' + data + "</div>");
            get_base_unit();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}

function get_margin_html(id) {
    $('.html_discount_add').empty();
    $.ajax({
        url: url_controller + 'get_margin_html/' + id,
        type: "GET",
        dataType: "HTML",
        success: function(data) {
            $('.html_discount_add').append('<div classs = "cover_add">' + data + "</div>");
            get_base_unit();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}

$('.html_discount_add').on('click', '.clear_html', function() {
    var html_target = $(this).parent().parent();
    html_target.remove();
});


$('.html_discount_add').on('keyup', '.number_type', function() {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});

function show_detail(id) {
    $('.modal-title').text('DETAIL PRODUK');
    $.ajax({
        url: url_controller + 'get_detail_product/' + id,
        type: "GET",
        dataType: "HTML",
        success: function(data) {
            $('.detail-product-html').html(data);
            $('#modal_detail_product').modal('show');
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
        }
    });
}

function delete_dot_value(value) {
    var array_value = value.split('.');
    var count_array = array_value.length;
    payment_value = value;
    for (var i = 0; i < count_array; i++) {
        payment_value = payment_value.replace('.', '');
    };
    return payment_value;
}

//----------------- import -----------------------------------
$(document).on('click', '.btn_import', function (e) {
    e.preventDefault();
    showLoading();
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-import')[0]);
    $.ajax({
        url: url_controller + "do_import_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                notif_success('import berhasil');
                $('.html_respon').html(data.html_respon);
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_import');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_import');
            alert_error('something wrong');
        }

    });
});

$(document).on('click', '.btn_save_import', function (e) {
    e.preventDefault();

    Swal.fire({
        title: 'Data akan Disimpan?',
        text: "data yang disimpan hanya data yang telah terverifikasi",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            showLoading();
            var id_current = $(this).data('id');
            $('.form-group').removeClass('has-error');
            $('.help-block').empty();
            $('#modal_product').modal('hide');
            // showLoading();
            //defined form
            var formData = new FormData($('.form-save-import')[0]);
            $.ajax({
                url: url_controller + "save_import_data",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    if (data.status) {
                        $('.html_respon').html('');
                        Swal.fire(
                            'Berhasil!',
                            data.counter +' Data Telah Disimpan',
                            'success'
                        );
                        $('.form-import')[0].reset();

                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('.' + data.inputerror[i]).parent().addClass('has-error');
                            $('.' + data.inputerror[i]).text(data.error_string[i]);
                        }
                    }
                    $('.btn_save_import');
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $('.btn_save_import');
                    alert_error('something wrong');
                }
            });
        }
    })
});


$(document).on('click', '.btn_search', function (e) {
    e.preventDefault();
    showLoading();
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    $.ajax({
        url: url_controller + "search_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                $('.html_respon').html(data.html_respon);
                $(".pagination").rPage();
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }

    });
});

//pagination 
$(document).on('click', '.page-link', function () {
    var page_number = $(this).data('ci-pagination-page');
    $(this).text('load..');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    formData.append('page', page_number);
    $.ajax({
        url: url_controller + "search_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon').html(data.html_respon);
                notif_success('selesai');
                $(".pagination").rPage();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_search');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_search');
            alert_error('something wrong');
        }

    });
});
// $(document).on('click', '.btn_pagination', function () {
//     $(this).text('load..');
//     var page_number = $(this).data('ci-pagination-page');
//     $('.form-group').removeClass('has-error');
//     $('.help-block').empty();
//     $('#modal_product').modal('hide');
//     // showLoading();
//     //defined form
//     var formData = new FormData($('.form-input')[0]);
//     formData.append('page', page_number);
//     $.ajax({
//         url: url_controller + "search_data",
//         type: "POST",
//         data: formData,
//         contentType: false,
//         processData: false,
//         dataType: "JSON",
//         success: function (data) {
//             if (data.status) {
//                 $('.html_respon').html(data.html_respon);
//                 notif_success('selesai');
//             } else {
//                 for (var i = 0; i < data.inputerror.length; i++) {
//                     $('.' + data.inputerror[i]).parent().addClass('has-error');
//                     $('.' + data.inputerror[i]).text(data.error_string[i]);
//                 }
//             }
//             $('.btn_search');
//         },
//         error: function (jqXHR, textStatus, errorThrown) {
//             $('.btn_search');
//             alert_error('something wrong');
//         }

//     });
    
// });

// $('.money_only').keyup(function() {
//     var new_val = money_function($(this).val());
//     $(this).val(new_val);
// })
$(document).on('keyup', '.money_only', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
})


function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}