<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Receive extends BackendController
{
    var $module_name        = 'receive';
    var $module_directory   = 'receive';
    var $module_js          = ['receive'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "Penerimaan";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function get_code()
    {
        $number_text = 0;
        $db_name = 'tb_receipt';
        $simbol = 'GR';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }


    public function list_data_request()
    {

        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $id_supplier = $this->input->post('id_supplier');


        $array_where = [];
        $array_where_in = [];

        $array_where['tb_request.status'] = 1;

        if ($date_from) {
            $array_where['tb_request.date >='] = $date_from;
        }
        if ($date_to) {
            $array_where['tb_request.date <='] = $date_to;
        }
        if ($id_supplier) {
            $array_where_in['tb_request.id_supplier'] = $id_supplier;
        }


        $array_query = [
            'select' => '
                tb_request.*,
                COUNT(tb_request_has_product.id) AS count_item,
                tb_account_warehouse.name AS warehouse_name,
                tb_account_warehouse.address AS warehouse_address,
                mst_vendor.name AS supplier_name,
                mst_vendor.address AS supplier_address,
            ',
            'from' => 'tb_request',
            'join' => [
                'tb_request_has_product,tb_request.id = tb_request_has_product.id_request,left',
                'tb_account_warehouse,tb_request.id_account_warehouse = tb_account_warehouse.id,left',
                'mst_vendor,tb_request.id_supplier = mst_vendor.id,left',
                'tb_receipt,tb_request.id = tb_receipt.id_request,inner'
            ],
            'group_by' => 'tb_request.id',
            'order_by' => 'tb_request.id, DESC'
        ];

        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }

        $get_data = Modules::run('database/get', $array_query)->result();


        $data_po['data_request'] = $get_data;
        $html_po = $this->load->view('view_search_result', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }

    public function get_request()
    {
        $this->db->select('
            tb_request.*,
            COUNT(tb_request_has_product.id) AS count_item,
            tb_account_warehouse.name AS supplier_name,
            st_user.name AS user_name
            ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $this->db->join('st_user', 'tb_request.created_by = st_user.id', 'left');
        $get_data = $this->db->where(['tb_request.status' => 0, 'tb_request.id_account_warehouse' => 0])->order_by('tb_request.id', 'DESC')->group_by('tb_request.id')->get()->result();
        $data['data_request'] = $get_data;
        $html_respon = $this->load->view('view_list_request', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function add_receive()
    {
        $id = $this->encrypt->decode($this->input->get('data'));

        $this->app_data['vendor'] = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();

        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS warehouse_name,
                            tb_account_warehouse.address AS warehouse_address,
                            mst_vendor.name AS supplier_name,
                            mst_vendor.address AS supplier_address,
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_account_warehouse = tb_account_warehouse.id', 'left');
        $this->db->join('mst_vendor', 'tb_request.id_supplier = mst_vendor.id', 'left');
        $get_data = $this->db->where(['tb_request.id' => $id])->group_by('tb_request.id')->get()->row();

        $this->app_data['data_request'] = $get_data;

        //get detail
        $this->db->select('
            tb_request_has_product.*,
            tb_product.code AS product_code,
            tb_product.name AS product_name,
            tb_product.qty_unit AS qty_unit,
            tb_product.cubic,
            tb_product.long_cm,
            tb_product.width_cm,
            tb_product.height_cm,
            tb_unit.name AS unit_name,
            tb_product_has_conversion.name AS conversion_name,
            tb_product_has_conversion.qty AS qty_conversion
        ');
        $this->db->from('tb_request_has_product');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_request_has_product.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $get_data_detail = $this->db->where(['tb_request_has_product.id_request' => $id])->get()->result();
        $this->app_data['data_detail'] = $get_data_detail;


        $this->app_data['page_title'] = "Tambah Penerimaan";
        $this->app_data['view_file'] = 'add_receive';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }
        // if ($this->input->post('payment') == '') {
        //     $data['error_string'][] = 'harus diisi';
        //     $data['inputerror'][] = 'payment';
        //     $data['status'] = FALSE;
        // }

        // if ($this->input->post('grand_total') == 'NaN') {
        //     $data['error_string'][] = 'belum terisi';
        //     $data['inputerror'][] = 'grand_total';
        //     $data['status'] = FALSE;
        // }

        // if (!empty($this->input->post('grand_total')) && !empty($this->input->post('payment'))) {
        //     $payment = str_replace('.', '', $this->input->post('payment'));
        //     if (!isset($_POST['debt_status'])) {
        //         if ($payment != ceil($this->input->post('grand_total'))) {
        //             $data['error_string'][] = 'pembayaran Harus : Rp.' . number_format($this->input->post('grand_total'), 0, '.', '.');
        //             $data['inputerror'][] = 'payment';
        //             $data['status'] = FALSE;
        //         }
        //     }


        //     if ($payment > ceil($this->input->post('grand_total'))) {
        //         $data['error_string'][] = 'pembayaran Maksimal : Rp.' . number_format($this->input->post('grand_total'), 0, '.', '.');
        //         $data['inputerror'][] = 'payment';
        //         $data['status'] = FALSE;
        //     }
        // }
        // $array_price = $this->input->post('price');
        // $array_price_default = $this->input->post('price_default');
        // $array_qty = $this->input->post('qty');
        // $array_qty_default = $this->input->post('qty_default');

        // foreach ($array_price as $key_price => $value_price) {

        //     if ($array_price[$key_price] == '' || $array_price[$key_price] == 0) {
        //         $data['error_string'][] = 'harus diisi dan tidak boleh 0';
        //         $data['inputerror'][] = 'price_' . $key_price;
        //         $data['status'] = FALSE;
        //     }
        //     // if ($array_qty[$key_price] > $array_qty_default[$key_price]) {
        //     //     $data['error_string'][] = 'maksimal ' . $array_qty_default[$key_price];
        //     //     $data['inputerror'][] = 'qty_' . $key_price;
        //     //     $data['status'] = FALSE;
        //     // }
        //     if ($array_qty[$key_price] == '') {
        //         $data['error_string'][] = 'harus diisi dan tidak boleh 0';
        //         $data['inputerror'][] = 'qty_' . $key_price;
        //         $data['status'] = FALSE;
        //     }
        // }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function preview_receive()
    {
        $this->validate_insert();
        $name = $this->input->post('name');
        $date = $this->input->post('date');
        $note = $this->input->post('note');

        $array_price = $this->input->post('price_receive');
        $array_qty = $this->input->post('qty_receive');
        $hpp_receive = $this->input->post('hpp_receive');

        $id = $this->input->post('id');
        $data['array_price'] = $array_price;
        $data['array_qty'] = $array_qty;
        $data['hpp_receive'] = $hpp_receive;
        $data['html_resume'] = $_POST['html_resume'];

        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS warehouse_name,
                            tb_account_warehouse.address AS warehouse_address,
                            mst_vendor.name AS supplier_name,
                            mst_vendor.address AS supplier_address,
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_account_warehouse = tb_account_warehouse.id', 'left');
        $this->db->join('mst_vendor', 'tb_request.id_supplier = mst_vendor.id', 'left');
        $get_data = $this->db->where(['tb_request.id' => $id])->group_by('tb_request.id')->get()->row();

        $data['data_request'] = $get_data;

        //get detail
        $this->db->select('
            tb_request_has_product.*,
            tb_product.code AS product_code,
            tb_product.name AS product_name,
            tb_product.qty_unit AS qty_unit,
            tb_unit.name AS unit_name,
            tb_product_has_conversion.name AS conversion_name,
            tb_product_has_conversion.qty AS qty_conversion
        ');
        $this->db->from('tb_request_has_product');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_request_has_product.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $get_data_detail = $this->db->where(['tb_request_has_product.id_request' => $id])->get()->result();
        $data['data_detail'] = $get_data_detail;

        $html_respon = $this->load->view('preview_receive', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    private function get_code_stock()
    {
        $number_text = 0;
        $db_name = 'tb_stock';
        $simbol = 'ST';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    private function get_code_debt()
    {
        $number_text = 0;
        $db_name = 'tb_debt';
        $simbol = 'DB';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_debt")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    private function validate_save_receive()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('debt_status')) {

            if ($this->input->post('deadline') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'deadline';
                $data['status'] = FALSE;
            }
        }


        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_receive()
    {
        $this->validate_save_receive();

        $vendor_delivery = $this->input->post('vendor_delivery');
        $invoice = $this->input->post('invoice');
        $due_date = Modules::run('helper/change_date', $this->input->post('due_date'), '-');
        $debt_delivery = $this->input->post('debt_delivery');

        $name = $this->input->post('name');
        $date = Modules::run('helper/change_date', $this->input->post('date'), '-');
        $ongkir_type = $this->input->post('ongkir_type');
        $ongkir = str_replace('.', '', $this->input->post('ongkir'));

        $array_price = $this->input->post('price_receive');
        $array_qty = $this->input->post('qty_receive');
        $hpp_receive = $this->input->post('hpp_receive');
        $total_correction = str_replace('.', '', $this->input->post('total_correction'));
        $id = $this->input->post('id');
        $main_data = Modules::run('database/find', 'tb_request', ['id' => $id])->row();

        //resume data
        $array_json_container = [
            'container_size' => $this->input->post('container_size'),
            'container_cargo' => $this->input->post('container_cargo'),
            'discount' => $this->input->post('discount'),
            'discount' => $this->input->post('discount'),
            'ppn' => $this->input->post('ppn')
        ];

        $code = $this->get_code();
        //get main receipt
        $array_insert_receipt = [
            'code' => $code,
            'id_request' => $id,
            'received_by' => $name,
            'received_date' => $date,
            'transport_price' => $ongkir,
            'transport_type' => $ongkir_type,
            'id_vendor_delivery' => $vendor_delivery,
            'json_hpp_container' => json_encode($array_json_container)
        ];
        Modules::run('database/insert', 'tb_receipt', $array_insert_receipt);

        //insert to debt
        if ($debt_delivery) {
            $data_debt = [
                'invoice' => $invoice,
                'id_vendor' => $vendor_delivery,
                'hutang' => $ongkir,
                'tanggal_hutang' => date('Y-m-d'),
                'tanggal_jatuh_tempo' => $due_date,
                'deskripsi' => 'Hutang Pengiriman Barang GR ' . $code,
            ];
            Modules::run('debt/insert_debt', $data_debt);
        }

        $get_receipt = Modules::run('database/find', 'tb_receipt', ['code' => $code])->row();
        //get datail PO
        $get_detail = Modules::run('database/find', 'tb_request_has_product', ['id_request' => $id])->result();
        $sub_total = 0;
        $subtotal_receive = 0;
        foreach ($get_detail as $item_detail) {

            $qty_receive = isset($array_qty[$item_detail->id]) ? str_replace('.', '', $array_qty[$item_detail->id]) : 0;
            $price_receive = isset($array_price[$item_detail->id]) ? str_replace('.', '', $array_price[$item_detail->id]) : 0;
            $hpp_price = isset($hpp_receive[$item_detail->id]) ? str_replace('.', '', $hpp_receive[$item_detail->id]) : 0;
            $interval = $qty_receive -  $item_detail->qty;

            $new_grandtotal = $price_receive * $item_detail->qty;
            $grand_total_receive = $price_receive * $qty_receive;
            //for main data
            $sub_total += $new_grandtotal;
            $subtotal_receive += $grand_total_receive;

            $array_insert_detail = [
                'id_receive' => $get_receipt->id,
                'id_item_request' => $item_detail->id,
                'qty_request' => $item_detail->qty,
                'price_request' => $item_detail->price,
                'price_receive' => $price_receive,
                'qty_receive' => $qty_receive,
                'hpp' => $hpp_price,
                'grand_total' => $grand_total_receive,
            ];
            Modules::run('database/insert', 'tb_receipt_has_product', $array_insert_detail);
            $get_detail = Modules::run('database/find', 'tb_receipt_has_product', ['id_receive' => $get_receipt->id, 'id_item_request' => $item_detail->id])->row();

            //update detail stock ==> for multiple warehouse apps
            $data_stock = [
                'id_product' => $item_detail->id_product,
                'id_warehouse' => $main_data->id_account_warehouse,
                'stock_qty' => $qty_receive,
                'id_transaction' => $get_detail->id,
                'type_transaction' => 1 // 1 = GOOD RECEIVE
            ];
            Modules::run('stock/insert_update_stock_qty', $data_stock);


            //update stock product ==> for single warehouse
            $get_product = Modules::run('database/find', 'tb_product', ['id' => $item_detail->id_product])->row();
            $new_stock = $get_product->stock + $qty_receive;
            Modules::run('database/update', 'tb_product', ['id' => $get_product->id], ['stock' => $new_stock]);
        }


        //tax
        $ppn_price = 0;
        if ($main_data->ppn > 0) {
            $ppn_price = round($subtotal_receive * ($main_data->ppn / 100));
        }

        $total_receive = $subtotal_receive + $ppn_price;
        $array_update_main_data = [
            'grand_total_product' => $subtotal_receive,
            'tax_price' => $ppn_price,
            'grandtotal_receipt' => $total_receive,
            'grandtotal_correction' => $total_correction
        ];
        Modules::run('database/update', 'tb_receipt', ['id' => $get_receipt->id], $array_update_main_data);
        //update PO
        Modules::run('database/update', 'tb_request', ['id' => $main_data->id], ['status' => 1]);

        echo json_encode(['status' => TRUE, 'id' => urlencode($this->encrypt->encode($get_receipt->id))]);
    }




    //logic for get price FIFO
    private function get_price_receive_product($id_product, $stock)
    {
        $get_data_stock = $this->db->query("
            SELECT
            tb_detail_stock.id,
            tb_stock.id_account_warehouse,
            tb_detail_stock.stock_rest,
            tb_detail_stock.main_price
            FROM tb_detail_stock
            INNER JOIN tb_stock ON tb_detail_stock.id_stock_opname = tb_stock.id
            WHERE tb_detail_stock.stock_rest > 0 AND tb_detail_stock.id_product = '$id_product' AND tb_stock.id_account_warehouse > 0
            ")->result();


        //count_respon
        $temp_stock = $stock;
        $grand_total = 0;
        $array_stock_in = [];
        $array_stock_out = [];
        foreach ($get_data_stock as $item_stock) {

            if ($temp_stock <= 0) {
                continue;
            }

            if ($temp_stock > $item_stock->stock_rest) {
                $grand_total += ($item_stock->stock_rest * $item_stock->main_price);
                //add to stock in
                $stock_in = $temp_stock - $item_stock->stock_rest;
                $array_stock_in[] = [
                    'stock' => $stock_in,
                    'price' => $item_stock->main_price
                ];
                //stock out
                $array_stock_out[] = [
                    'id' => $item_stock->id,
                    'stock_rest' => 0
                ];

                $temp_stock -= $item_stock->stock_rest;
            } else {
                $grand_total += ($temp_stock * $item_stock->main_price);
                $stock_rest = $item_stock->stock_rest - $temp_stock;

                //add to stock in
                $stock_in = $temp_stock;
                $array_stock_in[] = [
                    'stock' => $stock_in,
                    'price' => $item_stock->main_price
                ];
                //stock out
                $array_stock_out[] = [
                    'id' => $item_stock->id,
                    'stock_rest' => $stock_rest
                ];
                $temp_stock = 0;
            }
        }

        $array_respon = [
            'grand_total' => $grand_total,
            'stock_in' => $array_stock_in,
            'stock_out' => $array_stock_out
        ];

        return $array_respon;
    }

    private function insert_to_accountant($code, $id_receipt, $grand_total)
    {
        // print_r($code);
        // print_r($id_receipt);
        // print_r($grand_total);
        // exit;
        $account_reception_store    = json_decode($this->db->where(['field' => 'book_account_reception_store'])->get('tb_setting')->row()->value);
        $status_act = 4;
        $description_receiption = 'pengadaan barang toko, kode penerimaan : ' . $code;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->model->insert(
            'tb_book_account_has_detail',
            [
                'id_book_account' => $account_reception_store->debit,
                'description' => $description_receiption,
                'date' => date('Y-m-d'),
                'debit' => $grand_total,
                'credit' => 0,
                'status_act' => $status_act,
                'id_receipt' => $id_receipt,
                'token' => $token
            ]
        );
        $this->model->insert(
            'tb_book_account_has_detail',
            [
                'id_book_account' => $account_reception_store->credit,
                'description' => $description_receiption,
                'date' => date('Y-m-d'),
                'debit' => 0,
                'credit' => $grand_total,
                'status_act' => $status_act,
                'id_receipt' => $id_receipt,
                'token' => $token
            ]
        );
    }

    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
            tb_receipt.*,
            tb_account_warehouse.name AS suppplier_name,
            COUNT(tb_receipt_has_product.id) AS count_item,
            tb_request.code AS request_code,
            mst_vendor.name AS vendor_delivery,
            warehouse_transfer.name AS warehouse_transfer_name
        ');
        $this->db->from('tb_receipt');
        $this->db->join('tb_receipt_has_product', 'tb_receipt.id = tb_receipt_has_product.id_receive', 'left');
        $this->db->join('tb_request', 'tb_receipt.id_request = tb_request.id', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $this->db->join('tb_account_warehouse AS warehouse_transfer', 'tb_receipt.id_warehouse_transfer = warehouse_transfer.id', 'left');
        $this->db->join('mst_vendor', 'tb_receipt.id_vendor_delivery = mst_vendor.id', 'left');

        $get_data = $this->db->where(['tb_receipt.id' => $id])->group_by('tb_receipt.id')->get()->row();
        $this->app_data['data_receipt'] = $get_data;

        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS warehouse_name,
                            tb_account_warehouse.address AS warehouse_address,
                            mst_vendor.name AS supplier_name,
                            mst_vendor.address AS supplier_address,
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_account_warehouse = tb_account_warehouse.id', 'left');
        $this->db->join('mst_vendor', 'tb_request.id_supplier = mst_vendor.id', 'left');
        $get_request = $this->db->where(['tb_request.id' => $get_data->id_request])->group_by('tb_request.id')->get()->row();
        $this->app_data['data_request'] = $get_request;

        //get detail
        $this->db->select('
            tb_receipt_has_product.*,
            tb_product.code AS product_code,
            tb_product.name AS product_name,
            tb_product.qty_unit AS qty_unit,
            tb_unit.name AS unit_name,
            tb_base_unit.name AS base_unit_name
        ');
        $this->db->from('tb_receipt_has_product');
        $this->db->join('tb_request_has_product', 'tb_request_has_product.id = tb_receipt_has_product.id_item_request', 'left');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_base_unit', 'tb_unit.id_base_unit = tb_base_unit.id', 'left');
        $get_data_detail = $this->db->where(['tb_receipt_has_product.id_receive' => $id])->get()->result();
        $this->app_data['data_detail'] = $get_data_detail;

        $this->app_data['page_title'] = "Detail Penerimaan";
        $this->app_data['view_file'] = 'view_detail';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_form_transfer()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $html_resume_po = $_POST['html_resume_po'];


        $get_receipt = Modules::run('database/find', 'tb_receipt', ['id' => $id])->row();
        $get_request = Modules::run('database/find', 'tb_request', ['id' => $get_receipt->id_request])->row();

        $data['html_resume_po'] = $html_resume_po;
        $data['data_request'] = $get_request;
        $data['data_receipt'] = $get_receipt;

        $data['list_warehouse'] = Modules::run('database/find', 'tb_account_warehouse', ['type' => 1])->result();
        $html_form_transfer = $this->load->view('form_transfer', $data, TRUE);
        echo json_encode(['status' => TRUE, 'html_respon' => $html_form_transfer]);
    }



    public function save_transfer()
    {
        Modules::run('security/is_ajax');
        $id_warehouse_send = $this->input->post('id_warehouse_send');
        $date_send = Modules::run('helper/change_date', $this->input->post('date_send'), '-');
        $id_receive = $this->input->post('id_receive');

        $get_receive = Modules::run('database/find', 'tb_receipt', ['id' => $id_receive])->row();
        $get_request = Modules::run('database/find', 'tb_request', ['id' => $get_receive->id_request])->row();

        $this->db->select('
            tb_receipt_has_product.*,
            tb_product.id AS id_product
        ');
        $this->db->from('tb_receipt_has_product');
        $this->db->join('tb_request_has_product', 'tb_request_has_product.id = tb_receipt_has_product.id_item_request', 'left');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $get_data_detail = $this->db->where(['tb_receipt_has_product.id_receive' => $id_receive])->get()->result();

        //update data
        foreach ($get_data_detail as $item_data) {
            $qty = $this->input->post('qty_receive');
            $id_product = $item_data->id_product;

            //update in old warehouse
            $data_stock = [
                'id_product' => $id_product,
                'id_warehouse' => $get_request->id_account_warehouse,
                'stock_qty' => ($qty * -1), //=>minus
                'id_transaction' => $get_receive->id,
                'type_transaction' => 2 // 2 = TRANSFER
            ];
            Modules::run('stock/insert_update_stock_qty', $data_stock);

            //update in new warehouse
            $data_stock = [
                'id_product' => $id_product,
                'id_warehouse' => $id_warehouse_send,
                'stock_qty' => $qty, //=> plus
                'id_transaction' => $get_receive->id,
                'type_transaction' => 2 // 2 = TRANSFER
            ];
            Modules::run('stock/insert_update_stock_qty', $data_stock);
        }

        //update main data
        $array_update_main_data = [
            'is_transfer' => 1,
            'id_warehouse_transfer' => $id_warehouse_send,
            'date_transfer' => $date_send
        ];
        Modules::run('database/update', 'tb_receipt', ['id' => $id_receive], $array_update_main_data);
        echo json_encode(['status' => TRUE]);
    }

    // public function update_status()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $status = $this->input->post('status');
    //     $array_update = [
    //         'status' => $status
    //     ];
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(['status' => TRUE]);
    // }

    // public function get_edit()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $get_data = $this->model->find(array('id' => $id), 'tb_point')->row_array();
    //     echo json_encode($get_data);
    // }
    // public function update()
    // {
    //     $this->validate_insert();
    //     $id        = $this->input->post('id');
    //     $price     = $this->input->post('price');
    //     $point     = $this->input->post('point');
    //     $note      = $this->input->post('note');
    //     //insert data
    //     $array_update = array(
    //         'min_price' => $price,
    //         'point' => $point,
    //         'note' => $note,
    //         'updated_date' => date('Y-m-d H:i:s'),
    //         'updated_by' => $this->session->userdata('us_id')
    //     );
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
    // public function delete()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $this->model->delete(array('id' => $id), 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
}
