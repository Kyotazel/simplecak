<?php
$btn_payment = '
    <a href="' . Modules::run('helper/create_url', 'request/detail?data=' . urlencode($this->encrypt->encode($data_request->id))) . '" class="btn btn-light btn-rounded font-weight-bold"> Detail Purchase Order <i class="fa fa-arrow-circle-right"></i></a>
';
$btn_gr = ' 
    <a href="' . Modules::run('helper/create_url', 'receive/detail?data=' . urlencode($this->encrypt->encode($data_receipt->id))) . '" class="btn btn-light btn-rounded font-weight-bold"> Detail Good Receive <i class="fa fa-arrow-circle-right"></i></a>
';

$html_note_reject = '';
if ($data_request->status == 2) {
    $html_note_reject = '   
                        <label>Catatan Pembatalan:</label>
                        <div class="p-10 bg-info">
                            <p>
                               ' . $data_request->reject_note . '
                            </p>
                        </div>
                        ';
}

$btn_detail_gr = '<a href="' . Modules::run('helper/create_url', 'receive/detail?data=' . urlencode($this->encrypt->encode($data_request->id))) . '" class="btn btn-light btn-rounded"> Detail GR <i class="fa fa-arrow-right"></i></a>';

$array_status = [
    0 => '<label class="label label-warning">Menunggu Penerimaan</label>',
    1 => '<label class="label label-success">Telah Diterima</label>',
    2 => '<label class="label label-default">Dibatalkan</label>'
];
$array_ongkir_type = [
    1 => 'LOCO',
    2 => 'FRANCO'
];
?>

<div class="row" style="align-items:baseline;">
    <h2 class="mb-3 col-6">
        <span class="badge badge-light tx-20 badge-pill">NOMOR PO : <strong><?= $data_request->code; ?></strong></span>
        &nbsp;&nbsp;
        <span class="badge badge-light tx-20 badge-pill">NOMOR GR : <strong><?= $data_receipt->code; ?></strong></span>
    </h2>
    <div class="col-6 text-right">
        <?= $btn_payment . '&nbsp;' . $btn_gr; ?>
    </div>
</div>
<div class="row" style="align-items:baseline;">
    <div class="col-md-4 row" style="align-items:baseline;">
        <label for="" class="font-weight-bold text-uppercase col-12 m-0"><i class="fa fa-truck"></i> Keterangan PO</label>
        <div class="col-12">
            <table style="width:100%;" class="table-no-border">
                <tr>
                    <td style="width:100px ;">Supplier</td>
                    <td style="width: ;">:</td>
                    <td>
                        <div class="row col-12 border-dashed">
                            <div class="col">
                                <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->supplier_name; ?></b></div>
                                <p class="tx-12">
                                    <?= $data_request->supplier_address; ?>
                                </p>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="width:100px ;">Lokasi Kirim</td>
                    <td style="width: ;">:</td>
                    <td>
                        <div class="row col-12 border-dashed">
                            <div class="col">
                                <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->warehouse_name; ?></b></div>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="fa fa-truck project bg-primary-transparent text-primary "></i>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="col-md-4 ">
        <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Resume Purchase Order</label>
        <div class="row text-right">
            <div class="p-2 border-dashed col-6">
                <small>Sub Total (PO)</small>
                <h4 class="subttotal-po">Rp.<?= number_format($data_request->subtotal, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-6">
                <small>PAJAK PPN (<?= $data_request->ppn; ?>) %</small>
                <h4 class="subttotal-ppn">Rp.<?= number_format($data_request->ppn_price, 0, '.', '.'); ?></h4>
            </div>

            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                <small class="float-left">Tanggal PO : <b> <?= Modules::run('helper/date_indo', $data_request->date, '-'); ?> </b></small>
                &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                <small>Total PO : &nbsp;</small>
                <h4 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_request->grandtotal, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">

                <small>Status PO : &nbsp;</small>
                <h5 class="text-primary m-0 p-0 total_po"><span class="badge badge-pill badge-light"><?= $array_status[$data_request->status]; ?></span></h5>
            </div>
        </div>
    </div>
    <div class="col-md-4 ">
        <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Resume GOOD RECEIVE</label>
        <div class="row text-right">
            <div class="p-2 border-dashed col-6">
                <small>Sub Total (GR) : &nbsp;</small>
                <h4 class=" m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grand_total_product, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-6">
                <small>Pajak PPN : &nbsp;</small>
                <h4 class="m-0 p-0 total_po">Rp.<?= number_format($data_receipt->tax_price, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                <small>Tanggal Terima : <b><?= Modules::run('helper/date_indo', $data_receipt->received_date, '-'); ?></b></small>
                &nbsp;&nbsp;|&nbsp;&nbsp;
                <small>Total GR : &nbsp;</small>
                <h4 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grandtotal_receipt, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                <small>Penyesuaian Total GR : &nbsp;</small>
                <h4 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_receipt->grandtotal_correction, 0, '.', '.'); ?></h4>
            </div>
            <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                <small>Penyesuaian + Ongkir : &nbsp;</small>
                <h4 class="text-primary m-0 p-0 total_po">Rp.<?= number_format(($data_receipt->grandtotal_correction + $data_receipt->transport_price), 0, '.', '.'); ?></h4>
            </div>
        </div>
    </div>
    <div class="col-12 row p-1  mt-1 alert alert-success rounded-50">
        <div class="p-2  col-6 border-right">
            <small><i class="fa fa-truck"></i> Vendor Pengiriman :</small>
            <label class="subttotal-po m-0 font-weight-bold tx-18"><?= $data_receipt->vendor_delivery; ?></label>
        </div>
        <div class="p-2  col-3 border-right">
            <small class=""><i class="fa fa-user"></i> Penerima :</small>
            <label class="subttotal-po m-0 font-weight-bold tx-18"><?= $data_receipt->received_by; ?></label>
        </div>
        <div class="p-2 col-3">
            <small><i class="fa fa-file"></i> Ongkos Kirim : &nbsp;</small>
            <label for="" class=" tx-18 font-weight-bold m-0">
                Rp.<?= number_format($data_receipt->transport_price, 0, '.', '.'); ?>
                <span class="badge badge-pill badge-primary  tx-20"><?= $array_ongkir_type[$data_receipt->transport_type]; ?></span>
            </label>
        </div>
    </div>
</div>