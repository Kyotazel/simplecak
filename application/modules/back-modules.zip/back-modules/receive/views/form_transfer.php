<?php

?>
<form id="form-transfer">
    <div class="row">
        <div class="col-6">
            <?= $html_resume_po; ?>
        </div>
        <div class="col-6 rounded-10 shadow-1 p-3">
            <div class="col-12">
                <h4 class="card-title">FORM TRANSFER</h4>
            </div>
            <div class="form-group col-12">
                <label for="">Gudang Tujuan</label>
                <select name="id_warehouse_send" class="form-control chosen">
                    <?php
                    foreach ($list_warehouse as $item_warehouse) {
                        if ($item_warehouse->id == $data_request->id_account_warehouse) {
                            continue;
                        }
                        echo '
                                <option value="' . $item_warehouse->id . '">' . $item_warehouse->name . '</option>
                            ';
                    }
                    ?>
                </select>
                <span class="help-block text-danger"></span>
            </div>
            <div class="form-group col-12">
                <label for="">Tanggal Transfer</label>
                <input type="text" name="date_send" class="form-control bg-white datepicker" readonly>
                <span class="help-block text-danger"></span>
            </div>
            <div class="col-12">
                <div class="alert alert-outline-warning tx-12" role="alert">
                    <strong>Catatan :</strong> Transaksi ini akan memindahkan stok penerimaan kepada Stok gudang tujuan.
                </div>
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-rounded btn-primary-gradient btn_save_transfer" data-id="<?= $data_receipt->id; ?>">Simpan Data <i class="fa fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
</form>