<?php

$html_note_reject = '';
if ($data_request->status == 2) {
    $html_note_reject = '   
    <label>Catatan Pembatalan:</label>
    <div class="p-10 bg-info">
    <p>
    ' . $data_request->reject_note . '
    </p>
    </div>
    ';
}

$array_status = [
    0 => '<label class="label label-warning">Menunggu Penerimaan</label>',
    1 => '<label class="label label-success">Telah Diterima</label>',
    2 => '<label class="label label-default">Dibatalkan</label>'
];

$get_ppn = Modules::run('helper/get_single_config', 'ppn_tax', ['params' => 1]);
$container_size = Modules::run('helper/get_config', 'container_size');
$container_cargo = Modules::run('helper/get_config', 'container_cargo', true);


?>
<style>
    .datepicker {
        z-index: 1000 !important;
    }
</style>
<form class="form-receive">
    <div class="row">
        <div class="col-8 d-flex">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">DATA Resume PURCHASE ORDER (PO)</h3>
                </div>
                <div class="card-body">
                    <h2 class="mb-3 badge badge-light tx-20 badge-pill">NOMOR PO : <strong><?= $data_request->code; ?></strong></h2>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-truck"></i> Keterangan PO</label>
                            <table style="width:100%;">
                                <tr>
                                    <td style="width:100px ;">Supplier</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="row col-12 border-dashed">
                                            <div class="col">
                                                <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->supplier_name; ?></b></div>
                                                <p class="tx-12">
                                                    <?= $data_request->supplier_address; ?>
                                                </p>
                                            </div>
                                            <div class="col-auto align-self-center ">
                                                <div class="feature mt-0 mb-0">
                                                    <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width:100px ;">Tanggal PO</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                            </div>
                                            <input class="form-control bg-white border-dashed" value="<?= Modules::run('helper/date_indo', $data_request->date, '-'); ?>" name="request_date" readonly placeholder="pilih tanggal" type="text">
                                        </div>
                                        <span class="help-block text-danger notif_request_date"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width:100px ;">Dikirim Tanggal</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                            </div>
                                            <input class="form-control bg-white border-dashed" value="<?= Modules::run('helper/date_indo', $data_request->delivery_date, '-'); ?>" readonly placeholder="pilih tanggal" type="text">
                                        </div>
                                        <span class="help-block text-danger notif_delivery_date"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width:100px ;">Lokasi Kirim</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="row col-12 border-dashed">
                                            <div class="col">
                                                <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->warehouse_name; ?></b></div>
                                            </div>
                                            <div class="col-auto align-self-center ">
                                                <div class="feature mt-0 mb-0">
                                                    <i class="fa fa-truck project bg-primary-transparent text-primary "></i>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6 html_resume">
                            <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Resume Transaksi</label>
                            <div class="row text-right">
                                <div class="p-2 border-dashed col-6">
                                    <small>Sub Total (PO)</small>
                                    <h3 class="subttotal-po">Rp.<?= number_format($data_request->subtotal, 0, '.', '.'); ?></h3>
                                </div>
                                <div class="p-2 border-dashed col-6">
                                    <small>PAJAK PPN (<?= $data_request->ppn; ?>) %</small>
                                    <h3 class="subttotal-ppn" data-ppn="<?= $data_request->ppn; ?>">Rp.<?= number_format($data_request->ppn_price, 0, '.', '.'); ?></h3>
                                </div>

                                <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                                    <small>Total PO : &nbsp;</small>
                                    <h3 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_request->grandtotal, 0, '.', '.'); ?></h3>
                                </div>
                                <div class="p-2 border-dashed col-12  justify-content-end align-items-center">
                                    <small class="d-block">Total PO (Penyesuaian) : &nbsp;</small>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Rp.</span>
                                        </div>
                                        <input class="form-control bg-white font-weight-bold tx-20 text-right money_only" data-qty="2" value="<?= number_format($data_request->grandtotal, 0, '.', '.'); ?>" name="total_correction" type="text">
                                    </div>
                                </div>
                                <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                                    <small>Status PO : &nbsp;</small>
                                    <h5 class="text-primary m-0 p-0 "><span class="badge badge-pill badge-light"><?= $array_status[$data_request->status]; ?></span></h5>
                                </div>
                            </div>

                        </div>
                    </div>
                    <hr>
                    <h2 class=" badge badge-light tx-20 badge-pill">PENGHITUNGAN KONTAINER</h2>
                    <div class="row shadow-2 p-3">
                        <div class="col-md-7">

                            <label for="inputPassword3" class="control-label text-right">Ongkos Kirim</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Rp.</span>
                                </div>
                                <input class="form-control bg-white font-weight-bold tx-20 count_hpp money_only" name="ongkir" type="text">
                            </div>
                            <span class="help-block text-danger"></span>
                        </div>
                        <div class="col-12 mb-2"></div>
                        <div class="col-md-3">
                            <label for="">Ukuran Kontainer</label>
                            <select name="container_size" class="form-control" id="">
                                <?php
                                foreach ($container_size as $key => $value) {
                                    echo '
                                            <option value="' . $key . '">' . $value . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="">Kategori Muatan</label>
                            <select name="container_cargo" class="form-control" id="">
                                <?php

                                foreach ($container_cargo as $item_data) {
                                    echo '
                                            <option data-param="' . $item_data['params'] . '" value="' . $item_data['value'] . '">' . $item_data['label'] . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="">Diskon</label>
                            <div class="input-group">
                                <input class="form-control bg-white count_hpp  money_only" name="discount" type="text">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">%</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label for="">PPN ( <?= $get_ppn['label']; ?> )</label>
                            <div class="main-toggle main-toggle-dark change_ppn" data-value="<?= $get_ppn['value']; ?>"><span></span></div>
                        </div>
                        <div class="col-12 mt-2">
                            <h3 class="p-2 text-center border-dashed text-formula"></h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-4 d-flex">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">INPUT GOOD RECEIVE (GR)</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="inputPassword3" class="control-label text-right">Jenis Ongkir</label>
                        <select name="ongkir_type" class="form-control" id="">
                            <option value="1">LOCO</option>
                            <option value="2">FRANCO</option>
                        </select>
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="control-label text-right">Vendor Pengiriman</label>
                        <select name="vendor_delivery" id="" class="form-control chosen">
                            <?php
                            foreach ($vendor as $item_data) {
                                echo '
                                        <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                    ';
                            }
                            ?>
                        </select>
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="form-group html_debt html_invoice" style="display:none;">
                        <label for="inputPassword3" class="control-label text-right">Invoice Hutang</label>
                        <input type="text" class="form-control" name="invoice">
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="form-group html_debt html_invoice" style="display:none;">
                        <label for="inputPassword3" class="control-label text-right">Tanggal Jatuh Tempo</label>
                        <input type="text" class="form-control bg-white datepicker" readonly name="due_date">
                        <span class="help-block text-danger"></span>
                    </div>

                    <div class="html_debt">
                        <div class="main-toggle main-toggle-dark change_debt"><span></span></div>
                        <small>(*Hidupkan Jika Hutang)</small>
                    </div>


                    <hr>
                    <div class="form-group">
                        <label for="inputPassword3" class="control-label text-right">Diterima Oleh</label>
                        <input type="text" class="form-control" name="name">
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="control-label text-right">Tanggal Penerimaan</label>
                        <input type="text" class="form-control bg-white datepicker" readonly name="date">
                        <span class="help-block text-danger"></span>
                    </div>

                    <div class="form-group text-lg-right">
                        <a href="javascript:void(0)" class="btn btn-rounded btn-primary-gradient btn_save_receive" data-id="<?= $data_request->id; ?>">Simpan Transaksi <i class="fa fa-paper-plane"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="card">
        <div class="card-body">

            <div class="col-md-12 ">
                <div class="text-left mb-10 p-10">
                    <h3>Detail Barang PO <span class="badge badge-light">( Total Item : <?= $data_request->count_item; ?> ITEM )</span></h3>
                </div>
                <table class="table table_detail_request">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Produk</th>
                            <th>Nama Produk</th>
                            <th>Satuan</th>
                            <th>Qty PO</th>
                            <th>Harga PO</th>
                            <th>Harga Terima</th>
                            <th>Qty Terima</th>
                            <th>Selish</th>
                            <th>HPP</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $counter = 0;
                        foreach ($data_detail as $item_detail) {
                            $counter++;
                            if (!empty($item_detail->conversion_name)) {
                                $unit_request = $item_detail->conversion_name . ' / ' . $item_detail->qty_conversion . ' ' . $item_detail->unit_name;
                            } else {
                                $unit_request = $item_detail->unit_name;
                            }
                            $conversion_name = $item_detail->conversion_name ? $item_detail->conversion_name : $item_detail->unit_name;

                            $volume = ($item_detail->long_cm * $item_detail->width_cm * $item_detail->height_cm) / 1000000;

                            echo '
                                    <tr class="item_receive">
                                        <td>' . $counter . '</td>
                                        <td>' . $item_detail->product_code . '</td>
                                        <td>
                                            ' . $item_detail->product_name . '
                                            <small class="d-block text-muted"><i class="fa fa-tv"></i> Hitung : ( ' . $item_detail->long_cm . ' x ' . $item_detail->width_cm . ' x ' . $item_detail->height_cm . ' ) =  Volume : ' . $volume . ' <sup>Cm3</sup></small>
                                        </td>
                                        <td>' . $item_detail->unit_name . '</td>
                                        <td class="qty_po" data-value="' . $item_detail->qty . '">' . $item_detail->qty . ' ' . $conversion_name . '</td>
                                        <td>Rp.' . number_format($item_detail->price, 0, '.', '.') . '</td>
                                        <td>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">Rp.</span>
                                                </div>
                                                <input data-volume="' . $volume . '" data-id="' . $item_detail->id . '" class="form-control bg-white  price_receive money_only" data-qty="' . $item_detail->qty . '" value="' . number_format($item_detail->price, 0, '.', '.') . '" name="price_receive[' . $item_detail->id . ']"  placeholder="pilih tanggal" type="text">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input data-id="' . $item_detail->id . '" data-qty="' . $item_detail->qty . '" class="form-control bg-white  qty_receive number_only" value="' . number_format($item_detail->qty, 0, '.', '.') . '" name="qty_receive[' . $item_detail->id . ']"  placeholder="pilih tanggal" type="text">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1">' . $conversion_name . '</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="qty_interval_' . $item_detail->id . '">0</td>
                                        <td>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">Rp.</span>
                                                </div>
                                                <input class="form-control bg-white  hpp_receive_' . $item_detail->id . ' border-dashed" readonly value="' . number_format($item_detail->price, 0, '.', '.') . '" name="hpp_receive[' . $item_detail->id . ']"  placeholder="pilih tanggal" type="text">
                                            </div>
                                        </td>
                                    </tr>
                                ';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</form>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>

            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>