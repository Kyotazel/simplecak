<div class="table-responsive">
    <table class="table t-shadow table_request" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>GR</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_request as $item_po) {
                $counter++;

                $data['data_request'] = $item_po;
                $this->db->select('
                tb_receipt.*,
                tb_account_warehouse.name AS suppplier_name,
                COUNT(tb_receipt_has_product.id) AS count_item,
                tb_request.code AS request_code,
                mst_vendor.name AS vendor_delivery
                ');
                $this->db->from('tb_receipt');
                $this->db->join('tb_receipt_has_product', 'tb_receipt.id = tb_receipt_has_product.id_receive', 'left');
                $this->db->join('tb_request', 'tb_receipt.id_request = tb_request.id', 'left');
                $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
                $this->db->join('mst_vendor', 'tb_receipt.id_vendor_delivery = mst_vendor.id', 'left');

                $get_data = $this->db->where(['tb_receipt.id_request' => $item_po->id])->group_by('tb_receipt.id')->get()->row();

                $data['data_receipt'] = $get_data;

                $html_detail = $this->load->view('_partials/item_po', $data, TRUE);
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $html_detail . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>