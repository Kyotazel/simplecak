url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';

var save_method;



var save_method;

var table_receive;

var table_reject;

var id_use;

$(document).ready(function () {

    // table_receive = $('.table_receive').DataTable({

    //     "ajax": {

    //         "url": url_controller + "/list_data",

    //         "type": "POST"

    //     }

    // });

    search_data();
    show_formula();

    $('.chosen').chosen();

});





$(document).on('click', '.btn_search_data', function (e) { 

    e.preventDefault();

    search_data();

});



function search_data() {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    var formData = new FormData($('.form-input')[0]);

    $.ajax({
        url: url_controller + "list_data_request",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                $('.html_respon').html(data.html_respon);
                $(document).find('.table_request').DataTable();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });
}



function reload_table(){

     table.ajax.reload(null,false); //reload datatable ajax 

}



$(document).on('click', '.btn_add_receive', function () {

    $('.modal-title').text('TAMBAH DATA');

    $('.btn_add_receive');

    $.ajax({
        url: url_controller + '/get_request',
        type: "POST",
        dataType: "JSON",
        success: function (data) {
            $('.html_respon_modal').html(data.html_respon);
            $('#modal-form').modal('show');
            $('.table_add_request').DataTable();
            $('.btn_add_receive');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_add_receive');
            alert_error('something wrong');
        }
    });//end ajax
});


$(document).on('click', '.btn_transfer_stock', function () { 
    showLoading();
    var id = $(this).data('id');
    var html_resume_po = $('.html_resume_po').html();
    $.ajax({
        url: url_controller + '/get_form_transfer',
        type: "POST",
        data: {
            'id': id,
            'html_resume_po':html_resume_po
        },
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            $('#modal-trasfer').find('.html_respon_modal').html(data.html_respon);
            $(document).find('.chosen').chosen();
            $(document).find('.datepicker').datepicker({
                autoclose: true,
                format: 'dd-mm-yyyy'
            });
            $('#modal-trasfer').modal('show');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_add_receive');
            alert_error('something wrong');
            hideLoading();
        }
    });//end ajax

});

$(document).on('click', '.btn_save_transfer', function (e) { 
    e.preventDefault();


    var id = $(this).data('id');

    swal({
        title: "Apakah anda yakin?",
        text: "Transaksi akan disimpan!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            showLoading();
            $('.form-group').removeClass('has-error');
            $('.help-block').empty();
            var formData = new FormData($(document).find('#form-transfer')[0]);
            formData.append('id_receive', id);
            $.ajax({
                url: url_controller + "save_transfer",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    hideLoading();
                    if(data.status){
                        notif_success('data berhasil disimpan');
                        location.reload();
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    hideLoading();
                    alert_error('something wrong');
                }
            });
        }
    });
    

    
});


// $(document).on('click', '.btn_add_item', function () {

//     var id = $(this).data('id');

//     $(this).parent().parent().remove();

//     $.ajax({

// 	    url: url_controller+'/add_item_product',

//         type: "POST",

//         data:{'id':id},

// 	    dataType :"JSON",

//         success: function (data) {

//             $('.html_no_data').remove();

//             var chek_tr = $('.tr_' + data.id).length;

//             if (chek_tr == 0) {

//                 $('.tbody_item').append(data.html_respon);    

//             }

// 	    },

// 	      error:function(jqXHR, textStatus, errorThrown)

// 	      {

// 	       $('.btn_add_product');

// 	       alert_error('something wrong');

// 	      }

// 	  });//end ajax

// })



// $(document).on('click', '.btn_save_reject', function (e) {

//     e.preventDefault();

//     $(this);

//     var id = $(this).data('id');

//     var note = $('[name="note"]').val();

//     $('.form-group').removeClass('has-error');

// 	$('.help-block').empty();  

//     if (note == '') {

//         $('[name="note"]').next().text('harus di isi');

//         $('[name="note"]').parent().parent().addClass('has-error');

//         $('.btn_save_reject');

//     }else{

//         Swal.fire({

//             title: 'Apakah anda yakin?',

//             text: "Pengadaan ini akan dibatalkan",

//             type: 'warning',

//             showCancelButton: true,

//             confirmButtonColor: '#3085d6',

//             cancelButtonColor: '#d33',

//             confirmButtonText: 'Ya,lanjutkan',

//             cancelButtonText: 'Batal'

//         }).then((result) => {

//             if (result.value) {

//                 $.ajax({

//                     url: url_controller+'/save_reject',

//                     type: "POST",

//                     data: {'id':id,'note':note},

//                     dataType :"JSON",

//                     success: function(data){ 

//                         notif_success('data berhasil dibatalkan');

//                         window.location.href = url_controller;

//                     },

//                     error:function(jqXHR, textStatus, errorThrown)

//                     {

//                         $('.btn_save_reject');

//                         alert_error('something wrong');

//                     }

//                 });//end ajax

//             } else {

//                 $('.btn_save_reject');

//             }

//         })

//     }

// })



// $(document).on('click', '.btn_cancel', function () {

//     $(this).parent().parent().remove();

//     var count_tr = $('.tbody_item').has('tr').length;

//     if (count_tr == 0) {

//         $('.tbody_item').html('<tr class="html_no_data"><td colspan="7" class="text-center"> <div class="bg-empty-data"></div><h3 class="text-center text-muted mb-10">Pilihlah Data Produk Pengadaan Barang</h3></td></tr>');

//     }

// })



// $('.btn_add_product').click(function () {
//     $('.btn_save');
// 	save_method = 'add';
// 	$('.form-group').removeClass('has-error');
//  	$('.help-block').empty();
//     $('.form-input')[0].reset();
// 	$('.modal-title').text('TAMBAH DATA');
// 	$('#modal-form').modal('show');
// })



$('.count_total_price').keyup(function () {
    var counter = parseInt($('.grand_total_price').data('counter'));
    var counter_class = 0;

    var grand_total = 0;

    for (let i = 0; i < counter; i++) {
        counter_class++;
        // if ($('.update_status').prop('checked')) {
        //     var conversion_qty  = parseInt($('.qty_conversion_'+counter_class).val());
        //     var new_main_price = parseInt(delete_dot_value($('.new_main_price_' + counter_class).val()));
        //     var price_use = conversion_qty * new_main_price;
        // }else{

        // }


        var price_use = parseInt(delete_dot_value($('.price_use_' + counter_class).val()));
        qty_use = parseInt(delete_dot_value($('.qty_use_' + counter_class).val()));
        total_current = price_use * qty_use;
        grand_total += total_current;

    }

    // // var transport_price = $('[name="transport_price"]').val() =='' ? String(0) : $('[name="transport_price"]').val();

    // var tax_price = $('[name="tax_price"]').val() =='' ? String(0) : $('[name="tax_price"]').val();

    // // var other_price = $('[name="other_price"]').val() == '' ? String(0) : $('[name="other_price"]').val();

    // var discount = $('[name="discount_price"]').val() == '' ? String(0) : $('[name="discount_price"]').val();

    // // grand_total = grand_total + parseInt(delete_dot_value(transport_price)) + parseInt(delete_dot_value(tax_price)) + parseInt(delete_dot_value(other_price));

    // grand_total = grand_total + parseInt(delete_dot_value(tax_price));

    

    // if (parseInt(delete_dot_value(discount)) > grand_total) {

    //     $('[name="discount_price"]').val(0);

    // } else {

    //     grand_total = grand_total - parseInt(delete_dot_value(discount));

    // }



    $('.grand_total_price').html('Rp.' + money_function(String(grand_total), ''));

    $('[name="grand_total"]').val(grand_total);

});



// $('.update_status').change(function(){

//     $('.count_total_price').keyup();

// });



$(document).on('keyup', '.price_receive', function () {

    count_total();

    count_hpp();

});



var grand_total = 0;

var sub_total = 0;

var ppn_price = 0;

function count_total() {

    sub_total = 0;

    grand_total = 0;

    ppn_price = 0;



    $(document).find('.price_receive').each(function () { 

        var price = $(this).val();

        var qty = parseInt($(this).data('qty'));



        price = parseInt(delete_dot_value(price));

        sub_total += (price * qty);

    });

    var ppn_value = $('.subttotal-ppn').data('ppn');

    if (ppn_value > 0) {

        ppn_price = sub_total * (ppn_value / 100);

    }

    grand_total = ppn_price + sub_total;

    $('.subttotal-po').text('Rp.' + money_function(sub_total.toString()));

    $('.subttotal-ppn').text('Rp.' + money_function(ppn_price.toString()));

    $('.total_po').text('Rp.' + money_function(grand_total.toString()));
    $('[name="total_correction"]').val(money_function(grand_total.toString()));

}



$(document).on('keyup', '.qty_receive', function () { 

    var value = $(this).val();

    var qty_default = $(this).data('qty');

    var id = $(this).data('id');

    var interval = parseInt(value) - parseInt(qty_default);

    $('.qty_interval_' + id).text(interval);

    count_hpp();

});



function count_hpp() {
    var ongkir = delete_dot_value($('[name="ongkir"]').val());
    var type = $('[name="ongkir_type"]').val();


    total_qty = 0;
    $('.qty_receive').each(function () { 
        total_qty += parseInt($(this).val());
    });
    
    var ongkir_per_item = parseInt(ongkir) > 0 ? (ongkir / total_qty) : 0;
    var discount = parseInt(delete_dot_value($('[name="discount"]').val()));
    var ppn = $('.change_ppn').hasClass('on') ? $('.change_ppn').data('value') : 0;
    var container_cargo = $('[name="container_cargo"]').val();

    console.log(ppn);


    $('.price_receive').each(function () {

        var volume = parseFloat($(this).data('volume'));
        id = $(this).data('id');
        var new_price = parseInt(delete_dot_value($(this).val()));
        var fix_price = new_price;
        //discount price
        var discount_price = 0;
        if (discount > 0) {
            discount_price = new_price * (discount / 100);
        }
        //value price
        fix_price = new_price - discount_price;
        //ppn price
        if (ppn > 0) {
            fix_price = fix_price * ((100 + ppn) / 100);
        }

        console.log(fix_price);


        var ongkir_price = 0;
        if (parseInt(type) == 1) {
            if (container_cargo == 1) {
                // FCL
                ongkir_price = (parseInt(ongkir) / 30) * volume;
            }
            if (container_cargo == 2) {
                //LCL
                ongkir_price = Math.round(parseInt(ongkir) * volume);
            }
        }

        var hpp_price = Math.round(Math.round(ongkir_price) + fix_price);

        console.log('hpp : ' + hpp_price);

        $('.hpp_receive_' + id).val(money_function(hpp_price.toString())); 
    });
}

$('[name="container_cargo"]').change(function () {
    show_formula();
    count_hpp();
});

function show_formula() {
    var formula_text = $('[name="container_cargo"]').find('option:selected').data('param');
    $('.text-formula').text(formula_text);
}

$(document).on('keyup', '.count_hpp', function () { 
    count_hpp();
});

$('[name="ongkir_type"]').change(function () { 
    count_hpp();
});

$('.change_ppn').click(function () {
    $(this).toggleClass('on');
    count_hpp();
});



$('.btn_save_receive').click(function (e) {

    e.preventDefault();

    var id = $(this).data('id');

    $(this);

    $('.form-group').removeClass('has-error');

    $('.help-block').empty();

    $('.modal-title').text('KOREKSI KEMBALI');

    //defined form
    var html_resume = $(document).find('.html_resume').html();
    var formData = new FormData($('.form-receive')[0]);
    var ppn = $('.change_ppn').hasClass('on') ? $('.change_ppn').data('value') : 0;

    formData.append('html_resume', html_resume);
    formData.append('id', id);
    formData.append('ppn', ppn);

    var url;

    $.ajax({

        url: url_controller + '/preview_receive',

        type: "POST",

        data: formData,

        contentType: false,

        processData: false,

        dataType: "JSON",

        success: function (data) {

            if (data.status) {

                $('.html_respon_modal').html(data.html_respon);

                $('#modal-form').modal('show');

                $('.datepicker_today').datepicker({

                    autoclose: true,

                    format: 'dd-mm-yyyy',

                    startDate: new Date()

                });

                // notif_success('data berhasil disimpan');

                // window.location.href = url_controller+'/detail?data='+data.id

            } else {

                for (var i = 0; i < data.inputerror.length; i++) {

                    if (data.inputerror[i] == 'payment' || data.inputerror[i] == 'grand_total') {

                        $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');

                        if (data.inputerror[i] == 'grand_total') {

                            $('.' + data.inputerror[i]).text(data.error_string[i]);

                        } else {

                            $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);

                        }

                    

                    } else {

                        $('[name="' + data.inputerror[i] + '"]').parent().parent().addClass('has-error');

                        $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);

                        //qty tr

                        $('.' + data.inputerror[i]).text(data.error_string[i]);

                    }

	            

                    if (data.inputerror[i] == 'qty_product') {

                        alert_error('data produk belum dipilih');

                    }

                }

            }

            $('.btn_save_receive');

        },

        error: function (jqXHR, textStatus, errorThrown) {

            $('.btn_save_receive');

            alert_error('something wrong');

        }

    });//end ajax

});



$(document).on('click', '.btn_save', function (e) {

    e.preventDefault();

    var id = $(this).data('id');

    $(this);

    $('.form-group').removeClass('has-error');

    $('.help-block').empty();

    //defined form
    var ppn = $('.change_ppn').hasClass('on') ? $('.change_ppn').data('value') : 0;
    var formData = new FormData($('.form-receive')[0]);
    var debt_delivery = 0;
    if ($('.change_debt').hasClass('on')) {
        debt_delivery = 1;
    }


    formData.append('id', id);
    formData.append('debt_delivery', debt_delivery);
    formData.append('ppn', ppn);



    swal({

        title: "Apakah anda yakin?",

        text: "data akan Disimpan!",

        type: "warning",

        showCancelButton: true,

        confirmButtonClass: "btn-danger",

        confirmButtonText: "Ya , Lanjutkan",

        cancelButtonText: "Batal",

        closeOnConfirm: true,

        closeOnCancel: true

    },

        function (isConfirm) {

            if (isConfirm) {

                showLoading();

                $.ajax({

                    url: url_controller + '/save_receive',

                    type: "POST",

                    data: formData,

                    contentType: false,

                    processData: false,

                    dataType: "JSON",

                    success: function (data) {

                        hideLoading();

                        if (data.status) {

                            // $('.html_respon_modal').html(data.html_respon);

                            $('#modal-form').modal('hide');

                            notif_success('data berhasil disimpan');

                            window.location.href = url_controller + '/detail?data=' + data.id

                        } else {

                            for (var i = 0; i < data.inputerror.length; i++) {

                                $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');

                                $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);

                                //qty tr

                                $('.' + data.inputerror[i]).text(data.error_string[i]);

        

                                if (data.inputerror[i] == 'qty_product') {

                                    alert_error('data produk belum dipilih');

                                }

                            }

                        }

                        $('.btn_save');

                    },

                    error: function (jqXHR, textStatus, errorThrown) {

                        hideLoading();

                        alert_error('something wrong');

                    }

                });//end ajax

            }

        });







});



$(document).on("change", ".checkbox_status", function () {

    var id = $(this).val();

    if ($(this).prop('checked')) {

        status_active = 1;

    }else{

        status_active = 0;

    }

    $.ajax({

        url: url_controller+'/update_status',

        type: "POST",

        data: {'status':status_active,'id':id},

        dataType :"JSON",

        success: function(data){

                notif_success('status berhasil diupdate');

        },

        error:function(jqXHR, textStatus, errorThrown)

        {

            $('.btn_save');

            alert_error('something wrong');

        }

    });//end ajax

});



$(document).on('click', '.btn_edit', function () {

    var id = $(this).data('id');

    $('.modal-title').text('UPDATE DATA');

    $('.form-input')[0].reset();

	save_method = 'update';

	var PostData = {'id':id};

	$.ajax({

	    url: url_controller+'/get_edit',

	    type: "POST",

	    data: PostData,

	    dataType :"JSON",

        success: function (data) {

            id_use = data.id;  

            $('[name="price"]').val(data.min_price);

            $('[name="point"]').val(data.point);

            $('[name="note"]').val(data.note);

	      	$('#modal-form').modal('show'); 

	        $('.btn_save');

	    },

	      error:function(jqXHR, textStatus, errorThrown)

	      {

	       $('.btn_save');

	       alert_error('something wrong');

	      }

	  });//end ajax

});



$(document).on('click', '.btn_remove', function () {

    var id = $(this).data('id');

    Swal.fire({

        title: 'Apakah anda yakin?',

        text: "data ini akan dihapus",

        type: 'warning',

        showCancelButton: true,

        confirmButtonColor: '#3085d6',

        cancelButtonColor: '#d33',

        confirmButtonText: 'Ya,hapus data',

        cancelButtonText: 'Batal'

    }).then((result) => {

        if (result.value) {

            $.ajax({

                url: url_controller + '/delete',

                type: "POST",

                data: { 'id': id },

                dataType: "JSON",

                success: function (data) {

                    $('#modal-form').modal('hide');

                    notif_success('data berhasil dihapus');

                    reload_table();

                    $('.btn_remove');

                },
                error: function (jqXHR, textStatus, errorThrown) {

                    $('.btn_remove');

                    alert_error('something wrong');

                }

            });//end ajax

        }

    })

});


$(document).on('change', '[name="ongkir_type"]', function () { 
    var value = $(this).val();
    if (value == 2) {
        $('.html_debt').hide();
    } else {
        $('.html_debt').show();
    }

    if ($('.change_debt').hasClass('on')) {
        $('.html_invoice').show();
    } else {
        $('.html_invoice').hide();
    }
});

$(document).on('click', '.change_debt', function () {
    
    $(this).toggleClass('on');
    if ($('.change_debt').hasClass('on')) {
        $('.html_invoice').show();
    } else {
        $('.html_invoice').hide();
    }
});



$(document).on('keyup', '.number_only', function () {

    var qty = $(this).val();

    var clean_word = qty.replace(/[^,\d]/g, '');

    $(this).val(clean_word);

})



$(document).on('keyup', '.money_only', function () {

    var qty = $(this).val();

    var clean_word = qty.replace(/[^,\d]/g, '');

    var money = money_function(qty, '');

    $(this).val(money);

})



function money_function(angka, prefix) {

    

    var number_string = angka.replace(/[^,\d]/g, '').toString(),

        split = number_string.split(','),

        sisa = split[0].length % 3,

        rupiah = split[0].substr(0, sisa),

        ribuan = split[0].substr(sisa).match(/\d{3}/gi);



    if (ribuan) {

        separator = sisa ? '.' : '';

        rupiah += separator + ribuan.join('.');

    }



    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;

    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');

    return rupiah;

}



function to_money(angka, prefix) {

    

    var number_string = angka,

        split = number_string.split(','),

        sisa = split[0].length % 3,

        rupiah = split[0].substr(0, sisa),

        ribuan = split[0].substr(sisa).match(/\d{3}/gi);



    if (ribuan) {

        separator = sisa ? '.' : '';

        rupiah += separator + ribuan.join('.');

    }



    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;

    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');

    return rupiah;

}



function delete_dot_value(value) {

    var array_value = value.split('.');

    var count_array = array_value.length;

    payment_value = value;

    for (var i = 0; i < count_array; i++) {

        payment_value = payment_value.replace('.', '');

    };

    return payment_value;

}



$(document).on('keyup', '.number_only', function () {

    var qty = $(this).val();

    var clean_word = qty.replace(/[^,\d]/g, '');

    $(this).val(clean_word);

});





// function money_function(angka, prefix) {

//     var number_string = angka.replace(/[^,\d]/g, '').toString(),

//     split = number_string.split(','),

//     sisa = split[0].length % 3,

//     rupiah = split[0].substr(0, sisa),

//     ribuan = split[0].substr(sisa).match(/\d{3}/gi);



// if (ribuan) {

//     separator = sisa ? '.' : '';

//     rupiah += separator + ribuan.join('.');

// }



// rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;

// return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');

// }

