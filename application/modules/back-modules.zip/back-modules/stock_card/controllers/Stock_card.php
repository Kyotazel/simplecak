<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stock_card extends BackendController
{
    var $module_name        = 'stock_card';
    var $module_directory   = 'stock_card';
    var $module_js          = ['stock_card', 'print'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        $this->app_data['status_po'] = Modules::run('database/find', 'app_module_setting', ['field' => 'status_po'])->result();

        $this->app_data['page_title'] = "Kartu Stok";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function get_code()
    {
        $number_text = 0;
        $simbol = 'STO';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_request")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_stock_opname WHERE id IN(SELECT MAX(id) FROM tb_stock_opname)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 3, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function validate_list_data_request()
    {

        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $barcode = $this->input->post('barcode');

        if ($barcode == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'barcode';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function list_data_request()
    {
        $this->validate_list_data_request();

        $warehouse = $this->input->post('warehouse');
        $barcode = $this->input->post('barcode');
        $get_product = Modules::run('database/find', 'tb_product', ['code' => $barcode])->row();

        $array_query = [
            'select' => 'tb_product_has_card.*',
            'from' => 'tb_product_has_card',
            'where' => [
                'id_product' => $get_product->id,
                'id_warehouse' => $warehouse
            ]
        ];
        $get_data = Modules::run('database/get', $array_query)->result();
        $data_po['data_product'] = $get_product;

        $data_po['data_opname'] = $get_data;
        $html_po = $this->load->view('view_search_result', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }


    public function add()
    {
        $this->app_data['option_supplier'] = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        $this->app_data['option_warehouse'] = Modules::run('database/find', 'tb_account_warehouse', ['type' => 1])->result();
        $this->app_data['tax_ppn'] = Modules::run('helper/get_setting', 'ppn_tax')->value;
        $this->app_data['code_po'] = $this->get_code();

        $this->app_data['page_title'] = "Tambah Data Stock Opname";
        $this->app_data['view_file'] = 'form_add_so';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_supplier()
    {
        Modules::run('security/is_ajax');
        $get_supplier = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        $data['data_supplier'] = $get_supplier;
        $html_respon = $this->load->view('list_supplier', $data, TRUE);
        echo json_encode(['html_respon' => $html_respon, 'status' => TRUE]);
    }

    public function get_current_supplier()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_supplier = Modules::run('database/find', 'mst_vendor', ['id' => $id])->row();
        $html_respon = '
            <div class="row col-12 border-dashed">
                <div class="col">
                    <div class=" mt-2 mb-2 text-primary"><b>' . $get_supplier->name . '</b></div>
                    <p class="tx-12">' . $get_supplier->address . '</p>
                </div>
                <div class="col-auto align-self-center ">
                    <div class="feature mt-0 mb-0">
                        <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                    </div>
                </div>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }


    public function get_product()
    {
        $this->db->select('
                            tb_product.id ,
                            tb_product.code,
                            tb_product.name,
                            tb_product.stock,
                            tb_product.qty_unit,
                            tb_product.main_price,
                            tb_product.main_unit_price,
                            tb_unit.name AS unit_name,
                            tb_base_unit.name AS base_unit_name
                        ');
        $this->db->from('tb_product');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_base_unit', 'tb_unit.id_base_unit = tb_base_unit.id', 'left');
        // $this->db->where(['tb_product.status' => TRUE]);
        $get_data_product = $this->db->order_by('tb_product.name')->get()->result();
        $data['data_product'] = $get_data_product;
        $html_respon = $this->load->view($this->location . 'view_list_product', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function get_product_auto()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                                                    a.id,
                                                    a.code, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
			 									    where a.name like '%$term%' LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->code . ' - ' . $data_product->name,
                        'id' => $data_product->id,
                        'code' => $data_product->code,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_barcode_choosen()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                                                    a.id,
                                                    a.code, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
			 									    where a.code like '%$term%' LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->code . ' - ' . $data_product->name,
                        'code' => $data_product->code,
                        'id' => $data_product->id,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_unit_request()
    {
        $id = $this->input->post('id');
        $get_data_current = $this->db->where(['id' => $id])->get('tb_product')->row();
        $data_unit = $this->db->where(['id' => $get_data_current->id_unit])->get('tb_unit')->row();
        //get other conversion
        $get_all_conversion = $this->db->where(['id_product' => $id])->order_by('qty')->get('tb_product_has_conversion')->result();
        $array_value = [
            'id' => 0,
            'name' => $data_unit->name,
            'qty' => 1
        ];
        $html_option = '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $data_unit->name . '</option>';
        foreach ($get_all_conversion as $item_conversion) {
            $array_value = [
                'id' => $item_conversion->id,
                'name' => $item_conversion->name,
                'qty' => $item_conversion->qty
            ];
            $html_option .= '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $item_conversion->name . '</option>';
        }

        $array_respon = [
            'html_respon' => $html_option,
            'status' => TRUE,
            'data_product' => $this->encrypt->encode(json_encode($get_data_current)),
            'stock_warehouse' => $get_data_current->stock_warehouse
        ];
        echo json_encode($array_respon);
    }


    public function add_item_product()
    {
        //     $id = $this->encrypt->decode($this->input->post('id'));
        $get_data_product = json_decode($this->encrypt->decode($this->input->post('data_product')));
        $unit         = json_decode($this->encrypt->decode($this->input->post('unit')));
        $qty           = $this->input->post('qty');
        $id_stock_opname = $this->input->post('id_stock_opname');
        $id_warehouse = $this->input->post('id_warehouse');

        $data_unit = $this->db->where(['id' => $get_data_product->id_unit])->get('tb_unit')->row();
        //get availabel stock
        $get_avail_stock = Modules::run('database/find', 'tb_stock_opname_has_product', ['id_stock_opname' => $id_stock_opname, 'id_product' => $get_data_product->id])->row();
        if (!empty($get_avail_stock)) {

            //upadate row
            $new_qty    = $qty + $get_avail_stock->qty_stock;
            $new_margin = $new_qty - $get_avail_stock->qty_system;
            Modules::run('database/update', 'tb_stock_opname_has_product', ['id' => $get_avail_stock->id], ['qty_stock' => $new_qty, 'qty_margin' => $new_margin]);
        } else {
            //new row
            $get_stock_system = Modules::run('database/find', 'tb_product_has_stock', ['id_product' => $get_data_product->id, 'id_warehouse' => $id_warehouse])->row();
            $stock_system = isset($get_stock_system->stock_qty) ? $get_stock_system->stock_qty : 0;
            $array_insert = [
                'id_stock_opname' => $id_stock_opname,
                'id_product' => $get_data_product->id,
                'qty_system' => $stock_system,
                'qty_stock' => $qty,
                'qty_margin' => ($qty - $stock_system)
            ];
            Modules::run('database/insert', 'tb_stock_opname_has_product', $array_insert);
        }

        $array_respon = [
            'id' => $get_data_product->id,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function detail_product_opname()
    {
        Modules::run('security/is_ajax');
        $id_stock_opname = $this->input->post('id_stock_opname');
        $main_data = Modules::run('database/find', 'tb_stock_opname', ['id' => $id_stock_opname])->row();

        $array_query = [
            'select' => '
                tb_stock_opname_has_product.*,
                tb_product.code AS product_code,
                tb_product.name AS product_name,
                tb_unit.name AS unit_name
            ',
            'from' => 'tb_stock_opname_has_product',
            'join' => [
                'tb_product, tb_stock_opname_has_product.id_product = tb_product.id , left',
                'tb_unit,tb_product.id_unit = tb_unit.id,left'

            ],
            'where' => ['tb_stock_opname_has_product.id_stock_opname' => $id_stock_opname],
            'order_by' => 'id, DESC'
        ];

        $get_data = Modules::run('database/get', $array_query)->result();

        $no = 0;
        $data = [];
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $btn_delete     = Modules::run('security/delete_access', ' 
                <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-danger btn_delete_item"><i class="las la-trash"></i> </a>
            ');

            if ($main_data->status != 1) {
                $btn_delete = '';
            }

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->product_code;
            $row[] = $data_table->product_name;
            $row[] = $data_table->unit_name;
            $row[] = $data_table->qty_system;
            $row[] = $data_table->qty_stock;
            $row[] = $data_table->qty_margin;
            $row[] = $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    private function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('warehouse') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'warehouse';
            $data['status'] = FALSE;
        }

        if ($this->input->post('request_date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'request_date';
            $data['status'] = FALSE;
        }

        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();

        $code = $this->get_code();
        $name   = $this->input->post('name');
        $note   = $this->input->post('description');

        $request_date = Modules::run('helper/change_date', $this->input->post('request_date'), '-');
        $warehouse = $this->input->post('warehouse');

        //save to database 
        $array_insert = [
            'code' => $code,
            'id_warehouse' => $warehouse,
            'date' => $request_date,
            'name' => $name,
            'note' => $note,
            'status' => 0,
            'created_by' => $this->session->userdata('us_id')
        ];
        $this->model->insert('tb_stock_opname', $array_insert);
        $get_data = Modules::run('database/find', 'tb_stock_opname', ['code' => $code])->row();

        $array_respon = [
            'status' => TRUE,
            'id' => urlencode($this->encrypt->encode($get_data->id))
        ];
        echo json_encode($array_respon);
    }

    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));

        $array_query = [
            'select' => '
                tb_stock_opname.*,
                tb_account_warehouse.name AS warehouse_name
            ',
            'from' => 'tb_stock_opname',
            'join' => [
                'tb_account_warehouse, tb_stock_opname.id_warehouse = tb_account_warehouse.id, left'
            ],
            'where' => [
                'tb_stock_opname.id' => $id
            ]
        ];
        $get_data = Modules::run('database/get', $array_query)->row();

        $this->app_data['data_detail'] = $get_data;

        $this->app_data['page_title'] = "Detail Pengadaan";
        $this->app_data['view_file'] = 'detail_stock_opname';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function update_status()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $status = $this->input->post('status');

        Modules::run('database/update', 'tb_stock_opname', ['id' => $id], ['status' => $status, 'starting_time' => date('Y-m-d H:i:s')]);
        echo json_encode(['status' => TRUE]);
    }

    public function delete_item()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        Modules::run('database/delete', 'tb_stock_opname_has_product', ['id' => $id]);
        echo json_encode(['status' => TRUE]);
    }

    public function preview_result()
    {
        Modules::run('security/is_ajax');

        $id_stock_opname = $this->input->post('id');
        $array_query = [
            'select' => '
                tb_stock_opname_has_product.*,
                tb_product.code AS product_code,
                tb_product.name AS product_name,
                tb_unit.name AS unit_name
            ',
            'from' => 'tb_stock_opname_has_product',
            'join' => [
                'tb_product, tb_stock_opname_has_product.id_product = tb_product.id , left',
                'tb_unit,tb_product.id_unit = tb_unit.id,left'

            ],
            'where' => ['tb_stock_opname_has_product.id_stock_opname' => $id_stock_opname],
            'order_by' => 'id, DESC'
        ];

        $get_data = Modules::run('database/get', $array_query)->result();
        $data['detail_opname'] = $get_data;
        $html_respon = $this->load->view('preview_detail_opaname', $data, TRUE);
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function update_stock()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_main_data = Modules::run('database/find', 'tb_stock_opname', ['id' => $id])->row();
        $get_all = Modules::run('database/find', 'tb_stock_opname_has_product', ['id_stock_opname' => $id])->result();


        foreach ($get_all as $item_opname) {
            //update in new warehouse
            $data_stock = [
                'id_product' => $item_opname->id_product,
                'id_warehouse' => $get_main_data->id_warehouse,
                'stock_qty' => $item_opname->qty_stock, //=> plus
                'id_transaction' => $get_main_data->id,
                'type_transaction' => 3 // 3 = opname
            ];
            Modules::run('stock/insert_update_stock_qty', $data_stock);
        }

        Modules::run('database/update', 'tb_stock_opname', ['id' => $id], ['ending_time' => date('Y-m-d H:i:s'), 'status' => 2]);
        echo json_encode(['status' => TRUE]);
    }


    public function cancel()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_supplier.name AS supplier_name
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_supplier', 'tb_request.id_supplier = tb_supplier.id', 'left');
        $get_data = $this->db->where(['tb_request.id' => $id])->group_by('tb_request.id')->get()->row();
        $this->app_data['data_request'] = $get_data;
        //get detail
        $this->db->select('
                            tb_request_has_product.*,
                            tb_product.code AS product_code,
                            tb_product.name AS product_name,
                            tb_product.qty_unit AS qty_unit,
                            tb_unit.name AS unit_name,
                            tb_product_has_conversion.name AS conversion_name,
                            tb_product_has_conversion.qty AS conversion_qty
                        ');
        $this->db->from('tb_request_has_product');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_request_has_product.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $get_data_detail = $this->db->where(['tb_request_has_product.id_request' => $id])->get()->result();
        $this->app_data['data_detail'] = $get_data_detail;

        $this->app_data['page_title'] = "Batalkan Pengadaan";
        $this->app_data['view_file'] = 'form_cancel';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function save_reject()
    {
        $id     = $this->input->post('id');
        $note   = $this->input->post('note');
        $array_update = [
            'status' => 2,
            'reject_note' => $note
        ];
        Modules::run('database/update', 'tb_request', ['id' => $id], $array_update);
        echo json_encode(['status' => TRUE]);
    }
    // public function get_edit()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $get_data = $this->model->find(array('id' => $id), 'tb_point')->row_array();
    //     echo json_encode($get_data);
    // }
    // public function update()
    // {
    //     $this->validate_insert();
    //     $id        = $this->input->post('id');
    //     $price     = $this->input->post('price');
    //     $point     = $this->input->post('point');
    //     $note      = $this->input->post('note');
    //     //insert data
    //     $array_update = array(
    //         'min_price' => $price,
    //         'point' => $point,
    //         'note' => $note,
    //         'updated_date' => date('Y-m-d H:i:s'),
    //         'updated_by' => $this->session->userdata('us_id')
    //     );
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
    // public function delete()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $this->model->delete(array('id' => $id), 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
}
