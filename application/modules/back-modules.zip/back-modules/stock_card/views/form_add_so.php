<style>
    .datepicker {
        z-index: 1000 !important;
    }
</style>
<form class="form-input">

    <div class="row">
        <div class="col-12">
            <h2>Form Tambah Stock Opaname</h2>
        </div>
        <div class="col-12 d-flex">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">Keterangan Stock Opname</h3>
                </div>
                <div class="card-body">
                    <h2 class="mb-3 badge badge-light tx-20 badge-pill">NOMOR TRANSAKSI : <strong><?= $code_po; ?></strong></h2>
                    <div class="row">
                        <div class="col-md-5">
                            <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Tanggal & Gudang</label>
                            <table style="width:100%;">
                                <tr>
                                    <td style="width:150px ;">Tanggal Stok Opaname</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                            </div>
                                            <input class="form-control bg-white datepicker" name="request_date" readonly placeholder="pilih tanggal" type="text">
                                        </div>
                                        <span class="help-block text-danger notif_request_date"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Gudang Stock Opaname</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <select name="warehouse" class="form-control chosen" id="">
                                            <?php
                                            foreach ($option_warehouse as $item_data) {
                                                echo '
                                                        <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                                    ';
                                            }
                                            ?>
                                        </select>
                                        <span class="help-block text-danger notif_warehouse"></span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6 ">
                            <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Keterangan</label>
                            <div class="row ">
                                <div class=" col-12 form-group">
                                    <label>Judul Stock Opaname</label>
                                    <input class="form-control" name="name">
                                    <span class="text-danger notif_name help-block"></span>
                                </div>
                                <div class=" col-12 form-group">
                                    <label>Deskripsi</label>
                                    <textarea name="description" class="form-control" rows="5"></textarea>
                                    <span class="text-danger notif_description help-block"></span>
                                </div>

                                <div class="col-12 text-right mt-2">
                                    <a href="jacascript:void(0)" class="btn btn-rounded btn-primary-gradient btn_save">Simpan Data <i class="fa fa-paper-plane"></i> </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</form>



<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>