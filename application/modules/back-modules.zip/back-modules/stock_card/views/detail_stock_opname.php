<?php
$status_stock_opaname = Modules::run('helper/get_config', 'status_stock_opaname');
$status_current = isset($status_stock_opaname[$data_detail->status]) ? $status_stock_opaname[$data_detail->status] : '';
$btn_start = Modules::run('security/create_access', ' <a href="javascript:void(0)" class="btn btn-warning-gradient btn-rounded font-weight-bold btn_start_opname" data-id="' . $data_detail->id . '"><i class="fa fa-paper-plane"></i> Mulai Stok Opname</a> ');

?>
<style>
    .datepicker {
        z-index: 1000 !important;
    }
</style>


<div class="row">
    <div class="col-12 d-flex">
        <div class="card" style="width:100% ;">
            <div class="card-header bg-primary-gradient">
                <h3 class="card-title text-white">Detail Stock Opname</h3>
            </div>
            <div class="card-body">
                <h2 class="mb-3 badge badge-light tx-20 badge-pill">NOMOR TRANSAKSI : <strong><?= $data_detail->code; ?></strong></h2>
                <div class="row">
                    <div class="col-md-5">
                        <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Tanggal & Gudang</label>
                        <table style="width:100%;">
                            <tr>
                                <td style="width:200px ;">Tanggal Stok Opname</td>
                                <td style="width: ;">:</td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                        </div>
                                        <input class="form-control bg-white" value="<?= Modules::run('helper/date_indo', $data_detail->date, '-'); ?>" name="request_date" readonly placeholder="pilih tanggal" type="text">
                                    </div>
                                    <span class="help-block text-danger notif_request_date"></span>
                                </td>
                            </tr>
                            <tr>
                                <td>Gudang Stock Opname</td>
                                <td style="width: ;">:</td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                        </div>
                                        <input class="form-control bg-white" value="<?= $data_detail->warehouse_name; ?>" name="request_date" readonly placeholder="pilih tanggal" type="text">
                                    </div>
                                </td>
                            </tr>
                        </table>

                        <div class=" shadow-2 mt-3 p-2 text-center">
                            <small class="text-muted">Status Transaksi :</small>
                            <h3 class="text-primary"><?= $status_current; ?></h3>
                            <?php
                            if ($data_detail->status == 0) {
                                echo $btn_start;
                            }

                            if ($data_detail->status == 1) {
                                echo '
                                <small class="text-muted">Watu Dimulai :</small>
                                <label for="" class="font-weight-bold">' . Modules::run('helper/datetime_indo', $data_detail->starting_time, '-') . '</label>
                                ';
                            }

                            if ($data_detail->status == 2) {
                                echo '
                                    <small class="text-muted">Watu Dimulai :</small>
                                    <label for="" class="font-weight-bold">' . Modules::run('helper/datetime_indo', $data_detail->starting_time, '-') . '</label>
                                    <hr>
                                    <small class="text-muted">Watu Selesai :</small>
                                    <label for="" class="font-weight-bold">' . Modules::run('helper/datetime_indo', $data_detail->ending_time, '-') . '</label>
                                ';
                            }

                            ?>
                        </div>
                    </div>
                    <div class="col-md-6 ">
                        <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Keterangan</label>
                        <div class="row">
                            <div class="p-2 border-dashed col-12">
                                <small><i class="fa fa-tv"></i> Judul Stok Opname :</small>
                                <p><?= $data_detail->name; ?></p>
                            </div>
                            <div class="p-2 border-dashed col-12">
                                <small><i class="fa fa-tv"></i> Keterangan :</small>
                                <p><?= $data_detail->note; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <?php
        if ($data_detail->status > 0) {

            $html_form = '
                <div class="col-md-12">
                    <div class="col-md-12 shadow-2 p-3 border-radius-5">
                        <div class="col-md-12 row">
                            <input type="hidden" name="data_product">
                            <div class="col-md-2 form-group">
                                <label>Kode Barang</label>
                                <input type="text" class="form-control" id="barcode" name="barcode">
                                <span class="help-block text-danger notif_barcode"></span>
                            </div>
                            <div class="col-md-4 form-group">
                                <label>Nama Produk</label>
                                <input type="text" id="product-name" class="form-control" name="product_name">
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-2 form-group">
                                <label>Satuan</label>
                                <select name="unit" class="form-control" name="unit"></select>
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-1 form-group">
                                <label>Jumlah</label>
                                <input type="text" class="form-control" name="qty">
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-1 form-group text-center">
                                <label>&nbsp;</label><br>
                                <a href="javascript:void(0)" data-warehouse="' . $data_detail->id_warehouse . '" data-id="' . $data_detail->id . '" class="btn btn-primary-gradient btn-rounded btn_add_item"> Tambah</a>
                                <small class="d-block text-muted">(SHIFT + ENTER)</small>
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-2 form-group text-center">
                                <label>&nbsp;</label><br>
                                <a href="javascript:void(0)" data-warehouse="' . $data_detail->id_warehouse . '" data-id="' . $data_detail->id . '" class="btn btn-warning-gradient btn-rounded btn_finish_opname btn-block"> Update Ke stok <i class="fa fa-paper-plane"></i></a>
                                <small class="d-block text-muted">(klik jika opname telah selesai)</small>
                            </div>
                        </div>
                    </div>
                </div>
            ';

            if ($data_detail->status != 1) {
                $html_form = '<a href="javascript:void(0)" data-warehouse="' . $data_detail->id_warehouse . '" data-id="' . $data_detail->id . '" class="btn btn-primary-gradient btn-rounded btn_add_item" style="display:none;"> Tambah</a>';
            }

            echo '
            <div class="card">
                <div class="card-header">
                    <h4>Detail Stok Opname</h4>
                </div>
                <div class="card-body">
                    ' . $html_form . '
                    <div class="col-md-12 html_respon">
                        <hr>
                        <table class="table table_detail_opname">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Kode Produk</th>
                                    <th>Nama Produk</th>
                                    <th>Satuan</th>
                                    <th>Qty System </th>
                                    <th>Qty Fisik</th>
                                    <th>Margin</th>
                                    <th>Batal</th>
                                </tr>
                            </thead>
                            <tbody class="tbody_item detail_request">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            ';
        }
        ?>
    </div>
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>