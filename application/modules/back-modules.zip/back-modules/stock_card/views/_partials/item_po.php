<div class="row" style="align-items:baseline;">
    <div class="col-md-8 row">
        <label for="" class="font-weight-bold text-uppercase col-12 m-0"><i class="fa fa-truck"></i> Gudang Dan Tanggal</label>
        <div class="col-6">
            <table style="width:100%;" class="table-no-border">
                <tbody>
                    <tr>
                        <td style="width:100px ;">Tanggal Opaname</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="row col-12 border-dashed">
                                <div class="col">
                                    <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= Modules::run('helper/date_indo', $data_detail->date, '-'); ?></b></div>
                                </div>
                                <div class="col-auto align-self-center ">
                                    <div class="feature mt-0 mb-0">
                                        <i class="fa fa-truck project bg-primary-transparent text-primary "></i>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px ;">Gudang</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="row col-12 border-dashed">
                                <div class="col">
                                    <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_detail->warehouse_name; ?></b></div>
                                </div>
                                <div class="col-auto align-self-center ">
                                    <div class="feature mt-0 mb-0">
                                        <i class="fa fa-truck project bg-primary-transparent text-primary "></i>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-6">
            <table style="width: 100%;" class="table-no-border">
                <tbody>
                    <tr>
                        <td style="width:100px ;">Waktu Dimulai</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                </div>
                                <input class="form-control bg-white border-dashed" value="<?= Modules::run('helper/datetime_indo', $data_detail->starting_time, '-'); ?>" name="request_date" readonly="" placeholder="pilih tanggal" type="text">
                            </div>
                            <span class="help-block text-danger notif_request_date"></span>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px ;">Waktu Selesai</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                </div>
                                <input class="form-control bg-white border-dashed" value="<?= Modules::run('helper/datetime_indo', $data_detail->ending_time, '-'); ?>" readonly="" placeholder="pilih tanggal" type="text">
                            </div>
                            <span class="help-block text-danger notif_delivery_date"></span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
    <div class="col-md-4 ">
        <label for="" class="font-weight-bold text-uppercase m-0"><i class="fa fa-tv"></i> Keterangan</label>
        <div class="row ">
            <div class="p-2 border-dashed col-12">
                <small>Judul</small>
                <p><?= $data_detail->name; ?></p>
            </div>
            <div class="p-2 border-dashed col-12">
                <small>Keterangan</small>
                <p><?= $data_detail->note; ?></p>
            </div>

        </div>
        <div class="col-md-12 mt-3">

            <div class="text-right">

                <a href="<?= Modules::run('helper/create_url', 'stock_opname/detail?data=' . urlencode($this->encrypt->encode($data_detail->id))) ?>" class="btn btn-primary-gradient btn-rounded"><i class="fa fa-send"></i> Detail</a>
            </div>
        </div>

    </div>
</div>