<div class="table-responsive">
    <table class="table t-shadow table_request" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Keterangan</th>
                <th>Tanggal</th>
                <th>Kode Barang</th>
                <th>Nama barang</th>
                <th>MASUK</th>
                <th>Keluar</th>
                <th>Sisa</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $array_category_stock_card = Modules::run('helper/get_config', 'category_stock_card');

            $counter = 0;
            foreach ($data_opname as $item_product) {
                $counter++;
                $qty_in = 0;
                $qty_out = 0;
                $qty_rest = $item_product->stock_qty_rest;
                if ($item_product->stock_qty_in < 0) {
                    $qty_out = $item_product->stock_qty_in;
                }
                if ($item_product->stock_qty_in > 0) {
                    $qty_in = $item_product->stock_qty_in;
                }
                $desc = isset($array_category_stock_card[$item_product->type_transaction]) ? $array_category_stock_card[$item_product->type_transaction] : '-';
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>[ ' . $desc . ' ]</td>
                            <td>' . Modules::run('helper/datetime_indo', $item_product->created_date) . '</td>
                            <td>' . $data_product->code . '</td>
                            <td>' . $data_product->name . '</td>
                            <td>' . $qty_in . '</td>
                            <td>' . $qty_out . '</td>
                            <td>' . $qty_rest . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>