<?php
$get_data = Modules::run('database/find', 'tb_account_warehouse', ['type' => 1])->result();

?>
<style>
    .datepicker {
        z-index: 10000 !important;
    }
</style>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h3 class="col-8">Kartu Stok</h3>
        </div>

    </div>

    <div class="card-body">
        <form action="" class="form-input">
            <div class="row mb-3 border-dashed p-3">
                <div class="col-md-2 form-group">
                    <label>Kode Barang</label>
                    <input type="text" class="form-control" id="barcode" name="barcode">
                    <span class="help-block notif_barcode"></span>
                </div>
                <div class="col-md-4 form-group">
                    <label>Nama Produk</label>
                    <input type="text" id="product-name" class="form-control" name="product_name">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-2 form-group">
                    <label>Gudang</label>
                    <select name="warehouse" class="form-control" id="">
                        <?php

                        foreach ($get_data as $item_data) {
                            echo '
                                    <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                ';
                        }
                        ?>
                    </select>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-2">
                    <label for="">Tanggal Akhir</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                        </div>
                        <input class="form-control bg-white datepicker" name="date_to" readonly="" placeholder="pilih tanggal" type="text">
                    </div>
                    <span class="help-block notif_date_to text-danger"></span>
                </div>
                <div class="col-md-2">
                    <label for="">&nbsp;</label><br>
                    <button class="btn btn-rounded btn-primary-gradient btn_search_data"> <i class="fa fa-search"></i> Cari Data</button>
                </div>
            </div>
        </form>

        <div class="html_respon_data"></div>
    </div>
</div>



<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>