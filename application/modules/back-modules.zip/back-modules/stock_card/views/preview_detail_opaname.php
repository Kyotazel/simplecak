<div>
    <table class="table table_detail_opname2">
        <thead>
            <tr>
                <th>#</th>
                <th>Kode Produk</th>
                <th>Nama Produk</th>
                <th>Satuan</th>
                <th>Qty System </th>
                <th>Qty Fisik</th>
                <th>Margin</th>
            </tr>
        </thead>
        <tbody class="tbody_item detail_request">
            <?php
            $counter = 0;
            foreach ($detail_opname as $item_opname) {
                $counter++;
                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $item_opname->product_code . '</td>
                            <td>' . $item_opname->product_name . '</td>
                            <td>' . $item_opname->unit_name . '</td>
                            <td>' . $item_opname->qty_system . '</td>
                            <td>' . $item_opname->qty_stock . '</td>
                            <td>' . $item_opname->qty_margin . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>
<div class="text-right">
    <a href="javascript:void(0)" class="btn btn-rounded btn-warning-gradient font-weight-bold btn_save_stock_opname"> Simpan Data</a>
</div>