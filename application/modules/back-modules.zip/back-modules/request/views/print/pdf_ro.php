<?php
function change_date($date)
{
    $date_explode = explode('-', $date);
    $date_return = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
    return $date_return;
}

function date_function($date, $type, $return)
{
    if ($type == 'timestamp') {
        $timestamp_explode = explode(' ', $date);
        //create date indo
        $date_explode = explode('-', $timestamp_explode[0]);
        $date_indo = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        if ($return == 'time') {
            return $timestamp_explode[1];
        } elseif ($return == 'date') {
            return $timestamp_explode[0];
        } else {
            return $date_indo;
        }
    } else {
        $date_explode = explode('-', $date);
        $date_indo = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        if ($return == 'time') {
            return '-';
        } elseif ($return == 'date') {
            return $date;
        } else {
            return $date_indo;
        }
    }
}

$array_month = [
    '01' => 'Januari',
    '02' => 'Februari',
    '03' => 'Maret',
    '04' => 'April',
    '05' => 'Mei',
    '06' => 'Juni',
    '07' => 'Juli',
    '08' => 'Agustus',
    '09' => 'September',
    '10' => 'Oktober',
    '11' => 'November',
    '12' => 'December'
];



?>
<style type="text/css">
    .body {
        font-size: 10px;
        font-family: Times, serif;
    }

    .jarak {
        height: 25px;
    }

    .lebar {
        width: 70px;
    }

    .lebar-kecil {
        width: 40px;
    }

    /*table{
		width: 90%;
	}*/
    .table {
        /*width: 100px;*/
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
    }

    th {
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
        font-size: 11px;
    }

    .table tr td {
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
        font-size: 11px;
    }

    .more_width {
        width: 100px;
    }

    .small_width {
        width: 3px;
    }

    .much_width {
        width: 300px;
    }

    .width_200 {
        width: 200px;
    }

    .more_than_width {
        width: 150px;
    }

    /*hr{
		border-top: 0.1px solid #8c8b8b;
	}*/
    .hr_style {
        border-top: 1px dashed #808080;
        border-bottom: 1px dashed #fff;
    }

    .delivery_address {
        /*background-color: red;*/
        border: 1px dashed #808080;
    }

    .text-capitalize {
        text-transform: capitalize;
    }

    .border-none {
        border: none;
    }

    .border-bottom-none {
        border-bottom: none;
    }

    .border-top-none {
        border-top: none;
    }

    .border-right-none {
        border-right: none;
    }

    .border-left-none {
        border-left: none;
    }

    .border {
        border: 1px solid #000;
    }

    .border-bottom {
        border-bottom: 1px solid #000;
    }

    .border-top {
        border-top: 1px solid #000;
    }

    .border-left {
        border-left: 1px solid #000;
    }

    .border-right {
        border-right: 1px solid #000;
    }

    label {
        font-size: 10px;
    }
</style>
<html>

<head>
    <title></title>
</head>

<body>
    <table class="table">
        <tr>
            <td class="border-none" style="width:100px;padding:5px;">
                <img style="width: 100px;" src="<?= base_url('upload/' . $company['logo']); ?>">
            </td>
            <td class="border-none" style="width:300px;padding:5px;text-align:center;">
                <h3>RELEASE ORDER</h3>
                <h5 style="margin-bottom: 0px;text-align:center;">PERMINTAAN CONTAINER KOSONG</h5>
                <h2 style="margin-bottom: 0px;text-align:center;"><?= strtoupper($voyage['depo_from']); ?></h2>
            </td>
            <td class="border-none" style="width:200px;padding:5px;">
                <table class="border-none">
                    <tr>
                        <td style="width: 100px;" class="border-none">TANGGAL </td>
                        <td style="width: 5px;" class="border-none">:</td>
                        <td class="border-none"><?= Modules::run('helper/date_indo', $data_ro['date'], '-'); ?></td>
                    </tr>
                    <tr>
                        <td style="width: 100px;" class="border-none">DEPO/LAP </td>
                        <td style="width: 5px;" class="border-none">:</td>
                        <td class="border-none"><?= $voyage['depo_from']; ?></td>
                    </tr>
                    <tr>
                        <td style="width: 100px;" class="border-none">TUJUAN </td>
                        <td style="width: 5px;" class="border-none">:</td>
                        <td class="border-none"><?= $voyage['depo_to']; ?></td>
                    </tr>
                    <tr>
                        <td style="width: 100px;" class="border-none">TANGGAL AKHIR </td>
                        <td style="width: 5px;" class="border-none">:</td>
                        <td class="border-none"><?= Modules::run('helper/date_indo', $data_ro['due_date'], '-'); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
    <br>
    KEPADA YTH.<br>
    Harap dilayani permintaan Container Kosong (EMPTY) untuk EMKL / Forwarding Sebanyak :
    <br><br>
    <table class="table">
        <tr>
            <td style="width: 500px;">KONTAINER</td>
            <td style="width: 100px;">QTY</td>
        </tr>
        <?php
        $status_sd = 0;
        $status_sl = 0;
        $html_tr  = '';
        foreach ($data_detail as $item_countainer) {
            $countiner_type = isset($category_countainer[$item_countainer['category_countainer']]) ? $category_countainer[$item_countainer['category_countainer']] : '';
            $countainer_teus = isset($category_teus[$item_countainer['category_teus']]) ? $category_teus[$item_countainer['category_teus']] : 0;
            $html_tr .= '
                            <tr>
                                <td style="border:1px solid #000;padding:3px;">' . $countainer_teus . ' Feet - ' . strtoupper($countiner_type) . '</td>
                                <td style="border:1px solid #000;padding:3px;">' . $item_countainer['qty'] . '</td>
                            </tr>
                        ';
            if ($item_countainer->stuffing_take == 1) {
                $status_sl++;
            }
            if ($item_countainer->stuffing_take == 2) {
                $status_sd++;
            }
        }
        echo $html_tr;
        ?>
    </table>
    <br><br>
    <table>
        <tbody>
            <tr>
                <td>
                    <b for="">Stuffing</b>
                </td>
                <td colspan="3">
                    <label for="">Dalam Depo <input type="checkbox" disabled <?= $status_sd > 0 ? 'checked' : ''; ?> style="width:20px;height:20px"></label>
                    <label for="">Luar Depo <input type="checkbox" disabled <?= $status_sl > 0 ? 'checked' : ''; ?> style="width:20px;height:20px"></label>
                </td>
            </tr>
            <tr>
                <td>
                    <b for="">Catatan/Keterangan</b>
                </td>
                <td colspan="3">
                    <p style="color: red;">
                        STUFFING BARANG BERBAHAYA (DG) HARUS ADA SURAT IJIN.<br>
                        RO HANYA BERLAKU 3 (TIGA) HARI DARI TANGGAL RELEASE.
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="4" style="text-align: center;">
                    <br><br>
                    <b>TANDA TANGAN : </b>
                    <br><br>
                </td>
            </tr>
            <tr>
                <td style="text-align: center;width:180px;">
                    <label style="display: block;margin-bottom:30px;" for=""><b>MARKETING :</b></label>
                    <br><br><br><br>
                    <label for="">(________________)</label>
                </td>
                <td style="text-align: center;width:180px;"">
                    <label style=" display: block;margin-bottom:30px;" for=""><b>KEPALA DEPO :</b></label>
                    <br><br><br><br>
                    <label for="">(________________)</label>
                </td>
                <td style="text-align: center;width:180px;"">
                    <label style=" display: block;margin-bottom:30px;" for=""><b>PETUGAS CONTAINER LSL :</b></label>
                    <br><br><br><br>
                    <label for="">(________________)</label>
                </td>
                <td style="text-align: center;width:180px;"">
                    <label style=" display: block;margin-bottom:30px;" for=""><b>SECURITY :</b></label>
                    <br><br><br><br>
                    <label for="">(________________)</label>
                </td>
            </tr>

        </tbody>
    </table>
</body>

</html>