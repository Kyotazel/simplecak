<?php
function change_date($date)
{
    $date_explode = explode('-', $date);
    $date_return = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
    return $date_return;
}

function date_function($date, $type, $return)
{
    if ($type == 'timestamp') {
        $timestamp_explode = explode(' ', $date);
        //create date indo
        $date_explode = explode('-', $timestamp_explode[0]);
        $date_indo = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        if ($return == 'time') {
            return $timestamp_explode[1];
        } elseif ($return == 'date') {
            return $timestamp_explode[0];
        } else {
            return $date_indo;
        }
    } else {
        $date_explode = explode('-', $date);
        $date_indo = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
        if ($return == 'time') {
            return '-';
        } elseif ($return == 'date') {
            return $date;
        } else {
            return $date_indo;
        }
    }
}

function date_indo($date, $delimiter)
{
    $array_month = [
        '01' => 'januari', '02' => 'februari', '03' => 'maret', '04' => 'april', '05' => 'mei', '06' => 'juni', '07' => 'juli', '08' => 'agustus', '09' => 'september', '10' => 'oktober', '11' => 'november', '12' => 'december'
    ];
    $explode_date = explode($delimiter, $date);
    $date_return = $explode_date[2] . ' ' . ucfirst($array_month[$explode_date[1]]) . ' ' . $explode_date[0];
    return $date_return;
}


?>
<style type="text/css">
    .body {
        font-size: 10px;
        font-family: Times, serif;
    }

    .jarak {
        height: 25px;
    }

    .lebar {
        width: 70px;
    }

    .lebar-kecil {
        width: 40px;
    }

    /*table{
		width: 90%;
	}*/
    .table {
        /*width: 100px;*/
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
    }

    th {
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
        font-size: 11px;
    }

    .table tr td {
        border: 1px solid #000;
        border-collapse: collapse;
        padding-left: 8px;
        padding-right: 8px;
        font-size: 11px;
    }

    .more_width {
        width: 100px;
    }

    .small_width {
        width: 3px;
    }

    .much_width {
        width: 300px;
    }

    .width_200 {
        width: 200px;
    }

    .more_than_width {
        width: 150px;
    }

    /*hr{
		border-top: 0.1px solid #8c8b8b;
	}*/
    .hr_style {
        border-top: 1px dashed #808080;
        border-bottom: 1px dashed #fff;
    }

    .delivery_address {
        /*background-color: red;*/
        border: 1px dashed #808080;
    }

    .text-capitalize {
        text-transform: capitalize;
    }
</style>
<html>

<head>
    <title></title>
</head>

<body>
    <table>
        <tr>
            <td style="width: 363px;">
                <img style="width: 70px;" src="<?= base_url('upload/' . $company['company_logo']); ?>" alt="">
                <h4 style="margin: 0px;padding:0px;"><?= $company['name']; ?></h4>
                <p style="margin: 0px;padding:0px;font-size:10px;margin-top:3px;">
                    <?= $company['company_address']; ?><br>
                    No.Telp :<?= $company['company_number_phone']; ?> | Email : <?= $company['company_email']; ?>

                </p>
            </td>
            <td style="width: 350px;">
                <h4 style="margin:0;padding:0px;"><u>PURCHASE ORDER</u></h4>
                <table style="font-size: 11px;">
                    <tr>
                        <td>NO.PO</td>
                        <td>: <?= $data_request['code']; ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal PO</td>
                        <td>: <?= Modules::run('helper/date_indo', $data_request['date'], '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Pengiriman</td>
                        <td>: <?= Modules::run('helper/date_indo', $data_request['delivery_date'], '-'); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <td style="width: 350px;vertical-align:top;padding:5px;">
                <span style="font-size:11px;">Vendor :</span>
                <p style="margin:0;font-size:11px;width: 350px;">
                <h5 style="margin:0;padding:0;"><?= $data_request['supplier_name'] ?></h5>
                <?= $data_request['supplier_address'] ?>
                </p>
            </td>
            <td style="width: 350px;vertical-align:top;padding:5px;">
                <span style="font-size:11px;">Tujuan Pengiriman :</span>
                <p style="margin:0;font-size:11px;">
                <h5 style="margin:0;padding:0;"><?= $data_request['warehouse_name'] ?></h5>
                <?= $data_request['warehouse_address'] ?>
                </p>
            </td>
        </tr>
    </table>
    <br>
    <table class="table" style="vertical-align: top;">
        <thead>
            <tr style="vertical-align: middle;text-align:center;">
                <th style="width:20px;padding:5px;">No</th>
                <th style="width:80px;padding:5px;">KODE BARANG</th>
                <th style="width:100px;padding:5px;">NAMA BARANG</th>
                <th style="width:50px;padding:5px;">SATUAN</th>
                <th style="width:80px;padding:5px;">HARGA</th>
                <th style="width:30px;padding:5px;">QTY</th>
                <th style="width:100px;padding:5px;">SUBTOTAL</th>
            </tr>
        </thead>
        <?php
        $counter = 0;

        foreach ($data_detail as $item_detail) {
            $counter++;

            echo '
                             <tr>
                                 <td style="vertical-align:middle;">' . $counter . '</td>
                                 <td style="vertical-align:middle;">' . $item_detail['product_code'] . '</td>
                                 <td style="width:180px;vertical-align:middle;">' . $item_detail['product_name'] . '</td>
                                 <td style="vertical-align:middle;">' . $item_detail['unit_name'] . '</td>
                                 <td style="vertical-align:middle;">Rp.' . number_format($item_detail['price'], 0, '.', '.') . '</td>
                                 <td style="width:30px;vertical-align:middle;">' . $item_detail['qty'] . '</td>
                                 <td style="vertical-align:middle;">Rp.' . number_format($item_detail['grandtotal'], 0, '.', '.') . '</td>
                             </tr>
                         ';
        }
        ?>
        <tr>
            <td colspan="5"></td>
            <td style="padding:5px;">Sub Total</td>
            <td style="padding:5px;">Rp.<?= number_format($data_request['subtotal'], 0, '.', '.'); ?></td>
        </tr>
        <tr>
            <td colspan="5"></td>
            <td style="padding:5px;">Pajak PPN (<?= $data_request['ppn'] . '%'; ?>)</td>
            <td style="padding:5px;">Rp. <?= number_format($data_request['ppn_price'], 0, '.', '.'); ?></td>
        </tr>
        <tr>
            <td colspan="5"></td>
            <td style="padding:5px;"><b>Total</b></td>
            <td style="padding:5px;"><b>Rp.<?= number_format($data_request['grandtotal'], 0, '.', '.'); ?></b></td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <td style="width: 400px;vertical-align:top;padding:5px;">

            </td>
            <td style="width: 350px;vertical-align:top;padding:5px;text-align:center;">
                <span style="font-size:11px;">Manager Purchasing</span>
                <br>
                <br>
                <br>
                <br>
                <br>
                <span>(______________)</span>
            </td>
        </tr>
    </table>
</body>

</html>