<style>
    .datepicker {
        z-index: 1000 !important;
    }
</style>
<form class="form-input">

    <div class="row">
        <div class="col-12">
            <h2>Form Purchase Order ( PO )</h2>
        </div>
        <div class="col-4 d-flex">
            <div class="card " style="width:100%;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">Supplier</h3>
                </div>
                <div class="card-body">
                    <div class="col-md-12 form-group">
                        <label>Supplier</label>
                        <select name="id_suppplier" class="form-control chosen" id="">
                            <option value="">PIlih Supplier</option>
                            <?php
                            foreach ($option_supplier as $item_supplier) {
                                echo '
                                        <option value="' . $item_supplier->id . '">' . $item_supplier->name . '</option>
                                    ';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-12 html_suppplier"></div>
                </div>
            </div>
        </div>
        <div class="col-8 d-flex">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">Gudang & Resume PO</h3>
                </div>
                <div class="card-body">
                    <h2 class="mb-3 badge badge-light tx-20 badge-pill">NOMOR PO : <strong><?= $code_po; ?></strong></h2>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-truck"></i> Keterangan PO</label>
                            <table style="width:100%;">
                                <tr>
                                    <td style="width:100px ;">Tanggal PO</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                            </div>
                                            <input class="form-control bg-white datepicker" name="request_date" readonly placeholder="pilih tanggal" type="text">
                                        </div>
                                        <span class="help-block text-danger notif_request_date"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width:100px ;">Dikirim Tanggal</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                            </div>
                                            <input class="form-control bg-white datepicker" name="delivery_date" readonly placeholder="pilih tanggal" type="text">
                                        </div>
                                        <span class="help-block text-danger notif_delivery_date"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width:100px ;">Lokasi Kirim</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <select name="warehouse" class="form-control chosen" id="">
                                            <?php
                                            foreach ($option_warehouse as $item_data) {
                                                echo '
                                                        <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                                    ';
                                            }
                                            ?>
                                        </select>
                                        <span class="help-block text-danger notif_warehouse"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width:100px ;">PPN</td>
                                    <td style="width: ;">:</td>
                                    <td>
                                        <div class="main-toggle main-toggle-dark change_ppn on" data-value="<?= $tax_ppn; ?>"><span></span></div>
                                        <small>( * centang untuk include PPN <?= $tax_ppn; ?> %)</small>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6 ">
                            <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Resume Transaksi</label>
                            <div class="row text-right">
                                <div class="p-2 border-dashed col-6">
                                    <small>Sub Total (PO)</small>
                                    <h4 class="subttotal-po">Rp.0</h4>
                                </div>
                                <div class="p-2 border-dashed col-6">
                                    <small>PAJAK PPN ()</small>
                                    <h4 class="subttotal-ppn">Rp.0</h4>
                                </div>

                                <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                                    <small>Total PO : &nbsp;</small>
                                    <h4 class="text-primary m-0 p-0 total_po">Rp.0</h4>
                                </div>
                                <div class="col-12 text-right mt-2">
                                    <a href="jacascript:void(0)" class="btn btn-rounded btn-primary-gradient btn_save">Simpan Data <i class="fa fa-paper-plane"></i> </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fa fa-tv"></i> DETAIL PRODUK PO</h3>
                </div>
                <div class="card-body">
                    <div class="col-md-12">
                        <div class="col-md-12 border p-3 border-radius-5">
                            <div class="col-md-12 row">
                                <input type="hidden" name="data_product">
                                <div class="col-md-2 form-group">
                                    <label>Kode Barang</label>
                                    <input type="text" class="form-control" id="barcode" name="barcode">
                                    <span class="help-block"></span>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label>Nama Produk</label>
                                    <input type="text" id="product-name" class="form-control" name="product_name">
                                    <span class="help-block"></span>
                                </div>
                                <div class="col-md-2 form-group">
                                    <label>Satuan Pengadaan</label>
                                    <select name="unit" class="form-control" name="unit"></select>
                                    <span class="help-block"></span>
                                </div>
                                <div class="col-md-1 form-group">
                                    <label>Jumlah</label>
                                    <input type="text" class="form-control" name="qty">
                                    <span class="help-block"></span>
                                </div>
                                <div class="col-md-2 form-group">
                                    <label>Harga</label>
                                    <input type="text" class="form-control rupiah" name="price">
                                    <span class="help-block"></span>
                                </div>
                                <div class="col-md-1 form-group text-center">
                                    <label>&nbsp;</label><br>
                                    <a href="javascript:void(0)" class="btn btn-primary-gradient btn-rounded btn_add_item"> Tambah</a>
                                    <small class="d-block">(SHIFT + ENTER)</small>
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 html_respon">
                        <hr>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Kode Produk</th>
                                    <th>Nama Produk</th>
                                    <th>Satuan</th>
                                    <th>Harga </th>
                                    <th>Qty</th>
                                    <th>Total Harga</th>
                                    <th>Batal</th>
                                </tr>
                            </thead>
                            <tbody class="tbody_item detail_request">
                                <tr class="html_no_data">
                                    <td colspan="7" class="text-center">
                                        <div class="bg-empty-data"></div>
                                        <h3 class="text-center text-muted mb-10">Pilihlah Data Produk PO</h3>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>

</form>



<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>