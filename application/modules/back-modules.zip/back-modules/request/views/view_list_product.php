<div class="col-md-12">
    <table class="table table_list_product">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Produk</th>
                <th>Nama Produk</th>
                <th>Satuan</th>
                <th>Stok Tersedia</th>
                <th>Harga Per unit</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_product as $item_product) {
                $counter++;

                if ($item_product->stock > 0) {
                    //count data base unit
                    $base_unit_val = $item_product->stock % $item_product->qty_unit;
                    //count unit val
                    $unit_val         = ($item_product->stock - $base_unit_val) / $item_product->qty_unit;
                    // stock current
                    $stock_current = '';
                    if ($unit_val > 0) {
                        $stock_current .= number_format($unit_val, 0, '.', '.') . '&nbsp;' . $item_product->unit_name;
                    }
                    if ($base_unit_val > 0) {
                        if ($unit_val > 0) {
                            $stock_current .= '<br>';
                        }
                        $stock_current .= number_format($base_unit_val, 0, '.', '.') . '&nbsp;' . $item_product->base_unit_name;
                    }
                } else {
                    $stock_current = '<span style="color:red;">0</span>';
                }

                echo '
                        <tr>
                            <td>' . $counter . '</td>
                            <td>' . $item_product->code . '</td>
                            <td>' . $item_product->name . '</td>
                            <td>' . $item_product->qty_unit . $item_product->base_unit_name . '&nbsp;/&nbsp;' . $item_product->unit_name . '</td>
                            <td>' . $stock_current . '</td>
                            <td>Rp.' . number_format($item_product->main_unit_price) . '</td>
                            <td><a href="javascript:void(0)" class="btn btn-default btn_add_item" data-id="' . $this->encrypt->encode($item_product->id) . '">Tambahkan Produk</a></td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>

</div>