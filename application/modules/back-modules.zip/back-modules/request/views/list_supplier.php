<div class="col-12">
    <div class="table-responsive">
        <table class="table table-striped table_supplier">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 0;
                foreach ($data_supplier as $item_data) {
                    $counter++;
                    echo '
                            <tr>
                                <td>' . $counter . '</td>
                                <td>' . $item_data->code . '</td>
                                <td>' . $item_data->name . '</td>
                                <td>' . $item_data->address . '</td>
                                <td>
                                    <a href="javascript:void(0)" class="btn btn-rounded btn-primary" style="width:90px;">
                                        Pilih <i class="fa fa-paper-plane"></i>
                                    </a>
                                </td>
                            </tr>
                        ';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>