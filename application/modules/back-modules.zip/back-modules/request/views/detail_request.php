<?php
$data_print = [
    'data_request' => $data_request,
    'data_detail' => $data_detail
];
$print_data = $this->encrypt->encode(json_encode($data_print));

$btn_payment = '';
if ($data_request->status == 0) {
    $btn_payment = '
                    <div class="text-right">
                        <small class="block  mb-10">(* klik untuk melakukan penerimaan PO)</small>
                        <a href="' . Modules::run('helper/create_url', 'receive/add_receive?data=' . urlencode($this->encrypt->encode($data_request->id))) . '" class="btn btn-primary-gradient btn-rounded"><i class="fa fa-send"></i> Transaksi Good Receive (GR)</a> || 
                        <a href="javascript:void(0)" data-print="' . $print_data . '" class="btn btn-light btn-rounded btn btn_pdf_po"><i class="fa fa-print"></i> Cetak PO</a> &nbsp;&nbsp;||&nbsp;&nbsp;
                        <a href="javascript:void(0)" data-id="' . $data_request->id . '" class="btn btn-light btn-rounded btn btn_save_reject"><i class="fa fa-times"></i> Batalkan PO</a> &nbsp;&nbsp;||&nbsp;&nbsp;
                        <a href="' . Modules::run('helper/create_url', 'request') . '" class="btn btn-light btn-rounded"><i class="fa fa-arrow-left"></i> Lihat Data</a>
                    </div>
                ';
}
$html_note_reject = '';
if ($data_request->status == 2) {
    $html_note_reject = '   
                        <label>Catatan Pembatalan:</label>
                        <div class="p-10 bg-info">
                            <p>
                               ' . $data_request->reject_note . '
                            </p>
                        </div>
                        ';
}

$status_po = Modules::run('database/find', 'app_module_setting', ['field' => 'status_po'])->result();
$array_status = [];
foreach ($status_po as $item_data) {
    $array_status[$item_data->value] = $item_data->label;
}

?>


<div class="card" style="width:100% ;">
    <div class="card-header bg-primary-gradient">
        <h3 class="card-title text-white">Gudang & Resume PO</h3>
    </div>
    <div class="card-body">
        <div class="row">
            <h2 class="mb-3 badge badge-light tx-20 badge-pill col-md-4">NOMOR PO : <strong><?= $data_request->code; ?></strong></h2>
            <div class="col-8 mb-3">
                <?= $btn_payment; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-truck"></i> Keterangan PO</label>
                <table style="width:100%;">
                    <tr>
                        <td style="width:100px ;">Supplier</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="row col-12 border-dashed">
                                <div class="col">
                                    <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->supplier_name; ?></b></div>
                                    <p class="tx-12">
                                        <?= $data_request->supplier_address; ?>
                                    </p>
                                </div>
                                <div class="col-auto align-self-center ">
                                    <div class="feature mt-0 mb-0">
                                        <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px ;">Tanggal PO</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                </div>
                                <input class="form-control bg-white border-dashed" value="<?= Modules::run('helper/date_indo', $data_request->date, '-'); ?>" name="request_date" readonly placeholder="pilih tanggal" type="text">
                            </div>
                            <span class="help-block text-danger notif_request_date"></span>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px ;">Dikirim Tanggal</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                </div>
                                <input class="form-control bg-white border-dashed" value="<?= Modules::run('helper/date_indo', $data_request->delivery_date, '-'); ?>" readonly placeholder="pilih tanggal" type="text">
                            </div>
                            <span class="help-block text-danger notif_delivery_date"></span>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px ;">Lokasi Kirim</td>
                        <td style="width: ;">:</td>
                        <td>
                            <div class="row col-12 border-dashed">
                                <div class="col">
                                    <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_request->warehouse_name; ?></b></div>
                                </div>
                                <div class="col-auto align-self-center ">
                                    <div class="feature mt-0 mb-0">
                                        <i class="fa fa-truck project bg-primary-transparent text-primary "></i>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6 ">
                <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Resume Transaksi</label>
                <div class="row text-right">
                    <div class="p-2 border-dashed col-6">
                        <small>Sub Total (PO)</small>
                        <h3 class="subttotal-po">Rp.<?= number_format($data_request->subtotal, 0, '.', '.'); ?></h3>
                    </div>
                    <div class="p-2 border-dashed col-6">
                        <small>PAJAK PPN (<?= $data_request->ppn; ?>) %</small>
                        <h3 class="subttotal-ppn">Rp.<?= number_format($data_request->ppn_price, 0, '.', '.'); ?></h3>
                    </div>

                    <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                        <small>Total PO : &nbsp;</small>
                        <h3 class="text-primary m-0 p-0 total_po">Rp.<?= number_format($data_request->grandtotal, 0, '.', '.'); ?></h3>
                    </div>
                    <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                        <small>Status PO : &nbsp;</small>
                        <h5 class="text-primary m-0 p-0 total_po"><span class="badge badge-pill badge-light"><?= $array_status[$data_request->status]; ?></span></h5>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">

        <div class="col-md-12 ">
            <div class="text-left mb-10 p-10">
                <h3>Detail Barang PO <span class="badge badge-light">( Total Item : <?= $data_request->count_item; ?> ITEM )</span></h3>
            </div>
            <table class="table table_detail_request">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Produk</th>
                        <th>Nama Produk</th>
                        <th>Satuan </th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th>Grand Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $counter = 0;
                    foreach ($data_detail as $item_detail) {
                        $counter++;

                        if (!empty($item_detail->conversion_name)) {
                            $unit_request = $item_detail->conversion_name . ' / ' . $item_detail->qty_conversion . ' ' . $item_detail->unit_name;
                        } else {
                            $unit_request = $item_detail->unit_name;
                        }

                        $conversion_name = $item_detail->conversion_name ? $item_detail->conversion_name : $item_detail->unit_name;

                        echo '
                                    <tr>
                                        <td>' . $counter . '</td>
                                        <td>' . $item_detail->product_code . '</td>
                                        <td>' . $item_detail->product_name . '</td>
                                        <td>' . $item_detail->unit_name . '</td>
                                        <td>Rp.' . number_format($item_detail->price, 0, '.', '.') . ' / ' . $conversion_name . '</td>
                                        <td>' . $item_detail->qty . ' ' . $conversion_name . '</td>
                                        <td>Rp.' . number_format($item_detail->grandtotal, 0, '.', '.') . '</td>
                                    </tr>
                                ';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>