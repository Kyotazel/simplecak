var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;

var save_method;
var table_request;
var table_reject;
var table_receive;
var id_use;
$(document).ready(function () {
    // table_request = $('.table_request').DataTable({
    //     "ajax": {
    //         "url": url_controller + "/list_data_request",
    //         "type": "POST"
    //     }
    // });
    // table_reject = $('.table_reject').DataTable({
    //     "ajax": {
    //         "url": url_controller + "/list_data_reject",
    //         "type": "POST"
    //     }
    // });
    // table_receive = $('.table_receive').DataTable({
    //     "ajax": {
    //         "url": url_controller + "/list_data_receive",
    //         "type": "POST"
    //     }
    // });
    // $('.table_detail_request').DataTable();
    // console.log(url_controller);

    shortcut.add("shift+enter", function () {
        // Do something
        $('.btn_add_item').click();
    });

    $('.chosen').chosen();

    search_data();

});

function reload_table(){
     table.ajax.reload(null,false); //reload datatable ajax 
}

$(document).on('click', '.btn_search_data', function (e) { 
    e.preventDefault();
    search_data();
});

function search_data() {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    $.ajax({
        url: url_controller + "list_data_request",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                $('.html_respon_data').html(data.html_respon);
                $(document).find('.table_request').DataTable();
            }else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    $('.notif_'+data.inputerror[i]).parent().addClass('has-danger');
                    $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                }
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }

    });
}



$(document).on('click', '.btn_search_supplier', function () { 
    showLoading();
    $.ajax({
        url: url_controller + '/get_supplier/',
        type: "POST",
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.html_respon_modal').html(data.html_respon);
                $('#modal-form').modal('show');
                $('.modal-title').text('Pilih Supplier');
                $(document).find('.table_supplier').DataTable();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('error process');
        }
    });
});

$('[name="id_suppplier"]').change(function () { 
    var id_suppplier = $(this).val();
    $.ajax({
        url: url_controller + '/get_current_supplier',
        type: "POST",
        data:{'id':id_suppplier},
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.html_suppplier').html(data.html_respon);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('error process');
        }
    });
});

// $(document).on('keyup', '#barcode', function (e) {
//     e.preventDefault();
    
//     $(".form-input").submit(function (e) {
//         return false;
//     });

//     var barcode_current = $(this).val();
//     $.ajax({
//         url: url_controller + '/get_barcode_choosen/',
//         type: "POST",
//         dataType: "JSON",
//         data: { 'barcode': barcode_current },
//         success: function (ui) {
//             if (ui.status) {
//                 $('#product-name').val(ui.item.label);
//                 get_unit_request(ui.item.id);
//                 $('[name="qty"]').focus();
//             } else {
//                 notif_error('barang tidak ditemukan');
//             }
                
//         },
//         error: function (jqXHR, textStatus, errorThrown) {
//             alert_error('error process');
//         }
//     });
// });

$('#barcode').autocomplete({
    source: url_controller + "/get_barcode_choosen",
    select: function(event, ui) {
        event.preventDefault();
        console.log(ui.item);
        $('#barcode').val(ui.item.code);
        $('#product-name').val(ui.item.label);
        get_unit_request(ui.item.id);
        $('[name="qty"]').focus();
    }
});

$('#product-name').autocomplete({
    source: url_controller + "/get_product_auto",
    select: function(event, ui) {
        event.preventDefault();
        console.log(ui.item);
        $('#product-name').val(ui.item.label);
        $('#barcode').val(ui.item.code);
            (ui.item.id);
        $('[name="qty"]').focus();
    }
});

function get_unit_request(id) {
    $.ajax({
	    url: url_controller+'/get_unit_request',
	    type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            $('[name="unit"]').html(data.html_respon);
            $('[name="data_product"]').val(data.data_product);
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_add_product');
	       alert_error('something wrong');
	      }
	  });//end ajax
}



$('.btn_add_item').click(function () {
    var data_product = $('[name="data_product"]').val();
    var unit = $('[name="unit"]').val();
    var qty = $('[name="qty"]').val();
    var price = $('[name="price"]').val();

    if (data_product == '' || unit == '' || qty == '') {
        alert_error('lengkapi data');
    } else {
        $.ajax({
            url: url_controller + '/add_item_product',
            type: "POST",
            dataType: "JSON",
            data: { 'data_product': data_product, 'unit': unit, 'qty': qty, 'price': price },
            success: function (data) {
                $('.html_no_data').remove();
                var chek_tr = $('.tr_' + data.id).length;
                if (chek_tr) {
                    $('.tr_' + data.id).remove();
                }
                $('.tbody_item').append(data.html_respon);
    
                $('#product-name').val('');
                $('#barcode').val('');
                $('[name="qty"]').val('');
                $('[name="unit"]').html('');
                $('[name="data_product"]').val('');
                $('[name="price"]').val('');
                $('#barcode').focus();
                count_resume_request();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert_error('something wrong');
            }
        });//end ajax
    }
});

$(document).on('keypress','[name="price"]',function(e) {
    if(e.which == 13) {
        $('.btn_add_item').click();
    }
});

$(document).on('click', '.change_ppn', function () {
    var id      = $(this).data('id');
    var code    = $(this).data('code');
    $(this).toggleClass('on');
    active_status = $(this).hasClass('on') ? 1 : 0;
    count_resume_request();
});


var total_price = 0;
var ppn_price = 0;
var sub_total_price = 0;
function count_resume_request() {
    total_price = 0;
    ppn_price = 0;
    sub_total_price = 0;
    
    $(document).find('.detail_request').find('.item_request').each(function () { 
        var price = $(this).data('price');
        sub_total_price += parseInt(price);
    });
    
    
    var ppn_value = $('.change_ppn').data('value');
    ppn_price = 0;
    if ($('.change_ppn').hasClass('on') && sub_total_price > 0) {
        ppn_price = sub_total_price * (ppn_value / 100);

    }
    total_price = sub_total_price + ppn_price;

    $('.subttotal-po').text('Rp.' + money_function(sub_total_price.toString()));
    $('.subttotal-ppn').text('Rp.' + money_function(ppn_price.toString()));

    $('.total_po').text('Rp.'+money_function(total_price.toString()));
}


$(document).on('click', '.btn_save_reject', function (e) {
    e.preventDefault();
    var id = $(this).data('id');
    var note = $('[name="note"]').val();
    $('.form-group').removeClass('has-error');
	$('.help-block').empty();  
    if (note == '') {
        $('[name="note"]').next().text('harus di isi');
        $('[name="note"]').parent().parent().addClass('has-error');
        $('.btn_save_reject');
    } else {
        swal({
            title: "Apakah anda yakin?",
            text: "PO ini akan dibatalkan",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ya , Lanjutkan",
            cancelButtonText: "Batal",
            closeOnConfirm: true,
            closeOnCancel: true
        },
        function(isConfirm) {
            if (isConfirm) {
                showLoading();
                $.ajax({
                    url: url_controller+'/save_reject',
                    type: "POST",
                    data: {'id':id,'note':note},
                    dataType :"JSON",
                    success: function(data){ 
                        hideLoading();
                        notif_success('data berhasil dibatalkan');
                        location.reload();
                    },
                    error:function(jqXHR, textStatus, errorThrown)
                    {
                        hideLoading();
                        $('.btn_save_reject');
                        alert_error('something wrong');
                    }
                });//end ajax
            }
        });



    }
})

$(document).on('click', '.btn_cancel', function (e) {
    e.preventDefault();
    $(this).parent().parent().remove();
    var count_tr = $('.tbody_item').has('tr').length;
    if (count_tr == 0) {
        $('.tbody_item').html('<tr class="html_no_data"><td colspan="7" class="text-center"> <div class="bg-empty-data"></div><h3 class="text-center text-muted mb-10">Pilihlah Data Produk Pengadaan Barang</h3></td></tr>');
    }
})

// function del_tr(class_name) {
//     $(class_name).remove();
//     var count_tr = $('.tbody_item').has('tr').length;
//     if (count_tr == 0) {
//         $('.tbody_item').html('<tr class="html_no_data"><td colspan="7" class="text-center"> <div class="bg-empty-data"></div><h3 class="text-center text-muted mb-10">Pilihlah Data Produk Pengadaan Barang</h3></td></tr>');
//     }
// }



// $('.btn_add_product').click(function () {
//     $('.btn_save');
// 	save_method = 'add';
// 	$('.form-group').removeClass('has-error');
//  	$('.help-block').empty();
//     $('.form-input')[0].reset();
// 	$('.modal-title').text('TAMBAH DATA');
// 	$('#modal-form').modal('show');
// })

$('.btn_save').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    var html_data = $('.tbody_item').html();
    $('.modal-title').text('Koreksi Kembali');
    //defined form
    var formData = new FormData($('.form-input')[0]);

    var ppn_dataxx = 0;
    if ($('.change_ppn').hasClass('on')) {
        ppn_dataxx = $('.change_ppn').data('value');
    }

    formData.append('ppn', ppn_dataxx);
    formData.append('html_data', html_data);
    var url;
    $.ajax({
        url: url_controller + 'preview_request',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon_modal').html(data.html_respon);
                $('#modal-form').modal('show');
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                    //qty tr
                    $('.' + data.inputerror[i]).text(data.error_string[i]);

                    if (data.inputerror[i] == 'qty_product') {
                        alert_error('data produk belum dipilih');
                    }
                }
            }
            $('.btn_save');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_save');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_do_save', function (e) {
    e.preventDefault();
    showLoading();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    var ppn_data = 0;
    if ($('.change_ppn').hasClass('on')) {
        ppn_data = $('.change_ppn').data('value');
    }
    formData.append('ppn', ppn_data);
    
    $.ajax({
        url: url_controller + '/save',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                notif_success('data berhasil disimpan');
                window.location.href = url_controller + '/detail?data=' + data.id
            } else {
                alert_error('something wrong');
            }
            $('.btn_do_save');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

// $('.btn_save').click(function (e) {
//     e.preventDefault();
//     $(this);
// 	$('.form-group').removeClass('has-error');
// 	$('.help-block').empty();  
// 	  //defined form
// 	   var formData = new FormData($('.form-input')[0]);
// 	   var url;
// 	  $.ajax({
// 	    url: url_controller+'/preview_request',
// 	    type: "POST",
// 	    data: formData,
// 	    contentType: false,
// 	    processData : false,
// 	    dataType :"JSON",
// 	    success: function(data){
//             if (data.status) {
//                 notif_success('data berhasil disimpan');
//                 window.location.href = url_controller+'/detail?data='+data.id
// 	      } else{
// 	        for (var i = 0; i < data.inputerror.length; i++)
// 	         {
// 	            $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
//                 $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
//                 //qty tr
//                 $('.'+data.inputerror[i]).text(data.error_string[i]);

//                 if (data.inputerror[i] == 'qty_product') {
//                     alert_error('data produk belum dipilih');
//                 }
// 	         }
// 	      }
// 	      $('.btn_save');
// 	    },
// 	      error:function(jqXHR, textStatus, errorThrown)
// 	      {
// 	        $('.btn_save');
//             alert_error('something wrong');
// 	      }
// 	  });//end ajax
// })


$(document).on("change", ".checkbox_status", function () {
    var id = $(this).val();
    if ($(this).prop('checked')) {
        status_active = 1;
    }else{
        status_active = 0;
    }
    $.ajax({
        url: url_controller+'/update_status',
        type: "POST",
        data: {'status':status_active,'id':id},
        dataType :"JSON",
        success: function(data){
                notif_success('status berhasil diupdate');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_save');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_edit', function () {
    var id = $(this).data('id');
    $('.modal-title').text('UPDATE DATA');
    $('.form-input')[0].reset();
	save_method = 'update';
	var PostData = {'id':id};
	$.ajax({
	    url: url_controller+'/get_edit',
	    type: "POST",
	    data: PostData,
	    dataType :"JSON",
        success: function (data) {
            id_use = data.id;  
            $('[name="price"]').val(data.min_price);
            $('[name="point"]').val(data.point);
            $('[name="note"]').val(data.note);
	      	$('#modal-form').modal('show'); 
	        $('.btn_save');
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_save');
	       alert_error('something wrong');
	      }
	  });//end ajax
})

$(document).on('click', '.btn_remove', function () {
    var id = $(this).data('id');
    swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,hapus data',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: url_controller+'/delete',
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function(data){
                    $('#modal-form').modal('hide'); 
                    notif_success('data berhasil dihapus');
                    reload_table();
                    $('.btn_remove');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_remove');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
});


$(document).on('keyup', '.rupiah', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});

function clear_dot_value(value) {
    var array_value = value.split('.');
    var count_array = array_value.length;
    payment_value = value;
    for (var i = 0; i < count_array; i++) {
        payment_value = payment_value.replace('.', '');
    };
    return payment_value;
}


function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

if (ribuan) {
    separator = sisa ? '.' : '';
    rupiah += separator + ribuan.join('.');
}

rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}
