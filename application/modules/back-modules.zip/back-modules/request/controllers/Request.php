<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Request extends BackendController
{
    var $module_name        = 'request';
    var $module_directory   = 'request';
    var $module_js          = ['request', 'print'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        $this->app_data['status_po'] = Modules::run('database/find', 'app_module_setting', ['field' => 'status_po'])->result();

        $this->app_data['page_title'] = "Daftar Produk";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function get_code()
    {
        $number_text = 0;
        $simbol = 'PO';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_request")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_request WHERE id IN(SELECT MAX(id) FROM tb_request)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function validate_list_data_request()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $status = $this->input->post('status');

        if ($status == '') {

            if ($date_from == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'date_from';
                $data['status'] = FALSE;
            }
            if ($date_to == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function list_data_request()
    {
        $this->validate_list_data_request();
        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $id_supplier = $this->input->post('id_supplier');
        $status = $this->input->post('status');

        $array_where = [];
        $array_where_in = [];
        $filter_status = 0;

        if ($date_from) {
            $filter_status = 1;
            $array_where['tb_request.date >='] = $date_from;
        }
        if ($date_to) {
            $filter_status = 1;
            $array_where['tb_request.date <='] = $date_to;
        }
        if ($id_supplier) {
            $filter_status = 1;
            $array_where_in['tb_request.id_supplier'] = $id_supplier;
        }
        if ($status != '') {
            $array_where['tb_request.status'] = $status;
        }


        $array_query = [
            'select' => '
                tb_request.*,
                COUNT(tb_request_has_product.id) AS count_item,
                tb_account_warehouse.name AS warehouse_name,
                tb_account_warehouse.address AS warehouse_address,
                mst_vendor.name AS supplier_name,
                mst_vendor.address AS supplier_address,
            ',
            'from' => 'tb_request',
            'join' => [
                'tb_request_has_product,tb_request.id = tb_request_has_product.id_request,left',
                'tb_account_warehouse,tb_request.id_account_warehouse = tb_account_warehouse.id,left',
                'mst_vendor,tb_request.id_supplier = mst_vendor.id,left'
            ],
            'group_by' => 'tb_request.id',
            'order_by' => 'tb_request.id, DESC'
        ];

        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }

        if ($filter_status == 1) {
            $array_query['limit'] = 500;
        }

        $get_data = Modules::run('database/get', $array_query)->result();


        $data_po['data_request'] = $get_data;
        $html_po = $this->load->view('view_search_result', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }


    public function add()
    {
        $this->app_data['option_supplier'] = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        $this->app_data['option_warehouse'] = Modules::run('database/find', 'tb_account_warehouse', ['type' => 1])->result();
        $this->app_data['tax_ppn'] = Modules::run('helper/get_setting', 'ppn_tax')->value;
        $this->app_data['code_po'] = $this->get_code();

        $this->app_data['page_title'] = "Tambah Data Pengadaan";
        $this->app_data['view_file'] = 'form_add_request';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_supplier()
    {
        Modules::run('security/is_ajax');
        $get_supplier = Modules::run('database/find', 'mst_vendor', ['isDeleted' => 'N'])->result();
        $data['data_supplier'] = $get_supplier;
        $html_respon = $this->load->view('list_supplier', $data, TRUE);
        echo json_encode(['html_respon' => $html_respon, 'status' => TRUE]);
    }

    public function get_current_supplier()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_supplier = Modules::run('database/find', 'mst_vendor', ['id' => $id])->row();
        $html_respon = '
            <div class="row col-12 border-dashed">
                <div class="col">
                    <div class=" mt-2 mb-2 text-primary"><b>' . $get_supplier->name . '</b></div>
                    <p class="tx-12">' . $get_supplier->address . '</p>
                </div>
                <div class="col-auto align-self-center ">
                    <div class="feature mt-0 mb-0">
                        <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                    </div>
                </div>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }


    public function get_product()
    {
        $this->db->select('
                            tb_product.id ,
                            tb_product.code,
                            tb_product.name,
                            tb_product.stock,
                            tb_product.qty_unit,
                            tb_product.main_price,
                            tb_product.main_unit_price,
                            tb_unit.name AS unit_name,
                            tb_base_unit.name AS base_unit_name
                        ');
        $this->db->from('tb_product');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_base_unit', 'tb_unit.id_base_unit = tb_base_unit.id', 'left');
        // $this->db->where(['tb_product.status' => TRUE]);
        $get_data_product = $this->db->order_by('tb_product.name')->get()->result();
        $data['data_product'] = $get_data_product;
        $html_respon = $this->load->view($this->location . 'view_list_product', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function get_product_auto()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                                                    a.id,
                                                    a.code, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
			 									    where a.name like '%$term%' LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->code . ' - ' . $data_product->name,
                        'id' => $data_product->id,
                        'code' => $data_product->code,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_barcode_choosen()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                                                    a.id,
                                                    a.code, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
			 									    where a.code like '%$term%' LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->code . ' - ' . $data_product->name,
                        'code' => $data_product->code,
                        'id' => $data_product->id,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_unit_request()
    {
        $id = $this->input->post('id');
        $get_data_current = $this->db->where(['id' => $id])->get('tb_product')->row();
        $data_unit = $this->db->where(['id' => $get_data_current->id_unit])->get('tb_unit')->row();
        //get other conversion
        $get_all_conversion = $this->db->where(['id_product' => $id])->order_by('qty')->get('tb_product_has_conversion')->result();
        $array_value = [
            'id' => 0,
            'name' => $data_unit->name,
            'qty' => 1
        ];
        $html_option = '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $data_unit->name . '</option>';
        foreach ($get_all_conversion as $item_conversion) {
            $array_value = [
                'id' => $item_conversion->id,
                'name' => $item_conversion->name,
                'qty' => $item_conversion->qty
            ];
            $html_option .= '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $item_conversion->name . '</option>';
        }

        $array_respon = [
            'html_respon' => $html_option,
            'status' => TRUE,
            'data_product' => $this->encrypt->encode(json_encode($get_data_current)),
            'stock_warehouse' => $get_data_current->stock_warehouse
        ];
        echo json_encode($array_respon);
    }


    public function add_item_product()
    {
        //     $id = $this->encrypt->decode($this->input->post('id'));
        $get_data_product = json_decode($this->encrypt->decode($this->input->post('data_product')));
        $unit         = json_decode($this->encrypt->decode($this->input->post('unit')));
        $qty           = $this->input->post('qty');
        $data_unit = $this->db->where(['id' => $get_data_product->id_unit])->get('tb_unit')->row();
        $price = $this->input->post('price');
        $price = str_replace('.', '', $price);
        $total_price = $price * $qty;

        // $get_data_product->html_stock = $stock_current;
        $data_encrypt = $this->encrypt->encode(json_encode($get_data_product));

        $price_current = $get_data_product->main_price * $unit->qty;

        $html_respon = '
                                <tr class="tr_' . $get_data_product->id . ' item_request" data-price="' . $total_price . '">
                                    <input type="hidden" name="data_product[' . $get_data_product->id . ']" value="' . $data_encrypt . '">
                                    <input type="hidden" name="id_conversion[' . $get_data_product->id . ']" value="' . $this->encrypt->encode(json_encode($unit)) . '">
                                    <input type="hidden" name="total_price[' . $get_data_product->id . ']" value="' . $this->encrypt->encode($total_price) . '">
                                    <input type="hidden" name="price[' . $get_data_product->id . ']" value="' . $price . '">
                                    <input type="hidden" name="qty_product[' . $get_data_product->id . ']" value="' . $qty . '" class="form-control">

                                    <td>' . $get_data_product->code . '</td>
                                    <td>' . $get_data_product->name . '</td>
                                    <td>' . $data_unit->name . '</td>
                                    <td>
                                        Rp.' . number_format($price, 0, '.', '.') . '
                                    </td>
                                    <td>' . $qty . '</td>
                                    <td>Rp.' . number_format($total_price, 0, '.', '.') . '</td>
                                    <td>
                                        <a href="javascript:void(0)" class="btn btn-danger btn_cancel btn-pill"><i class="fa fa-times"></i></a>
                                    </td>
                                </tr>
                            ';

        $array_respon = [
            'id' => $get_data_product->id,
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        // if ($this->input->post('name') == '') {
        //     $data['error_string'][] = 'harus diisi';
        //     $data['inputerror'][] = 'name';
        //     $data['status'] = FALSE;
        // }
        if ($this->input->post('id_suppplier') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'id_supplier';
            $data['status'] = FALSE;
        }
        // if ($this->input->post('note') == '') {
        //     $data['error_string'][] = 'harus diisi';
        //     $data['inputerror'][] = 'note';
        //     $data['status'] = FALSE;
        // }

        if (!isset($_POST['qty_product'])) {
            $data['error_string'][] = 'product belum dipilih';
            $data['inputerror'][] = 'qty_product';
            $data['status'] = FALSE;
        } else {
            $array_qty = $this->input->post('qty_product');
            foreach ($array_qty as $item_qty => $val_qty) {
                if ($val_qty == '' || $val_qty == 0) {
                    $data['error_string'][] = 'harus diisi dan tidak boleh 0';
                    $data['inputerror'][] = 'qty_' . $item_qty;
                    $data['status'] = FALSE;
                }
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function preview_request()
    {

        $this->validate_insert();


        $request_date   = $this->input->post('request_date');
        $delivery_date = $this->input->post('delivery_date');
        $warehouse = $this->input->post('warehouse');
        $array_data_product = $this->input->post('data_product');
        $code = $this->get_code();
        $ppn = $this->input->post('ppn');

        $name   = $this->input->post('name');
        $note   = $this->input->post('note');
        $id_supplier = $this->input->post('id_suppplier');
        $array_qty = $this->input->post('qty_product');
        $array_price = $this->input->post('price');


        $html_data = $_POST['html_data'];

        $html_data = str_replace('<a href="javascript:void(0)" class="btn btn-danger btn_cancel btn-pill"><i class="fa fa-times"></i></a>', '', $html_data);
        //get grand total
        $total_price = $this->input->post('total_price');
        //get grand total
        $grand_total = 0;
        foreach ($total_price as $item_total_price) {
            $grand_total += $this->encrypt->decode($item_total_price);
        }

        $ppn_price = $ppn > 0 ? round($grand_total * ($ppn / 100)) : 0;
        $grand_total_price = $grand_total + $ppn_price;

        $get_supplier = $this->db->where(['id' => $id_supplier])->get('mst_vendor')->row();
        $get_warehouse = $this->db->where(['id' => $warehouse])->get('tb_account_warehouse')->row();

        $html_respon = '
            <div class="row mb-3">
                <div class="col-md-6">
                    <h4>SUPPLIER : </h4>
                    <div class="row col-12 border-dashed">
                        <div class="col">
                            <div class=" mt-2 mb-2 text-primary"><b>' . $get_supplier->name . '</b></div>
                            <p class="tx-12">' . $get_supplier->address . '</p>
                        </div>
                        <div class="col-auto align-self-center ">
                            <div class="feature mt-0 mb-0">
                                <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <table style="width:100%;">
                        <tbody>
                            <tr>
                                <td style="width:100px ;">Tanggal PO</td>
                                <td style="width: ;">:</td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                        </div>
                                        <input class="form-control bg-white  border-dashed" name="request_date" readonly="" value="' . $request_date . '" placeholder="pilih tanggal" type="text">
                                    </div>
                                    <span class="help-block text-danger notif_request_date"></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="width:100px ;">Dikirim Tanggal</td>
                                <td style="width: ;">:</td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                        </div>
                                        <input class="form-control bg-white  border-dashed" name="delivery_date" value="' . $delivery_date . '" readonly="" placeholder="pilih tanggal" type="text">
                                    </div>
                                    <span class="help-block text-danger notif_delivery_date"></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="width:100px ;">Lokasi Kirim</td>
                                <td style="width: ;">:</td>
                                <td>
                                    ' . $get_warehouse->name . '
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-12 mt-3">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <th>Kode Produk</th>
                            <th>Nama Produk</th>
                            <th>Satuan</th>
                            <th>Harga</th>
                            <th>Qty</th>
                            <th>Total Harga</th>
                            <th></th>
                        </thead>
                        <tbody>
                            ' . $html_data . '
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row text-right">
                <div class="p-2 border-dashed col-12">
                    <small>Sub Total (PO)</small>
                    <h4 class="subttotal-po">Rp.' . number_format($grand_total, 0, '.', '.') . '</h4>
                </div>
                <div class="p-2 border-dashed col-12">
                    <small>PAJAK PPN (' . $ppn . ' %)</small>
                    <h4 class="subttotal-ppn">Rp.' . number_format($ppn_price, 0, '.', '.') . '</h4>
                </div>

                <div class="p-2 border-dashed col-12 d-flex justify-content-end align-items-center">
                    <small>Total PO : &nbsp;</small>
                    <h4 class="text-primary m-0 p-0 total_po">Rp.' . number_format($grand_total_price, 0, '.', '.') . '</h4>
                </div>
                <div class="col-12 text-right mt-2">
                    <a href="javascript:void(0)" class="btn btn-rounded btn-primary-gradient btn_do_save">Simpan Data <i class="fa fa-paper-plane"></i> </a>
                </div>
            </div>
        
        ';

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save()
    {
        $this->validate_insert();

        $data_product = $this->input->post('data_product');
        $code = $this->get_code();
        $name   = $this->input->post('name');
        $note   = $this->input->post('note');
        $id_supplier = $this->input->post('id_suppplier');
        $array_qty = $this->input->post('qty_product');
        $array_price = $this->input->post('price');
        $array_id_conversion = $this->input->post('id_conversion');
        $total_price = $this->input->post('total_price');

        $request_date = Modules::run('helper/change_date', $this->input->post('request_date'), '-');
        $delivery_date = Modules::run('helper/change_date', $this->input->post('delivery_date'), '-');
        $warehouse = $this->input->post('warehouse');
        $ppn = $this->input->post('ppn');

        //get grand total
        $grand_total = 0;
        foreach ($total_price as $item_total_price) {
            $grand_total += $this->encrypt->decode($item_total_price);
        }
        $ppn_price = $ppn > 0 ? round($grand_total * ($ppn / 100)) : 0;
        $grand_total_price = $ppn_price + $grand_total;

        //save to database 
        $array_insert_request = [
            'id_account_warehouse' => $warehouse,
            'ppn' => $ppn,
            'ppn_price' => $ppn_price,
            'code' => $code,
            'id_supplier' => $id_supplier,
            'name' => $name,
            'date' => $request_date,
            'delivery_date' => $delivery_date,
            'note' => $note,
            'subtotal' => $grand_total,
            'grandtotal' => $grand_total_price,
            'created_by' => $this->session->userdata('us_id')
        ];
        $this->model->insert('tb_request', $array_insert_request);
        //get max id 
        $get_max_id  = Modules::run('database/find', 'tb_request', ['code' => $code])->row();
        foreach ($array_qty as $key_qty => $value_qty) {
            $id_product = $key_qty;
            $price  = $array_price[$key_qty];
            $qty    = $value_qty;
            $id_conversion = json_decode($this->encrypt->decode($array_id_conversion[$key_qty]));

            $grand_total_current = $price * $qty;

            $array_insert_detail = [
                'id_request' => $get_max_id->id,
                'id_product' => $id_product,
                'price' => $price,
                'qty' => $qty,
                'id_conversion_unit' => $id_conversion->id,
                'grandtotal' => $grand_total_current,
                'created_by' => $this->session->userdata('us_id')
            ];
            $this->model->insert('tb_request_has_product', $array_insert_detail);
        }
        $array_respon = [
            'status' => TRUE,
            'id' => urlencode($this->encrypt->encode($get_max_id->id))
        ];
        echo json_encode($array_respon);
    }

    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS warehouse_name,
                            tb_account_warehouse.address AS warehouse_address,
                            mst_vendor.name AS supplier_name,
                            mst_vendor.address AS supplier_address,
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_account_warehouse = tb_account_warehouse.id', 'left');
        $this->db->join('mst_vendor', 'tb_request.id_supplier = mst_vendor.id', 'left');
        $get_data = $this->db->where(['tb_request.id' => $id])->group_by('tb_request.id')->get()->row();

        $this->app_data['data_request'] = $get_data;
        //get detail
        $this->db->select('
                            tb_request_has_product.*,
                            tb_product.code AS product_code,
                            tb_product.name AS product_name,
                            tb_product.qty_unit AS qty_unit,
                            tb_unit.name AS unit_name,
                            tb_product_has_conversion.name AS conversion_name,
                            tb_product_has_conversion.qty AS qty_conversion
                        ');
        $this->db->from('tb_request_has_product');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_request_has_product.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $get_data_detail = $this->db->where(['tb_request_has_product.id_request' => $id])->get()->result();
        $this->app_data['data_detail'] = $get_data_detail;

        $this->app_data['page_title'] = "Detail Pengadaan";
        $this->app_data['view_file'] = 'detail_request';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function cancel()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_supplier.name AS supplier_name
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_supplier', 'tb_request.id_supplier = tb_supplier.id', 'left');
        $get_data = $this->db->where(['tb_request.id' => $id])->group_by('tb_request.id')->get()->row();
        $this->app_data['data_request'] = $get_data;
        //get detail
        $this->db->select('
                            tb_request_has_product.*,
                            tb_product.code AS product_code,
                            tb_product.name AS product_name,
                            tb_product.qty_unit AS qty_unit,
                            tb_unit.name AS unit_name,
                            tb_product_has_conversion.name AS conversion_name,
                            tb_product_has_conversion.qty AS conversion_qty
                        ');
        $this->db->from('tb_request_has_product');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_request_has_product.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $get_data_detail = $this->db->where(['tb_request_has_product.id_request' => $id])->get()->result();
        $this->app_data['data_detail'] = $get_data_detail;

        $this->app_data['page_title'] = "Batalkan Pengadaan";
        $this->app_data['view_file'] = 'form_cancel';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function save_reject()
    {
        $id     = $this->input->post('id');
        $note   = $this->input->post('note');
        $array_update = [
            'status' => 2,
            'reject_note' => $note
        ];
        Modules::run('database/update', 'tb_request', ['id' => $id], $array_update);
        echo json_encode(['status' => TRUE]);
    }
    // public function get_edit()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $get_data = $this->model->find(array('id' => $id), 'tb_point')->row_array();
    //     echo json_encode($get_data);
    // }
    // public function update()
    // {
    //     $this->validate_insert();
    //     $id        = $this->input->post('id');
    //     $price     = $this->input->post('price');
    //     $point     = $this->input->post('point');
    //     $note      = $this->input->post('note');
    //     //insert data
    //     $array_update = array(
    //         'min_price' => $price,
    //         'point' => $point,
    //         'note' => $note,
    //         'updated_date' => date('Y-m-d H:i:s'),
    //         'updated_by' => $this->session->userdata('us_id')
    //     );
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
    // public function delete()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $this->model->delete(array('id' => $id), 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
}
