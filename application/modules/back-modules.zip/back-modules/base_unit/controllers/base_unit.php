<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Base_unit extends BackendController
{
    var $module_name        = 'base_unit';
    var $module_directory   = 'base_unit';
    var $module_js          = ['base_unit'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['page_title'] = "Master Base Unit";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        $get_all_data = $this->db->order_by('id', 'DESC')->get('tb_base_unit');
        $data = array();
        $no = 0;
        foreach ($get_all_data->result() as $data_table) {
            $btn_edit = Modules::run('security/edit_access', '<a class="btn btn-sm btn-rounded btn-warning-gradient" href="javascript:void(0)" title="Edit" onclick="edit_base_unit(' . "'" . $data_table->id . "'" . ')"><i class="fa fa-edit"></i> edit</a>');
            $btn_delete = Modules::run('security/edit_access', '<a class="btn btn-sm btn-rounded btn-danger-gradient" href="javascript:void(0)" title="Hapus" onclick="delete_base_unit(' . "'" . $data_table->id . "'" . ')"><i class="fa fa-trash"></i> delete</a>');
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();
        //insert data
        $name = $this->input->post('name');
        $array_insert = array(
            'name' => $name,
            'created_date' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/insert', 'tb_base_unit', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    public function get_edit($id)
    {
        $get_data = Modules::run('database/find', 'tb_base_unit', ['id' => $id])->row_array();
        echo json_encode($get_data);
    }
    public function update()
    {
        $this->validate_insert();
        $id         = $this->input->post('id');
        $name         = $this->input->post('name');

        //insert data
        $array_update = array(
            'name' => $name,
            'updated_date' => date('Y-m-d H:i:s'),
            'updated_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/update', 'tb_base_unit', ['id' => $id], $array_update);
        echo json_encode(array('status' => TRUE));
    }
    public function delete($id)
    {
        Modules::run('database/delete', 'tb_base_unit', ['id' => $id]);
        echo json_encode(array('status' => TRUE));
    }
}
