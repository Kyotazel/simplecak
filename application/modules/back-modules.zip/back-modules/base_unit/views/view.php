<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <div class="row">
            <div class="col-9">
                <h4>Data Base Unit</h4>
            </div>
            <div class="col-3 text-right">
                <?php
                $btn_add = Modules::run('security/create_access', '
                    <button type="button" id="add_button" title="add data" class="btn btn-primary-gradient btn-rounded pull-right" onclick="add_base_unit()">
                    <i class="fa fa-plus"></i> Tambah Data
                    </button>
                    ');
                echo $btn_add;
                ?>

            </div>
        </div>
    </div>
    <div class="card-body">
        <table id="table_user" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>




<div class="modal" id="modal_base_unit">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body">
                <form role="form" id="form_base_unit">
                    <input type="hidden" name="id">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="masukan nama..">
                            <span class="help-block text-danger"></span>
                        </div>
                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-lg btn-primary pull-right btn_save"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>