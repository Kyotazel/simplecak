<h2 class="mb-3 col-12">
    <span class="badge badge-light tx-20 badge-pill">NOMOR SO : <strong><?= $data_do->code; ?></strong></span>
</h2>
<div class="row" style="align-items:baseline;">
    <div class="col-md-4 row">
        <label for="" class="font-weight-bold text-uppercase col-12"><i class="fa fa-truck"></i> Nama Driver </label>
        <div class="row col-12 border-dashed">
            <div class="col">
                <div class=" mt-2 mb-2 text-primary text-uppercase"><b><?= $data_do->employee_name; ?></b></div>
                <p class="tx-12">
                </p>
            </div>
            <div class="col-auto align-self-center ">
                <div class="feature mt-0 mb-0">
                    <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                </div>
            </div>
        </div>
        <div class="p-2 border-dashed col-12">
            <small class="d-block">Transportasi :</small>
            <label for="" class="m-0 p-0 font-weight-bold tx-15"><?= $data_do->plat_nomor . ' - ' . $data_do->transport_name; ?></label>
        </div>
        <div class="p-2 border-dashed col-12">
            <small class="d-block">Tanggal Kirim :</small>
            <label for="" class="m-0 p-0 font-weight-bold tx-15"><?= Modules::run('helper/date_indo', $data_do->date, '-'); ?></label>
        </div>
    </div>
    <div class="col-md-8 ">
        <label for="" class="font-weight-bold text-uppercase"><i class="fa fa-tv"></i> Resume SO</label>
        <div class="row text-right">
            <div class="p-2 border-dashed col-4">
                <small>Jumlah SO : &nbsp;</small>
                <h3 class=" m-0 p-0 total_po"><?= $resume_so->count_invoice; ?> Invoice</h3>
            </div>
            <div class="p-2 border-dashed col-4">
                <small>Total Customer : &nbsp;</small>
                <h3 class="m-0 p-0 total_po"><?= $resume_so->count_customer; ?> Customer</h3>
            </div>
            <div class="p-2 border-dashed col-4">
                <small>Total Invoice : &nbsp;</small>
                <h3 class="m-0 p-0 total_po">Rp.<?= number_format($resume_so->total_invoice, 0, '.', '.'); ?></h3>
            </div>
            <div class="col-md-12 mt-3">

                <div class="text-right">
                    <small>(*klik untuk melihat detail)</small>
                    <a class="btn btn btn-primary-gradient btn-rounded" href="<?= Modules::run('helper/create_url', 'delivery_recapitulation/detail?data=' . urlencode($this->encrypt->encode($data_do->id))); ?>">Transaksi Setoran DO <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>