<style>
    .datepicker {
        z-index: 10000 !important;
    }
</style>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h3 class="col-8">Setoran Pengiriman</h3>
            <!-- <div class="col-4 text-right">
                <a href="<?= Modules::run('helper/create_url', 'delivery_order/add'); ?>" class="btn btn-primary-gradient btn-rounded"><i class="fa fa-plus-circle"></i> Tambah Transaksi Pengiriman</a>
            </div> -->
        </div>

    </div>

    <div class="card-body">
        <form action="" class="form-input">
            <div class="row mb-3 border-dashed p-3">
                <div class="col-md-2">
                    <label for="">Tanggal Awal</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                        </div>
                        <input class="form-control bg-white datepicker" name="date_from" readonly="" placeholder="pilih tanggal" type="text">
                    </div>
                </div>
                <div class="col-md-2">
                    <label for="">Tanggal Akhir</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                        </div>
                        <input class="form-control bg-white datepicker" name="date_to" readonly="" placeholder="pilih tanggal" type="text">
                    </div>
                </div>
                <div class="col-md-2">
                    <label for="">&nbsp;</label><br>
                    <button class="btn btn-rounded btn-primary-gradient btn_search_data"> <i class="fa fa-search"></i> Cari Data</button>
                </div>
            </div>
        </form>
        <div class="html_respon"></div>
    </div>
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:80%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>

            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>