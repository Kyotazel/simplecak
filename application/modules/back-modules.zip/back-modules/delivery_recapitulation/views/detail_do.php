<?php

$html_note_reject = '';

$array_status = [
    0 => '<label class="label label-warning">Menunggu Penerimaan</label>',
    1 => '<label class="label label-success">Telah Diterima</label>',
    2 => '<label class="label label-default">Dibatalkan</label>'
];

$array_print = [
    'list_so' => $list_so,
    'data_do' => $data_do
];

?>
<style>
    .datepicker {
        z-index: 1000 !important;
    }
</style>
<form class="form-do">
    <div class="row">
        <div class="col-4">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">Keterangan Pengiriman :</h3>
                </div>
                <div class="card-body">
                    <h2 class="mb-3 badge badge-light tx-20 badge-pill">NOMOR DO : <strong><?= $data_do->code; ?></strong></h2>
                    <div class="row">
                        <div class="form-group col-12">
                            <label for="">Driver</label>
                            <span class="d-block font-weight-bold p-2 border-dashed"><?= $data_do->employee_name; ?></span>
                        </div>
                        <div class="form-group col-12">
                            <label for="">Transport</label>
                            <span class="d-block font-weight-bold p-2 border-dashed"><?= $data_do->transport_name; ?></span>
                        </div>
                        <div class="form-group col-12">
                            <label for=""> Tanggal Kirim</label>
                            <span class="d-block font-weight-bold border-dashed p-2"><?= Modules::run('helper/change_date', $data_do->date, '-'); ?></span>
                        </div>
                    </div>
                    <div class="mt-3 text-center">
                        <?php
                        if ($data_do->is_checked) {
                            echo '
                                <div class="alert alert-success">
                                    <strong>Pengiriman Telah Selesai</strong>
                                </div>
                            ';
                        } else {
                            echo '
                                <a href="javascript:void(0)" data-id="' . $data_do->id . '" class="btn btn-primary-gradient btn-rounded font-weight-bold btn_update_delivery"><i class="fa fa-file"></i> Update Status (Pengiriman Selesai)</a>
                            ';
                        }
                        ?>

                    </div>
                </div>
            </div>

        </div>

        <div class="col-8 d-flex">
            <div class="card" style="width:100% ;">
                <div class="card-header bg-primary-gradient">
                    <h3 class="card-title text-white">Detail SO : </h3>
                </div>
                <div class="card-body">
                    <h2 class="mb-3"><span class="badge badge-light tx-20 badge-pill">Daftar SO Pengiriman</span> : <strong></strong> </h2>
                    <div class="row">
                        <div class="col-md-12 ">
                            <table class="table table-bordered table_detail_request">
                                <thead>
                                    <tr>
                                        <th style="width:5%;">No</th>
                                        <th style="width:70%;">SO</th>
                                        <th>Penerimaan DO</th>
                                    </tr>
                                </thead>
                                <tbody class="view_so_choose">
                                    <?php
                                    $array_payment = [
                                        1 => 'Cash',
                                        2 => 'transfer',
                                        3 => 'Buku Besar'
                                    ];
                                    $counter = 0;
                                    foreach ($list_so as $item_so) {
                                        $counter++;
                                        $array_query = [
                                            'select' => '
                                                    tb_sales.*,
                                                    mst_customer.code AS customer_code,
                                                    mst_customer.name AS customer_name,
                                                    mst_customer.address AS customer_address,
                                                ',
                                            'from' => 'tb_sales',
                                            'join' => [
                                                'mst_customer,tb_sales.id_member = mst_customer.id,left'
                                            ],
                                            'where' => [
                                                'tb_sales.id' => $item_so->id_sales
                                            ],
                                            'group_by' => 'tb_sales.id',
                                            'order_by' => 'tb_sales.id, DESC'
                                        ];

                                        if (!empty($list_exception)) {
                                            $array_query['where_not_in']['tb_sales.id'] = $list_exception;
                                        }

                                        $get_data = Modules::run('database/get', $array_query)->row();
                                        $data_po['reject_note'] = '';
                                        $data_po['data_so'] = $get_data;
                                        $html_po = $this->load->view('_partials/item_detail_do', $data_po, true);

                                        $html_confirm_payment  = '';
                                        if ($item_so->is_checked == 0 && $item_so->payment_price > 0) {
                                            $html_confirm_payment = '
                                            
                                                <div class="col-12">
                                                    <div class="col-12 border-dashed p-2 row">
                                                        <div class="col-12 mb-2">
                                                            <span class="badge badge-pill badge-light tx-15">Konfirmasi Pembayaran SO :</span>
                                                        </div>
                                                        <div class="col-4 border-right">
                                                            <small class="d-block">Dibayar Oleh :</small>
                                                            <label for="" class="m-0 font-weight-bold">' . $item_so->payment_by . '</label>
                                                        </div>
                                                        <div class="col-4 border-right">
                                                            <small class="d-block">Jenis Pembayaran :</small>
                                                            <label for="" class="m-0 font-weight-bold">' . $array_payment[$item_so->payment_type] . '</label>
                                                        </div>
                                                        <div class="col-4">
                                                            <small class="d-block">Nominal Bayar :</small>
                                                            <label for="" class="m-0 font-weight-bold">Rp.' . number_format($item_so->payment_price, 0, '.', '.') . '</label>
                                                        </div>
                                                        <div class="col-12 text-right mt-1">
                                                        <a href="javascript:void(0)" data-id="' . $item_so->id . '" class="btn btn-danger-gradient btn-rounded font-weight-bold btn_reject-payment"><i class="fa fa-times"></i> Tolak Pembayaran <i class="fa fa-send"></i></a>
                                                            <a href="javascript:void(0)" data-id="' . $item_so->id . '" class="btn btn-warning-gradient btn-rounded font-weight-bold btn_confirm-payment"><i class="fa fa-paper-plane"></i> Konfirmasi Pembayaran <i class="fa fa-send"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            ';
                                        }

                                        if ($item_so->is_checked == 1) {
                                            $html_confirm_payment = '
                                            
                                                <div class="col-12">
                                                    <div class="col-12 border-dashed p-2 row">
                                                        <div class="col-12 mb-2">
                                                            <span class="badge badge-pill badge-success tx-15">pembayaran Telah Dikonfirmasi</span>
                                                        </div>
                                                        <div class="col-4 border-right">
                                                            <small class="d-block">Dibayar Oleh :</small>
                                                            <label for="" class="m-0 font-weight-bold">' . $item_so->payment_by . '</label>
                                                        </div>
                                                        <div class="col-4 border-right">
                                                            <small class="d-block">Jenis Pembayaran :</small>
                                                            <label for="" class="m-0 font-weight-bold">' . $array_payment[$item_so->payment_type] . '</label>
                                                        </div>
                                                        <div class="col-4">
                                                            <small class="d-block">Nominal Bayar :</small>
                                                            <label for="" class="m-0 font-weight-bold">Rp.' . number_format($item_so->payment_price, 0, '.', '.') . '</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            ';
                                        }

                                        if ($item_so->is_checked == 2) {
                                            $html_confirm_payment = '
                                            
                                                <div class="col-12">
                                                    <div class="col-12 border-dashed p-2 row">
                                                        <div class="col-12 mb-2">
                                                            <span class="badge badge-pill badge-danger tx-15">Pembayaran Ditolak</span>
                                                        </div>
                                                        <div class="col-4 border-right">
                                                            <small class="d-block">Dibayar Oleh :</small>
                                                            <label for="" class="m-0 font-weight-bold">' . $item_so->payment_by . '</label>
                                                        </div>
                                                        <div class="col-4 border-right">
                                                            <small class="d-block">Jenis Pembayaran :</small>
                                                            <label for="" class="m-0 font-weight-bold">' . $array_payment[$item_so->payment_type] . '</label>
                                                        </div>
                                                        <div class="col-4">
                                                            <small class="d-block">Nominal Bayar :</small>
                                                            <label for="" class="m-0 font-weight-bold">Rp.' . number_format($item_so->payment_price, 0, '.', '.') . '</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            ';
                                        }


                                        echo '
                                                <tr>
                                                    <td>' . $counter . '</td>
                                                    <td>
                                                        ' . $html_po . '
                                                        ' . $html_confirm_payment . '
                                                    </td>
                                                    <td>
                                                            <span class="badge badge-light tx-20 badge-pill">Penerimaan : </span>
                                                            <div class="p-2 border-dashed col-12">
                                                                <small>Diterima Oleh : &nbsp;</small>
                                                                <label class=" m-0 p-0 total_po d-block tx-15 font-weight-bold">' . $item_so->received_by . '</label>
                                                            </div>
                                                            <div class="p-2 border-dashed col-12">
                                                            <small>Tanggal Diterima : &nbsp;</small>
                                                            <label class=" m-0 p-0 total_po d-block tx-15 font-weight-bold">' . Modules::run('helper/change_date', $item_so->received_date, '-') . '</label>
                                                            </div>
                                                            <div class="p-2 border-dashed col-12">
                                                                <small>Catatan Penerimaan : &nbsp;</small>
                                                                <p>' . $item_so->additional_note . '</p>
                                                            </div>
                                                            
                                                    </td>
                                                </tr>
                                            ';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="min-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Member</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>