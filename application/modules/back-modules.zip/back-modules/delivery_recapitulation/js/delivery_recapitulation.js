url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';

var save_method;



var save_method;

var table_receive;

var table_reject;

var id_use;

$(document).ready(function () {

    // table_receive = $('.table_receive').DataTable({
    //     "ajax": {
    //         "url": url_controller + "/list_data",
    //         "type": "POST"
    //     }
    // });
    search_data();
    $('.chosen').chosen();
});


$(document).on('click', '.btn_search_data', function (e) { 
    e.preventDefault();
    search_data();
});


function search_data() {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    var formData = new FormData($('.form-input')[0]);

    $.ajax({
        url: url_controller + "list_data_request",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                $('.html_respon').html(data.html_respon);
                $(document).find('.table_request').DataTable();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });
}

function reload_table(){

     table.ajax.reload(null,false); //reload datatable ajax 

}


$(document).on('click', '.btn_choose_so', function () { 
    showLoading();
    var list_so = [];
    $(document).find('.view_so_choose').find('[name="so_choose[]"]').each(function () { 
        var id = $(this).val();
        list_so.push(id); 
    });
    $.ajax({
        url: url_controller+'list_so'+'/?token='+_token_user,
        type: "POST",
        data:{'list_so':list_so},
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('#modal-form').modal('show');
                $('.html_respon_modal').html(data.html_respon);
                $(document).find('.table_request').DataTable(); 
            }
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }

    });//end ajax
});

$(document).on('click', '.btn_choose', function () { 
    var id = $(this).data('id');
    var html_detail = $(document).find('.html_detail_so_' + id).html();
    $(document).find('.tr_so_choose_' + id).remove();
    $(document).find('.view_so_choose').append(`
        <tr class="tr_so_choose_`+id+`">
            <td>
                `+ html_detail +`
                <div class="col-12 mt-2 text-right">
                    <a href="javascript:void(0)" class="btn btn-light btn_cancel_so"><i class="fa fa-times"></i> Batal</a>
                </div>
            </td>
        </tr>
    `);
    $(this).closest('tr').remove();
});



$(document).on('click', '.btn_confirm-payment', function () { 
    var id = $(this).data('id');
    swal({
        title: "Apakah anda yakin ?",
        text: 'Pembayaran akan Dikonfirmasi',
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {

            showLoading();
            // swal.showLoading();
            $('.form-group').removeClass('has-danger');
            $('.help-block').empty();
            // save_method = $(this).data('method');

            $.ajax({
                url: url_controller+'save_payment/?token='+_token_user,
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function (data) {
                    hideLoading();
                    if(data.status){
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil disimpan",
                            type: "success"
                        });
                        location.reload();
                    }
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    hideLoading();
                    $('.btn_save_group').button('reset');
                }
            });//end ajax

        }
    });
});

$(document).on('click', '.btn_reject-payment', function () { 
    var id = $(this).data('id');
    swal({
        title: "Apakah anda yakin ?",
        text: 'Pembayaran Ditolak',
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {

            showLoading();
            // swal.showLoading();
            $('.form-group').removeClass('has-danger');
            $('.help-block').empty();
            // save_method = $(this).data('method');

            $.ajax({
                url: url_controller+'reject_payment/?token='+_token_user,
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function (data) {
                    hideLoading();
                    if(data.status){
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil disimpan",
                            type: "success"
                        });
                        location.reload();
                    }
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    hideLoading();
                    $('.btn_save_group').button('reset');
                }
            });//end ajax

        }
    });
});


$(document).on('click', '.btn_update_delivery', function () { 
    var id = $(this).data('id');
    swal({
        title: "Apakah anda yakin ?",
        text: 'status pengiriman telah selesai',
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {

            showLoading();
            // swal.showLoading();
            $('.form-group').removeClass('has-danger');
            $('.help-block').empty();
            // save_method = $(this).data('method');

            $.ajax({
                url: url_controller+'update_status_delivery/?token='+_token_user,
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function (data) {
                    hideLoading();
                    if(data.status){
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil disimpan",
                            type: "success"
                        });
                        location.reload();
                    }
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    hideLoading();
                    $('.btn_save_group').button('reset');
                }
            });//end ajax

        }
    });
});


$(document).on('click', '.bt_save', function (e) {
    e.preventDefault();
    id = $(this).data('id');
    var status = $(this).data('status');
    
 
    swal({
        title: "Apakah anda yakin ?",
        text: 'Pastikan Data Telah benar',
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {

            showLoading();
            // swal.showLoading();
            $('.form-group').removeClass('has-danger');
            $('.help-block').empty();
            // save_method = $(this).data('method');
              //defined form
            var formData = new FormData($('.form-do')[0]);
            $.ajax({
                url: url_controller+'save/?token='+_token_user,
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function (data) {
                    hideLoading();
                    if(data.status){
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil disimpan",
                            type: "success"
                        });
                        location.href = url_controller + 'detail?data=' + data.id;
                    }
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    hideLoading();
                    $('.btn_save_group').button('reset');
                }
            });//end ajax

        }
    });
});






$(document).on('click', '.btn_add_receive', function () {

    $('.modal-title').text('TAMBAH DATA');

    $('.btn_add_receive');

    $.ajax({

        url: url_controller + '/get_request',

        type: "POST",

        dataType: "JSON",

        success: function (data) {

            $('.html_respon_modal').html(data.html_respon);

            $('#modal-form').modal('show');

            $('.table_add_request').DataTable();

            $('.btn_add_receive');

        },

        error: function (jqXHR, textStatus, errorThrown) {

            $('.btn_add_receive');

            alert_error('something wrong');

        }

    });//end ajax

});


$('.count_total_price').keyup(function () {
    var counter = parseInt($('.grand_total_price').data('counter'));
    var counter_class = 0;

    var grand_total = 0;

    for (let i = 0; i < counter; i++) {
        counter_class++;
        // if ($('.update_status').prop('checked')) {
        //     var conversion_qty  = parseInt($('.qty_conversion_'+counter_class).val());
        //     var new_main_price = parseInt(delete_dot_value($('.new_main_price_' + counter_class).val()));
        //     var price_use = conversion_qty * new_main_price;
        // }else{

        // }


        var price_use = parseInt(delete_dot_value($('.price_use_' + counter_class).val()));
        qty_use = parseInt(delete_dot_value($('.qty_use_' + counter_class).val()));
        total_current = price_use * qty_use;
        grand_total += total_current;

    }

    // // var transport_price = $('[name="transport_price"]').val() =='' ? String(0) : $('[name="transport_price"]').val();

    // var tax_price = $('[name="tax_price"]').val() =='' ? String(0) : $('[name="tax_price"]').val();

    // // var other_price = $('[name="other_price"]').val() == '' ? String(0) : $('[name="other_price"]').val();

    // var discount = $('[name="discount_price"]').val() == '' ? String(0) : $('[name="discount_price"]').val();

    // // grand_total = grand_total + parseInt(delete_dot_value(transport_price)) + parseInt(delete_dot_value(tax_price)) + parseInt(delete_dot_value(other_price));

    // grand_total = grand_total + parseInt(delete_dot_value(tax_price));

    

    // if (parseInt(delete_dot_value(discount)) > grand_total) {

    //     $('[name="discount_price"]').val(0);

    // } else {

    //     grand_total = grand_total - parseInt(delete_dot_value(discount));

    // }



    $('.grand_total_price').html('Rp.' + money_function(String(grand_total), ''));

    $('[name="grand_total"]').val(grand_total);

});



// $('.update_status').change(function(){

//     $('.count_total_price').keyup();

// });



$(document).on('keyup', '.price_receive', function () {

    count_total();

    count_hpp();

});



var grand_total = 0;

var sub_total = 0;

var ppn_price = 0;

function count_total() {

    sub_total = 0;

    grand_total = 0;

    ppn_price = 0;



    $(document).find('.price_receive').each(function () { 

        var price = $(this).val();

        var qty = parseInt($(this).data('qty'));



        price = parseInt(delete_dot_value(price));

        sub_total += (price * qty);

    });

    var ppn_value = $('.subttotal-ppn').data('ppn');

    if (ppn_value > 0) {

        ppn_price = sub_total * (ppn_value / 100);

    }

    grand_total = ppn_price + sub_total;

    $('.subttotal-po').text('Rp.' + money_function(sub_total.toString()));

    $('.subttotal-ppn').text('Rp.' + money_function(ppn_price.toString()));

    $('.total_po').text('Rp.' + money_function(grand_total.toString()));
    $('[name="total_correction"]').val(money_function(grand_total.toString()));

}



$(document).on('keyup', '.qty_receive', function () { 

    var value = $(this).val();

    var qty_default = $(this).data('qty');

    var id = $(this).data('id');



    var interval = parseInt(value) - parseInt(qty_default);

    $('.qty_interval_' + id).text(interval);

    count_hpp();

});



function count_hpp() {
    var ongkir = delete_dot_value($('[name="ongkir"]').val());
    var type = $('[name="ongkir_type"]').val();
    if (type == 2) {
        ongkir = 0;
    }

    total_qty = 0;

    $('.qty_receive').each(function () { 

        total_qty += parseInt($(this).val());

    });

    var ongkir_per_item = parseInt(ongkir) > 0 ? (ongkir / total_qty) : 0;

    $('.price_receive').each(function () {

        id = $(this).data('id');

        var new_price = parseInt(delete_dot_value($(this).val()));

        var hpp_price = Math.round(ongkir_per_item)+ new_price;

        $('.hpp_receive_' + id).val(hpp_price); 

    });

}



$('[name="ongkir"]').keyup(function () {

    count_hpp();

});

$('[name="ongkir_type"]').change(function () { 

    count_hpp();

});





$('.btn_save_receive').click(function (e) {

    e.preventDefault();

    var id = $(this).data('id');

    $(this);

    $('.form-group').removeClass('has-error');

    $('.help-block').empty();

    $('.modal-title').text('KOREKSI KEMBALI');

    //defined form
    var html_resume = $(document).find('.html_resume').html();
    var formData = new FormData($('.form-receive')[0]);
    formData.append('html_resume', html_resume);
    formData.append('id', id);

    var url;

    $.ajax({

        url: url_controller + '/preview_receive',

        type: "POST",

        data: formData,

        contentType: false,

        processData: false,

        dataType: "JSON",

        success: function (data) {

            if (data.status) {

                $('.html_respon_modal').html(data.html_respon);

                $('#modal-form').modal('show');

                $('.datepicker_today').datepicker({

                    autoclose: true,

                    format: 'dd-mm-yyyy',

                    startDate: new Date()

                });

                // notif_success('data berhasil disimpan');

                // window.location.href = url_controller+'/detail?data='+data.id

            } else {

                for (var i = 0; i < data.inputerror.length; i++) {

                    if (data.inputerror[i] == 'payment' || data.inputerror[i] == 'grand_total') {

                        $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');

                        if (data.inputerror[i] == 'grand_total') {

                            $('.' + data.inputerror[i]).text(data.error_string[i]);

                        } else {

                            $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);

                        }

                    

                    } else {

                        $('[name="' + data.inputerror[i] + '"]').parent().parent().addClass('has-error');

                        $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);

                        //qty tr

                        $('.' + data.inputerror[i]).text(data.error_string[i]);

                    }

	            

                    if (data.inputerror[i] == 'qty_product') {

                        alert_error('data produk belum dipilih');

                    }

                }

            }

            $('.btn_save_receive');

        },

        error: function (jqXHR, textStatus, errorThrown) {

            $('.btn_save_receive');

            alert_error('something wrong');

        }

    });//end ajax

});



$(document).on('click', '.btn_save', function (e) {

    e.preventDefault();

    var id = $(this).data('id');

    $(this);

    $('.form-group').removeClass('has-error');

    $('.help-block').empty();

    //defined form

    var formData = new FormData($('.form-receive')[0]);

    formData.append('id', id);



    swal({

        title: "Apakah anda yakin?",

        text: "data akan Disimpan!",

        type: "warning",

        showCancelButton: true,

        confirmButtonClass: "btn-danger",

        confirmButtonText: "Ya , Lanjutkan",

        cancelButtonText: "Batal",

        closeOnConfirm: true,

        closeOnCancel: true

    },

        function (isConfirm) {

            if (isConfirm) {

                showLoading();

                $.ajax({

                    url: url_controller + '/save_receive',

                    type: "POST",

                    data: formData,

                    contentType: false,

                    processData: false,

                    dataType: "JSON",

                    success: function (data) {

                        hideLoading();

                        if (data.status) {

                            // $('.html_respon_modal').html(data.html_respon);

                            $('#modal-form').modal('hide');

                            notif_success('data berhasil disimpan');

                            window.location.href = url_controller + '/detail?data=' + data.id

                        } else {

                            for (var i = 0; i < data.inputerror.length; i++) {

                                $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');

                                $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);

                                //qty tr

                                $('.' + data.inputerror[i]).text(data.error_string[i]);

        

                                if (data.inputerror[i] == 'qty_product') {

                                    alert_error('data produk belum dipilih');

                                }

                            }

                        }

                        $('.btn_save');

                    },

                    error: function (jqXHR, textStatus, errorThrown) {

                        hideLoading();

                        alert_error('something wrong');

                    }

                });//end ajax

            }

        });







});



$(document).on("change", ".checkbox_status", function () {

    var id = $(this).val();

    if ($(this).prop('checked')) {

        status_active = 1;

    }else{

        status_active = 0;

    }

    $.ajax({

        url: url_controller+'/update_status',

        type: "POST",

        data: {'status':status_active,'id':id},

        dataType :"JSON",

        success: function(data){

                notif_success('status berhasil diupdate');

        },

        error:function(jqXHR, textStatus, errorThrown)

        {

            $('.btn_save');

            alert_error('something wrong');

        }

    });//end ajax

});



$(document).on('click', '.btn_edit', function () {

    var id = $(this).data('id');

    $('.modal-title').text('UPDATE DATA');

    $('.form-input')[0].reset();

	save_method = 'update';

	var PostData = {'id':id};

	$.ajax({

	    url: url_controller+'/get_edit',

	    type: "POST",

	    data: PostData,

	    dataType :"JSON",

        success: function (data) {

            id_use = data.id;  

            $('[name="price"]').val(data.min_price);

            $('[name="point"]').val(data.point);

            $('[name="note"]').val(data.note);

	      	$('#modal-form').modal('show'); 

	        $('.btn_save');

	    },

	      error:function(jqXHR, textStatus, errorThrown)

	      {

	       $('.btn_save');

	       alert_error('something wrong');

	      }

	  });//end ajax

});



$(document).on('click', '.btn_remove', function () {

    var id = $(this).data('id');

    Swal.fire({

        title: 'Apakah anda yakin?',

        text: "data ini akan dihapus",

        type: 'warning',

        showCancelButton: true,

        confirmButtonColor: '#3085d6',

        cancelButtonColor: '#d33',

        confirmButtonText: 'Ya,hapus data',

        cancelButtonText: 'Batal'

    }).then((result) => {

        if (result.value) {

            $.ajax({

                url: url_controller+'/delete',

                type: "POST",

                data: {'id':id},

                dataType :"JSON",

                success: function(data){

                    $('#modal-form').modal('hide'); 

                    notif_success('data berhasil dihapus');

                    reload_table();

                    $('.btn_remove');

                },
                error:function(jqXHR, textStatus, errorThrown)

                {

                    $('.btn_remove');

                    alert_error('something wrong');

                }

            });//end ajax

        }

    })

})





$(document).on('keyup', '.number_only', function () {

    var qty = $(this).val();

    var clean_word = qty.replace(/[^,\d]/g, '');

    $(this).val(clean_word);

})



$(document).on('keyup', '.money_only', function () {

    var qty = $(this).val();

    var clean_word = qty.replace(/[^,\d]/g, '');

    var money = money_function(qty, '');

    $(this).val(money);

})



function money_function(angka, prefix) {

    

    var number_string = angka.replace(/[^,\d]/g, '').toString(),

        split = number_string.split(','),

        sisa = split[0].length % 3,

        rupiah = split[0].substr(0, sisa),

        ribuan = split[0].substr(sisa).match(/\d{3}/gi);



    if (ribuan) {

        separator = sisa ? '.' : '';

        rupiah += separator + ribuan.join('.');

    }



    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;

    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');

    return rupiah;

}



function to_money(angka, prefix) {

    

    var number_string = angka,

        split = number_string.split(','),

        sisa = split[0].length % 3,

        rupiah = split[0].substr(0, sisa),

        ribuan = split[0].substr(sisa).match(/\d{3}/gi);



    if (ribuan) {

        separator = sisa ? '.' : '';

        rupiah += separator + ribuan.join('.');

    }



    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;

    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');

    return rupiah;

}



function delete_dot_value(value) {

    var array_value = value.split('.');

    var count_array = array_value.length;

    payment_value = value;

    for (var i = 0; i < count_array; i++) {

        payment_value = payment_value.replace('.', '');

    };

    return payment_value;

}



$(document).on('keyup', '.number_only', function () {

    var qty = $(this).val();

    var clean_word = qty.replace(/[^,\d]/g, '');

    $(this).val(clean_word);

});





// function money_function(angka, prefix) {

//     var number_string = angka.replace(/[^,\d]/g, '').toString(),

//     split = number_string.split(','),

//     sisa = split[0].length % 3,

//     rupiah = split[0].substr(0, sisa),

//     ribuan = split[0].substr(sisa).match(/\d{3}/gi);



// if (ribuan) {

//     separator = sisa ? '.' : '';

//     rupiah += separator + ribuan.join('.');

// }



// rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;

// return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');

// }

