<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Delivery_recapitulation extends BackendController
{
    var $module_name        = 'delivery_recapitulation';
    var $module_directory   = 'delivery_recapitulation';
    var $module_js          = ['delivery_recapitulation', 'print'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "SALES INVOICE";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = 'tb_delivery';
        $simbol = 'DO';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function list_data_request()
    {

        $date_from = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $id_customer = $this->input->post('id_customer');
        $status = $this->input->post('status');

        $array_where = [];
        $array_where_in = [];

        $array_where['tb_delivery.is_checked'] = 0;

        if ($date_from) {
            $array_where['tb_delivery.date >='] = $date_from;
        }
        if ($date_to) {
            $array_where['tb_delivery.date <='] = $date_to;
        }
        // if ($id_customer) {
        //     $array_where_in['tb_sales.id_member'] = $id_customer;
        // }
        // if ($status) {
        //     $array_where['tb_sales.status'] = $status;
        // }


        $array_query = [
            'select' => '
                tb_delivery.*,
                mst_employee.name AS employee_name,
                mst_transport.plat_nomor,
                mst_transport.nama_transport AS transport_name
            ',
            'from' => 'tb_delivery',
            'join' => [
                'mst_employee, tb_delivery.id_driver = mst_employee.id, left',
                'mst_transport, tb_delivery.id_transport = mst_transport.id, left'
            ]
        ];

        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }

        $get_data = Modules::run('database/get', $array_query)->result();

        $data_po['data_so'] = $get_data;
        $html_po = $this->load->view('view_search_result', $data_po, true);

        echo json_encode(['status' => TRUE, 'html_respon' => $html_po]);
    }

    public function save_payment()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_delivery_so = Modules::run('database/find', 'tb_delivery_has_so', ['id' => $id])->row();
        $get_so = Modules::run('database/find', 'tb_sales', ['id' => $get_delivery_so->id_sales])->row();
        $get_credit = Modules::run('database/find', 'tb_credit', ['id_transaction' => $get_delivery_so->id_sales])->row();

        $description = '
            konfirmasi pembayaran SO ( ' . $get_so->code . ' )
        ';

        $data_payment = [
            'id_credit' => $get_credit->id,
            'payment_type' => $get_delivery_so->payment_type,
            'price' => $get_delivery_so->payment_price,
            'note' => $description
        ];
        Modules::run('credit/insert_payment', $data_payment);

        //update payment
        Modules::run('database/update', 'tb_delivery_has_so', ['id' => $get_delivery_so->id], [
            'is_checked' => 1,
            'checked_by' => $this->session->userdata('us_id')
        ]);

        //respon
        echo json_encode(['status' => TRUE]);
    }

    public function reject_payment()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        Modules::run('database/update', 'tb_delivery_has_so', ['id' => $id], [
            'is_checked' => 2,
            'checked_by' => $this->session->userdata('us_id')
        ]);

        //respon
        echo json_encode(['status' => TRUE]);
    }

    public function update_status_delivery()
    {
        Modules::run('security/is_ajax');
        $id_delivery = $this->input->post('id');
        Modules::run('database/update', 'tb_delivery', ['id' => $id_delivery], [
            'is_checked' => 1,
            'checked_by' => $this->session->userdata('us_id')
        ]);

        //so
        $get_so = Modules::run('database/find', 'tb_delivery_has_so', ['id_delivery' => $id_delivery])->result();
        foreach ($get_so as $item_so) {
            $status = 1;
            if ($item_so->is_checked == 1) {
                $status = 3;
            }
            Modules::run('database/update', 'tb_sales', ['id' => $item_so->id_sales], [
                'status' => $status
            ]);
        }

        //respon
        echo json_encode(['status' => TRUE]);
    }




    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $array_query = [
            'select' => '
                tb_delivery.*,
                mst_employee.name AS employee_name,
                mst_transport.plat_nomor,
                mst_transport.nama_transport AS transport_name
            ',
            'from' => 'tb_delivery',
            'join' => [
                'mst_employee, tb_delivery.id_driver = mst_employee.id, left',
                'mst_transport, tb_delivery.id_transport = mst_transport.id, left'
            ],
            'where' => [
                'tb_delivery.id' => $id
            ]
        ];
        $main_data = Modules::run('database/get', $array_query)->row();

        $this->app_data['data_do'] = $main_data;
        $this->app_data['list_so'] = Modules::run('database/find', 'tb_delivery_has_so', ['id_delivery' => $id])->result();

        $this->app_data['page_title'] = "Detail Delivery Order";
        $this->app_data['view_file'] = 'detail_do';
        echo Modules::run('template/main_layout', $this->app_data);
    }
}
