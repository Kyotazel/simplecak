var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';

var save_method;
var table_paid;
var table_has_paid;
var id_use;
var total_debit_general = 0;
var total_credit_general = 0;
var table_cashout;
var table_cashin;
var table_transfer;
$(document).ready(function(){

    // table_cashout= $('.table_cashout').DataTable({
    //     "ajax": {
    //         "url": url_controller+"/list_cashout"+'/?token='+_token_user,
    //         "type": "POST"
    //     }
    // });
    if ($('.html_respon_cash_in').length) {
        list_cash_in();    
    }

    if ($('.html_respon_cash_transfer').length) {
        list_cash_transfer();    
    }

    if ($('.html_respon_cash_out').length) {
        list_cash_out();    
    }

    decide_date();
    $('.chosen').chosen();

});


$(document).on('click', '.btn_search_cash_in', function (e) { 
    e.preventDefault();
    list_cash_in();
});
// cash
function list_cash_in() {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-search-cash-in')[0]);
      var url;
      $.ajax({
        url: url_controller+'/list_cashin'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            hideLoading();
            if(data.status){
                $('.html_respon_cash_in').html(data.html_respon);
                $('.table-cash').DataTable(
                    {
                        "columns": [
                            { "width": "5%" },
                            { "width": "15%" },
                            { "width": "45%" },
                            { "width": "15%" },
                        ],
                        "lengthMenu": [[50, 100, 500, -1], [50, 100, 500, "All"]]
                    }
                );
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
}


$(document).on('click', '.btn_search_cash_transfer', function (e) { 
    e.preventDefault();
    list_cash_transfer();
});
// cash
function list_cash_transfer() {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-search-cash-transfer')[0]);
      var url;
      $.ajax({
        url: url_controller+'/list_transfer'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            hideLoading();
            if(data.status){
                $('.html_respon_cash_transfer').html(data.html_respon);
                $('.table-cash').DataTable(
                    {
                        "columns": [
                            { "width": "5%" },
                            { "width": "15%" },
                            { "width": "45%" },
                            { "width": "15%" },
                        ],
                        "lengthMenu": [[50, 100, 500, -1], [50, 100, 500, "All"]]
                    }
                );
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
}

$(document).on('click', '.btn_search_cash_out', function (e) { 
    e.preventDefault();
    list_cash_out();
});
// cash
function list_cash_out() {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-search-cash-out')[0]);
      var url;
      $.ajax({
        url: url_controller+'/list_cashout'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            hideLoading();
            if(data.status){
                $('.html_respon_cash_out').html(data.html_respon);
                $('.table-cash').DataTable(
                    {
                        "columns": [
                            { "width": "5%" },
                            { "width": "15%" },
                            { "width": "45%" },
                            { "width": "15%" },
                        ],
                        "lengthMenu": [[50, 100, 500, -1], [50, 100, 500, "All"]]
                    }
                );
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
}



function reload_table(){
    table_cashout.ajax.reload(null, false); //reload datatable ajax 
    table_cashin.ajax.reload(null, false); //reload datatable ajax 
    table_transfer.ajax.reload(null,false); //reload datatable ajax 
}

$('[name="period"]').change(function () {
    decide_date();
})

function decide_date() {
    if($('.datepicker_custom').length){
        $(".datepicker_custom").datepicker("destroy");
        $('.datepicker_custom').val('');
        var period = $('[name="period"]').val();
        var split_period = period.split('/');  

        $('.datepicker_custom').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy',
            startDate: split_period[0],
            endDate: split_period[1]
        });
    }
}


$('[name="type"]').change(function(){
    var value_current = $(this).val();
    if(value_current==1){
        $('.form-account').show();
        $('.form-transaction').hide();
    }else{
        $('.form-account').hide();
        $('.form-transaction').show();
    }
});

$('.btn_search').click(function (e) {
    e.preventDefault();
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-input')[0]);
      var url;
      $.ajax({
        url: url_controller+'/search_data'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            hideLoading();
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
                $('.table-journal').DataTable(
                    {
                        "columns": [
                            { "width": "5%" },
                            null,
                            null,
                            null,
                            { "width": "30%" },
                            { "width": "10%" },
                            { "width": "10%" }
                        ],
                        "lengthMenu": [[50, 100, 500, -1], [50, 100, 500, "All"]]
                    }
                );
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
  });


$(document).on('click', '.btn_view_transaction', function () { 
    showLoading();
    var token   = $(this).data('token');
    var account = $(this).data('account'); 
    $.ajax({
        url: url_controller+'/view_detail_token'+'/?token='+_token_user,
        type: "POST",
        data: {'token':token,'account':account},
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.html_respon_detail').html(data.html_respon);
                $('#modal-form-detail').modal('show');
            } 
        },
            error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});


$('.btn_add_journal').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
    var formData = new FormData($('.form-input')[0]);
    var url;
    $.ajax({
        url: url_controller+'/add_item'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('Ditambahkan');
                $('.text_empty_data').parent().remove();
                $('.tbody_item').append(data.html_respon);
                count_total();
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                }
            }
            $('.btn_add_journal');
        },
            error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_add_journal');
            alert_error('something wrong');
        }
    });//end ajax
});



function count_total(){
    var total_debit = 0;
    $("input[name='price_debit[]']").each(function() {
        var debit_current = $(this).val();
        total_debit += parseInt(debit_current);
    });

    var total_credit = 0;
    $("input[name='price_credit[]']").each(function() {
        var credit_current = $(this).val();
        total_credit += parseInt(credit_current);
    });

    $('.text-debit').text(money_function(String(total_debit,'Rp.')));
    $('.text-credit').text(money_function(String(total_credit,'Rp.')));

    total_credit_general = total_credit;
    total_debit_general = total_debit;
}

$(document).on('click','.btn_cancel_item',function(){
    $(this).parent().parent().remove();
    count_total();
});


$('.btn-save').click(function (e) {
    if(total_debit_general != total_credit_general || total_credit_general==0 || total_debit_general==0){
        swal(
            
            'DEBIT & KREDIT HARUS SAMA',
            'Total Debit & Kredit Harus Sama dan data tidak boleh kosong',
            'warning'
            );

    }else{
        e.preventDefault();
        $(this);
        $('.form-group').removeClass('has-error');
        $('.help-block').empty();  
          //defined form
          var html_data = $('.table_data_journal').html();
          var formData = new FormData($('.form-input')[0]);
          formData.append('html_data',html_data);
          var url;
          $.ajax({
            url: url_controller+'/preview_save_journal'+'/?token='+_token_user,
            type: "POST",
            data: formData,
            contentType: false,
            processData : false,
            dataType :"JSON",
            success: function(data){
                if(data.status){
                    $('.html_respon_modal').html(data.html_respon);
                    $('#modal_form').modal('show');
                } else{
                    for (var i = 0; i < data.inputerror.length; i++)
                    {
                       $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                       $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                   }
               }
               $('.btn-save');
           },
           error:function(jqXHR, textStatus, errorThrown)
           {
            $('.btn-save');
            alert_error('something wrong');
        }
        });//end ajax
      }
  });

$(document).on('click','.btn_do_save',function(e){
    e.preventDefault();

    swal({
        title: 'Apakah anda yakin?',
        text: "data ini akan disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, lanjutkan',
        cancelButtonText: 'Batal'
    },function(isConfirm) {
        if (isConfirm) {
            $(this);
            $('.form-group').removeClass('has-error');
            $('.help-block').empty();  
              //defined form
              var formData = new FormData($('.form-input')[0]);
              var url;
              $.ajax({
                url: url_controller+'/save_journal'+'/?token='+_token_user,
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function(data){
                    if(data.status){
                        alert_success('Berhasil Disimpan');

                        $('.form-input')[0].reset();
                        $('.tbody_item').empty();
                        $('#modal_form').modal('hide');
                        count_total();
                        
                    } else{
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                           $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                           $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                       }
                   }
                   $('.btn_do_save');
               },
               error:function(jqXHR, textStatus, errorThrown)
               {
                $('.btn_do_save');
                alert_error('something wrong');
            }
            });//end ajax
          }
      })
});

//-------------------------------------------------------------- ledger book --------------------------------------------------------------------------------
$('.btn_search_ledger').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    var id_period = $('[name="period"]').find(":selected").data('id')

    
      //defined form
    var formData = new FormData($('.form-input')[0]);
    formData.append('id_period', id_period);
      var url;
      $.ajax({
        url: url_controller+'/search_data_ledger'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
                $('.table-journal').DataTable({
                    "lengthMenu": [[50, 100, 500, -1], [50, 100, 500, "All"]]
                });
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'account') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            $('.btn_search_ledger');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_search_ledger');
            alert_error('something wrong');
        }
    });//end ajax
});
  
//----------------------------------------------------------- profit loss -----------------------------------------------------------------------------------------------
$('.btn_search_profit_lost').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-input')[0]);
      var url;
      $.ajax({
        url: url_controller+'/search_profit_lost'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
                $('.table-journal').DataTable();
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            $('.btn_search_profit_lost');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_search_profit_lost');
            alert_error('something wrong');
        }
    });//end ajax
  });

  //------------------------------------------------------------- trial balance ----------------------------------------------------------------------------

  $('.btn_search_trial_balance').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    
    var id_period = $('[name="period"]').find(":selected").data('id')
      //defined form
      var formData = new FormData($('.form-input')[0]);
      formData.append('id_period', id_period);
      var url;
      $.ajax({
        url: url_controller+'/search_trial_balance'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
                $('.table-journal').DataTable();
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            $('.btn_search_trial_balance');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_search_trial_balance');
            alert_error('something wrong');
        }
    });//end ajax
  });

  //------------------------------------------------------------- balance sheet ----------------------------------------------------------------------------
  $('.btn_search_balance_sheet').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var id_period = $('[name="period"]').find(":selected").data('id')
      var formData = new FormData($('.form-input')[0]);
      formData.append('id_period', id_period);
      var url;
      $.ajax({
        url: url_controller+'/search_balance_sheet'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
                $('.table-journal').DataTable();
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            $('.btn_search_balance_sheet');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_search_balance_sheet');
            alert_error('something wrong');
        }
    });//end ajax
  });

  //-------------------------------------------------- monthly recapitulation -----------------------------------------------------------------------

//   $(document).on('click', '.btn_remove', function () {
//     var id = $(this).data('id');
//     swal({
//         title: 'Apakah anda yakin?',
//         text: "data ini akan dihapus",
//         type: 'warning',
//         showCancelButton: true,
//         confirmButtonColor: '#3085d6',
//         cancelButtonColor: '#d33',
//         confirmButtonText: 'Ya,hapus data',
//         cancelButtonText: 'Batal'
//     },function(isConfirm) {
//         if (isConfirm) {
//             $.ajax({
//                 url: url_controller + '/delete',
//                 type: "POST",
//                 data: { 'id': id },
//                 dataType: "JSON",
//                 success: function (data) {
//                     $('#modal-form').modal('hide');
//                     alert_success('data berhasil dihapus');
//                     reload_table();
//                     $('.btn_remove');
//                 },
//                 error: function (jqXHR, textStatus, errorThrown) {
//                     $('.btn_remove');
//                     alert_error('something wrong');
//                 }
//             });//end ajax
//         }
//     })
//   });

$('.btn_monthly_recapitulation').click(function (e) {
    e.preventDefault();
    swal({
        title: 'Apakah anda yakin?',
        text: "data rekapitulasi akan disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    },function(isConfirm) {
        if (isConfirm) {
            $(this);
            $('.form-group').removeClass('has-error');
                $('.help-block').empty();  
                $('.html_respon_error').empty();
                //defined form
                var formData = new FormData($('.form-input')[0]);
                var url;
                $.ajax({
                url: url_controller+'/do_monthly_recapitulation'+'/?token='+_token_user,
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function(data){
                    if(data.status){
                        swal(
                            'Berhasil!',
                            'Data rekapitulasi berhasil tersimpan!',
                            'success'
                        );
                    } else{
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            if (data.inputerror[i] == 'error') {
                                $('.html_respon_error').html(data.error_string[i]);
                            } else {
                                $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                                $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                            }
                        }
                    }
                    $('.btn_monthly_recapitulation');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_monthly_recapitulation');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});

$(document).on('click', '.btn_update_resume', function (e) {
    e.preventDefault();
    swal({
        title: 'Apakah anda yakin?',
        text: "data rekapitulasi akan disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    },function(isConfirm) {
        if (isConfirm) {
            $(this);
            $('.form-group').removeClass('has-error');
                $('.help-block').empty();  
                $('.html_respon_error').empty();
                //defined form
            var formData = new FormData($('.form-input')[0]);
            formData.append('status_update', true);
                var url;
                $.ajax({
                url: url_controller+'/do_monthly_recapitulation'+'/?token='+_token_user,
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function(data){
                    if(data.status){
                        notif_success('Data berhasil disimpan');
                    } else{
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            if (data.inputerror[i] == 'error') {
                                $('.html_respon_error').html(data.error_string[i]);
                            } else {
                                $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                                $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                            }
                        }
                    }
                    $('.btn_update_resume');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_update_resume');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});

$('.btn_monthly_search_recapitulation').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-input')[0]);
      var url;
      $.ajax({
        url: url_controller+'/search_monthly_recapitulation'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            $('.btn_monthly_search_recapitulation');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_monthly_search_recapitulation');
            alert_error('something wrong');
        }
    });//end ajax
  });


  $(document).on('click', '.btn_yearly_recapitulation', function (e) {
    e.preventDefault();
    swal({
        title: 'Apakah anda yakin?',
        text: "Pastikan saldo telah balance, Saldo awal akan dirubah sesuai saldo neraca akhir periode",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    },function(isConfirm) {
        if (isConfirm) {
            $(this);
            $('.form-group').removeClass('has-error');
                $('.help-block').empty();  
                $('.html_respon_error').empty();
                //defined form
            var formData = new FormData($('.form-input')[0]);
                var url;
                $.ajax({
                url: url_controller+'/do_yearly_recapitulation'+'/?token='+_token_user,
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function(data){
                    if(data.status){
                        swal(
                            'Berhasil!',
                            'Data rekapitulasi berhasil tersimpan!',
                            'success'
                        );
                    } else{
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            if (data.inputerror[i] == 'error') {
                                $('.html_respon_error').html(data.error_string[i]);
                            } else {
                                $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                                $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                            }
                        }
                    }
                    $('.btn_yearly_recapitulation');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_yearly_recapitulation');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});


$(document).on('click', '.btn_update_resume_yearly', function (e) {
    e.preventDefault();
    swal({
        title: 'Apakah anda yakin?',
        text: "data rekapitulasi akan disimpan"+'/?token='+_token_user,
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    },function(isConfirm) {
        if (isConfirm) {
            $(this);
            $('.form-group').removeClass('has-error');
                $('.help-block').empty();  
                $('.html_respon_error').empty();
                //defined form
            var formData = new FormData($('.form-input')[0]);
            formData.append('status_update', true);
                var url;
                $.ajax({
                url: url_controller+'/do_yearly_recapitulation'+'/?token='+_token_user,
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function(data){
                    if(data.status){
                        notif_success('Data rekapitulasi berhasil tersimpan!');
                    } else{
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            if (data.inputerror[i] == 'error') {
                                $('.html_respon_error').html(data.error_string[i]);
                            } else {
                                $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                                $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                            }
                        }
                    }
                    $('.btn_update_resume_yearly');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_update_resume_yearly');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});

$('.btn_check_balance').click(function () {
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-input')[0]);
      var url;
      $.ajax({
        url: url_controller+'/check_balance_sheet'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            $('.btn_check_balance');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_check_balance');
            alert_error('something wrong');
        }
    });//end ajax
});

$('.btn_monthly_search_recapitulation_yearly').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
      //defined form
      var formData = new FormData($('.form-input')[0]);
      var url;
      $.ajax({
        url: url_controller+'/search_yearly_recapitulation'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                alert_success('pencarian Selesai');
                $('.html_respon').html(data.html_respon);
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    if (data.inputerror[i] == 'price') {
                        $('.notif_'+data.inputerror[i]).parent().addClass('has-error');
                        $('.notif_'+data.inputerror[i]).text(data.error_string[i]);
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);   
                    }
                }
            }
            $('.btn_monthly_search_recapitulation_yearly');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_monthly_search_recapitulation_yearly');
            alert_error('something wrong');
        }
    });//end ajax
});



$(document).on('click', '.btn_edit_token', function () { 
    var token = $(this).data('token');
    showLoading();
    $.ajax({
        url: url_controller+'/get_edit_journal'+'/?token='+_token_user,
        type: "POST",
        data: {'token':token},
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.html_respon_update_journal').html(data.html_respon);
                $('#modal-form-edit').modal('show');
            }

            $(document).find('.chosen').chosen();

            $(document).find('.datepicker_form').each(function () { 
                value = $(this).val();
                $(this).datepicker({
                    autoclose: true,
                    format: 'dd-mm-yyyy',
                    setDate:value
                });
                // $(this).val(value);
                
            });

            
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
    });//end ajax
});

$(document).on('click', '.btn_add_form', function () { 
    var type = $(this).data('type');
    showLoading();
    $.ajax({
        url: url_controller+'/create_form_input'+'/?token='+_token_user,
        type: "POST",
        data: {'type':type},
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                if (type == 'debit') {
                    $('.html_from_debit').append(data.html_respon);
                } else {
                    $('.html_from_credit').append(data.html_respon);
                }
            } 
            $('.datepicker_form').datepicker({
                autoclose: true,
                format: 'dd-mm-yyyy'
            });
            $(document).find('.chosen').chosen();
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
    });//end ajax
});

$(document).on('keyup', '.price_debit', function () { 
    count_price_total_price_edit();
});
$(document).on('keyup', '.price_credit', function () { 
    count_price_total_price_edit();
});

function count_price_total_price_edit() {
    var total_debit = 0;
    var total_credit = 0;
    $(document).find('.price_debit').each(function () { 
        var selector = $(this);
        if(selector.val() !=''){    
            value = parseInt(clear_dot_value(selector.val()));
            total_debit += value;
        }
    });
    $(document).find('.price_credit').each(function () { 
        var selector = $(this);
        if (selector.val() != '') {    
            value = parseInt(clear_dot_value(selector.val()));
            total_credit += value;
        }
    });

    $(document).find('.text_total_debit').text('Rp.' + money_function(total_debit.toString()));
    $(document).find('.text_total_debit').data('price', total_debit);
    $(document).find('.text_total_credit').text('Rp.' + money_function(total_credit.toString()));
    $(document).find('.text_total_credit').data('price', total_credit);
}

$(document).on('click', '.btn_delete_item', function () { 
    $(this).closest('.media').remove();
    count_price_total_price_edit();
});

$(document).on('click', '.btn_save_update_journal', function () {

    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    var selector_btn = $(this);

    var total_debit     = $(document).find('.text_total_debit').data('price'); 
    var total_credit = $(document).find('.text_total_credit').data('price');
    if (parseInt(total_credit) != parseInt(total_debit)) {
        alert_error('total debit & kredit harus sama');
        return false;
    }

    if (total_credit == 0 || total_debit == 0) {
        alert_error('total debit & kredit tidak boleh 0');
        return false;
    }

    var status_err = 0;
    $(document).find('.money_only').each(function () { 
        selector = $(this);
        if (selector.val() == '') {
            status_err++;
        }
    });
    if (status_err > 0) {
        alert_error('lengkapi form nominal yang belum terisi');
        return false;
    }

    var status_err = 0;
    $(document).find('[name="date_debit[]"]').each(function () { 
        selector = $(this);
        if (selector.val() == '') {
            status_err++;
        }
    });
    $(document).find('[name="date_credit[]"]').each(function () { 
        selector = $(this);
        if (selector.val() == '') {
            status_err++;
        }
    });
    if (status_err > 0) {
        alert_error('lengkapi form tanggal yang belum terisi');
        return false;
    }

    var status_err = 0;
    $(document).find('[name="desc_debit[]"]').each(function () { 
        selector = $(this);
        if (selector.val() == '') {
            status_err++;
        }
    });
    $(document).find('[name="desc_credit[]"]').each(function () { 
        selector = $(this);
        if (selector.val() == '') {
            status_err++;
        }
    });
    if (status_err > 0) {
        alert_error('lengkapi form deskripsi yang belum terisi');
        return false;
    }
    showLoading();
    var token   = selector_btn.data('token');
    var type = $('[name="type"]').val(); 
      //defined form
    var formData = new FormData($('.form-update-journal')[0]);
    formData.append('token', token);
    formData.append('type', type);
    var url;
    $.ajax({
        url: url_controller+'/update_journal',
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('#modal-form-edit').modal('hide');
                notif_success('Berhasil disimpan');
                if (data.status_save == 'add') {
                    location.href = url_controller;
                } else {
                    $('.btn_search').click();
                }
                
            } 
        
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_delete_token', function (e) {
    e.preventDefault();
    token = $(this).data('token');
    swal({
        title: 'Apakah anda yakin?',
        text: "data jurnal akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    },function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: url_controller+'/remove_journal'+'/?token='+_token_user,
                type: "POST",
                data: {'token':token},
                dataType :"JSON",
                success: function(data){
                    if(data.status){
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil Dihapus",
                            type: "success"
                        });

                        $('.tr_' + token).hide();
                    } 
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});

  
//---------------------------------------------------------- cash out -------------------------------------------------------------------------------------

$('.btn_save_cashout').click(function (e) {
    e.preventDefault();
    $(this);
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
    var status = $(this).data('status');
      //defined form
    var formData = new FormData($('.form-input')[0]);
    formData.append('status', status);
      var url;
      $.ajax({
        url: url_controller+'/save_cash_out'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function(data){
            if(data.status){
                $('#modal_form_cash_out').modal('hide');
                alert_success('data berhasil disimpan');

                if ($('.html_respon_cash_in').length) {
                    list_cash_in();
                }
                if ($('.html_respon_cash_out').length) {
                    list_cash_out();
                }
                if ($('.html_respon_cash_transfer').length) {
                    list_cash_transfer();
                }
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    $('.notif_'+data.inputerror[i]).addClass('has-error');
                    $('.notif_' + data.inputerror[i]).text(data.error_string[i]);   
                    if (data.inputerror[i] == 'arr_debit_account') {
                        alert_error('Item akun tujuan belum diisi');
                    }
                }
            }
            $('.btn_save_cashout');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_save_cashout');
            alert_error('something wrong');
        }
    });//end ajax
  });

$('.btn_add_cashout').click(function () {
    $(".chosen").val('').trigger("chosen:updated");
    $('.btn_save');
    save_method = 'add';
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('.form-input')[0].reset();
    $('.modal-title').text('TAMBAH DATA');
    $('#modal_form_cash_out').modal('show');
});


$(document).on('click', '.btn_add_item_cashout', function () { 
    var price = $('[name="price"]').val();
    var description = $('[name="description"]').val();
    var name_account = $('[name="debit_account"]').find(':selected').data('name');
    var id_account = $('[name="debit_account"]').find(':selected').data('id');

    if (price == '') {
        alert_error('nominal belum diisi');
        return false;
    }
    if (description == '') {
        alert_error('deskripsi belum diisi');
        return false;
    }
    if (id_account == '') {
        alert_error('akun belum dipilih');
        return false;
    }

    var html_item = `
        <tr class="item">
            <td>
                <input name="arr_debit_account[]" type="hidden" value="`+ id_account +`">
                <input name="arr_debit_price[]" type="hidden" value="`+ price +`">
                <input name="arr_debit_desc[]" type="hidden" value="`+ description +`">
                <span class="badge badge-light tx-16">`+name_account+`</span>
            </td>
            <td>
                Rp.`+price+`
            </td>
            <td>`+description+`</td>
            <td>
                <a class="btn btn-rounded btn-danger-gradient btn-sm text-white btn_remove_cashout_item"><i class="fa fa-trash"></i></a>
            </td>
        </tr>
    `;

    $('[name="price"]').val('');
    $('[name="description"]').val('');
    $('[name="debit_account"]').val('').trigger("chosen:updated");

    $('.tr_empty').hide();
    $('.html_add_item').append(html_item);
});

$(document).on('click', '.btn_remove_cashout_item', function () { 
    $(this).closest('tr').remove();
    if ($('.html_add_item').find('.item').length == false) {
        $('.tr_empty').show();
    }
});

$(document).on('click', '.btn_remove_cash', function () {
    var id = $(this).data('id');
    var code = $(this).data('code');
    swal({
        title: 'Apakah anda yakin?',
        text: "data ini akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,hapus data',
        cancelButtonText: 'Batal'
    },function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: url_controller+'/delete_cash'+'/?token='+_token_user,
                type: "POST",
                data: {'id':id,'code':code},
                dataType :"JSON",
                success: function(data){ 
                    notif_success('data berhasil dihapus');
                    if ($('.html_respon_cash_in').length) {
                        list_cash_in();
                    }
                    if ($('.html_respon_cash_out').length) {
                        list_cash_out();
                    }
                    if ($('.html_respon_cash_transfer').length) {
                        list_cash_transfer();
                    }

                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_remove_cash');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

$(document).on('click', '.empty_form', function () {
    var name = $(this).data('name');
    $('[name="' + name + '"]').val('');
});


$(document).on('keyup', '.money_only', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
})

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}
function clear_dot_value(value) {
    var array_value = value.split('.');
    var count_array = array_value.length;
    payment_value = value;
    for (var i = 0; i < count_array; i++) {
        payment_value = payment_value.replace('.', '');
    };
    return payment_value;
}