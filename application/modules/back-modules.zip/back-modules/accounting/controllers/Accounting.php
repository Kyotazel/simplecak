<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Accounting extends BackendController
{

    var $module_name = 'accounting';
    var $module_directory = 'accounting';
    var $module_js = ['accounting'];
    var $app_data = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']  = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = $this->tb_name;
        $simbol = 'SP';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from $db_name ")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function index()
    {
        // $array_transaction = [
        //     1 => 'BOL (Bill Of lading)',
        //     2 => 'pembayaran invoice',
        //     3 => 'operasional pembongkaran',
        //     4 => 'operasional lainnya',
        //     5 => 'Pembayaran Piutang',
        //     6 => 'Pembayaran Hutang',
        //     7 => 'Transaksi hutang',
        //     8 => 'input Pengeluaran',
        //     9 => 'kas masuk',
        //     10 => 'kas keluar',
        //     11 => 'kas transfer',
        //     12 => 'tutup buku bulanan',
        //     13 => 'tutup buku tahunan',
        //     14 => 'manual'

        // ];
        // print_r(json_encode($array_transaction));
        // exit;

        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;

        $accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value);
        $this->app_data['account_transaction'] = $accounting_transaction;
        $this->app_data['data_period'] = $this->db->get('tb_book_period')->result();

        $this->app_data['page_title']     = "Jurnal Umum";
        $this->app_data['view_file']     = 'view_general_journal';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    private function validate_search()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date_from') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_from';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    private function change_date($date)
    {
        $explode_date = explode('-', $date);
        $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
        return $date_return;
    }

    public function search_data()
    {
        $this->validate_search();
        $date_to     = $this->change_date($this->input->post('date_to'));
        $date_from     = $this->change_date($this->input->post('date_from'));
        $type         = $this->input->post('type');
        $account     = $this->encrypt->decode($this->input->post('account'));
        $transaction = $this->encrypt->decode($this->input->post('transaction'));


        $array_where = [
            'date >=' => $date_from,
            'date <=' => $date_to
        ];

        $type_name = '';
        $array_where_in = [];

        $data['account_search'] = false;
        $array_list_token = [];
        if ($type == 1) {
            if (!empty($account)) {
                // $get_account_current = $this->db->where(['id' => $account])->get('tb_book_account')->row();
                // $type_name = $get_account_current->type_account . '-' . $get_account_current->code . ' ' . $get_account_current->name;
                // if ($get_account_current->id_parent == 0) {
                //     //get data sub acount
                //     $array_where['tb_book_account.id_parent'] = $account;
                // } else {
                //     // $array_where['tb_book_account_has_detail.id_book_account'] = $account;
                // }

                $get_token_list = $this->db->select('token')->where($array_where)->where('id_book_account', $account)->get('tb_book_account_has_detail')->result();

                $array_list_token[] = 0;
                foreach ($get_token_list as $item_token) {
                    $array_list_token[] = $item_token->token;
                }

                $array_where_in['tb_book_account_has_detail.id_book_account'] = $array_list_token;
                $data['account_search'] = true;
            } else {
                $get_token_list = $this->db->where($array_where)->group_by('token')->get('tb_book_account_has_detail')->result();
                $array_list_token[] = 0;
                foreach ($get_token_list as $item_token) {
                    $array_list_token[] = $item_token->token;
                }
            }
        } else {
            if (!empty($transaction)) {
                $array_where['tb_book_account_has_detail.status_act'] = $transaction;
                $accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value, TRUE);
                $type_name = $accounting_transaction[$transaction];
            }

            $get_token_list = $this->db->where($array_where)->group_by('token')->get('tb_book_account_has_detail')->result();
            $array_list_token[] = 0;
            foreach ($get_token_list as $item_token) {
                $array_list_token[] = $item_token->token;
            }
        }

        $data['array_spesification'] = [
            'date_from' => $this->input->post('date_from'),
            'date_to' => $this->input->post('date_to'),
            'type' => $type,
            'type_name' => $type_name
        ];

        if (!empty($array_list_token)) {
            $this->db->from('tb_book_account_has_detail')
                ->select('
			tb_book_account_has_detail.*,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
                ->join('tb_book_account', 'tb_book_account_has_detail.id_book_account = tb_book_account.id', 'left')
                ->where_in('tb_book_account_has_detail.token', $array_list_token)
                ->order_by('tb_book_account_has_detail.token');

            $get_data = $this->db->get()->result();
        } else {
            $get_data = [];
        }

        $accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value, TRUE);
        $data['account_transaction'] = $accounting_transaction;

        $data['data_journal'] = $get_data;
        $html_respon = $this->load->view('view_search_result', $data, TRUE);


        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function view_detail_token()
    {
        Modules::run('security/is_ajax');

        $token      = $this->input->post('token');
        $account    = $this->input->post('account');

        $this->db->from('tb_book_account_has_detail')
            ->select('
                tb_book_account_has_detail.*,
                tb_book_account.type_account,
                tb_book_account.code AS account_code,
                tb_book_account.name AS account_name
                ')
            ->join('tb_book_account', 'tb_book_account_has_detail.id_book_account = tb_book_account.id', 'left')
            ->where(['tb_book_account_has_detail.token' => $token])
            ->order_by('tb_book_account_has_detail.id');

        $get_data = $this->db->get()->result();
        $data['token']          = $token;
        $data['account_id']     = $account;
        $data['data_detail']    = $get_data;
        $html_respon = $this->load->view('view_detail_token', $data, TRUE);

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function get_edit_journal()
    {
        $token = $this->input->post('token');
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $data['data_account'] = $get_account;

        $array_where = ['tb_book_account_has_detail.token' => $token];
        $this->db->from('tb_book_account_has_detail')
            ->select('
			tb_book_account_has_detail.*,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account', 'tb_book_account_has_detail.id_book_account = tb_book_account.id', 'left')
            ->where($array_where);
        $get_data = $this->db->get()->result();
        $data['data_journal'] = $get_data;
        $data['token'] = $token;
        $html_respon = $this->load->view('form_edit_journal', $data, TRUE);
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function create_form_input()
    {
        $type = $this->input->post('type');
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $html_option = '';
        foreach ($get_account as $item_account) {
            $selected = '';
            $html_option .=  '
                            <option ' . $selected . ' value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                        ';
        }
        $suffix = $type == 'debit' ? 'debit' : 'credit';
        $html_respon = '
            <div class="media mb-1">
                <div class="media-body">
                    <div class="row">
                        <div class="col-12 p-0">
                            <label for="" class="m-0 font-weight-bold">Masukan COA dan keterangan jurnal : </label>
                        </div>
                        <div class="col-12 p-0">
                            <select name="account_' . $suffix . '[]" class="form-control chosen" >' . $html_option . '</select>
                        </div>
                        <div class="col-6 p-0">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="width: 50px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control price_' . $suffix . ' money_only" name="price_' . $suffix . '[]"  placeholder="masukan nominal">
                            </div>
                        </div>
                        <div class="col-6 p-0">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="width: 50px;"><i class="fa fa-calendar"></i></div>
                                </div>
                                <input type="text" data-language="en" class="form-control datepicker_form bg-white" readonly name="date_' . $suffix . '[]" placeholder="Pilih tanggal transaksi" value="' . date('d-m-Y') . '">
                            </div>
                        </div>
                        <div class="col-12 p-0">
                            <textarea name="desc_' . $suffix . '[]" class="form-control" placeholder="ketik deskripsi..." rows="2"></textarea>
                        </div>
                        <div class="col-12 text-right p-0">
                            <a href="javascript:void(0)" class="btn btn-danger btn-sm btn_delete_item"><i class="fa fa-trash"></i> Hapus</a>
                        </div>
                    </div>
                </div>
            </div>
        ';
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function update_journal()
    {
        Modules::run('security/is_ajax');
        $account_debit = $this->input->post('account_debit');
        $price_debit = $this->input->post('price_debit');
        $date_debit = $this->input->post('date_debit');
        $desc_debit = $this->input->post('desc_debit');

        $account_credit = $this->input->post('account_credit');
        $price_credit = $this->input->post('price_credit');
        $date_credit = $this->input->post('date_credit');
        $desc_credit = $this->input->post('desc_credit');
        $token = $this->input->post('token');
        $type = $this->input->post('type');

        if ($token > 0) {
            $get_current_data = $this->db->where(['token' => $token])->get('tb_book_account_has_detail')->row();
            $id_transaction = $get_current_data->id_transaction;
            $status_act = $get_current_data->status_act;
            //update data
            Modules::run('database/delete', 'tb_book_account_has_detail', ['token' => $token]);
            $status_save = 'update';
        } else {
            //add data
            $token = time();
            $status_save = 'add';
            $status_act = 14;
            $id_transaction = 0;
        }

        //insert new value
        foreach ($account_debit as $key => $item_debit) {
            $price = str_replace('.', '', $price_debit[$key]);

            $array_insert = [
                'id_book_account' => $this->encrypt->decode($account_debit[$key]),
                'id_transaction' => $id_transaction,
                'date' => Modules::run('helper/change_date', $date_debit[$key], '-'),
                'description' => $desc_debit[$key],
                'debit' => $price,
                'token' => $token,
                'status_act' => $status_act
            ];

            if ($type > 0) {
                $array_insert['status_journal'] = $type;
            }

            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        foreach ($account_credit as $key => $item_credit) {
            $price = str_replace('.', '', $price_credit[$key]);

            $array_insert = [
                'id_book_account' => $this->encrypt->decode($account_credit[$key]),
                'id_transaction' => $id_transaction,
                'date' => Modules::run('helper/change_date', $date_credit[$key], '-'),
                'description' => $desc_credit[$key],
                'credit' =>  $price,
                'token' => $token,
                'status_act' => $status_act
            ];
            if ($type > 0) {
                $array_insert['status_journal'] = $type;
            }
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        //get response
        echo json_encode(['status' => TRUE, 'status_save' => $status_save]);
    }

    public function add()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent>' => 0])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;

        $accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value);
        $this->app_data['account_transaction'] = $accounting_transaction;

        $this->app_data['page_title']     = "Tambah Jurnal Umum";
        $this->app_data['view_file']     = 'view_add_journal';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_add_item()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->encrypt->decode($this->input->post('account')) == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'account';
            $data['status'] = FALSE;
        }
        if ($this->input->post('description') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'description';
            $data['status'] = FALSE;
        }

        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function add_item()
    {
        $this->validate_add_item();

        $account = json_decode($this->encrypt->decode($this->input->post('account')));
        $description = $this->input->post('description');
        $price = str_replace('.', '', $this->input->post('price'));
        $type_insert = $this->input->post('type_insert');

        // print_r($account);
        // exit;
        $credit = '';
        $debit = '';
        if ($type_insert == 1) {
            $debit = number_format($price, 0, '.', '.');
            $class_name = 'price_debit[]';
        } else {
            $credit = number_format($price, 0, '.', '.');;
            $class_name = 'price_credit[]';
            $account->name = '<span style="margin-left:10px">' . $account->name . '</span>';
        }

        $array_data = [
            'id_book_account' => $account->id,
            'description' => $description,
            'date' => date('Y-m-d'),
            'debit' => str_replace('.', '', $debit),
            'credit' => str_replace('.', '', $credit)
        ];

        $html_respon = '
            <tr>
                <td>
                    <input type="hidden" name="data[]" value="' . $this->encrypt->encode(json_encode($array_data)) . '">
                    <input type="hidden" name="' . $class_name . '" value="' . $price . '">
                    ' . $account->code_account . '
                </td>
                <td>' . $account->name . '</td>
                <td>' . $description . '</td>
                <td>' . $debit . '</td>
                <td>' . $credit . '</td>
                <td>
                    <a href="javascript:void(0)" class="btn btn-danger btn-sm btn_cancel_item"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
		';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function preview_save_journal()
    {
        $this->validate_save_journal();
        $html_data = $_POST['html_data'];
        $search_link = '<a href="javascript:void(0)" class="btn btn-danger btn-sm btn_cancel_item"><i class="fa fa-close"></i></a>';
        $html_data = str_replace($search_link, '', $html_data);

        $html_respon = '
		<div class="col-md-12">' . $html_data . '</div>
		<div class="col-md-12 text-right">
		<small>(*klik untuk simpan data)</small>
		<a href="javascript:void(0)" class="btn btn-success btn_do_save"><i class="fa fa-send"></i> Lanjutkan Simpan Data </a>
		</div>
		';

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    private function validate_save_journal()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->encrypt->decode($this->input->post('account')) == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'account';
            $data['status'] = FALSE;
        }

        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_journal()
    {
        $date = $this->change_date($this->input->post('date'));
        $type_journal = $this->encrypt->decode($this->input->post('type_journal'));
        $array_data = $this->input->post('data');
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        foreach ($array_data as $item_data) {
            $item_current = json_decode($this->encrypt->decode($item_data));
            $item_current->created_by = $this->session->userdata('us_id');
            $item_current->date = $date;
            $item_current->token = $token;
            $item_current->status_journal = $type_journal;

            Modules::run('database/insert', 'tb_book_account_has_detail', $item_current);
        }

        echo json_encode(['status' => TRUE]);
    }

    public function remove_journal()
    {
        Modules::run('security/is_ajax');
        $token = $this->input->post('token');
        Modules::run('database/delete', 'tb_book_account_has_detail', ['token' => $token]);
        echo json_encode(['status' => TRUE]);
    }

    //-------------------------------------------------------------------------- ledger book ----------------------------------------------------------------------------------

    public function ledger_book()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent >' => 0, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;

        $this->app_data['data_period'] = $this->db->get('tb_book_period')->result();

        // $data['view_file']      = "view_ledger_book";
        // $data['title']          = "Buku Besar"; // untuk header pada bagian atas data
        // $data['subtitle']       = "Buku Besar"; // untuk subtitle pada bagian atas data
        // $data['module']         = $this->module; //variable module untuk di controller template/media   
        // $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        // $data['page_title']     = 'Buku Besar'; // untuk title pada tab 

        // echo modules::run('template/media_admin', $data);

        $this->app_data['page_title']     = "Buku Besar";
        $this->app_data['view_file']     = 'view_ledger_book';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_search_data_ledger()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date_from') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_from';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }
        if (empty($this->input->post('account'))) {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'account';
            $data['status'] = FALSE;
        }


        if (!empty($this->input->post('date_from')) && !empty($this->input->post('date_to'))) {
            if (strtotime($this->input->post('date_to')) < strtotime($this->input->post('date_from'))) {
                $data['error_string'][] = 'tanggal akhir harus lebih besar';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function search_data_ledger()
    {
        $this->validate_search_data_ledger();

        $id_period = $this->input->post('id_period');
        $date_from  = $this->change_date($this->input->post('date_from'));
        $date_to    = $this->change_date($this->input->post('date_to'));
        $list_account_search    = $this->input->post('account');

        $balance_sheet_account   = json_decode($this->db->where(['params' => 'balance_sheet_account'])->get('app_module_setting')->row()->value);
        $list_account   = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);

        $start_period   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        //get data account current 
        $html_respon = '';
        foreach ($list_account_search as $item_account) {
            $account        = $this->encrypt->decode($item_account);
            $account_current   = Modules::run('database/find', 'tb_book_account', ['id' => $account])->row();
            $data['account_name'] = $account_current->type_account . '-' . $account_current->code . ' ' . $account_current->name;
            $data['account_search'] = $account_current;

            $get_account_current    = $this->db->where(['id' => $account,])->get('tb_book_account')->row();
            $get_saldo_account      = $this->db->where(['id_book_account' => $account, 'id_period' => $id_period])->get('tb_book_period_has_saldo')->row();
            $saldo_account          = !empty($get_saldo_account) ? $get_saldo_account->saldo : 0;
            //get period current 
            $period = $this->db->where(['id' => $id_period])->get('tb_book_period')->row();

            $first_saldo = 0;
            $status_saldo  = false;
            $current_type_account = $list_account[$get_account_current->type_account]['type_saldo'];
            if (in_array($get_account_current->type_account, $balance_sheet_account)) {

                $get_saldo = $this->db
                    ->select('
                            SUM(credit) AS credit_saldo,
                            SUM(debit) AS debit_saldo
                        ')
                    ->where(['date >' => $period->date_from, 'date < ' => $date_from, 'id_book_account' => $account])
                    ->get('tb_book_account_has_detail')->row();

                $debit_first_saldo  = $get_saldo->debit_saldo ? $get_saldo->debit_saldo : 0;
                $credit_first_saldo = $get_saldo->credit_saldo ? $get_saldo->credit_saldo : 0;
                $status_saldo = TRUE;
                $first_saldo = $current_type_account == 'debit' ? $debit_first_saldo - $credit_first_saldo : $credit_first_saldo - $debit_first_saldo;
            }

            $first_saldo += $saldo_account;


            $data['array_spesification'] = [
                'date_from' => $this->input->post('date_from'),
                'date_to' => $this->input->post('date_to'),
                'account' => $get_account_current->type_account . '-' . $get_account_current->code . ' ' . $get_account_current->name,
                'type_saldo' => $current_type_account,
                'status_saldo' => $status_saldo
            ];

            $data['array_saldo'] = [
                'type_saldo' => $current_type_account,
                'first_saldo' => $first_saldo,
                'status_saldo' => $status_saldo,
                'account_name' => $get_account_current->name
            ];

            $array_where = [
                'date >=' => $date_from,
                'date <=' => $date_to,
                'tb_book_account_has_detail.id_book_account' => $account
            ];

            $this->db->from('tb_book_account_has_detail')
                ->select('
			tb_book_account_has_detail.*,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
                ->join('tb_book_account', 'tb_book_account_has_detail.id_book_account = tb_book_account.id', 'inner')
                ->where($array_where);
            $get_data = $this->db->get()->result();
            $data['data_journal'] = $get_data;
            $html_respon .= $this->load->view('view_search_result_ledger', $data, TRUE);
        }

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    //---------------------------------------------------- profit AND LOST ---------------------------------------------------------------------

    public function profit_lost()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent >' => 0])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $this->app_data['data_period'] = $this->db->get('tb_book_period')->result();

        // $data['view_file']      = "view_profit_lost";
        // $data['title']          = "LAPORAN LABA RUGI"; // untuk header pada bagian atas data
        // $data['subtitle']       = "LAPORAN LABA RUGI"; // untuk subtitle pada bagian atas data
        // $data['module']         = $this->module; //variable module untuk di controller template/media   
        // $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        // $data['page_title']     = 'LAPORAN LABA RUGI'; // untuk title pada tab 

        // echo modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "LAPORAN LABA RUGI";
        $this->app_data['view_file']     = 'view_profit_lost';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_search_profit_lost()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('date_from') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_from';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }

        if (!empty($this->input->post('date_from')) && !empty($this->input->post('date_to'))) {
            if (strtotime($this->input->post('date_to')) < strtotime($this->input->post('date_from'))) {
                $data['error_string'][] = 'tanggal akhir harus lebih besar';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }


    public function search_profit_lost()
    {
        $this->validate_search_profit_lost();
        $date_from  = $this->change_date($this->input->post('date_from'));
        $date_to    = $this->change_date($this->input->post('date_to'));
        // $account    = $this->encrypt->decode($this->input->post('account'));

        $data['array_date'] = [
            'date_from' => $this->input->post('date_from'),
            'date_to' => $this->input->post('date_to')
        ];


        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            (SUM(credit) - SUM(debit)) AS total_saldo,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.status_journal = 0 AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0,
                    'tb_book_account.type_account' => 4
                ]
            )
            ->group_by('tb_book_account.id');
        $get_data_profit = $this->db->get()->result();
        $data['data_profit'] = $get_data_profit;


        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            (SUM(debit) - SUM(credit)) AS total_saldo,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.status_journal = 0 AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0,
                    'tb_book_account.type_account' => 6
                ]
            )
            ->group_by('tb_book_account.id');
        $get_data_hpp = $this->db->get()->result();
        $data['data_hpp'] = $get_data_hpp;

        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            (SUM(debit) - SUM(credit)) AS total_saldo,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.status_journal = 0 AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0,
                    'tb_book_account.type_account' => 5
                ]
            )
            ->group_by('tb_book_account.id');
        $get_cost = $this->db->get()->result();

        $data['data_cost'] = $get_cost;

        $html_respon = $this->load->view('view_search_result_profit_loss', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    //------------------------------------------------------------------------------ Trial balance  ----------------------------------------------------------------
    public function trial_balance()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent >' => 0])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $this->app_data['start_period']   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->app_data['data_period'] = $this->db->get('tb_book_period')->result();

        // echo modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "NERACA SALDO (TRIAL BALANCE)";
        $this->app_data['view_file']     = 'view_trial_balance';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_search_trial_balance()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }

        if (!empty($this->input->post('date_from')) && !empty($this->input->post('date_to'))) {
            if (strtotime($this->input->post('date_to')) < strtotime($this->input->post('date_from'))) {
                $data['error_string'][] = 'tanggal akhir harus lebih besar';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }


    public function search_trial_balance()
    {
        $this->validate_search_trial_balance();
        $period = explode('/', $this->input->post('period'));
        $id_period = $this->input->post('id_period');
        // print_r($_POST);
        // exit;
        $date_from  = $period[0];
        $date_to    = $this->change_date($this->input->post('date_to'));
        // $account    = $this->encrypt->decode($this->input->post('account'));

        $data['array_date'] = [
            'date_from' => $this->change_date($date_from),
            'date_to' => $this->input->post('date_to')
        ];
        $data['array_first_saldo'] = $this->get_fist_saldo_period($id_period);

        // print_r($data['array_first_saldo']);
        // exit;

        $this->db->from('tb_book_account')
            ->select('
            CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            tb_book_account.id AS id_book_account,
            tb_book_account.saldo,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
            tb_book_account.name AS account_name
            ')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to'  ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0
                ]
            )
            ->order_by('code_account')
            ->group_by('tb_book_account.id');
        $get_data_account = $this->db->get()->result();
        $data['data_account'] = $get_data_account;


        $html_respon = $this->load->view('view_search_result_trial_balance', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    private function get_fist_saldo_period($id_period)
    {
        $array_saldo = [];
        $get_saldo_current = $this->db->where(['id_period' => $id_period])->get('tb_book_period_has_saldo')->result();
        foreach ($get_saldo_current as $item_saldo) {
            $array_saldo[$item_saldo->id_book_account] = $item_saldo->saldo;
        }
        return $array_saldo;
    }

    //--------------------------------------------------------------------------------- BALANCE SHEET ---------------------------------------------------------------------------
    public function balance_sheet()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent >' => 0])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $this->app_data['start_period']   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->app_data['data_period'] = $this->db->get('tb_book_period')->result();

        // $data['view_file']      = "view_balance_sheet";
        // $data['title']          = "NERACA LAJUR"; // untuk header pada bagian atas data
        // $data['subtitle']       = "NERACA LAJUR"; // untuk subtitle pada bagian atas data
        // $data['module']         = $this->module; //variable module untuk di controller template/media   
        // $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        // $data['page_title']     = 'NERACA LAJUR'; // untuk title pada tab 

        // echo modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "NERACA LAJUR";
        $this->app_data['view_file']     = 'view_balance_sheet';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_search_balance_sheet()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;



        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }

        if (!empty($this->input->post('date_from')) && !empty($this->input->post('date_to'))) {
            if (strtotime($this->input->post('date_to')) < strtotime($this->input->post('date_from'))) {
                $data['error_string'][] = 'tanggal akhir harus lebih besar';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }


    public function search_balance_sheet()
    {
        $this->validate_search_balance_sheet();
        $date_from  = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $date_to    = $this->change_date($this->input->post('date_to'));
        // $account    = $this->encrypt->decode($this->input->post('account'));
        $id_period = $this->input->post('id_period');
        $data['array_date'] = [
            'date_from' => $this->change_date($date_from),
            'date_to' => $this->input->post('date_to')
        ];

        $this->db->simple_query('SET SESSION group_concat_max_len=1000000');
        $this->db->from('tb_book_account')
            ->select('
            CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
            SUM(DISTINCT detail_book.credit) AS credit_saldo,
            SUM(DISTINCT detail_book.debit) AS debit_saldo,
            GROUP_CONCAT(DISTINCT detail_book.id,"-",detail_book.debit) AS list_debit_saldo,
            GROUP_CONCAT(DISTINCT detail_book.id,"-",detail_book.credit) AS list_credit_saldo,
            GROUP_CONCAT(DISTINCT adjusting_journal.id,"-",adjusting_journal.credit) AS adjusting_credit_saldo,
            GROUP_CONCAT(DISTINCT adjusting_journal.id,"-",adjusting_journal.debit) AS adjusting_debit_saldo,
            tb_book_account.id AS id_book_account,
            tb_book_account.saldo,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
            tb_book_account.name AS account_name
            ')
            ->join('tb_book_account_has_detail AS detail_book', "tb_book_account.id = detail_book.id_book_account AND detail_book.date >= '$date_from' AND detail_book.date <= '$date_to' AND detail_book.status_journal = 0 ", 'left')
            ->join('tb_book_account_has_detail AS adjusting_journal', "tb_book_account.id = adjusting_journal.id_book_account AND adjusting_journal.date >= '$date_from' AND adjusting_journal.date <= '$date_to' AND adjusting_journal.status_journal = 1 ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0
                ]
            )
            ->order_by('code_account')
            ->group_by('tb_book_account.id');
        $get_data_account = $this->db->get()->result();
        $data['data_account'] = $get_data_account;
        // $active_period = $this->db->where(['status' => 1])->get('tb_book_period')->row();
        $data['array_first_saldo'] = $this->get_fist_saldo_period($id_period);

        $html_respon = $this->load->view('view_search_result_balance_sheet', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    //------------------------------------- tutup buku --------------------------------------------------------------------
    public function monthly_book()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent >' => 0])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $this->app_data['start_period']   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->app_data['active_period'] = $this->db->where(['status' => 1])->get('tb_book_period')->row();

        // $data['view_file']      = "view_monthly_book";
        // $data['title']          = "TUTUP BUKU BULANAN"; // untuk header pada bagian atas data
        // $data['subtitle']       = "TUTUP BUKU BULANAN"; // untuk subtitle pada bagian atas data
        // $data['module']         = $this->module; //variable module untuk di controller template/media   
        // $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        // $data['page_title']     = 'TUTUP BUKU BULANAN'; // untuk title pada tab

        // echo modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "TUTUP BUKU BULANAN";
        $this->app_data['view_file']     = 'view_monthly_book';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_do_monthly_recapitulation()
    {

        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $array_month = [
            '01' => 'Januari',
            '02' => 'Februari',
            '03' => 'Maret',
            '04' => 'April',
            '05' => 'Mei',
            '06' => 'Juni',
            '07' => 'Juli',
            '08' => 'Agustus',
            '09' => 'September',
            '10' => 'Oktober',
            '11' => 'November',
            '12' => 'December',
        ];

        $period = $this->input->post('period');
        // $month = $this->encrypt->decode($this->input->post('month'));
        $explode_month = explode('-', $period);
        $year_current = $explode_month[1];
        $month_current = $explode_month[0];

        $date_current = $year_current . '-' . $month_current . '-01';
        // $start_period  = $this->db->where(['field' => 'start_period_accounting'])->get('tb_setting')->row()->value;
        // if (strtotime($date_current) < strtotime($start_period)) {
        //     $data['error_string'][] = '
        //     <div class="alert alert-default alert-dismissible border">
        //         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        //         <h4><i class="icon fa fa-warning"></i> Mohon maaf periode awal ' . $this->change_date($start_period) . '!</h4>
        //     </div>
        //     ';
        //     $data['inputerror'][] = 'error';
        //     $data['status'] = FALSE;
        // }

        $get_data_current  = $this->db->where(['year' => $year_current, 'month' => $month_current])->get('tb_book_account_recapitulation')->row();
        if (!empty($get_data_current) && $this->input->post('status_update') == false) {
            $data['error_string'][] = '
            <div class="alert alert-default alert-dismissible border">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-warning"></i> Mohon maaf Rekapitulasi periode ' . $array_month[$month_current] . ' ' . $year_current . ' Sudah Tersedia!</h4>
                <p class="text-center">Jika data rekapitulasi akan dirubah, silahkan klik tombol dibawah ini.</p>
                <div class="mt-10 text-center">
                    <a href="javascript:void(0)" style="text-decoration:none;" class="btn btn-success btn_update_resume"><i class="fa fa-send"></i> Lanjutkan Update Data</a>
                </div>
            </div>
            ';
            $data['inputerror'][] = 'error';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function do_monthly_recapitulation()
    {
        $this->validate_do_monthly_recapitulation();
        $period = $this->input->post('period');
        $explode_month = explode('-', $period);
        $year_current = $explode_month[1];
        $month_current = $explode_month[0];
        $date_from =  $year_current . '-' . $month_current . '-01';
        $last_date = cal_days_in_month(CAL_GREGORIAN, $month_current, $year_current);
        $date_to = $year_current . '-' . $month_current . '-' . $last_date;
        $recapitulation_period = $year_current . '-' . $month_current;
        $status_update = $this->input->post('status_update');
        $status_journal = 2; //status for close book

        $active_period = $this->db->where(['status' => 1])->get('tb_book_period')->row();

        if ($status_update) {
            $get_recapitulation_current = $this->db->where(['recapitulation_period' => $recapitulation_period])->get('tb_book_account_has_detail')->row();
            $date_juournal = isset($get_recapitulation_current->date) ? $get_recapitulation_current->date : $date_to;
            //delete old data
            Modules::run('database/delete', 'tb_book_account_has_detail', ['recapitulation_period' => $recapitulation_period]);
            Modules::run('database/delete', 'tb_book_account_recapitulation', ['year' => $year_current, 'month' => $month_current]);
        } else {
            $date_juournal = $date_to;
        }
        $date_juournal = $date_to;

        $array_month = [
            '01' => 'Januari',
            '02' => 'Februari',
            '03' => 'Maret',
            '04' => 'April',
            '05' => 'Mei',
            '06' => 'Juni',
            '07' => 'Juli',
            '08' => 'Agustus',
            '09' => 'September',
            '10' => 'Oktober',
            '11' => 'November',
            '12' => 'December',
        ];

        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            (SUM(credit) - SUM(debit)) AS total_saldo,
            tb_book_account.type_account,
            tb_book_account.id,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0,
                    'tb_book_account.type_account' => 4,
                    'tb_book_account.isDeleted' => 'N'
                ]
            )
            ->group_by('tb_book_account.id');
        $get_data_profit = $this->db->get()->result();

        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            (SUM(debit) - SUM(credit)) AS total_saldo,
            tb_book_account.type_account,
            tb_book_account.id,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0,
                    'tb_book_account.type_account' => 6,
                    'tb_book_account.isDeleted' => 'N'
                ]
            )
            ->group_by('tb_book_account.id');
        $get_data_hpp = $this->db->get()->result();

        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            (SUM(debit) - SUM(credit)) AS total_saldo,
            tb_book_account.type_account,
            tb_book_account.id,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0,
                    'tb_book_account.type_account' => 5,
                    'tb_book_account.isDeleted' => 'N'
                ]
            )
            ->group_by('tb_book_account.id');
        $get_cost = $this->db->get()->result();

        $get_data_prive = $this->db->where(['params' => 'account_prive'])->get('app_module_setting')->row()->value;
        $array_prive = json_decode($get_data_prive);
        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            (SUM(credit) - SUM(debit)) AS total_saldo,
            tb_book_account.type_account,
            tb_book_account.id,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id ' => $array_prive->akun_prive,
                ]
            )
            ->group_by('tb_book_account.id');
        $get_prive = $this->db->get()->row();

        //count adavantage
        $this->db->trans_start();
        //recapitulation other account
        $this->insert_balance_sheet_recapitulation($date_from, $date_to, $year_current, $month_current, $active_period->id);
        $total_profit = 0;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name

        //------------------------------ pendapatan / revenue -----------------------------------
        foreach ($get_data_profit as $item_profit) {
            $description = 'Tutup Buku Bulanan Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
            if ($item_profit->total_saldo == false) {
                continue;
            }
            //empty renevune / pendapatan
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $item_profit->id,
                    'description' => $description,
                    'date' => $date_juournal,
                    'debit' => $item_profit->total_saldo,
                    'credit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );
            //insert to recapitulation
            $this->model->insert(
                'tb_book_account_recapitulation',
                [
                    'id_book_account' => $item_profit->id,
                    'saldo' => $item_profit->total_saldo,
                    'year' => $year_current,
                    'month' => $month_current,
                    'status' => 1,
                    'id_period' => $active_period->id
                ]
            );
            $total_profit += $item_profit->total_saldo;
        }
        //ikhtisar laba rugi 
        if ($total_profit > 0) {
            $description = 'Ikhtisar Laba-Rugi Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => 0,
                    'description' => $description,
                    'date' => $date_juournal,
                    'credit' => $total_profit,
                    'debit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );
        }

        //------------------------------------ hpp -----------------------------------------------
        $total_hpp = 0;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        foreach ($get_data_hpp as $item_hpp) {

            if ($item_hpp->total_saldo == false) {
                continue;
            }

            $description = 'Tutup Buku Bulanan Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $item_hpp->id,
                    'description' => $description,
                    'date' => $date_juournal,
                    'credit' => $item_hpp->total_saldo,
                    'debit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );
            //insert to recapitulation
            $this->model->insert(
                'tb_book_account_recapitulation',
                [
                    'id_book_account' => $item_hpp->id,
                    'saldo' => $item_hpp->total_saldo,
                    'year' => $year_current,
                    'month' => $month_current,
                    'status' => 1,
                    'id_period' => $active_period->id
                ]
            );
            $total_hpp += $item_hpp->total_saldo;
        }

        //debit for Hpp
        if ($total_hpp > 0) {
            $description = 'Ikhtisar Laba-Rugi Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => 0,
                    'description' => $description,
                    'date' => $date_juournal,
                    'debit' => $total_hpp,
                    'credit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );
        }

        //----------------------------------------- cost / biaya ------------------------------------------
        $total_cost = 0;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        foreach ($get_cost as $item_cost) {

            if ($item_cost->total_saldo == false) {
                continue;
            }

            $total_cost += $item_cost->total_saldo;
            $description = 'Tutup Buku Bulanan Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $item_cost->id,
                    'description' => $description,
                    'date' => $date_juournal,
                    'credit' => $item_cost->total_saldo,
                    'debit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );
            //insert to recapitulation
            $this->model->insert(
                'tb_book_account_recapitulation',
                [
                    'id_book_account' => $item_cost->id,
                    'saldo' => $item_cost->total_saldo,
                    'year' => $year_current,
                    'month' => $month_current,
                    'status' => 1,
                    'id_period' => $active_period->id
                ]
            );
        }
        //debit for cost
        if ($total_cost > 0) {
            $description = 'Ikhtisar Laba-Rugi Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => 0,
                    'description' => $description,
                    'date' => $date_juournal,
                    'debit' => $total_cost,
                    'credit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );
        }

        //-------------------------------------------- modal dan prive ----------------------------------------
        $nett_profit =  $total_profit - ($total_hpp + $total_cost);
        //modal
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $description = 'Ikhtisar Laba-Rugi Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
        $this->model->insert(
            'tb_book_account_has_detail',
            [
                'id_book_account' => 0,
                'description' => $description,
                'date' => $date_juournal,
                'debit' => $nett_profit,
                'credit' => 0,
                'status_act' => 12,
                'token' => $token,
                'recapitulation_period' => $recapitulation_period,
                'status_journal' => $status_journal
            ]
        );

        $description = 'Laba-Rugi Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
        $this->model->insert(
            'tb_book_account_has_detail',
            [
                'id_book_account' => $array_prive->akun_revenue,
                'description' => $description,
                'date' => $date_juournal,
                'credit' => $nett_profit,
                'debit' => 0,
                'status_act' => 12,
                'token' => $token,
                'recapitulation_period' => $recapitulation_period,
                'status_journal' => $status_journal
            ]
        );

        //prive
        if ($get_prive->total_saldo > 0) {
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $description = 'Prive tutup buku Periode  : ' . $array_month[$month_current] . ' ' . $year_current;
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $array_prive->prive,
                    'description' => $description,
                    'date' => $date_juournal,
                    'credit' => $get_prive->total_saldo,
                    'debit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );

            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $array_prive->akun_revenue,
                    'description' => $description,
                    'date' => $date_juournal,
                    'debit' => $get_prive->total_saldo,
                    'credit' => 0,
                    'status_act' => 12,
                    'token' => $token,
                    'recapitulation_period' => $recapitulation_period,
                    'status_journal' => $status_journal
                ]
            );
        }

        $this->db->trans_complete();
        if ($this->db->trans_status() == false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }
        echo json_encode(array('status' => TRUE));
    }

    private function insert_balance_sheet_recapitulation($date_from, $date_to, $year, $month, $id_period)
    {
        //get balance sheet account
        $list_account = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);
        $array_balance_sheet = json_decode($this->db->where(['params' => 'balance_sheet_account'])->get('app_module_setting')->row()->value, TRUE);
        $this->db->from('tb_book_account')
            ->select('
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            tb_book_account.type_account,
            tb_book_account.id,
            tb_book_account.saldo,
			tb_book_account.code AS account_code,
			tb_book_account.name AS account_name
			')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to' ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0,
                    'tb_book_account.isDeleted' => 'N'
                ]
            )
            ->where_in('tb_book_account.type_account', $array_balance_sheet)
            ->group_by('tb_book_account.id');
        $get_other_account = $this->db->get()->result();

        //insert to recapitulation
        foreach ($get_other_account as $item_account) {
            //decide saldo
            if ($list_account[$item_account->type_account]['type_saldo'] == 'debit') {
                $total_saldo = $item_account->saldo + ($item_account->debit_saldo - $item_account->credit_saldo);
            } else {
                $total_saldo = $item_account->saldo + ($item_account->credit_saldo - $item_account->debit_saldo);
            }

            //insert to recapitulation
            $array_insert =  [
                'id_book_account' => $item_account->id,
                'saldo' => $total_saldo,
                'year' => $year,
                'month' => $month,
                'status' => 1,
                'id_period' => $id_period
            ];
            Modules::run('database/insert', 'tb_book_account_recapitulation', $array_insert);
        }
    }
    public function monthly_recapitulation()
    {
        $get_year = $this->db->select('MIN(year) AS min_year, MAX(year) AS max_year')->where(['year >' => 0])->get('tb_book_account_recapitulation')->row();

        $this->app_data['year'] = $get_year;
        $this->app_data['start_period']   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->app_data['active_period'] = $this->db->where(['status' => 1])->get('tb_book_period')->row();


        $this->app_data['page_title']     = "REKAPITULASI BULANAN";
        $this->app_data['view_file']     = 'view_monthly_recapitulation';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function search_monthly_recapitulation()
    {
        $year   = $this->encrypt->decode($this->input->post('year'));
        $month  = $this->encrypt->decode($this->input->post('month'));
        $report = $this->input->post('report');

        $date_from  = '01-' . $month . '-' . $year;
        $last_date = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $date_to = $last_date . '-' . $month . '-' . $year;

        if ($report == 1) {
            $data['array_date'] = [
                'date_from' => $date_from,
                'date_to' => $date_to
            ];

            //profit lost
            $this->db->from('tb_book_account')
                ->select('
                tb_book_account_recapitulation.saldo AS total_saldo,
                tb_book_account.type_account,
                tb_book_account.code AS account_code,
                tb_book_account.name AS account_name
			')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'left')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0,
                        'tb_book_account.type_account' => 4
                    ]
                )
                ->group_by('tb_book_account.id');
            $get_data_profit = $this->db->get()->result();
            $data['data_profit'] = $get_data_profit;


            $this->db->from('tb_book_account')
                ->select('
                    tb_book_account_recapitulation.saldo AS total_saldo,
                    tb_book_account.type_account,
                    tb_book_account.code AS account_code,
                    tb_book_account.name AS account_name
                ')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'left')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0,
                        'tb_book_account.type_account' => 6
                    ]
                )
                ->group_by('tb_book_account.id');
            $get_data_hpp = $this->db->get()->result();
            $data['data_hpp'] = $get_data_hpp;

            $this->db->from('tb_book_account')
                ->select('
                    tb_book_account_recapitulation.saldo AS total_saldo,
                    tb_book_account.type_account,
                    tb_book_account.code AS account_code,
                    tb_book_account.name AS account_name
                ')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'left')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0,
                        'tb_book_account.type_account' => 5
                    ]
                )
                ->group_by('tb_book_account.id');
            $get_cost = $this->db->get()->result();

            $data['data_cost'] = $get_cost;

            $html_respon = $this->load->view('view_search_result_profit_loss', $data, TRUE);
        } elseif ($report == 2) {
            //trial balance
            $data['array_date'] = [
                'date_from' => $date_from,
                'date_to' => $date_to
            ];
            $data['status_recapitulation'] = TRUE;
            $this->db->from('tb_book_account')
                ->select('
                CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
                tb_book_account_recapitulation.saldo AS total_saldo,
                tb_book_account.saldo,
                tb_book_account.type_account,
                tb_book_account.code AS account_code,
                tb_book_account.name AS account_name
                ')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'inner')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0
                    ]
                )
                ->order_by('code_account')
                ->group_by('tb_book_account.id');
            $get_data_account = $this->db->get()->result();

            $data['data_account'] = $get_data_account;
            $html_respon = $this->load->view('view_search_result_trial_balance', $data, TRUE);
        } else {
            $data['array_date'] = [
                'date_from' => $date_from,
                'date_to' => $date_to
            ];
            $list_profit_account = [4, 5, 6];
            $this->db->from('tb_book_account')
                ->select('
                    tb_book_account_recapitulation.saldo AS total_saldo,
                    tb_book_account.type_account,
                    tb_book_account.code AS account_code,
                    tb_book_account.name AS account_name
                ')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'left')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0
                    ]
                )->where_in('tb_book_account.type_account', $list_profit_account)
                ->group_by('tb_book_account.id');
            $get_profit = $this->db->get()->result();
            // print_r($get_profit);
            // exit;
            //COUNT PROFIT
            $list_account   = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);
            $saldo_debit_profit = 0;
            $saldo_credit_profit = 0;

            foreach ($get_profit as $item_profit) {
                $type_saldo = $list_account[$item_profit->type_account]['type_saldo'];

                if ($type_saldo == 'debit') {
                    $saldo_debit_profit += $item_profit->total_saldo;
                } else {
                    $saldo_credit_profit += $item_profit->total_saldo;
                }
            }

            $nett_profit = $saldo_credit_profit - $saldo_debit_profit;
            $data['data_nett_profit'] = $nett_profit;
            $list_account_activa = [1, 2];
            $this->db->from('tb_book_account')
                ->select('
                    tb_book_account_recapitulation.saldo AS total_saldo,
                    tb_book_account.type_account,
                    tb_book_account.code AS account_code,
                    tb_book_account.name AS account_name,
                    CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
                ')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'left')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0
                    ]
                )->where_in('tb_book_account.type_account', $list_account_activa)
                ->order_by('code_account')
                ->group_by('tb_book_account.id');
            $get_activa = $this->db->get()->result();
            $data['data_activa'] = $get_activa;

            $this->db->from('tb_book_account')
                ->select('
                    tb_book_account_recapitulation.saldo AS total_saldo,
                    tb_book_account.type_account,
                    tb_book_account.code AS account_code,
                    tb_book_account.name AS account_name,
                    CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
                ')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'left')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0,
                        'tb_book_account.type_account' => 7
                    ]
                )
                ->order_by('code_account')
                ->group_by('tb_book_account.id');
            $get_passiva = $this->db->get()->result();
            $data['data_passiva'] = $get_passiva;

            $this->db->from('tb_book_account')
                ->select('
                    tb_book_account_recapitulation.saldo AS total_saldo,
                    tb_book_account.type_account,
                    tb_book_account.code AS account_code,
                    tb_book_account.name AS account_name,
                    CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
                ')
                ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.year = '$year' AND tb_book_account_recapitulation.month = '$month'  ", 'left')
                ->where(
                    [
                        'tb_book_account.id_parent >' => 0,
                        'tb_book_account.type_account' => 3
                    ]
                )
                ->order_by('code_account')
                ->group_by('tb_book_account.id');
            $get_modal = $this->db->get()->result();
            $data['data_modal'] = $get_modal;
            $html_respon = $this->load->view('view_search_result_balance', $data, TRUE);
        }

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function yearly_book()
    {
        $get_year = $this->db->select('MIN(year) AS min_year, MAX(year) AS max_year')->get('tb_book_account_recapitulation')->row();
        $this->app_data['year'] = $get_year;
        $this->app_data['start_period']   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->app_data['period'] = $this->db->get('tb_book_period')->result();
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent >' => 0])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $this->app_data['start_period']   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;

        $this->app_data['page_title']     = "TUTUP BUKU TAHUNAN";
        $this->app_data['view_file']     = 'view_yearly_recapitulation';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function yearly_recapitulation()
    {
        $get_year = $this->db->select('MIN(year) AS min_year, MAX(year) AS max_year')->get('tb_book_account_recapitulation')->row();
        $this->app_data['year'] = $get_year;
        $this->app_data['start_period']   = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->app_data['period']     = $this->db->order_by('id_parent')->get('tb_book_period')->result();

        $this->app_data['page_title']     = "REKAPITULASI TAHUNAN";
        $this->app_data['view_file']     = 'view_search_yearly_recapitulation';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_do_yearly_recapitulation()
    {
        // print_r($_POST);
        // exit;
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $start_period  = $this->db->where(['params' => 'start_period_accounting'])->get('app_module_setting')->row()->value;
        $date_from      = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $explode_from   = explode('-', $date_from);
        $period = json_decode($this->encrypt->decode($this->input->post('period')));
        $get_data_current  = $this->db->where(['id_period' => $period->id, 'status' => 2])->get('tb_book_account_recapitulation')->row();

        if (!empty($get_data_current) && $this->input->post('status_update') == false) {
            $data['error_string'][] = '
            <div class="alert alert-default alert-dismissible border">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fa fa-warning"></i> Mohon maaf Rekapitulasi periode : <b> ' . $period->name . ' </b> Sudah Tersedia!</h5>
                <p class="text-center">Jika data rekapitulasi akan dirubah, silahkan klik tombol dibawah ini.</p>
                <div class="mt-10 text-center">
                    <a href="javascript:void(0)" style="text-decoration:none;" class="btn btn-success btn_update_resume_yearly"><i class="fa fa-send"></i> Lanjutkan Update Data</a>
                </div>
            </div>
            ';
            $data['inputerror'][] = 'error';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function do_yearly_recapitulation()
    {
        $this->validate_do_yearly_recapitulation();
        // $year = $this->encrypt->decode($this->input->post('year'));
        $period = json_decode($this->encrypt->decode($this->input->post('period')));

        $date_from      = $period->date_from;
        // $explode_from   = explode('-', $date_from);
        // $last_date = cal_days_in_month(CAL_GREGORIAN, '12', $year);
        $date_to    = $period->date_to;
        $list_account   = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);

        // $active_period = $this->db->where(['status' => 1])->get('tb_book_period')->row();
        $array_first_saldo = $this->get_fist_saldo_period($period->id);



        $this->db->from('tb_book_account')
            ->select('
            CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            tb_book_account.saldo,
            tb_book_account.id AS id_book_account,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
            tb_book_account.name AS account_name
            ')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to'  ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0
                ]
            )
            ->order_by('code_account')
            ->group_by('tb_book_account.id');
        $get_data_account = $this->db->get()->result();

        $this->db->trans_start();

        if ($this->input->post('status_update')) {
            //delete old data
            Modules::run('dtaabase/delete', 'tb_book_account_recapitulation', ['id_period' => $period->id, 'status' => 2]);
        }

        $total_credit = 0;
        $total_debit = 0;
        foreach ($get_data_account as $item_account) {

            $saldo_current = isset($array_first_saldo[$item_account->id_book_account]) ? $array_first_saldo[$item_account->id_book_account] : 0;
            // print_r($item_account);
            // exit;
            $type_saldo = $list_account[$item_account->type_account]['type_saldo'];
            if ($type_saldo == 'debit') {
                $total_saldo = $saldo_current + ($item_account->debit_saldo - $item_account->credit_saldo);
                $total_debit += $total_saldo;
            } else {
                $total_saldo = $saldo_current + ($item_account->credit_saldo - $item_account->debit_saldo);
                $total_credit += $total_saldo;
            }

            $array_insert = [
                'id_book_account' => $item_account->id_book_account,
                'saldo' => $total_saldo,
                'id_period' => $period->id,
                'status' => 2
            ];
            Modules::run('database/insert', 'tb_book_account_recapitulation', $array_insert);
        }

        $this->db->trans_complete();
        if ($this->db->trans_status() == false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }
        echo json_encode(array('status' => TRUE));
    }

    public function check_balance_sheet()
    {
        $period = json_decode($this->encrypt->decode($this->input->post('period')));
        // print_r($period);
        // exit;
        $date_from  = $period->date_from;
        $date_to    = $period->date_to;
        // $account    = $this->encrypt->decode($this->input->post('account'));
        $active_code    = $this->db->where(['status' => 1])->get('tb_book_period')->row();
        $data['array_first_saldo'] = $this->get_fist_saldo_period($active_code->id);
        $data['array_date'] = [
            'date_from' => $this->change_date($date_from),
            'date_to' => $date_to
        ];

        $this->db->from('tb_book_account')
            ->select('
            CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
            SUM(credit) AS credit_saldo,
            SUM(debit) AS debit_saldo,
            tb_book_account.saldo,
            tb_book_account.id AS id_book_account,
			tb_book_account.type_account,
			tb_book_account.code AS account_code,
            tb_book_account.name AS account_name
            ')
            ->join('tb_book_account_has_detail', "tb_book_account.id = tb_book_account_has_detail.id_book_account AND tb_book_account_has_detail.date >= '$date_from' AND tb_book_account_has_detail.date <= '$date_to'  ", 'left')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0
                ]
            )
            ->order_by('code_account')
            ->group_by('tb_book_account.id');
        $get_data_account = $this->db->get()->result();
        $data['data_account'] = $get_data_account;

        $html_respon = $this->load->view('view_search_result_trial_balance', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function search_yearly_recapitulation()
    {
        $period = json_decode($this->encrypt->decode($this->input->post('period')));
        $date_from  = $period->date_from;
        // $last_date = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $date_to = $period->date_to;
        //trial balance
        $data['array_date'] = [
            'date_from' => $date_from,
            'date_to' => $date_to
        ];
        $data['status_recapitulation'] = TRUE;
        $this->db->from('tb_book_account')
            ->select('
            CONCAT(tb_book_account.type_account,"-",tb_book_account.code) AS code_account,
            tb_book_account_recapitulation.saldo AS total_saldo,
            tb_book_account.saldo,
            tb_book_account.type_account,
            tb_book_account.code AS account_code,
            tb_book_account.name AS account_name
            ')
            ->join('tb_book_account_recapitulation', "tb_book_account.id = tb_book_account_recapitulation.id_book_account AND tb_book_account_recapitulation.id_period = '$period->id' AND tb_book_account_recapitulation.status = 2  ", 'inner')
            ->where(
                [
                    'tb_book_account.id_parent >' => 0
                ]
            )
            ->order_by('code_account')
            ->group_by('tb_book_account.id');
        $get_data_account = $this->db->get()->result();

        $data['data_account'] = $get_data_account;
        $html_respon = $this->load->view('view_search_result_trial_balance', $data, TRUE);

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    //------------------------------------ CASH transaction -------------------------------------------------------
    public function cash_out()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value);
        $this->app_data['account_transaction'] = $accounting_transaction;
        $get_cash = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'status_bank' => 1, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();

        $this->app_data['data_cash'] = $get_cash;

        $this->app_data['page_title']     = "Kas Keluar";
        $this->app_data['view_file']     = 'view_cash_out';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function cash_in()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value);
        $this->app_data['account_transaction'] = $accounting_transaction;
        $get_cash = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'status_bank' => 1, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();

        $this->app_data['data_cash'] = $get_cash;

        // echo modules::run('template/media_admin', $data);

        $this->app_data['page_title']     = "Kas Masuk";
        $this->app_data['view_file']     = 'view_cash_in';
        echo Modules::run('template/main_layout', $this->app_data);
    }
    public function cash_transfer()
    {
        $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_account'] = $get_account;
        $accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value);
        $this->app_data['account_transaction'] = $accounting_transaction;
        $get_cash = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id_parent > ' => 0, 'status_bank' => 1, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->result();
        $this->app_data['data_cash'] = $get_cash;

        $this->app_data['page_title']     = "Kas TRANSFER";
        $this->app_data['view_file']     = 'view_cash_transfer';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    private function validate_save_cash_out()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $id_debit_account   = $this->encrypt->decode($this->input->post('debit_account'));
        $id_credit_account  =  $this->encrypt->decode($this->input->post('credit_account'));

        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }

        $status_act = $this->input->post('status');
        if ($status_act == 1) {
            if ($this->input->post('arr_debit_account') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'arr_debit_account';
                $data['status'] = FALSE;
            }
        } else {
            if ($id_credit_account == $id_debit_account) {
                $data['error_string'][] = 'akun tidak boleh sama dengan akun tujuan';
                $data['inputerror'][] = 'debit_account';
                $data['status'] = FALSE;

                $data['error_string'][] = 'akun tidak boleh sama dengan akun kas';
                $data['inputerror'][] = 'credit_account';
                $data['status'] = FALSE;
            }

            if ($this->input->post('price') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }
            if ($this->input->post('description') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'description';
                $data['status'] = FALSE;
            }

            if ($this->encrypt->decode($this->input->post('debit_account')) == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'debit_account';
                $data['status'] = FALSE;
            }
        }
        if ($this->encrypt->decode($this->input->post('credit_account')) == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'credit_account';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_cash_out()
    {
        $this->validate_save_cash_out();


        $status_act = $this->input->post('status');

        if ($status_act == 1) {
            //cashout
            $id_credit_account  =  $this->encrypt->decode($this->input->post('credit_account'));
            $date               = $this->change_date($this->input->post('date'));
            $arr_debit_account = $this->input->post('arr_debit_account');
            $arr_debit_price = $this->input->post('arr_debit_price');
            $arr_debit_desc = $this->input->post('arr_debit_desc');

            $arr_json = [];
            $total_price = 0;
            foreach ($arr_debit_account as $key => $value) {
                $id_debit_account   = $arr_debit_account[$key];
                $price_debit        = $arr_debit_price[$key];
                $desc               = $arr_debit_desc[$key];
                $price = str_replace('.', '', $price_debit);

                $arr_json[] = [
                    'id_account' => $id_debit_account,
                    'desc' => $desc,
                    'price' => str_replace('.', '', $price_debit)
                ];
                $total_price += $price;
            }

            //save data
            $array_insert_transaction = [
                'status_act' => $status_act,
                'date' => $date,
                'credit_account' => $id_credit_account,
                'price' => $total_price,
                'json_cash' => json_encode($arr_json),
                'created_by' => $this->session->userdata('us_id')
            ];
            Modules::run('database/insert', 'tb_cash_transaction', $array_insert_transaction);
            $get_max_id = $this->db->select('MAX(id) AS max_id')->get('tb_cash_transaction')->row();
            $array_code = [2 => 9, 1 => 10, 3 => 11];
            $status_act_accounting = isset($array_code[$status_act]) ? $array_code[$status_act] : 0;
            if (isset($array_code[$status_act])) {
                //insert to accountant
                $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique nam

                Modules::run('database/insert', 'tb_book_account_has_detail', [
                    'id_book_account' => $id_credit_account,
                    'description' => 'Transaksi Kas keluar',
                    'date' => $date,
                    'credit' => $total_price,
                    'debit' => 0,
                    'status_act' => $status_act_accounting,
                    'id_transaction' => $get_max_id->max_id,
                    'token' => $token
                ]);

                foreach ($arr_json as $item_data) {
                    Modules::run('database/insert', 'tb_book_account_has_detail', [
                        'id_book_account' => $item_data['id_account'],
                        'description' => $item_data['desc'],
                        'date' => $date,
                        'debit' => $item_data['price'],
                        'credit' => 0,
                        'status_act' => $status_act_accounting,
                        'id_transaction' => $get_max_id->max_id,
                        'token' => $token
                    ]);
                }
            }
        } else {
            //cash in & transfer
            $id_debit_account   = $this->encrypt->decode($this->input->post('debit_account'));
            $id_credit_account  =  $this->encrypt->decode($this->input->post('credit_account'));
            $price              = str_replace('.', '', $this->input->post('price'));
            $description        = $this->input->post('description');
            $date               = $this->change_date($this->input->post('date'));

            $array_insert_transaction = [
                'status_act' => $status_act,
                'date' => $date,
                'description' => $description,
                'debit_account' => $id_debit_account,
                'credit_account' => $id_credit_account,
                'price' => $price,
                'created_by' => $this->session->userdata('us_id')
            ];
            Modules::run('database/insert', 'tb_cash_transaction', $array_insert_transaction);
            //get max id 
            $get_max_id = $this->db->select('MAX(id) AS max_id')->get('tb_cash_transaction')->row();

            $array_code = [2 => 9, 1 => 10, 3 => 11];
            $status_act_accounting = isset($array_code[$status_act]) ? $array_code[$status_act] : 0;
            if (isset($array_code[$status_act])) {
                //insert to accountant
                $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
                Modules::run('database/insert', 'tb_book_account_has_detail', [
                    'id_book_account' => $id_debit_account,
                    'description' => $description,
                    'date' => $date,
                    'debit' => $price,
                    'credit' => 0,
                    'status_act' => $status_act_accounting,
                    'id_transaction' => $get_max_id->max_id,
                    'token' => $token
                ]);

                Modules::run('database/insert', 'tb_book_account_has_detail', [
                    'id_book_account' => $id_credit_account,
                    'description' => $description,
                    'date' => $date,
                    'credit' => $price,
                    'debit' => 0,
                    'status_act' => $status_act_accounting,
                    'id_transaction' => $get_max_id->max_id,
                    'token' => $token
                ]);
            }
        }
        echo json_encode(['status' => TRUE]);
    }

    public function list_cashout()
    {
        $date_from  = $this->input->post('date_from') ?  Modules::run('helper/change_date', $this->input->post('date_from'), '-') : '';
        $date_to    = $this->input->post('date_to') ?  Modules::run('helper/change_date', $this->input->post('date_to'), '-') : '';
        $debit_account = $this->encrypt->decode($this->input->post('debit_account_search'));
        $credit_account = $this->encrypt->decode($this->input->post('credit_account'));

        $array_where = [];
        $array_where['status_act'] = 1;
        if ($date_from != '') {
            $array_where['tb_cash_transaction.date >='] = $date_from;
        }
        if ($date_to != '') {
            $array_where['tb_cash_transaction.date <='] = $date_to;
        }
        if ($credit_account) {
            $array_where['tb_cash_transaction.credit_account'] = $credit_account;
        }

        $start_period = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->db->select('
            tb_cash_transaction.*,
            CONCAT(debit_account.type_account,"-",debit_account.code," ",debit_account.name) AS debit_account_name,
            CONCAT(credit_account.type_account,"-",credit_account.code," ",credit_account.name) AS credit_account_name
        ');
        $this->db->from('tb_cash_transaction');
        $this->db->join('tb_book_account AS debit_account', 'tb_cash_transaction.debit_account = debit_account.id', 'left');
        $this->db->join('tb_book_account AS credit_account', 'tb_cash_transaction.credit_account = credit_account.id', 'left');
        $this->db->order_by('tb_cash_transaction.id', 'DESC');
        $this->db->where($array_where);
        $get_all_data = $this->db->get()->result();

        $html_tr = '';
        $counter = 0;
        foreach ($get_all_data as $item_data) {
            $counter++;
            $btn_delete = Modules::run('security/delete_access', '
            <a href="javascript:void(0)" class="btn btn-danger-gradient btn-rounded btn-sm btn_remove_cash"  data-id="' . $this->encrypt->encode($item_data->id) . '"  data-code="cashout"><i class="fa fa-trash"></i> Hapus</a>
            ');

            $html_spend = '';
            $list_spend = json_decode($item_data->json_cash, TRUE);
            $total_spend  = 0;
            if (!empty($list_spend)) {
                foreach ($list_spend as $item_spend) {
                    $id_account = $item_spend['id_account'];

                    if (!empty($debit_account) && $id_account != $debit_account) {
                        continue;
                    }

                    $get_account = $this->db->select('CONCAT(type_account,"-",code) AS code_account,name,id')->where(['id' => $id_account, 'isDeleted' => 'N'])->order_by('code_account')->get('tb_book_account')->row();

                    $html_spend .= '
                        <div class="row p-2 border-dashed">
                            <div class="col-3 border-right">
                            ' . $get_account->code_account . ' ' . $get_account->name . '
                            </div>
                            <div class="col-6 border-right">
                                ' . $item_spend['desc'] . '
                            </div>
                            <div class="col-3">
                                Rp.' . number_format($item_spend['price'], 0, '.', '.') . '
                            </div>
                        </div>
                    ';

                    $total_spend += $item_spend['price'];
                }
            }

            $html_tr .= '
                <tr>
                    <td>' . $counter . '</td>
                    <td>
                        <div class="">
                            <small class="d-block"><i class="fa fa-calendar text-muted"></i> Tanggal Transaksi :</small>
                            <label for="" class="m-0 font-weight-bold tx-16 d-block"> ' . Modules::run('helper/date_indo', $item_data->date, '-') . '</label>    
                        </div>
                    </td>
                    <td>
                        <div class="row">
                            <div class="col-12 mb-2">
                                <small class="d-block"><i class="fa fa-tv text-muted"></i> Akun Pengirim :</small>
                                <span class="px-4 badge badge-light badge-pill tx-16">' . $item_data->credit_account_name . '</span>
                            </div>
                            
                            <small class="d-block col-12"><i class="fa fa-tv text-muted"></i> Akun Tujuan :</small>
                            ' . $html_spend . '
                        </div>
                    </td>
                    <td>
                        <div class="row">
                            <div class="col">
                                <div class=""><small class="text-muted"><i class="fa fa-check-circle"></i> Nominal :</small></div>
                                <div class="h4 mt-1 mb-1"><b>Rp.' . number_format($total_spend, 0, '.', '.') . '</b><span class="text-success tx-13 ml-2"></span></div>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="fe fe-monitor project bg-primary-transparent text-primary "></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 ">
                            ' . $btn_delete . '
                        </div>
                    </td>
                </tr>
            ';
        }
        $html_respon = '
            <table class="table table-cash t-shadow">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Nominal</th>
                    </tr>
                </thead>
                <tbody>' . $html_tr . '</tbody>
            </table>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function list_cashin()
    {
        $date_from  = $this->input->post('date_from') ?  Modules::run('helper/change_date', $this->input->post('date_from'), '-') : '';
        $date_to    = $this->input->post('date_to') ?  Modules::run('helper/change_date', $this->input->post('date_to'), '-') : '';
        $debit_account = $this->encrypt->decode($this->input->post('debit_account'));
        $credit_account = $this->encrypt->decode($this->input->post('credit_account'));

        $array_where = [];
        $array_where['status_act'] = 2;
        if ($date_from != '') {
            $array_where['tb_cash_transaction.date >='] = $date_from;
        }
        if ($date_to != '') {
            $array_where['tb_cash_transaction.date <='] = $date_to;
        }
        if ($debit_account) {
            $array_where['tb_cash_transaction.debit_account'] = $debit_account;
        }
        if ($credit_account) {
            $array_where['tb_cash_transaction.credit_account'] = $credit_account;
        }



        $start_period = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->db->select('
            tb_cash_transaction.*,
            CONCAT(debit_account.type_account,"-",debit_account.code," ",debit_account.name) AS debit_account_name,
            CONCAT(credit_account.type_account,"-",credit_account.code," ",credit_account.name) AS credit_account_name
        ');
        $this->db->from('tb_cash_transaction');
        $this->db->join('tb_book_account AS debit_account', 'tb_cash_transaction.debit_account = debit_account.id', 'left');
        $this->db->join('tb_book_account AS credit_account', 'tb_cash_transaction.credit_account = credit_account.id', 'left');
        $this->db->order_by('tb_cash_transaction.id', 'DESC');
        $this->db->where($array_where);
        $get_all_data = $this->db->get()->result();

        $html_tr = '';
        $counter = 0;
        foreach ($get_all_data as $item_data) {
            $counter++;
            $btn_delete = Modules::run('security/delete_access', '
                <a href="javascript:void(0)" class="btn btn-danger-gradient btn-rounded btn-sm btn_remove_cash"  data-id="' . $this->encrypt->encode($item_data->id) . '"  data-code="cashin"><i class="fa fa-trash"></i> Hapus</a>
            ');
            $btn_edit = Modules::run('security/edit_access', '
                <a href="javascript:void(0)" class="btn btn-warning-gradient btn-rounded btn-sm btn_edit_cash"  data-id="' . $this->encrypt->encode($item_data->id) . '"  data-code="cashin"><i class="fa fa-trash"></i> Hapus</a>
            ');
            $html_tr .= '
                <tr>
                    <td>' . $counter . '</td>
                    <td>
                        <div class="">
                            <small class="d-block"><i class="fa fa-calendar text-muted"></i> Tanggal Transaksi :</small>
                            <label for="" class="m-0 font-weight-bold tx-16 d-block"> ' . Modules::run('helper/date_indo', $item_data->date, '-') . '</label>    
                        </div>
                    </td>
                    <td>
                        <div class="row">
                            <div class="col-6">
                                <small class="d-block"><i class="fa fa-tv text-muted"></i> Akun Pengirim :</small>
                                <span class="px-4 badge badge-light badge-pill tx-16">' . $item_data->credit_account_name . '</span>
                            </div>
                            <div class="col-6">
                                <small class="d-block"><i class="fa fa-tv text-muted"></i> Akun Tujuan :</small>
                                <span class="px-4 badge badge-light badge-pill tx-16">' . $item_data->debit_account_name . '</span>
                            </div>
                            <div class="col-12 border-dashed p-1 mt-2">
                                <small class="d-block mb-2"> Keterangan :</small>
                                ' . $item_data->description . '
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="row">
                            <div class="col">
                                <div class=""><small class="text-muted"><i class="fa fa-check-circle"></i> Nominal :</small></div>
                                <div class="h4 mt-1 mb-1"><b>Rp.' . number_format($item_data->price, 0, '.', '.') . '</b><span class="text-success tx-13 ml-2"></span></div>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="fe fe-monitor project bg-primary-transparent text-primary "></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 ">
                            ' . $btn_edit . $btn_delete . '
                        </div>
                    </td>
                </tr>
            ';
        }
        $html_respon = '
            <table class="table table-cash t-shadow">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Nominal</th>
                    </tr>
                </thead>
                <tbody>' . $html_tr . '</tbody>
            </table>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function list_transfer()
    {
        $date_from  = $this->input->post('date_from') ?  Modules::run('helper/change_date', $this->input->post('date_from'), '-') : '';
        $date_to    = $this->input->post('date_to') ?  Modules::run('helper/change_date', $this->input->post('date_to'), '-') : '';
        $debit_account = $this->encrypt->decode($this->input->post('debit_account'));
        $credit_account = $this->encrypt->decode($this->input->post('credit_account'));

        $array_where = [];
        $array_where['status_act'] = 3;
        if ($date_from != '') {
            $array_where['tb_cash_transaction.date >='] = $date_from;
        }
        if ($date_to != '') {
            $array_where['tb_cash_transaction.date <='] = $date_to;
        }
        if ($debit_account) {
            $array_where['tb_cash_transaction.debit_account'] = $debit_account;
        }
        if ($credit_account) {
            $array_where['tb_cash_transaction.credit_account'] = $credit_account;
        }

        $start_period = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
        $this->db->select('
            tb_cash_transaction.*,
            CONCAT(debit_account.type_account,"-",debit_account.code," ",debit_account.name) AS debit_account_name,
            CONCAT(credit_account.type_account,"-",credit_account.code," ",credit_account.name) AS credit_account_name
        ');
        $this->db->from('tb_cash_transaction');
        $this->db->join('tb_book_account AS debit_account', 'tb_cash_transaction.debit_account = debit_account.id', 'left');
        $this->db->join('tb_book_account AS credit_account', 'tb_cash_transaction.credit_account = credit_account.id', 'left');
        $this->db->order_by('tb_cash_transaction.id', 'DESC');
        $this->db->where($array_where);
        $get_all_data = $this->db->get()->result();

        $html_tr = '';
        $counter = 0;
        foreach ($get_all_data as $item_data) {
            $counter++;
            $btn_delete = Modules::run('security/delete_access', '
            <a href="javascript:void(0)" class="btn btn-danger-gradient btn-rounded btn-sm btn_remove_cash"  data-id="' . $this->encrypt->encode($item_data->id) . '"  data-code="transfer"><i class="fa fa-trash"></i> Hapus</a>
            ');
            $html_tr .= '
                <tr>
                    <td>' . $counter . '</td>
                    <td>
                        <div class="">
                            <small class="d-block"><i class="fa fa-calendar text-muted"></i> Tanggal Transaksi :</small>
                            <label for="" class="m-0 font-weight-bold tx-16 d-block"> ' . Modules::run('helper/date_indo', $item_data->date, '-') . '</label>    
                        </div>
                    </td>
                    <td>
                        <div class="row">
                            <div class="col-6">
                                <small class="d-block"><i class="fa fa-tv text-muted"></i> Akun Pengirim :</small>
                                <span class="px-4 badge badge-light badge-pill tx-16">' . $item_data->credit_account_name . '</span>
                            </div>
                            <div class="col-6">
                                <small class="d-block"><i class="fa fa-tv text-muted"></i> Akun Tujuan :</small>
                                <span class="px-4 badge badge-light badge-pill tx-16">' . $item_data->debit_account_name . '</span>
                            </div>
                            <div class="col-12 border-dashed p-1 mt-2">
                                <small class="d-block mb-2"> Keterangan :</small>
                                ' . $item_data->description . '
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="row">
                            <div class="col">
                                <div class=""><small class="text-muted"><i class="fa fa-check-circle"></i> Nominal :</small></div>
                                <div class="h4 mt-1 mb-1"><b>Rp.' . number_format($item_data->price, 0, '.', '.') . '</b><span class="text-success tx-13 ml-2"></span></div>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="fe fe-monitor project bg-primary-transparent text-primary "></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 ">
                            ' . $btn_delete . '
                        </div>
                    </td>
                </tr>
            ';
        }
        $html_respon = '
            <table class="table table-cash t-shadow">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Nominal</th>
                    </tr>
                </thead>
                <tbody>' . $html_tr . '</tbody>
            </table>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function delete_cash()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));
        $code = $this->input->post('code');

        Modules::run('database/delete', 'tb_cash_transaction', ['id' => $id]);
        $array_code = ['cashin' => 9, 'cashout' => 10, 'transfer' => 11];
        if (isset($array_code[$code])) {
            Modules::run('database/delete', 'tb_book_account_has_detail', ['id_transaction' => $id, 'status_act' => $array_code[$code]]);
        }

        echo json_encode(array('status' => TRUE));
    }

    public function print_journal()
    {
        // echo '<pre>';
        $data_result = json_decode($this->encrypt->decode($this->input->post('data_result')), TRUE);
        $data_journal = $data_result['data'];
        $spesification = $data_result['spesification'];

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('30');
        $sheet->getColumnDimension('D')->setWidth('80');
        $sheet->getColumnDimension('E')->setWidth('15');
        $sheet->getColumnDimension('F')->setWidth('15');

        //bold style 
        $sheet->getStyle("A1:F2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:F2');
        $sheet->getStyle('A1:F2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:F2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA JURNAL');
        $sheet->getStyle('A3:F3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:F3');
        $sheet->getStyle('A3:F3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'PERIODE : ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to']);
        $sheet->getStyle('A3:F3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "F4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE AKUN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'JURNAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'KETERANGAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'DEBIT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F4', 'KREDIT');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_journal as $item_print) {

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['code_account']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $item_print['date']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($item_print['account']));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $item_print['description']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['debit']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $item_print['credit']);

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA JURNAL  ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_ledger_book()
    {
        $data_result = json_decode($this->encrypt->decode($this->input->post('data_result')), TRUE);
        $spesification = $data_result['spesification'];
        $data_print = $data_result['data_print'];

        // $get_profile = $this->db->get('tb_profile')->row_array();
        $data['first_saldo'] = $data_result['first_saldo'];
        $last_saldo = $data_result['last_saldo'];

        $label_first_saldo_credit = '';
        $label_first_saldo_debit = '';
        if ($spesification['type_saldo'] == 'debit') {
            $label_first_saldo_debit =  $data_result['first_saldo'];
        } else {
            $label_first_saldo_credit =  $data_result['first_saldo'];
        }

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('80');
        $sheet->getColumnDimension('D')->setWidth('15');
        $sheet->getColumnDimension('E')->setWidth('15');

        //bold style 
        $sheet->getStyle("A1:F2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:E2');
        $sheet->getStyle('A1:E2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:E2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN BUKU BESAR');
        $sheet->getStyle('A3:E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:E3');
        $sheet->getStyle('A3:E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'AKUN :' . strtoupper($spesification['account']) . ' | PERIODE : ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to']);
        $sheet->getStyle('A3:E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "E4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE AKUN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'KETERANGAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'DEBIT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'KREDIT');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':E' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':E' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        $sheet_number_resume++;

        $sheet->mergeCells('A' . $sheet_number_resume . ':C' . $sheet_number_resume);
        $sheet->getStyle('A3:E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'SALDO AWAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $label_first_saldo_debit);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $label_first_saldo_credit);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':E' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        foreach ($data_print as $item_print) {

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['code_account']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $item_print['date']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $item_print['description']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $item_print['debit']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['credit']);
            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':E' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }

        $sheet->mergeCells('A' . $sheet_number_resume . ':C' . $sheet_number_resume);
        $sheet->getStyle('A3:E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'SALDO AKHIR AKUN :' . $spesification['account']);

        $sheet->mergeCells('D' . $sheet_number_resume . ':E' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $last_saldo);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':E' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN BUKU BESAR AKUN :  ' . $spesification['account'] . ' PERIODE ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_profit_lost()
    {
        $data_result = json_decode($this->encrypt->decode($this->input->post('data_result')), TRUE);
        $data_profit = $data_result['profit'];
        $data_hpp    = $data_result['hpp'];
        $data_cost   = $data_result['cost'];
        $data_resume   = $data_result['resume'];
        $spesification =  $data_result['spesification'];

        // $get_profile = $this->db->get('tm_profile')->row_array();
        // $data['data_profile'] = $get_profile;

        // echo '<pre>';
        // print_r($data_result);
        // exit;

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('40');
        $sheet->getColumnDimension('B')->setWidth('5');
        $sheet->getColumnDimension('C')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:C2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:C2');
        $sheet->getStyle('A1:C2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:C2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN LABA / RUGI');
        $sheet->getStyle('A3:C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:C3');
        $sheet->getStyle('A3:C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'PERIODE : ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to']);
        $sheet->getStyle('A3:C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet_number_resume = 5;
        $no = 0;

        //--------------------------- pendapatan --------------------------------------
        $sheet->mergeCells('A' . $sheet_number_resume . ':C' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'PENDAPATAN');
        $sheet->getStyle('A' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_profit['data_print'] as $item_print) {
            $sheet_number_resume++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['account_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($item_print['saldo']));

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'TOTAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_profit['total_saldo']);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getFont()->setBold(true);

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);

        //---------------------------------------- hpp ----------------------------------
        $sheet_number_resume++;
        $sheet_number_resume++;
        $sheet->mergeCells('A' . $sheet_number_resume . ':C' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'HPP (HARGA POKOK PENJUALAN)');
        $sheet->getStyle('A' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_hpp['data_print'] as $item_print) {
            $sheet_number_resume++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['account_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($item_print['saldo']));

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'TOTAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_hpp['total_saldo']);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);

        //---------------------------------------- cost ----------------------------------
        $sheet_number_resume++;
        $sheet_number_resume++;

        $sheet->mergeCells('A' . $sheet_number_resume . ':C' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'BIAYA');
        $sheet->getStyle('A' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_cost['data_print'] as $item_print) {
            $sheet_number_resume++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['account_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($item_print['saldo']));

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'TOTAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_cost['total_saldo']);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);

        $sheet_number_resume++;
        $sheet_number_resume++;

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'LABA KOTOR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_resume['bruto']);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'LABA BERSIH');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_resume['nett']);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN LABA / RUGI PERIODE ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }


    public function print_balance()
    {
        $data_result = json_decode($this->encrypt->decode($this->input->post('data_result')), TRUE);
        $data_print = $data_result['data_print'];
        $all_data = $data_result;
        // $data['total']    = $data_result['total'];
        // $data['spesification'] =  $data_result['spesification'];

        // $data_profile = $this->db->get('tm_profile')->row_array();

        // print_r($data_result);
        // exit;

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('30');
        $sheet->getColumnDimension('B')->setWidth('3');
        $sheet->getColumnDimension('C')->setWidth('20');
        $sheet->getColumnDimension('D')->setWidth('10');
        $sheet->getColumnDimension('E')->setWidth('30');
        $sheet->getColumnDimension('F')->setWidth('3');
        $sheet->getColumnDimension('G')->setWidth('20');

        $sheet_number_resume = 0;
        $sheet_number_resume++;
        //bold style 
        $sheet->getStyle('A' . $sheet_number_resume . ':G' . ($sheet_number_resume + 1))->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A' . $sheet_number_resume . ':G' . ($sheet_number_resume + 1));
        $sheet->getStyle('A' . $sheet_number_resume . ':G' . ($sheet_number_resume + 1))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A' . $sheet_number_resume . ':G' . ($sheet_number_resume + 1))->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN NERACA');

        $sheet_number_resume++;
        $sheet_number_resume++;
        $sheet->mergeCells('A' . $sheet_number_resume . ':G' . $sheet_number_resume);
        $sheet->getStyle('A' . $sheet_number_resume . ':G' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'PER TANGGAL  : ' . $all_data['date']);
        $sheet->getStyle('A' . $sheet_number_resume . ':G' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet_number_resume++;
        //sheet table resume 
        $from = "A" . $sheet_number_resume; // or any value
        $to = "C" . $sheet_number_resume; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $sheet->mergeCells('A' . $sheet_number_resume . ':C' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'AKTIVA');
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_print['activa'] as $item_print) {

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['account_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $item_print['saldo']);
            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'TOTAL AKTIVA :');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $all_data['total_activa']);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':C' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet_number_resume = 4; //reset sehet number

        $from = "E" . $sheet_number_resume; // or any value
        $to = "G" . $sheet_number_resume; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $sheet->mergeCells('E' . $sheet_number_resume . ':G' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'KEWAJIBAN');
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_print['obligate'] as $item_print) {

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['account_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, ':');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $item_print['saldo']);
            $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'TOTAL KEWAJIBAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $all_data['total_obligate']);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet_number_resume++;
        $from = "E" . $sheet_number_resume; // or any value
        $to = "G" . $sheet_number_resume; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $sheet->mergeCells('E' . $sheet_number_resume . ':G' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'MODAL');
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );
        foreach ($data_print['modal'] as $item_print) {

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['account_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, ':');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $item_print['saldo']);
            $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'LABA / RUGI');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $all_data['nett_profit']);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getFont()->setBold(true);

        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'TOTAL MODAL ');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $all_data['total_modal']);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet_number_resume++;
        $sheet_number_resume++;
        $from = "E" . $sheet_number_resume; // or any value
        $to = "G" . $sheet_number_resume; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $sheet->mergeCells('E' . $sheet_number_resume . ':G' . $sheet_number_resume);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'RESUME');
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'TOTAL AKTIVA ');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $all_data['total_activa']);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);
        $sheet_number_resume++;
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, 'TOTAL PASSIVA ');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, ':');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $all_data['total_passiva']);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('E' . $sheet_number_resume . ':G' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN NERACA PER TANGGAL ' . $all_data['date'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_trial_balance()
    {
        $data_result = json_decode($this->encrypt->decode($this->input->post('data_result')), TRUE);
        $data_print = $data_result['data_print'];
        $total    = $data_result['total'];
        $spesification =  $data_result['spesification'];

        // $get_profile = $this->db->get('tm_profile')->row_array();
        // $data['data_profile'] = $get_profile;

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('50');
        $sheet->getColumnDimension('C')->setWidth('15');
        $sheet->getColumnDimension('D')->setWidth('15');

        //bold style 
        $sheet->getStyle("A1:F2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:D2');
        $sheet->getStyle('A1:D2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:D2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'NERACA SALDO');
        $sheet->getStyle('A3:D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:D3');
        $sheet->getStyle('A3:D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'PER TANGGAL  : ' . $spesification['date_to']);
        $sheet->getStyle('A3:D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "D4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE AKUN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'AKUN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'DEBIT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'KREDIT');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_print as $item_print) {

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['code']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $item_print['account']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $item_print['debit']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $item_print['credit']);
            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $sheet->mergeCells('A' . $sheet_number_resume . ':B' . $sheet_number_resume);
        $sheet->getStyle('A3:E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'TOTAL SALDO :');

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $total['total_debit']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $total['total_credit']);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN NERACA SALDO PER TANGGAL ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_balance_sheet()
    {
        $data_result = json_decode($this->encrypt->decode($this->input->post('data_result')), TRUE);
        $data['data_print'] = $data_result['data_print'];
        $data['total']    = $data_result['total'];
        $data['spesification'] =  $data_result['spesification'];
        $data['advantage'] =  $data_result['advantage'];
        $data['balance'] =  $data_result['balance'];


        $get_profile = $this->db->get('tb_profile')->row_array();
        $data['data_profile'] = $get_profile;

        ob_start();
        $this->load->view($this->location . 'print_balance_sheet', $data);
        $html = ob_get_contents();
        ob_end_clean();
        require_once('./assets/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('L', 'A4', 'en');
        $pdf->WriteHTML($html);
        $pdf->Output('LAPORAN NERACA LAJUR.pdf', 'D');
    }

    // ------------------------  transaction function --------
    public function insert_invoice_bol($data)
    {
        //requirement data :
        // ['total_tagihan'=>'','total_pajak'=>'','piutang'=>'','kode_invoice'=>'','id_tagihan'=>'']

        $code_transaction = 1;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $account_invoice = $this->db->where(['params' => 'account_invoice_transaction'])->get('app_module_setting')->row()->value;
        $array_account = json_decode($account_invoice);

        $total_tagihan  = isset($data['total_tagihan']) ? $data['total_tagihan'] : 0;
        $total_pajak    = isset($data['total_pajak']) ? $data['total_pajak'] : 0;
        $total_piutang  = isset($data['piutang']) ? $data['piutang'] : 0;
        $invoice_code   = isset($data['kode_invoice']) ? $data['kode_invoice'] : '-';
        $id_tagihan     = isset($data['id_tagihan']) ? $data['id_tagihan'] : 0;

        $rest_invoice   = $total_tagihan - $total_piutang;
        $fix_income     = $total_tagihan - $total_pajak;
        $date_transaction = date('Y-m-d');

        if ($rest_invoice > 0) {
            //cash 
            $description = 'Invoice Booking Slot dengan kode invoice ' . $invoice_code;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $rest_invoice,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_tagihan,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        if ($total_piutang > 0) {
            //piutang
            $description = 'Piutang Invoice Booking Slot dengan kode invoice ' . $invoice_code;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas_piutang,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $total_piutang,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_tagihan,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        if ($total_pajak > 0) {
            //kewajiban pajak
            $description = 'Pajak Invoice Booking Slot dengan kode invoice ' . $invoice_code;
            $array_insert = [
                'id_book_account' => $array_account->akun_kewajiban_pajak,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_pajak,
                'status_act' => $code_transaction,
                'id_transaction' => $id_tagihan,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        //income
        $description = 'Pendapatan Booking Slot dengan kode invoice ' . $invoice_code;
        $array_insert = [
            'id_book_account' => $array_account->akun_pendapatan,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => 0,
            'credit' => $fix_income,
            'status_act' => $code_transaction,
            'id_transaction' => $id_tagihan,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
    }

    public function payment_invoice_bol($data)
    {
        //requirement data :
        // ['total_bayar'=>'','pajak_invoice'=>'','kode_invoice'=>'','id_tagihan'=>'']

        $code_transaction = 2;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $account_invoice = $this->db->where(['params' => 'account_invoice_transaction'])->get('app_module_setting')->row()->value;
        $array_account = json_decode($account_invoice);

        $total_bayar  = isset($data['total_bayar']) ? $data['total_bayar'] : 0;
        $total_pajak    = isset($data['pajak_invoice']) ? $data['pajak_invoice'] : 0;
        $invoice_code   = isset($data['kode_invoice']) ? $data['kode_invoice'] : '-';
        $id_tagihan     = isset($data['id_tagihan']) ? $data['id_tagihan'] : 0;

        $fix_income     = $total_bayar;
        $date_transaction = date('Y-m-d');

        //check tax
        $get_tax = Modules::run('database/find', 'tb_book_account_has_detail', ['status_act' => 1, 'id_book_account' => $array_account->akun_kas_pajak])->row();

        print_r($get_tax);
        exit;

        if ($total_pajak > 0 && empty($get_tax)) {
            $fix_income = $fix_income - $total_pajak;

            //pajak
            $description = 'Pajak dengan kode invoice ' . $invoice_code;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas_pajak,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $total_pajak,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_tagihan,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

            //     //kewajiban pajak
            $description = 'Pajak Bill of Lading (BOL) dengan kode invoice ' . $invoice_code;
            $array_insert = [
                'id_book_account' => $array_account->akun_kewajiban_pajak,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_pajak,
                'status_act' => $code_transaction,
                'id_transaction' => $id_tagihan,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        $description = 'Pembayaran Piutang dengan kode invoice ' . $invoice_code;
        $array_insert = [
            'id_book_account' => $array_account->akun_kas,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => $fix_income,
            'credit' => 0,
            'status_act' => $code_transaction,
            'id_transaction' => $id_tagihan,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

        $array_insert = [
            'id_book_account' => $array_account->akun_kas_piutang,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => 0,
            'credit' => $fix_income,
            'status_act' => $code_transaction,
            'id_transaction' => $id_tagihan,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
    }

    public function insert_cost_operational($data)
    {

        //requirement data
        $code_transaction = 3; //operational pembongakaran
        $account_cost_transaction = $this->db->where(['params' => 'account_cost_transaction'])->get('app_module_setting')->row()->value;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        //$account_invoice = $this->db->where(['params' => 'account_invoice_transaction'])->get('app_module_setting')->row()->value;
        $array_account = json_decode($account_cost_transaction);
        $date_transaction = isset($data['tanggal']) ? isset($data['total_biaya']) : date('Y-m-d');

        $total_biaya    = isset($data['total_biaya']) ? $data['total_biaya'] : 0;
        $total_bayar    = isset($data['total_bayar']) ? $data['total_bayar'] : 0;
        $total_hutang   = isset($data['total_hutang']) ? $data['total_hutang'] : 0;
        $kode_voyage    = isset($data['kode_voyage']) ? $data['kode_voyage'] : 0;
        $id_voyage      = isset($data['id_voyage']) ? $data['id_voyage'] : 0;
        $id_transaction  = isset($data['id_transaction']) ? $data['id_transaction'] : 0;
        $description    = isset($data['deskripsi']) ? $data['deskripsi'] : '';
        $operational_category  = isset($data['jenis_operasional']) ? $data['jenis_operasional'] : '';


        if ($total_bayar > 0) {
            $description = $description != '' ? $description : 'Biaya Operasional ' . $operational_category . ' dengan kode voyage ' . $kode_voyage;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_bayar,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
            $array_insert = [
                'id_book_account' => $array_account->akun_biaya,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $total_bayar,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        if ($total_hutang > 0) {
            $description =  $description != '' ? $description : 'Hutang Biaya Operasional ' . $operational_category . ' dengan kode voyage ' . $kode_voyage;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas_hutang,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $total_hutang,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

            $array_insert = [
                'id_book_account' => $array_account->akun_kewajiban_hutang,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_hutang,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }
    }

    public function delete_cost_operational($id_transaction)
    {
        $code_transaction = 3; //operational pembongakaran
        Modules::run('database/delete', 'tb_book_account_has_detail', ['status_act' => $code_transaction, 'id_transaction' => $id_transaction]);
    }

    public function insert_other_cost_operational($data)
    {
        //requirement data :
        //['total_biaya','total_bayar','total_hutang','kode_voyage','id_voyage']
        $code_transaction = 4; //operational biaya pembongakaran lainnya
        $account_cost_transaction = $this->db->where(['params' => 'account_other_cost_transaction'])->get('app_module_setting')->row()->value;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $array_account = json_decode($account_cost_transaction);
        $date_transaction = date('Y-m-d');

        $total_biaya  = isset($data['total_biaya']) ? $data['total_biaya'] : 0;
        $total_bayar  = isset($data['total_bayar']) ? $data['total_bayar'] : 0;
        $total_hutang  = isset($data['total_hutang']) ? $data['total_hutang'] : 0;
        $kode_voyage  = isset($data['kode_voyage']) ? $data['kode_voyage'] : 0;
        $id_voyage  = isset($data['id_voyage']) ? $data['id_voyage'] : 0;

        if ($total_bayar > 0) {
            $description = 'Biaya Pembongakaran dengan kode voyage ' . $kode_voyage;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_bayar,
                'status_act' => $code_transaction,
                'id_transaction' => $id_voyage,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        if ($total_hutang > 0) {
            $description = 'Hutang Biaya Pembongakaran dengan kode voyage ' . $kode_voyage;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas_hutang,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $total_hutang,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_voyage,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

            $array_insert = [
                'id_book_account' => $array_account->akun_kewajiban_hutang,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_hutang,
                'status_act' => $code_transaction,
                'id_transaction' => $id_voyage,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

            $total_biaya = $total_biaya - $total_hutang;
        }

        $description = 'Biaya Pembongakaran dengan kode voyage ' . $kode_voyage;
        $array_insert = [
            'id_book_account' => $array_account->akun_biaya,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => $total_bayar,
            'credit' => 0,
            'status_act' => $code_transaction,
            'id_transaction' => $id_voyage,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
    }

    public function insert_payment_credit($data)
    {
        //requirement data :
        //['total_bayar','kode_piutang','id_piutang']
        $code_transaction = 5; //operational pembayaran piutang
        $account = $this->db->where(['params' => 'account_payment_credit'])->get('app_module_setting')->row()->value;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $array_account = json_decode($account);
        $date_transaction = date('Y-m-d');

        $total_bayar  = isset($data['total_bayar']) ? $data['total_bayar'] : 0;
        $kode_piutang  = isset($data['kode_piutang']) ? $data['kode_piutang'] : 0;
        $id_piutang  = isset($data['id_piutang']) ? $data['id_piutang'] : 0;

        $description = 'Pembayaran Piutang, kode piutang ' . $kode_piutang;

        $array_insert = [
            'id_book_account' => $array_account->akun_kas,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => $total_bayar,
            'credit' => 0,
            'status_act' => $code_transaction,
            'id_transaction' => $id_piutang,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

        $array_insert = [
            'id_book_account' => $array_account->akun_kas_piutang,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => 0,
            'credit' => $total_bayar,
            'status_act' => $code_transaction,
            'id_transaction' => $id_piutang,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
    }

    public function insert_payment_debt($data)
    {
        //requirement data :
        //['total_bayar','kode_hutang','id_hutang']
        $code_transaction = 6; //operational pembayaran hutang
        $account = $this->db->where(['params' => 'account_payment_debt'])->get('app_module_setting')->row()->value;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $array_account = json_decode($account);
        $date_transaction = date('Y-m-d');

        $total_bayar  = isset($data['total_bayar']) ? $data['total_bayar'] : 0;
        $kode_hutang  = isset($data['kode_hutang']) ? $data['kode_hutang'] : 0;
        $id_hutang  = isset($data['id_hutang']) ? $data['id_hutang'] : 0;

        $description = 'Pembayaran hutang, kode hutang ' . $kode_hutang;

        $array_insert = [
            'id_book_account' => $array_account->akun_kewajiban_hutang,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => $total_bayar,
            'credit' => 0,
            'status_act' => $code_transaction,
            'id_transaction' => $id_hutang,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

        $array_insert = [
            'id_book_account' => $array_account->akun_kas_hutang,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => 0,
            'credit' => $total_bayar,
            'status_act' => $code_transaction,
            'id_transaction' => $id_hutang,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
    }

    public function insert_transaction_debt($data)
    {
        //requirement data :
        //['total_hutang','kode_hutang','id_hutang']
        $code_transaction = 7; //operational pembayaran hutang
        $account = $this->db->where(['params' => 'account_payment_debt'])->get('app_module_setting')->row()->value;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $array_account = json_decode($account);
        $date_transaction = date('Y-m-d');

        $total_hutang  = isset($data['total_hutang']) ? $data['total_hutang'] : 0;
        $kode_hutang  = isset($data['kode_hutang']) ? $data['kode_hutang'] : 0;
        $id_hutang  = isset($data['id_hutang']) ? $data['id_hutang'] : 0;

        $description = 'transaksi hutang, kode hutang ' . $kode_hutang;

        $array_insert = [
            'id_book_account' => $array_account->akun_kewajiban_hutang,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => 0,
            'credit' => $total_hutang,
            'status_act' => $code_transaction,
            'id_transaction' => $id_hutang,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

        $array_insert = [
            'id_book_account' => $array_account->akun_kas_hutang,
            'description' => $description,
            'date' => $date_transaction,
            'debit' => $total_hutang,
            'credit' => 0,
            'status_act' => $code_transaction,
            'id_transaction' => $id_hutang,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
    }

    public function insert_cost_maintenance($data)
    {

        //requirement data
        $code_transaction = 15; //operational pembongakaran
        $account_cost_transaction = $this->db->where(['params' => 'account_cost_transaction'])->get('app_module_setting')->row()->value;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        //$account_invoice = $this->db->where(['params' => 'account_invoice_transaction'])->get('app_module_setting')->row()->value;
        $array_account = json_decode($account_cost_transaction);
        $date_transaction = isset($data['tanggal']) ? isset($data['total_biaya']) : date('Y-m-d');

        $total_biaya    = isset($data['total_biaya']) ? $data['total_biaya'] : 0;
        $total_bayar    = isset($data['total_bayar']) ? $data['total_bayar'] : 0;
        $total_hutang   = isset($data['total_hutang']) ? $data['total_hutang'] : 0;
        $nama_aset    = isset($data['aset']) ? $data['aset'] : '-';
        $id_voyage      = isset($data['id_voyage']) ? $data['id_voyage'] : 0;
        $id_transaction  = isset($data['id_transaction']) ? $data['id_transaction'] : 0;
        $description    = isset($data['deskripsi']) ? $data['deskripsi'] : '';
        $operational_category  = isset($data['jenis_operasional']) ? $data['jenis_operasional'] : '';

        if ($total_bayar > 0) {
            $description = $description != '' ? $description : 'Biaya Operasional maintenance ' . $operational_category . ' , nama aset : ' . $nama_aset;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_bayar,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
            $array_insert = [
                'id_book_account' => $array_account->akun_biaya,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $total_bayar,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }

        if ($total_hutang > 0) {
            $description =  $description != '' ? $description : 'Hutang Biaya Operasional maintenance ' . $operational_category . ' , nama aset : ' . $nama_aset;
            $array_insert = [
                'id_book_account' => $array_account->akun_kas_hutang,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => $total_hutang,
                'credit' => 0,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

            $array_insert = [
                'id_book_account' => $array_account->akun_kewajiban_hutang,
                'description' => $description,
                'date' => $date_transaction,
                'debit' => 0,
                'credit' => $total_hutang,
                'status_act' => $code_transaction,
                'id_transaction' => $id_transaction,
                'token' => $token
            ];
            Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
        }
    }

    public function delete_cost_maintenance($id_transaction)
    {
        $code_transaction = 15; //operational pembongakaran
        Modules::run('database/delete', 'tb_book_account_has_detail', ['status_act' => $code_transaction, 'id_transaction' => $id_transaction]);
    }

    public function insert_salary($data)
    {
        $code_transaction = 16; //penggajian 
        $nominal    = isset($data['nominal']) ? $data['nominal'] : 0;
        $id_transaksi    = isset($data['id_transaksi']) ? $data['id_transaksi'] : 0;
        $akun_biaya    = isset($data['akun_biaya']) ? $data['akun_biaya'] : '-';
        $akun_kas      = isset($data['akun_kas']) ? $data['akun_kas'] : 0;
        $deskripsi  = isset($data['deskripsi']) ? $data['deskripsi'] : 0;
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name

        $array_insert = [
            'id_book_account' => $akun_kas,
            'description' => $deskripsi,
            'date' => date('Y-m-d'),
            'debit' => 0,
            'credit' => $nominal,
            'status_act' => $code_transaction,
            'id_transaction' => $id_transaksi,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);

        $array_insert = [
            'id_book_account' => $akun_biaya,
            'description' => $deskripsi,
            'date' => date('Y-m-d'),
            'debit' => $nominal,
            'credit' => 0,
            'status_act' => $code_transaction,
            'id_transaction' => $id_transaksi,
            'token' => $token
        ];
        Modules::run('database/insert', 'tb_book_account_has_detail', $array_insert);
    }



    public function test()
    {
        // ---------- insert_invoice_bol -------------------
        // $array_data = ['total_tagihan' => 100000, 'total_pajak' => 10000, 'piutang' => 30000, 'kode_invoice' => 'ABC1', 'id_tagihan' => 1];
        // Modules::run('accounting/insert_invoice_bol', $array_data);

        // ---------- payment_invoice_bol -------------------
        // $array_data = ['total_bayar' => 100000, 'pajak_invoice' => 10000, 'kode_invoice' => 'ABC1', 'id_tagihan' => 1];
        // Modules::run('accounting/payment_invoice_bol', $array_data);

        // ---------- insert_cost_operational -------------------
        // $array_data = ['total_biaya' => 100000, 'total_bayar' => 30000, 'total_hutang' => 70000, 'kode_voyage' => 'ABCD 1', 'id_voyage' => 1];
        // Modules::run('accounting/insert_cost_operational', $array_data);

        // ---------- insert_cost_operational -------------------
        // $array_data = ['total_biaya' => 100000, 'total_bayar' => 30000, 'total_hutang' => 70000, 'kode_voyage' => 'ABCD 1', 'id_voyage' => 1];
        // Modules::run('accounting/insert_other_cost_operational', $array_data);

        // // ---------- insert_payment_credit -------------------
        // $array_data = ['total_bayar' => 10000, 'kode_piutang' => 'AUHGHB', 'id_piutang' => 1];
        // Modules::run('accounting/insert_payment_credit', $array_data);

        // ---------- insert_payment_debt -------------------
        // $array_data = ['total_bayar' => 10000, 'kode_hutang' => 'AUHGHB', 'id_hutang' => 1];
        // Modules::run('accounting/insert_payment_debt', $array_data);
    }
}
