<?php
// $get_profile = $this->db->get('tm_profile')->row();
$list_account   = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);
$balance_sheet_account   = json_decode($this->db->where(['params' => 'balance_sheet_account'])->get('app_module_setting')->row()->value, TRUE);
// print_r($balance_sheet_account);

function count_grand_total_saldo($list_debit, $list_credit)
{

    $total_debit = 0;
    $total_credit = 0;
    if ($list_debit) {
        $array_debit = explode(',', $list_debit);
        foreach ($array_debit as $item_debit) {
            $explode_item_debit = explode('-', $item_debit);
            $total_debit += $explode_item_debit[1];
        }
    }

    if ($list_credit) {
        $array_credit = explode(',', $list_credit);
        foreach ($array_credit as $item_credit) {
            $explode_item_credit = explode('-', $item_credit);
            $total_credit += $explode_item_credit[1];
        }
    }

    $array_respon = [
        'credit' => $total_credit,
        'debit' => $total_debit
    ];

    return  $array_respon;
}


?>
<div class="card" style="">
    <div class="card-body">
        <div class="col-md-12">
            <div class="col-md-12 text-center">
                <img style="width: 150px;;" src="<?= base_url('assets/images/logo.png'); ?>" alt="">
            </div>
            <div class="col-md-12 text-center">
                <!-- <h2><?= $get_profile->name ?> " <?= $get_profile->tagline; ?> "</h2>
                <p><?= $get_profile->address; ?></p> -->
                <h3 class="">NERACA LAJUR</h3>
                <p>PERIODE PER TANGGAL : <b><?= $array_date['date_to']; ?></b></p>
            </div>
            <span class="clearfix"></span>
            <div class="col-md-12 mt-10">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th rowspan="2">Kode Akun</th>
                                <th rowspan="2">Nama Akun</th>
                                <th colspan="2">Neraca Saldo</th>
                                <th colspan="2">Jurnal Penyesuian</th>
                                <th colspan="2">Setelah penyesuaian</th>
                                <th colspan="2">Laba/Rugi</th>
                                <th colspan="2">Neraca</th>
                            </tr>
                            <tr>
                                <th>Debit</th>
                                <th>Kredit</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $data_print = [];
                            $data_print['spesification'] = $array_date;
                            $total_saldo_debit = 0;
                            $total_saldo_credit = 0;

                            $total_saldo_adjusment_debit = 0;
                            $total_saldo_adjusment_credit = 0;

                            $total_saldo_after_adjusment_debit = 0;
                            $total_saldo_after_adjusment_credit = 0;

                            $total_profit_debit = 0;
                            $total_profit_credit = 0;

                            $total_balance_debit = 0;
                            $total_balance_credit = 0;

                            foreach ($data_account as $item_account) {
                                $type_saldo = $list_account[$item_account->type_account]['type_saldo'];
                                // print_r($type_saldo);

                                // $array_adjusting_debit_saldo = $item_account->adjusting_debit_saldo;
                                // $array_adjusting_credit_saldo = $item_account->adjusting_credit_saldo;
                                $trial_balance_saldo  = count_grand_total_saldo($item_account->list_debit_saldo, $item_account->list_credit_saldo);
                                $adjusting_saldo = count_grand_total_saldo($item_account->adjusting_debit_saldo, $item_account->adjusting_credit_saldo);


                                $label_saldo_debit = '-';
                                $label_saldo_credit = '-';
                                $label_adjustment_debit = '';
                                $label_adjustment_credit = '-';
                                $label_after_adjustment_debit = '';
                                $label_after_adjustment_credit = '-';

                                $label_adjustment_debit = $adjusting_saldo['debit'] ?  '' . number_format($adjusting_saldo['debit'], 0, '.', '.') : '-';
                                $label_adjustment_credit = $adjusting_saldo['credit'] ?  '' . number_format($adjusting_saldo['credit'], 0, '.', '.') : '-';
                                $total_saldo_adjusment_debit += $adjusting_saldo['debit'];
                                $total_saldo_adjusment_credit += $adjusting_saldo['credit'];


                                $label_profit_debit     = '-';
                                $label_profit_credit    = '-';

                                $label_balance_debit     = '-';
                                $label_balance_credit    = '-';
                                $saldo_current = isset($array_first_saldo[$item_account->id_book_account]) ? $array_first_saldo[$item_account->id_book_account] : 0;
                                if ($type_saldo == 'debit') {
                                    $total_saldo = $saldo_current + ($trial_balance_saldo['debit'] - $trial_balance_saldo['credit']);
                                    $total_saldo_debit += $total_saldo;
                                    $label_saldo_debit = '' . number_format($total_saldo, 0, '.', '.');

                                    $saldo_adjusment        = $adjusting_saldo['debit'] - $adjusting_saldo['credit'];


                                    $saldo_after_adjusment  =  $total_saldo + $saldo_adjusment;
                                    $total_saldo_after_adjusment_debit += $saldo_after_adjusment;


                                    $label_after_adjustment_debit = '' . number_format($saldo_after_adjusment, 0, '.', '.');


                                    if (in_array($item_account->type_account, $balance_sheet_account)) {
                                        $label_balance_debit =  '' . number_format($saldo_after_adjusment, 0, '.', '.');
                                        $total_balance_debit += $saldo_after_adjusment;
                                    } else {
                                        $label_profit_debit =  '' . number_format($saldo_after_adjusment, 0, '.', '.');
                                        $total_profit_debit += $saldo_after_adjusment;
                                    }
                                    //adjusment 
                                } else {

                                    $total_saldo = $saldo_current + ($trial_balance_saldo['credit'] - $trial_balance_saldo['debit']);
                                    $total_saldo_credit += $total_saldo;
                                    $label_saldo_credit = '' . number_format($total_saldo, 0, '.', '.');

                                    $saldo_adjusment = $adjusting_saldo['credit'] - $adjusting_saldo['debit'];

                                    $saldo_after_adjusment  =  $total_saldo + $saldo_adjusment;
                                    $total_saldo_after_adjusment_credit += $saldo_after_adjusment;

                                    $label_after_adjustment_credit = '' . number_format($saldo_after_adjusment, 0, '.', '.');

                                    if (in_array($item_account->type_account, $balance_sheet_account)) {
                                        $label_balance_credit =  '' . number_format($saldo_after_adjusment, 0, '.', '.');
                                        $total_balance_credit += $saldo_after_adjusment;
                                    } else {
                                        $label_profit_credit =  '' . number_format($saldo_after_adjusment, 0, '.', '.');
                                        $total_profit_credit += $saldo_after_adjusment;
                                    }
                                }

                                //labal rugi

                                echo '
                                        <tr>
                                            <td>' . $item_account->code_account . '</td>
                                            <td>' . strtoupper($item_account->account_name) . '</td>
                                            <td>' . $label_saldo_debit . '</td>
                                            <td>' . $label_saldo_credit . '</td>
                                            <td>' . $label_adjustment_debit . '</td>
                                            <td>' . $label_adjustment_credit . '</td>
                                            <td>' . $label_after_adjustment_debit . '</td>
                                            <td>' . $label_after_adjustment_credit . '</td>
                                            <td>' . $label_profit_debit . '</td>
                                            <td>' . $label_profit_credit . '</td>
                                            <td>' . $label_balance_debit . '</td>
                                            <td>' . $label_balance_credit . '</td>
                                        </tr>
                                    ';

                                $data_print['data_print'][] = [
                                    'code_account' => $item_account->code_account,
                                    'account' => strtoupper($item_account->account_name),
                                    'label_saldo_debit' => $label_saldo_debit,
                                    'label_saldo_credit' => $label_saldo_credit,
                                    'label_adjusment_debit' => $label_adjustment_debit,
                                    'label_adjustment_credit' => $label_adjustment_credit,
                                    'label_after_adjustment_debit' => $label_after_adjustment_debit,
                                    'label_after_adjustment_credit' => $label_after_adjustment_credit,
                                    'label_profit_debit' => $label_profit_debit,
                                    'label_profit_credit' => $label_profit_credit,
                                    'label_balance_debit' => $label_balance_debit,
                                    'label_balance_credit' => $label_balance_credit
                                ];
                            }
                            echo '
                                <tr>
                                    <td colspan="2" class="text-bold" style="font-size:14px;">TOTAL SALDO</td>
                                    <td class="text-bold"> ' . number_format($total_saldo_debit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_saldo_credit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_saldo_adjusment_debit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_saldo_adjusment_credit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_saldo_after_adjusment_debit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_saldo_after_adjusment_credit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_profit_debit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_profit_credit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_balance_debit, 0, '.', '.') . '</td>
                                    <td class="text-bold"> ' .  number_format($total_balance_credit, 0, '.', '.') . '</td>
                                </tr>
                            ';
                            $data_print['total'] = [
                                'total_saldo_debit' => $total_saldo_debit,
                                'total_saldo_credit' => $total_saldo_credit,
                                'total_saldo_adjusment_debit' => $total_saldo_adjusment_debit,
                                'total_saldo_adjusment_credit' => $total_saldo_adjusment_credit,
                                'total_saldo_after_adjusment_debit' => $total_saldo_after_adjusment_debit,
                                'total_saldo_after_adjusment_credit' => $total_saldo_after_adjusment_credit,
                                'total_profit_debit' => $total_profit_debit,
                                'total_profit_credit' => $total_profit_credit,
                                'total_balance_debit' => $total_balance_debit,
                                'total_balance_credit' => $total_balance_credit
                            ];
                            $count_advantage = $total_profit_credit - $total_profit_debit;
                            echo '
                                    <tr>
                                        <td colspan="8" class="text-bold text-right" style="font-size:14px;">LABA RUGI</td>
                                        <td class="text-bold" style="font-size:16px;"></td>
                                        <td class="text-bold" style="font-size:16px;"> ' .  number_format($count_advantage, 0, '.', '.') . '</td>
                                        <td class="text-bold" style="font-size:16px;" colspan="2"></td>
                                    </tr>
                                ';
                            $data_print['advantage'] = $count_advantage;
                            $total_balance_credit += $count_advantage;
                            $selisih = $total_balance_debit - $total_balance_debit;

                            if ($selisih == 0) {
                                $label_output = '<label class="text-green">BALANCE</label>';
                            } else {
                                $label_output = '<label class="text-red">NOT BALANCE</label>';
                            }

                            echo '
                                    <tr>
                                        <td colspan="10" class="text-bold text-right" style="font-size:14px;">' . $label_output . '</td>
                                        <td class="text-bold" style="font-size:16px;"> ' .  number_format($total_balance_debit, 0, '.', '.') . '</td>
                                        <td class="text-bold" style="font-size:16px;"> ' .  number_format($total_balance_credit, 0, '.', '.') . '</td>
                                    </tr>
                                ';
                            $data_print['balance'] = [
                                'label' => $label_output,
                                'debit' => $total_balance_debit,
                                'credit' => $total_balance_credit
                            ];

                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <!-- <div class="col-md-12 text-right p-20">
                <form method="POST" action="<?= base_url('accounting_report/print_balance_sheet'); ?>">
                    <small>(*klik untuk cetak laporan)</small>
                    <input type="hidden" value="<?= $this->encrypt->encode(json_encode($data_print)); ?>" name="data_result">
                    <button type="submit" class="btn btn-success btn-lg"><i class="fa fa-file-pdf-o"></i> Cetak PDF</button>
                </form>
            </div> -->
        </div>
    </div>
    <!-- /.card-body -->
</div>