<?php
// $get_profile = $this->db->get('tm_profile')->row();
$array_profit = [];
$array_hpp = [];
$array_cost = [];
$array_resume = [];
?>
<div class="card border" style="margin-left:10%;margin-right: 10% !important;width:80%;">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12 text-center">
                <img style="width: 150px;;" src="<?= base_url('assets/images/logo.png'); ?>" alt="">
            </div>
            <div class="col-md-12 text-center">
                <!-- <h2><?= $get_profile->name ?> </h2> -->
                <!-- <p><?= $get_profile->address; ?></p> -->
                <h5 class="">LAPORAN LABA RUGI</h5>
                <p>PERIODE : <b><?= $array_date['date_from'] . ' S/d ' . $array_date['date_to']; ?></b></p>
            </div>
            <span class="clearfix"></span>
            <div class="col-md-8">
                <div class="table-responsive">
                    <h5 class="mb-10">PENDAPATAN</h5>
                    <table class="table">
                        <?php
                        $total_profit = 0;
                        foreach ($data_profit as $item_profit) {
                            $total_profit += $item_profit->total_saldo;
                            echo '
                            <tr>
                                <td width="200px">' . $item_profit->account_name . '</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($item_profit->total_saldo, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                            $array_profit['data_print'][] = [
                                'account_name' => $item_profit->account_name,
                                'saldo' => $item_profit->total_saldo
                            ];
                        }

                        echo '
                            <tr>
                                <td width="200px" class="text-bold">TOTAL PENDAPATAN</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($total_profit, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                        $array_profit['total_saldo'] = $total_profit;

                        ?>

                    </table>
                    <h5 class="mb-10">HPP (HARGA POKOK PENJUALAN) : </h5>
                    <table class="table">
                        <?php
                        $total_hpp = 0;
                        foreach ($data_hpp as $item_hpp) {
                            $total_hpp += $item_hpp->total_saldo;
                            echo '
                            <tr>
                                <td width="200px">' . $item_hpp->account_name . '</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($item_hpp->total_saldo, 0, '.', '.') . '</b></td>
                            </tr>
                            ';

                            $array_hpp['data_print'][] = [
                                'account_name' => $item_hpp->account_name,
                                'saldo' => $item_hpp->total_saldo
                            ];
                        }
                        echo '
                            <tr>
                                <td width="200px" class="text-bold">TOTAL HPP</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($total_hpp, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                        $array_hpp['total_saldo'] = $total_hpp;
                        ?>
                    </table>

                    <h5 class="mb-10">BIAYA : </h5>
                    <table class="table">
                        <?php
                        $total_cost = 0;
                        foreach ($data_cost as $item_cost) {
                            $total_cost += $item_cost->total_saldo;
                            echo '
                            <tr>
                                <td width="200px">' . $item_cost->account_name . '</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($item_cost->total_saldo, 0, '.', '.') . '</b></td>
                            </tr>
                            ';

                            $array_cost['data_print'][] = [
                                'account_name' => $item_cost->account_name,
                                'saldo' => $item_cost->total_saldo
                            ];
                        }
                        echo '
                            <tr>
                                <td width="200px" class="text-bold">TOTAL BIAYA</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($total_cost, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                        $array_cost['total_saldo'] = $total_cost;
                        ?>
                    </table>
                </div>
            </div>

            <?php
            $bruto_profit = $total_profit - $total_hpp;
            $nett_profit =  $total_profit - ($total_hpp + $total_cost);

            $array_resume = [
                'bruto' => $bruto_profit,
                'nett' => $nett_profit
            ];

            $data_print = [
                'profit' => $array_profit,
                'cost' => $array_cost,
                'hpp' => $array_hpp,
                'resume' => $array_resume,
                'spesification' => $array_date
            ];
            ?>

            <div class="col-md-4">
                <h5 class="text-center mb-10">Laba/Rugi:</h5>
                <div class="border-radius-5 p-10 text-center bg-warning mb-10">
                    <label>Laba/Rugi (Kotor)</label>
                    <h2><b><?= 'Rp.' . number_format($bruto_profit, 0, '.', '.'); ?></b></h2>
                </div>
                <div class="border-radius-5 p-10 text-center bg-warning mb-10">
                    <label>Laba/Rugi (bersih)</label>
                    <h2><b><?= 'Rp.' . number_format($nett_profit, 0, '.', '.'); ?></b></h2>
                </div>
                <hr>
                <div class="text-center">
                    <div class="col-md-12 text-right mt-3">
                        <form method="POST" action="<?= Modules::run('helper/create_url', 'accounting/print_profit_lost'); ?>">
                            <small>(*klik untuk cetak laporan)</small>
                            <input type="hidden" value="<?= $this->encrypt->encode(json_encode($data_print)); ?>" name="data_result">
                            <button type="submit" class="btn btn-primary btn-lg"><i class="fa fa-file-pdf-o"></i> Cetak EXCEL</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>
    <!-- /.card-body -->
</div>