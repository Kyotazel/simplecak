<?php

$html_journal_debit = '';
$html_journal_credit = '';

$total_debit = 0;
$total_credit = 0;


foreach ($data_journal as $item_journal) {

    $date = Modules::run('helper/change_date', $item_journal->date, '-');

    $html_option = '';
    foreach ($data_account as $item_account) {
        $selected = $item_account->id == $item_journal->id_book_account ? 'selected' : '';
        $html_option .=  '
                            <option ' . $selected . ' value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                        ';
    }

    if ($item_journal->debit > 0) {
        $total_debit += $item_journal->debit;
        $html_journal_debit .= '
            <div class="media mb-1">
                <div class="media-body">
                    <div class="row">
                        <div class="col-12 p-0">
                            <label for="" class="m-0 font-weight-bold">Masukan COA dan keterangan jurnal : </label>
                        </div>
                        <div class="col-12 p-0">
                            <select name="account_debit[]" class="form-control chosen">' . $html_option . '</select>
                        </div>
                        <div class="col-6 p-0">
                            <div class="input-group d-flex">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="width: 50px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control money_only price_debit" name="price_debit[]" value="' . number_format($item_journal->debit, 0, '.', '.') . '" placeholder="masukan nominal">
                            </div>
                        </div>
                        <div class="col-6 p-0">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="width: 50px;"><i class="fa fa-calendar"></i></div>
                                </div>
                                <input type="text" data-language="en" class="form-control datepicker_form bg-white" readonly name="date_debit[]" value="' . $date . '"  placeholder="Pilih tanggal transaksi">
                            </div>
                        </div>
                        <div class="col-12 p-0">
                            <textarea name="desc_debit[]" class="form-control" placeholder="ketik deskrispi" rows="2">' . $item_journal->description . '</textarea>
                        </div>
                        <div class="col-12 text-right p-0"> 
                            <a href="javascript:void(0)" class="btn btn-danger btn-sm btn_delete_item"><i class="fa fa-trash"></i> Hapus</a>
                        </div>
                    </div>
                </div>
            </div>
        ';
    }

    if ($item_journal->credit > 0) {
        $total_credit += $item_journal->credit;
        $html_journal_credit .= '
            <div class="media mb-1">
                <div class="media-body">
                    <div class="row">
                        <div class="col-12 p-0">
                            <label for="" class="m-0 font-weight-bold">Masukan COA dan keterangan jurnal : </label>
                        </div>
                        <div class="col-12 p-0">
                            <select name="account_credit[]" class="form-control chosen" >' . $html_option . '</select>
                        </div>
                        <div class="col-6 p-0">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="width: 50px;">Rp.</div>
                                </div>
                                <input type="text" class="form-control money_only price_credit" name="price_credit[]" value="' . number_format($item_journal->credit, 0, '.', '.') . '" placeholder="masukan nominal">
                            </div>
                        </div>
                        <div class="col-6 p-0">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text" style="width: 50px;"><i class="fa fa-calendar"></i></div>
                                </div>
                                <input type="text" data-language="en" class="form-control datepicker_form bg-white" readonly name="date_credit[]" placeholder="Pilih tanggal transaksi" value="' . $date . '">
                            </div>
                        </div>
                        <div class="col-12 p-0">
                            <textarea name="desc_credit[]" class="form-control" placeholder="ketik deskrispi" rows="2">' . $item_journal->description . '</textarea>
                        </div>
                        <div class="col-12 text-right p-0">
                            <a href="javascript:void(0)" class="btn btn-danger btn-sm btn_delete_item"><i class="fa fa-trash"></i> Hapus</a>
                        </div>
                    </div>
                </div>
            </div>
        ';
    }
}

?>
<form class="form-update-journal">
    <div class="row pl-3 pr-3">
        <div class="card border shadow-none col-6 p-0 m-0">
            <div class="card-header ">
                <div class="row align-items-center">
                    <h3 class="card-title m-0 p-0 col-6">
                        <i class="fa fa-tv text-primary"></i> DEBIT
                        <small>(* masukan item debit)</small>
                    </h3>
                    <div class="col-6">
                        <a href="javascript:void(0)" class="btn btn-dark btn-sm waves-effect waves-light btn_add_form" data-type="debit"><i class="fa fa-plus-circle"></i> Tambah Item Debit</a>
                    </div>
                </div>
            </div>
            <div class="card-body html_from_debit" style="min-height: 500px;">
                <?= $html_journal_debit; ?>
            </div>

            <div class="card-footer text-center">
                <h3 class="text-primary text_total_debit m-0 p-0 font-weight-bold" data-price="<?= $total_debit; ?>">Rp.<?= number_format($total_debit, 0, '.', '.'); ?></h3>
            </div>
        </div>


        <div class="card border shadow-none col-6 p-0 m-0">
            <div class="card-header ">
                <div class="row align-items-center">
                    <h3 class="card-title m-0 p-0 col-6">
                        <i class="fa fa-tv text-primary"></i> Kredit
                        <small>(* masukan item kredit)</small>
                    </h3>
                    <div class="col-6">
                        <a href="javascript:void(0)" class="btn btn-dark btn-sm waves-effect waves-light btn_add_form" data-type="credit"><i class="fa fa-plus-circle"></i> Tambah Item Kredit</a>
                    </div>
                </div>
            </div>
            <div class="card-body html_from_credit" style="min-height: 500px;">
                <?= $html_journal_credit; ?>
            </div>
            <div class="card-footer text-center">
                <h3 class="text-primary text_total_credit m-0 p-0 font-weight-bold" data-price="<?= $total_credit; ?>">Rp.<?= number_format($total_credit, 0, '.', '.'); ?></h3>
            </div>
        </div>
    </div>
</form>
<div class="col-12 text-right mt-1">
    <a href="javascript:void(0)" class="btn btn-primary btn_save_update_journal" data-token="<?= $token; ?>">Simpan Data <i class="fa fa-paper-plane"></i></a>
</div>