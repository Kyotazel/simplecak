<?php
// $get_profile = $this->db->get('tm_profile')->row();
$list_account   = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);

?>
<div class="card border" style="margin-left:10%;margin-right: 10% !important;width:80%;">
    <div class="card-body">
        <div class="col-md-12">
            <div class="col-md-12 text-center">
                <img style="width: 150px;;" src="<?= base_url('assets/images/logo.png'); ?>" alt="">
            </div>
            <div class="col-md-12 text-center">
                <!-- <h2><?= $get_profile->name ?> " <?= $get_profile->tagline; ?> "</h2>
                <p><?= $get_profile->address; ?></p> -->
                <h3 class="">NERACA</h3>
                <p>PERIODE PER TANGGAL : <b><?= $array_date['date_to']; ?></b></p>
            </div>
            <span class="clearfix"></span>
            <div class="row">
                <div class="col-md-6">
                    <h3 class="mb-10">AKTIVA: </h3>
                    <table class="table">
                        <?php
                        $data_print = [];
                        $data_print['date'] = $array_date['date_to'];

                        $total_activa = 0;
                        foreach ($data_activa as $item_activa) {
                            $total_activa += $item_activa->total_saldo;
                            echo '
                            <tr>
                                <td width="200px">' . $item_activa->account_name . '</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($item_activa->total_saldo, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                            $data_print['data_print']['activa'][] = [
                                'account_name' => $item_activa->account_name,
                                'saldo' => $item_activa->total_saldo
                            ];
                        }

                        echo '
                            <tr>
                                <td width="200px" class="text-bold"><b>TOTAL AKTIVA</b></td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($total_activa, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                        $data_print['total_activa'] = $total_activa;
                        ?>
                    </table>
                </div>
                <div class="col-md-6">
                    <h3 class="mb-10">KEWAJIBAN : </h3>
                    <table class="table">
                        <?php
                        $total_passiva = 0;
                        foreach ($data_passiva as $item_passiva) {
                            $total_passiva += $item_passiva->total_saldo;
                            echo '
                            <tr>
                                <td width="200px">' . $item_passiva->account_name . '</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($item_passiva->total_saldo, 0, '.', '.') . '</b></td>
                            </tr>
                            ';

                            $data_print['data_print']['obligate'][] = [
                                'account_name' => $item_passiva->account_name,
                                'saldo' => $item_passiva->total_saldo
                            ];
                        }
                        echo '
                            <tr>
                                <td width="200px" class="text-bold"><b>TOTAL KEWAJIBAN</b></td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($total_passiva, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                        $data_print['total_obligate'] = $total_passiva;
                        ?>
                    </table>

                    <h3 class="mb-10">MODAL : </h3>
                    <table class="table">
                        <?php
                        $total_modal = 0;
                        foreach ($data_modal as $item_modal) {
                            $total_modal += $item_modal->total_saldo;
                            echo '
                            <tr>
                                <td width="200px">' . $item_modal->account_name . '</td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($item_modal->total_saldo, 0, '.', '.') . '</b></td>
                            </tr>
                            ';

                            $data_print['data_print']['modal'][] = [
                                'account_name' => $item_modal->account_name,
                                'saldo' => $item_modal->total_saldo
                            ];
                        }
                        echo '
                            <tr>
                                <td width="200px" class="text-bold"><b>LABA / RUGI</b></td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($data_nett_profit, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                        $total_modal += $data_nett_profit;
                        $data_print['nett_profit'] = $data_nett_profit;
                        echo '
                            <tr>
                                <td width="200px" class="text-bold"><b>TOTAL MODAL</b></td>
                                <td width="10px">:</td>
                                <td><b>Rp.' . number_format($total_modal, 0, '.', '.') . '</b></td>
                            </tr>
                            ';
                        $data_print['total_modal'] = $total_modal;
                        $total_passiva += $total_modal;

                        echo '
                        <tr>
                            <td width="200px" class="text-bold"><b>TOTAL PASSIVA</b></td>
                            <td width="10px">:</td>
                            <td><b>Rp.' . number_format($total_passiva, 0, '.', '.') . '</b></td>
                        </tr>
                        ';
                        $data_print['total_passiva'] = $total_passiva;
                        ?>
                    </table>
                </div>
            </div>
            <span class="clearfix"></span>

            <div class="col-md-12 text-right p-20">
                <form method="POST" action="<?= Modules::run('helper/create_url', 'accounting/print_balance'); ?>">
                    <small>(*klik untuk cetak laporan)</small>
                    <input type="hidden" value="<?= $this->encrypt->encode(json_encode($data_print)); ?>" name="data_result">
                    <button type="submit" class="btn btn-primary btn-lg"><i class="fa fa-file-pdf-o"></i> Cetak EXCEL</button>
                </form>
            </div>
        </div>
    </div>
    <!-- /.card-body -->
</div>