<?php
$btn_add = Modules::run('security/create_access', '
<button type="button" title="add data" class="btn btn-primary-gradient btn-rounded font-weight-bold btn_add_cashout">
    <i class="fa fa-plus-circle"></i> Tambah Data
</button>
');
?>
<div class="card">
    <div class="card-body">
        <div class="mb-3 row">
            <h3 class="col-md-8">Data Kas Masuk</h3>
            <div class="col-md-4 text-right">
                <?= $btn_add; ?>
            </div>
            <div class="col-12 p-2 border-dashed rounded mt-2">
                <form class="form-search-cash-in">
                    <div class="row">
                        <div class="col-5 row">
                            <div class="col-md-6">
                                <label for="">
                                    TANGGAL AWAL
                                    <a href="javascript:void(0)" class="empty_form" data-name="date_from" title="empty date"><i class="fa fa-history"></i></a>
                                </label>
                                <input type="text" class="form-control datepicker bg-white" placeholder="piih tanggal..." readonly="" name="date_from">
                            </div>
                            <div class="col-md-6">
                                <label for="">
                                    TANGGAL AKHIR
                                    <a href="javascript:void(0)" class="empty_form" data-name="date_to" title="empty date"><i class="fa fa-history"></i></a>
                                </label>
                                <input type="text" class="form-control datepicker bg-white" placeholder="piih tanggal..." readonly="" name="date_to">
                            </div>
                        </div>
                        <div class="col-3 form-group">
                            <label for="exampleInputEmail1">AKUN KAS TUJUAN :</label>
                            <select name="debit_account" class="form-control chosen">
                                <option value="">Semua</option>
                                <?php
                                foreach ($data_cash as $item_account) {
                                    echo '
                                            <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-3 form-group">
                            <label for="exampleInputEmail1">DARI DANA :</label>
                            <select name="credit_account" class="form-control chosen">
                                <option value="">Semua</option>
                                <?php
                                foreach ($data_account as $item_account) {
                                    echo '
                                            <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-1">
                            <label for="">&nbsp;</label><br>
                            <button type="submit" class="btn btn-primary-gradient btn-rounded btn-block btn_search_cash_in"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="html_respon_cash_in"></div>


    </div>
    <div class="html_respon"></div>
    <!-- /.card-body -->
</div>


<div class="modal" id="modal_form_cash_out">
    <div class="modal-dialog" style="max-width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="card-body pad">
                <form role="form" class="form-input">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6  p-10">
                                <div class="col-md-12 form-group">
                                    <label for="exampleInputEmail1">AKUN KAS TUJUAN :</label>
                                    <select name="debit_account" class="form-control chosen">
                                        <?php
                                        foreach ($data_cash as $item_account) {
                                            echo '
                                            <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                        }
                                        ?>
                                    </select>
                                    <span class="help-block notif_debit_account text-danger"></span>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label for="exampleInputEmail1">DARI DANA :</label>
                                    <select name="credit_account" class="form-control chosen">
                                        <?php
                                        foreach ($data_account as $item_account) {
                                            echo '
                                            <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                        }
                                        ?>
                                    </select>
                                    <span class="help-block notif_credit_account text-danger"></span>
                                </div>
                            </div>
                            <div class="col-md-6 border border-radius-5 p-10">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tanggal</label>
                                    <input class="form-control bg-white datepicker_form " data-language="en" name="date" type="text" readonly>
                                    <span class="help-block text-danger notif_date"></span>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Nominal (Rp.)</label>
                                    <input class="form-control money_only" name="price" type="text">
                                    <span class="help-block text-danger notif_price"></span>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Keterangan</label>
                                    <textarea name="description" class="form-control" rows="5"></textarea>
                                    <span class="help-block text-danger notif_description"></span>
                                </div>
                            </div>
                            <div class="col-md-12 text-right mt-2">
                                <small>(*klik untuk simpan data) </small>&nbsp;
                                <button type="submit" data-status="2" class="btn btn-primary btn-rounded pull-right btn_save_cashout"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
</div>