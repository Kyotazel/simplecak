<?php
function change_date($date)
{
    $explode_date = explode('-', $date);
    $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
    return $date_return;
}
?>
<style>
    .datepicker {
        z-index: 1200 !important;
    }

    table.display {
        margin: 0 auto;
        width: 100%;
        clear: both;
        border-collapse: collapse;
        table-layout: fixed;
        word-wrap: break-word;
    }
</style>
<div class="card">
    <div class="card-body">

        <form class="form-input">
            <div class="row">
                <div class="col-md-4 form-group">
                    <label>Periode Akuntansi :</label>
                    <select name="period" class=" form-control">
                        <?php
                        foreach ($data_period as $item_period) {
                            $selected = $item_period->status ? 'selected' : '';
                            echo '
                                                    <option data-id="' . $item_period->id . '" ' . $selected . ' value="' . change_date($item_period->date_from) . '/' . change_date($item_period->date_to) . '">' . $item_period->name . '</option>
                                                ';
                        }
                        ?>
                    </select>
                </div>

                <div class="col-md-4 form-group">
                    <label for="">Per tanggal Neraca</label>
                    <input type="text" readonly class="bg-white form-control datepicker_form" data-language="en" name="date_to">
                    <span class="help-block"></span>
                </div>
                <div class="col-md-2 text-left">
                    <label>&nbsp;</label><br>
                    <button class="btn btn-primary btn-block btn_search_trial_balance"><i class="fa fa-search"></i> Cari Data</button>
                </div>
            </div>
        </form>
    </div>
    <div class="html_respon"></div>
    <!-- /.card-body -->
</div>