<?php
$array_jurnal = [
    0 => 'Jurnal',
    1 => 'penyesuaian'
];
?>
<style>
    .form-group {
        margin-bottom: 0;
    }
</style>



<div class="container">
    <div class="card">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="card-title m-0">Input Jurnal</h3>
                </div>
                <div class="col-4 mb-2 d-flex align-items-center">
                    <label for="" class="font-weight-bold" style="width: 150px;">Jenis Jurnal</label>
                    <select class="form-control" name="type">
                        <option value="0">Jurnal</option>
                        <option value="1">Penyesuaian</option>
                    </select>
                </div>
            </div>
            <form class="form-update-journal">
                <div class="row pl-3 pr-3">
                    <div class="card border shadow-none col-6 p-0 m-0">
                        <div class="card-header ">
                            <div class="row align-items-center">
                                <h3 class="card-title m-0 p-0 col-6">
                                    <i class="fa fa-tv text-primary"></i> DEBIT
                                    <small>(* masukan item debit)</small>
                                </h3>
                                <div class="col-6">
                                    <a href="javascript:void(0)" class="btn btn-dark btn-sm waves-effect waves-light btn_add_form" data-type="debit"><i class="fa fa-plus-circle"></i> Tambah Item Debit</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body html_from_debit" style="min-height: 500px;">
                        </div>

                        <div class="card-footer text-center">
                            <h3 class="text-primary text_total_debit m-0 p-0 font-weight-bold" data-price="0">Rp.0</h3>
                        </div>
                    </div>
                    <div class="card border shadow-none col-6 p-0 m-0">
                        <div class="card-header ">
                            <div class="row align-items-center">
                                <h3 class="card-title m-0 p-0 col-6">
                                    <i class="fa fa-tv text-primary"></i> Kredit
                                    <small>(* masukan item kredit)</small>
                                </h3>
                                <div class="col-6">
                                    <a href="javascript:void(0)" class="btn btn-dark btn-sm waves-effect waves-light btn_add_form" data-type="credit"><i class="fa fa-plus-circle"></i> Tambah Item Kredit</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body html_from_credit" style="min-height: 500px;">
                        </div>
                        <div class="card-footer text-center">
                            <h3 class="text-primary text_total_credit m-0 p-0 font-weight-bold" data-price="0">Rp.0</h3>
                        </div>
                    </div>
                </div>
            </form>
            <div class="col-12 text-right mt-3">
                <a href="javascript:void(0)" class="btn btn-primary btn_save_update_journal btn-rounded btn-lg" data-token="0">Simpan Data <i class="fa fa-paper-plane"></i></a>
            </div>
        </div>
    </div>
</div>



<div class="modal" id="modal_form">
    <div class="modal-dialog" style="max-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>