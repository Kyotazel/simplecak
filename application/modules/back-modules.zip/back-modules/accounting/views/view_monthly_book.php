<?php
$explode_date = explode('-', $start_period);

$array_month = [
    '01' => 'Januari',
    '02' => 'Februari',
    '03' => 'Maret',
    '04' => 'April',
    '05' => 'Mei',
    '06' => 'Juni',
    '07' => 'Juli',
    '08' => 'Agustus',
    '09' => 'September',
    '10' => 'Oktober',
    '11' => 'November',
    '12' => 'December',
];

$start    = (new DateTime($active_period->date_from))->modify('first day of this month');
$end      = (new DateTime($active_period->date_to))->modify('first day of next month');
$interval = DateInterval::createFromDateString('1 month');
$period   = new DatePeriod($start, $interval, $end);
$html_option = '';
$now_period = date('m-Y');
foreach ($period as $dt) {
    $value = $dt->format("m-Y");
    $text = $array_month[$dt->format("m")] . ' - ' . $dt->format("Y");
    $selected = $value == $now_period ? 'selected' : '';
    $html_option .= '
        <option ' . $selected . ' value="' . $value . '">' . $text . '</option>
    ';
    // echo $array_month[$dt->format("m")] . ' - ' . $dt->format("Y") . "<br>\n";
}

?>

<style>
    .datepicker {
        z-index: 1200 !important;
    }

    table.display {
        margin: 0 auto;
        width: 100%;
        clear: both;
        border-collapse: collapse;
        table-layout: fixed;
        word-wrap: break-word;
    }
</style>
<div class="card">
    <div class="card-body">

        <form class="form-input">
            <div class="row">
                <div class="col-md-5">
                    <div class="col-md-12 form-group">
                        <label for="">Aktif Periode : <b class="text-uppercase text-bold label label-success" style="font-size: 15px;"><?= $active_period->name; ?></b></label>
                        <select name="period" class="form-control" id=""><?= $html_option; ?></select>
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-12">
                        <div class="html_respon_error"></div>
                    </div>
                </div>

                <div class="col-md-2 text-left">
                    <label>&nbsp;</label><br>
                    <button class="btn btn-success btn-block btn_monthly_recapitulation"><i class="fa fa-search"></i> Proses data</button>
                </div>
                <div class="col-md-2 text-left">
                    <label>&nbsp;</label><br>
                    <a href="<?= Modules::run('helper/create_url', 'accounting/monthly_recapitulation'); ?>" class="btn btn-primary btn-block  btn_link">
                        <i class="fa fa-tv"></i> Lihat Rekapitulasi
                    </a>
                </div>
                <!-- <div class="col-md-3">
                                    <label for="">&nbsp;</label><br>
                                    <div class="p-10 border-radius-5 bg-success">
                                        <h5>Periode Awal akuntansi : <b><?= $start_period; ?></b></h5>
                                    </div>
                                </div> -->
            </div>
        </form>

    </div>
    <div class="html_respon"></div>
    <!-- /.card-body -->
</div>