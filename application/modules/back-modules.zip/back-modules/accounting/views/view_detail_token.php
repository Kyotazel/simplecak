<?php
$transaction = $data_detail[0]->status_act;
$accounting_transaction   = json_decode($this->db->where(['params' => 'json_accounting_transaction'])->get('app_module_setting')->row()->value, TRUE);
$type_name = $accounting_transaction[$transaction];
?>

<div class="row">
    <div class="col-6 p-2 border-dashed">
        <label for="" class="m-0 p-0 d-block"><i class="fa fa-tv"></i> Jenis Transaksi : </label>
        <span class="font-weight-bold tx-16"><?= strtoupper($type_name); ?></span>
    </div>
    <div class="col-3 p-2 border-dashed">
        <label for="" class="d-block m-0 p-0"><i class="fa fa-calendar"></i> Creted Date : </label>
        <span class="font-weight-bold"><?= Modules::run('helper/datetime_indo', $data_detail[0]->created_date); ?></span>
    </div>
    <div class="col-3 p-2 border-dashed">
        <label for="" class="p-0 m-0 d-block"><i class="fa fa-code"></i> Token : </label>
        <span class="font-weight-bold"><?= $token; ?></span>
    </div>
</div>
<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Kode akun</th>
                <th>Tanggal</th>
                <th>Keterangan</th>
                <th>Debit</th>
                <th>Kredit</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_detail as $item_data) {
                $counter++;
                $credit_price   = $item_data->credit > 0 ? 'Rp.' . number_format($item_data->credit, 0, '.', '.') : '-';
                $debit_price    = $item_data->debit > 0 ? 'Rp.' . number_format($item_data->debit, 0, '.', '.') : '-';

                $class_bg = $item_data->id_book_account == $account_id ? 'text-primary' : '';

                echo '
                        <tr class="' . $class_bg . '">
                            <td>' . $item_data->type_account . '-' . $item_data->account_code . ' ' . $item_data->account_name . '</td>
                            <td>' . Modules::run('helper/date_indo', $item_data->date, '-') . '</td>
                            <td>' . $item_data->description . '</td>
                            <td>' . $debit_price . '</td>
                            <td>' . $credit_price . '</td>
                        </tr>
                    ';
            }
            ?>
        </tbody>
    </table>
</div>