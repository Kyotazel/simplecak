<?php
function change_date($date)
{
    $explode_date = explode('-', $date);
    $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
    return $date_return;
}
?>
<style>
    .datepicker {
        z-index: 1200 !important;
    }

    table.display {
        margin: 0 auto;
        width: 100%;
        clear: both;
        border-collapse: collapse;
        table-layout: fixed;
        word-wrap: break-word;
    }
</style>
<div class="card">
    <div class="card-body">

        <form class="form-input">
            <div class="row">
                <div class="col-md-3">
                    <label>Periode Akuntansi :</label>
                    <select name="period" class=" form-control">
                        <?php
                        foreach ($data_period as $item_period) {
                            $selected = $item_period->status ? 'selected' : '';
                            echo '
                                            <option data-id="' . $item_period->id . '" ' . $selected . ' value="' . change_date($item_period->date_from) . '/' . change_date($item_period->date_to) . '">' . $item_period->name . '</option>
                                        ';
                        }
                        ?>
                    </select>
                    <span class="help-block text-danger" style="color:red;"></span>
                </div>
                <div class="col-md-3  form_date row ">
                    <div class="col-md-6 form-group">
                        <label for="">Tanggal Awal</label>
                        <input type="text" readonly class="bg-white form-control datepicker_form" data-language="en" name="date_from">
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Tanggal Akhir</label>
                        <input type="text" readonly class="bg-white form-control datepicker_form" data-language="en" name="date_to">
                        <span class="help-block text-danger"></span>
                    </div>
                </div>
                <div class="col-md-5">
                    <label>Akun Rekening</label>
                    <select name="account[]" multiple class=" form-control chosen">
                        <?php
                        foreach ($data_account as $item_account) {
                            echo '
                                    <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                ';
                        }
                        ?>
                    </select>
                    <span class="help-block text-danger notif_account" style="color:red;"></span>
                </div>

                <div class="col-md-1">
                    <label>&nbsp;</label><br>
                    <button class="btn btn-primary btn_search_ledger btn-rounded"><i class="fa fa-search"></i> Cari</button>
                </div>
            </div>
        </form>
    </div>
    <div class="html_respon"></div>
    <!-- /.card-body -->
</div>

<!-- detail content -->
<div class="modal fade" tabindex="-1" id="modal-form-detail">
    <div class="modal-dialog" style="max-width: 50%;">
        <div class="modal-content">
            <div class="modal-header bg-primary-gradient text-white">
                <h5 class="modal-title text-white">Detail Transaksi :</h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <div class="html_respon_detail"></div>
            </div>
        </div>
    </div>
</div>