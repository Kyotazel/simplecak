<?php
$time = time();
?>
<div class="card m-0">
    <div class="card-body bg-gray-100">
        <div class="col-md-12 bg-white shadow rounded" style="padding: 40px;">
            <h4 class="mb-4  font-weight-bold">
                <i class="fa fa-tv"></i> <?= $account_name; ?>
                <small class="tx-11 text-muted">( klik data untuk melihat detail transaksi )</small>
                <!-- <a href="javascript:void(0)" class="float-right accordion-toggle collapsed" data-toggle="collapse" data-parent="#view_<?= $time; ?>" href="#view_<?= $time; ?>" aria-expanded="true"><i class="fas fa-angle-down"></i></a> -->
            </h4>
            <div id="#view_<?= $time; ?>" class="table-responsive  panel-collapse collapse in show" role="tabpanel" aria-expanded="false" style="height: 700px;overflow:scroll;">
                <table class="table table-hover">
                    <thead class="">
                        <tr>
                            <th>No</th>
                            <th>kode akun</th>
                            <th>Tanggal</th>
                            <th>Keterangan</th>
                            <th>Debit</th>
                            <th>Kredit</th>
                            <th>Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $first_saldo = $array_saldo['first_saldo'];
                        $data_print = [];
                        $data_print['spesification'] = $array_spesification;
                        $data_print['first_saldo'] = $first_saldo;
                        $counter = 0;

                        if ($array_saldo['status_saldo']) {
                            $debit_first_saldo  = '';
                            $credit_first_saldo = '';
                            if ($array_saldo['type_saldo'] == 'debit') {
                                $debit_first_saldo = number_format($first_saldo, 0, '.', '.');
                            } else {
                                $credit_first_saldo = number_format($first_saldo, 0, '.', '.');
                            }

                            echo '
                                <tr title="klik untuk melihat detail transaksi">
                                    <td style="display:none;">0</td>
                                    <td style="display:none;"></td>
                                    <td style="display:none;"></td>
                                    <td colspan="4" class="text-center">
                                        <label for="">SALDO AWAL</label>
                                    </td>
                                    <td>Rp. ' . $debit_first_saldo . '</td>
                                    <td>Rp. ' . $credit_first_saldo . '</td>
                                    <td>Rp. ' . number_format($first_saldo, 0, '.', '.') . '</td>
                                </tr>
							';
                        }

                        foreach ($data_journal as $item_journal) {
                            $account_current = str_replace('-', '.', $item_journal->account_code);
                            $debit = '';
                            $credit = '';

                            if ($array_saldo['type_saldo'] == 'debit') {
                                $first_saldo = ($first_saldo + $item_journal->debit) - $item_journal->credit;
                            } else {
                                $first_saldo = ($first_saldo + $item_journal->credit) - $item_journal->debit;
                            }

                            // print_r($item_journal);
                            $account_name = '';

                            if ($item_journal->debit) {
                                $debit = 'Rp.' . number_format($item_journal->debit, 0, '.', '.');
                                $account_name = '<span>' . $item_journal->account_name . '</span>';
                            }
                            if ($item_journal->credit) {
                                $credit = 'Rp.' . number_format($item_journal->credit, 0, '.', '.');
                                $account_name = '<span style="margin-left:10px;">' . $item_journal->account_name . '</span>';
                            }
                            $counter++;
                            echo '
							<tr class="btn_view_transaction" style=":hover{cursor:pointer;}" data-account="' . $account_search->id . '" data-token="' . $item_journal->token . '">
                                <td>' . $counter . '</td>
                                <td>' . $item_journal->type_account . '-' . $account_current . '</td>
                                <td>' . Modules::run('helper/date_indo', $item_journal->date, '-') . '</td>
                                <td>' . $item_journal->description . '</td>
                                <td>' . $debit . '</td>
                                <td>' . $credit . '</td>
                                <td>Rp. ' . number_format($first_saldo, 0, '.', '.') . '</td>
							</tr>
                            ';

                            $data_print['data_print'][] = [
                                'code_account' => $item_journal->type_account . '-' . $account_current,
                                'date' => $item_journal->date,
                                'description' => $item_journal->description,
                                'debit' => $item_journal->debit,
                                'credit' => $item_journal->credit,
                                'saldo' => $first_saldo
                            ];
                        }

                        $data_print['last_saldo'] = $first_saldo;
                        echo '
                        <tr>
                            <td style="display:none;">' . $counter++ . '</td>
                            <td style="display:none;"></td>
                            <td style="display:none;"></td>
                            <td style="display:none;"></td>
                            <td style="display:none;"></td>
                            <td colspan="6" class="text-right">
                                <label for="">SALDO AKHIR AKUN ' . $array_saldo['account_name'] . '</label>
                            </td>                            
                            <td class="text-green text-bold"> <b> Rp. ' . number_format($first_saldo, 0, '.', '.') . ' </b></td>
                        </tr>
                    ';
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="text-right mt-2">
                <h4 class="font-weight-bold"><small class="text-muted tx-11">Saldo Akhir akun : </small>Rp. <?= number_format($first_saldo, 0, '.', '.'); ?></h4>
            </div>
        </div>

        <div class="col-md-12 text-right p-20 mt-3">
            <form method="POST" action="<?= Modules::run('helper/create_url', 'accounting/print_ledger_book'); ?>">
                <small>(*klik untuk cetak laporan)</small>
                <input type="hidden" value="<?= $this->encrypt->encode(json_encode($data_print)); ?>" name="data_result">
                <button type="submit" class="btn btn-primary "><i class="fa fa-file-pdf-o"></i> Cetak EXCEL</button>
            </form>
        </div>

    </div>
    <!-- /.card-body -->
</div>