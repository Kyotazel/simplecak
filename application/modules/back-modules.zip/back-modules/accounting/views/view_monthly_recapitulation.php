<?php
$explode_date = explode('-', $start_period);

$array_month = [
    '01' => 'Januari',
    '02' => 'Februari',
    '03' => 'Maret',
    '04' => 'April',
    '05' => 'Mei',
    '06' => 'Juni',
    '07' => 'Juli',
    '08' => 'Agustus',
    '09' => 'September',
    '10' => 'Oktober',
    '11' => 'November',
    '12' => 'December',
];

function change_date($date)
{
    $explode_date = explode('-', $date);
    $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
    return $date_return;
}
?>
<style>
    .datepicker {
        z-index: 1200 !important;
    }

    table.display {
        margin: 0 auto;
        width: 100%;
        clear: both;
        border-collapse: collapse;
        table-layout: fixed;
        word-wrap: break-word;
    }
</style>
<div class="card">
    <div class="card-body">

        <form class="form-input">
            <div class="row">
                <div class="col-md-5 row">
                    <div class="col-md-6 form-group">
                        <label for="">Tahun</label>
                        <select name="year" class="form-control" id="">
                            <?php
                            echo '<option value="' . $this->encrypt->encode($year->min_year) . '">' . $year->min_year . '</option>';
                            $count_year = $year->max_year - $year->min_year;
                            $start_year = $year->min_year;
                            for ($i = 0; $i < $count_year; $i++) {
                                $start_year++;
                                echo '
                                                    <option value="' . $this->encrypt->encode($start_year) . '">' . $start_year . '</option>
                                                ';
                            }

                            ?>
                        </select>
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">BULAN</label>
                        <select class="form-control" name="month" id="">
                            <?php
                            foreach ($array_month as $key_month => $value_month) {
                                echo '<option value="' . $this->encrypt->encode($key_month) . '">' . $value_month . '</option>';
                            }
                            ?>
                        </select>
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-12">
                        <div class="html_respon_error"></div>
                    </div>
                </div>
                <div class="col-md-3 form-group">
                    <label for="">Jenis Laporan</label>
                    <select name="report" class="form-control" id="">
                        <option value="1">LAPORAN LABA RUGI</option>
                        <option value="2">LAPORAN NERACA SALDO</option>
                        <option value="3">LAPORAN NERACA</option>
                    </select>
                    <span class="help-block"></span>
                </div>

                <div class="col-md-2 text-left">
                    <label>&nbsp;</label><br>
                    <button class="btn btn-primary btn-block btn_monthly_search_recapitulation"><i class="fa fa-search"></i> Cari data</button>
                </div>
                <div class="col-md-2 text-left">
                    <label>&nbsp;</label><br>
                    <a class="btn btn-default btn_link" href="<?= Modules::run('helper/create_url', 'accounting/monthly_book'); ?>"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                </div>
            </div>
        </form>

    </div>
    <div class="html_respon"></div>
    <!-- /.card-body -->
</div>