<div class="card">
    <div class="card-body">
        <div class="mb-3 row">
            <h3 class="col-md-8">Data Kas Keluar</h3>
            <div class="col-md-4 text-right">
                <button type="button" title="add data" class="btn btn-primary-gradient btn_add_cashout font-weight-bold btn-rounded">
                    <i class="fa fa-plus-circle"></i> Tambah Data
                </button>
            </div>
            <div class="col-12 p-2 border-dashed rounded mt-2">
                <form class="form-search-cash-out">
                    <div class="row">
                        <div class="col-5 row">
                            <div class="col-md-6">
                                <label for="">
                                    TANGGAL AWAL
                                    <a href="javascript:void(0)" class="empty_form" data-name="date_from" title="empty date"><i class="fa fa-history"></i></a>
                                </label>
                                <input type="text" class="form-control datepicker bg-white" placeholder="piih tanggal..." readonly="" name="date_from">
                            </div>
                            <div class="col-md-6">
                                <label for="">
                                    TANGGAL AKHIR
                                    <a href="javascript:void(0)" class="empty_form" data-name="date_to" title="empty date"><i class="fa fa-history"></i></a>
                                </label>
                                <input type="text" class="form-control datepicker bg-white" placeholder="piih tanggal..." readonly="" name="date_to">
                            </div>
                        </div>
                        <div class="col-3 form-group">
                            <label for="exampleInputEmail1">AKUN KAS :</label>
                            <select name="credit_account" class="form-control chosen">
                                <option value="">SEMUA</option>
                                <?php
                                foreach ($data_cash as $item_account) {
                                    echo '
                                            <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-3 form-group">
                            <label for="exampleInputEmail1">AKUN TUJUAN :</label>
                            <select name="debit_account_search" class="form-control chosen">
                                <option value="">SEMUA</option>
                                <?php
                                foreach ($data_account as $item_account) {
                                    echo '
                                            <option data-id="' . $item_account->id . '" data-name="' . $item_account->code_account . ' ' . $item_account->name . '" value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-1">
                            <label for="">&nbsp;</label><br>
                            <button type="submit" class="btn btn-primary-gradient btn-rounded btn-block btn_search_cash_out"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="html_respon_cash_out"></div>

    </div>
    <div class="html_respon"></div>
    <!-- /.card-body -->
</div>

<div class="modal" id="modal_form_cash_out">
    <div class="modal-dialog" style="max-width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="card-body pad">
                <form role="form" class="form-input">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6 m-0 p-0">
                                <div class="col-md-12 form-group">
                                    <label for="exampleInputEmail1">Dari Kas :</label>
                                    <select name="credit_account" class="form-control chosen">
                                        <?php
                                        foreach ($data_cash as $item_account) {
                                            echo '
                                            <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                        }
                                        ?>
                                    </select>
                                    <span class="help-block text-danger notif_credit_account"></span>
                                </div>
                            </div>
                            <div class="col-md-4 m-0">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tanggal</label>
                                    <input class="form-control bg-white datepicker_form " data-language="en" name="date" type="text" readonly>
                                    <span class="help-block text-danger notif_date"></span>
                                </div>

                            </div>
                            <div class="col-md-12 row">
                                <div class="col-md-3 form-group">
                                    <label for="exampleInputEmail1">Akun Tujuan :</label>
                                    <select name="debit_account" class="form-control chosen">
                                        <?php
                                        foreach ($data_account as $item_account) {
                                            echo '
                                            <option data-id="' . $item_account->id . '" data-name="' . $item_account->code_account . ' ' . $item_account->name . '" value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                        ';
                                        }
                                        ?>
                                    </select>
                                    <span class="help-block text-danger"></span>
                                </div>
                                <div class="form-group col-md-3 ">
                                    <label for="exampleInputEmail1">Nominal (Rp.)</label>
                                    <input class="form-control money_only" name="price" type="text">
                                    <span class="help-block text-danger"></span>
                                </div>
                                <div class="form-group col-md-5 ">
                                    <label for="exampleInputEmail1">Keterangan</label>
                                    <input class="form-control" name="description">
                                    <span class="help-block text-danger"></span>
                                </div>
                                <div class="col-md-1">
                                    <label for="">&nbsp;</label><br>
                                    <a href="javascript:void(0)" class="btn btn-primary btn_add_item_cashout"><i class="fa fa-plus"></i></a>
                                </div>
                                <div class="col-md-12">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Akun Tujuan</th>
                                                <th>Nominal</th>
                                                <th>Keterangan</th>
                                                <th style="width: 10px;"></th>
                                            </tr>
                                        </thead>
                                        <tbody class="html_add_item">
                                            <tr class="tr_empty">
                                                <td colspan="4">
                                                    <div class="col-12 text-center">
                                                        <div class="plan-card text-center">
                                                            <i class="fas fa-file plan-icon text-primary"></i>
                                                            <h6 class="text-drak text-uppercase mt-2">Data Kosong</h6>
                                                            <small class="text-muted">Tidak ada item.</small>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="col-md-12 text-right mt-10">
                                <small>(*klik untuk simpan data) </small>&nbsp;
                                <button type="submit" data-status="1" class="btn btn-primary pull-right btn_save_cashout"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
</div>