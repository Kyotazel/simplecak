<?php
$explode_date = explode('-', $start_period);

$array_month = [
    '01' => 'Januari',
    '02' => 'Februari',
    '03' => 'Maret',
    '04' => 'April',
    '05' => 'Mei',
    '06' => 'Juni',
    '07' => 'Juli',
    '08' => 'Agustus',
    '09' => 'September',
    '10' => 'Oktober',
    '11' => 'November',
    '12' => 'December',
];

function change_date($date)
{
    $explode_date = explode('-', $date);
    $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
    return $date_return;
}
?>

<div class="card">
    <div class="card-body">

        <form class="form-input">
            <div class="row">
                <div class="col-md-5">
                    <div class="col-md-12 form-group">
                        <label for="">Periode Akuntansi :</label>
                        <select name="period" class="form-control" id="">
                            <?php

                            foreach ($period as $item_period) {
                                $arr_value = [
                                    'id' => $item_period->id,
                                    'date_from' => $item_period->date_from,
                                    'date_to' => $item_period->date_to,
                                    'name' => $item_period->name
                                ];

                                $selected = $item_period->status ? 'selected' : '';

                                echo '
                                        <option ' . $selected . ' value="' . $this->encrypt->encode(json_encode($arr_value)) . '">' . $item_period->name . ' (' . change_date($item_period->date_from) . ' s/d ' . change_date($item_period->date_to) . ')</option>
                                    ';
                            }

                            ?>
                        </select>
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-12">
                        <div class="html_respon_error"></div>
                    </div>
                </div>

                <div class="col-md-2 text-left">
                    <label>&nbsp;</label><br>
                    <button class="btn btn-success btn-block btn_monthly_search_recapitulation_yearly"><i class="fa fa-search"></i> Cari data</button>
                </div>
                <div class="col-md-2">
                    <label>&nbsp;</label><br>
                    <a class="btn btn-default btn_link" href="<?= Modules::run('helper/create_url', 'accounting/yearly_book'); ?>"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                </div>
            </div>
        </form>

    </div>
    <div class="html_respon"></div>
    <!-- /.card-body -->
</div>