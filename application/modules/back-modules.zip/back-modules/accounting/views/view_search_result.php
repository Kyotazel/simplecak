<?php
function date_indo($date, $delimiter)
{

    $array_month = [
        '01' => 'januari', '02' => 'februari', '03' => 'maret', '04' => 'april', '05' => 'mei', '06' => 'juni', '07' => 'juli', '08' => 'agustus', '09' => 'september', '10' => 'oktober', '11' => 'november', '12' => 'december'
    ];
    $explode_date = explode($delimiter, $date);
    $date_return = $explode_date[2] . ' ' . ucfirst($array_month[$explode_date[1]]) . ' ' . $explode_date[0];
    return $date_return;
}

// print_r($account_transaction);

?>
<style>
    div#DataTables_Table_0_wrapper {
        width: 100% !important;
    }
</style>
<div class="card">
    <div class="card-body">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table  table-journal " style="width: 100%;">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>kode akun</th>
                            <th>Tanggal</th>
                            <th>Jurnal</th>
                            <th style="width: 200px;">Keterangan</th>
                            <th>Debit</th>
                            <th>Kredit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $token_before = 0;
                        $status_act = 0;
                        $counter = 0;
                        $total_credit = 0;
                        $total_debit = 0;
                        $data_print = [];
                        $data_print['spesification'] = $array_spesification;
                        foreach ($data_journal as $item_journal) {
                            $account_current = str_replace('-', '.', $item_journal->account_code);
                            $debit = '';
                            $credit = '';
                            // print_r($item_journal);
                            $account_name = '';
                            if ($item_journal->debit) {
                                $debit = 'Rp.' . number_format($item_journal->debit, 0, '.', '.');
                                $account_name = '<span>' . $item_journal->account_name . '</span>';
                            }
                            if ($item_journal->credit) {
                                $credit = 'Rp.' . number_format($item_journal->credit, 0, '.', '.');
                                $account_name = '<span style="margin-left:30px;">' . $item_journal->account_name . '</span>';
                            }
                            $counter++;

                            if ($token_before != $item_journal->token & $token_before > 0) {
                                $counter++;
                                if ($total_credit != $total_debit) {
                                    $text = 'Tidak Balance';
                                    $class_sign = 'bg-danger';
                                } else {
                                    $text = 'Balance';
                                    $class_sign = 'bg-primary';
                                }
                                $act_name = isset($account_transaction[$status_act]) ? $account_transaction[$status_act] : '';

                                $text_total_debit = 'Rp. ' . number_format($total_debit, 0, '.', '.');
                                $text_total_credit = 'Rp.' . number_format($total_credit, 0, '.', '.');

                                // if ($account_search) {
                                //     $text = 'Balance';
                                //     $class_sign = 'bg-primary';
                                //     $text_total_debit = '-';
                                //     $text_total_credit = '-';
                                // }
                                echo '
                                    <tr class="' . $class_sign . ' text-white tr_' . $token_before . '">
                                        <td style="display:none">' . $counter . '</td>
                                        <td style="display:none;"></td>
                                        <td colspan="2">
                                            <i class="fa fa-tv"></i> Token : <b> ' . $token_before . '</b>
                                        </td>
                                        <td class="text-capitalize"><i class="fa fa-tv"></i> <b> ' . $act_name  . ' </b></td>
                                        <td colspan="2" class="text-right">
                                            <a href="javascript:void(0)" data-token="' . $token_before . '" class="btn btn-light btn-sm waves-effect waves-light btn_edit_token"><i class="fa fa-edit"></i> Edit Jurnal</a> &nbsp; | &nbsp;
                                            <a href="javascript:void(0)" data-token="' . $token_before . '" class="btn btn-light btn-sm waves-effect waves-light btn_delete_token"><i class="fa fa-trash"></i> Hapus Jurnal</a> &nbsp; | &nbsp; 
                                            <b>' . $text . '</b> : 
                                        </td>
                                        <td style="width:100px">' . $text_total_debit . '</td>
                                        <td style="width:100px">' . $text_total_credit . '</td>
                                    </tr>
                                ';
                                $total_debit = 0;
                                $total_credit = 0;
                            }

                            $total_debit    += $item_journal->debit;
                            $total_credit   += $item_journal->credit;
                            echo '
                                <tr class="tr_' . $item_journal->token . '">
                                    <td style="display:none">' . $counter . '</td>
                                    <td colspan="2">' . $item_journal->type_account . '-' . $account_current . '</td>
                                    <td>' . date_indo($item_journal->date, '-') . '</td>
                                    <td>' . $account_name . '</td>
                                    <td>' . $item_journal->description . '</td>
                                    <td style="width:100px">' . $debit . '</td>
                                    <td style="width:100px">' . $credit . '</td>
                                </tr>
                            ';
                            // if($item_journal->token != $token)
                            $token_before = $item_journal->token;
                            $status_act = $item_journal->status_act;
                            $data_print['data'][] = [
                                'code_account' => $item_journal->type_account . '-' . $account_current,
                                'account' => $item_journal->account_name,
                                'date' => $item_journal->date,
                                'description' => $item_journal->description,
                                'debit' => $item_journal->debit,
                                'credit' => $item_journal->credit
                            ];
                        }

                        //last loop
                        if ($counter > 0) {
                            if ($total_credit != $total_debit) {
                                $text = 'Tidak Balance';
                                $class_sign = 'bg-danger';
                            } else {
                                $text = 'Balance';
                                $class_sign = 'bg-primary';
                            }
                            $act_name = isset($account_transaction[$status_act]) ? $account_transaction[$status_act] : '';

                            $text_total_debit = 'Rp. ' . number_format($total_debit, 0, '.', '.');
                            $text_total_credit = 'Rp.' . number_format($total_credit, 0, '.', '.');

                            // if ($account_search) {
                            //     $text = 'Balance';
                            //     $class_sign = 'bg-primary';
                            //     $text_total_debit = '-';
                            //     $text_total_credit = '-';
                            // }
                            echo '
                            <tr class="' . $class_sign . ' text-white tr_' . $token_before . '">
                                <td style="display:none">' . $counter . '</td>
                                <td style="display:none;"></td>
                                <td colspan="2">
                                    <i class="fa fa-tv"></i> Token : <b> ' . $token_before . '</b>
                                </td>
                                <td class="text-capitalize"><i class="fa fa-tv"></i> <b> ' . $act_name  . ' </b></td>
                                <td colspan="2" class="text-right">
                                    <a href="javascript:void(0)" data-token="' . $token_before . '" class="btn btn-light btn-sm waves-effect waves-light btn_edit_token"><i class="fa fa-edit"></i> Edit Jurnal</a> &nbsp; | &nbsp;
                                    <a href="javascript:void(0)" data-token="' . $token_before . '" class="btn btn-light btn-sm waves-effect waves-light btn_delete_token"><i class="fa fa-trash"></i> Hapus Jurnal</a> &nbsp; | &nbsp; 
                                    <b>' . $text . '</b> : 
                                </td>
                                <td style="width:100px">' . $text_total_debit . '</td>
                                <td style="width:100px">' . $text_total_credit . '</td>
                            </tr>
                        ';
                            $total_debit = 0;
                            $total_credit = 0;
                        }

                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-12 text-right mt-3">
            <form method="POST" action="<?= base_url('accounting/print_journal'); ?>">
                <small>(*klik untuk cetak laporan)</small>
                <input type="hidden" value="<?= $this->encrypt->encode(json_encode($data_print)); ?>" name="data_result">
                <button type="submit" class="btn btn-primary "><i class="fa fa-file-pdf-o"></i> CETAK EXCEL</button>
            </form>
        </div>

    </div>
    <!-- /.card-body -->
</div>


<!-- detail content -->
<div class="modal fade" tabindex="-1" id="modal-form-edit" data-backdrop="static">
    <div class="modal-dialog" style="max-width: 60%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Jurnal</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <div class="html_respon_update_journal"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>