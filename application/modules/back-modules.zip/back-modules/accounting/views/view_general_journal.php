<?php
function change_date($date)
{
    $explode_date = explode('-', $date);
    $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
    return $date_return;
}
?>
<style>
    .datepicker {
        z-index: 120000000000000 !important;
    }

    table.display {
        margin: 0 auto;
        width: 100%;
        clear: both;
        border-collapse: collapse;
        table-layout: fixed;
        word-wrap: break-word;
    }
</style>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6 mb-2">
                <label>Periode Akuntansi :</label>
                <select name="period" class=" form-control">
                    <?php
                    foreach ($data_period as $item_period) {
                        $selected = $item_period->status ? 'selected' : '';
                        echo '
                                <option ' . $selected . ' value="' . change_date($item_period->date_from) . '/' . change_date($item_period->date_to) . '">' . $item_period->name . '</option>
                            ';
                    }
                    ?>
                </select>
                <span class="help-block text-danger" style="color:red;"></span>
            </div>
            <div class="col-md-6 text-right">
                <?php
                $add_btn = '
                        <small>(*klik untuk tambah data jurnal)</small>
                        <a href="' . Modules::run('helper/create_url', 'accounting/add') . '" class="btn btn-primary btn-rounded font-weight-bold btn_link"><i class="fa fa-plus-circle"></i> Tambah Data Jurnal</a>
                    ';
                echo Modules::run('security/create_access', $add_btn);
                ?>

            </div>
        </div>


        <form class="form-input">
            <div class="row p-2 border border-radius-5">
                <div class="col-md-3">
                    <div>
                        <label>Pencarian</label>
                        <select name="type" class=" form-control">
                            <option value="1">Berdasarkan Akun</option>
                            <option value="2">Berdasarkan Transaksi</option>
                        </select>
                        <span class="help-block text-danger" style="color:red;"></span>
                    </div>
                </div>
                <div class="col-md-6 row  form_date ">
                    <div class="col-md-5 form-group">
                        <label for="">Tanggal Awal</label>
                        <input type="text" readonly class="bg-white form-control datepicker_form" data-language="en" name="date_from">
                        <span class="help-block text-danger"></span>
                    </div>
                    <div class="col-md-1 text-center">
                        <label for="">&nbsp;</label><br>
                        <label for="">S/D</label>
                    </div>
                    <div class="col-md-5 form-group">
                        <label for="">Tanggal Akhir</label>
                        <input type="text" readonly class="bg-white form-control datepicker_form" data-language="en" name="date_to">
                        <span class="help-block text-danger"></span>
                    </div>
                </div>
                <div class="col-md-3 form-account">
                    <label>Akun Rekening</label>
                    <select name="account" class=" form-control chosen">
                        <option value="">Semua Akun Rekening</option>
                        <?php
                        foreach ($data_account as $item_account) {
                            echo '
                                                <option value="' . $this->encrypt->encode($item_account->id) . '">' . $item_account->code_account . ' ' . $item_account->name . '</option>
                                            ';
                        }
                        ?>
                    </select>
                    <span class="help-block text-danger" style="color:red;"></span>
                </div>
                <div class="col-md-3 form-transaction" style="display: none;">
                    <label>Transaksi</label>
                    <select name="transaction" class=" form-control chosen">
                        <option value="">Semua Transaksi</option>
                        <?php
                        foreach ($account_transaction as $key_transaction => $value_transaction) {
                            echo '
                                <option value="' . $this->encrypt->encode($key_transaction) . '">' . $key_transaction . ' - ' . $value_transaction . '</option>
                            ';
                        }
                        ?>
                    </select>
                    <span class="help-block text-danger" style="color:red;"></span>
                </div>

                <div class="col-md-12 text-right">
                    <button class="btn btn-primary btn_search btn-rounded font-weight-bold"><i class="fa fa-search"></i> Cari Data</button>
                </div>
            </div>
        </form>
    </div>
    <!-- /.card-body -->
</div>

<div class="html_respon"></div>