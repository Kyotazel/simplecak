<?php
// $get_profile = $this->db->get('tm_profile')->row();
$list_account   = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);

?>
<div class="card border" style="margin-left:10%;margin-right: 10% !important;width:80%;">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12 text-center">
                <img style="width: 150px;;" src="<?= base_url('assets/images/logo.png'); ?>" alt="">
            </div>
            <div class="col-md-12 text-center">
                <h3 class="">NERACA SALDO</h3>
                <p>PERIODE PER TANGGAL : <b><?= $array_date['date_to']; ?></b></p>
            </div>
            <span class="clearfix"></span>
            <div class="col-md-12 mt-10">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kode Akun</th>
                                <th>Nama Akun</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $data_print = [];
                            $data_print['spesification'] = $array_date;
                            $total_saldo_debit = 0;
                            $total_saldo_credit = 0;
                            // print_r(count($data_account));
                            foreach ($data_account as $item_account) {
                                $array_data_current =  (array) $item_account;

                                // print_r($array_data_current);
                                // echo '<br>';


                                $type_saldo = $list_account[$item_account->type_account]['type_saldo'];
                                $label_saldo_debit = 0;
                                $label_saldo_credit = 0;
                                if (isset($status_recapitulation)) {
                                    if ($type_saldo == 'debit') {
                                        $total_saldo = $item_account->total_saldo;

                                        $total_saldo_debit += $total_saldo;
                                        $label_saldo_debit = $total_saldo;
                                    } else {
                                        $total_saldo = $item_account->total_saldo;
                                        $total_saldo_credit += $total_saldo;
                                        $label_saldo_credit = $total_saldo;
                                    }
                                } else {

                                    $saldo_current = isset($array_first_saldo[$item_account->id_book_account]) ? $array_first_saldo[$item_account->id_book_account] : 0;
                                    if ($type_saldo == 'debit') {
                                        $total_saldo = $saldo_current + ($item_account->debit_saldo - $item_account->credit_saldo);
                                        $total_saldo_debit += $total_saldo;
                                        $label_saldo_debit = $total_saldo;
                                    } else {
                                        $total_saldo = $saldo_current + ($item_account->credit_saldo - $item_account->debit_saldo);
                                        $total_saldo_credit += $total_saldo;
                                        $label_saldo_credit = $total_saldo;
                                    }
                                }

                                echo '
                                        <tr>
                                            <td>' . $item_account->code_account . '</td>
                                            <td>' . strtoupper($item_account->account_name) . '</td>
                                            <td>Rp.' . number_format($label_saldo_debit, 0, '.', '.') . '</td>
                                            <td>Rp.' . number_format($label_saldo_credit, 0, '.', '.') . '</td>
                                        </tr>
                                    ';

                                $data_print['data_print'][] = [
                                    'code' => $item_account->code_account,
                                    'account' => strtoupper($item_account->account_name),
                                    'debit' => $label_saldo_debit,
                                    'credit' => $label_saldo_credit
                                ];
                            }
                            echo '
                                <tr>
                                    <td colspan="2" class="text-center font-weight-bold">TOTAL SALDO</td>
                                    <td class="font-weight-bold">Rp. ' . number_format($total_saldo_debit, 0, '.', '.') . '</td>
                                    <td class="font-weight-bold">Rp. ' .  number_format($total_saldo_credit, 0, '.', '.') . '</td>
                                </tr>
                            ';

                            $data_print['total'] = [
                                'total_debit' => $total_saldo_debit,
                                'total_credit' => $total_saldo_credit
                            ];

                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-12 text-right p-20">
                <form method="POST" action="<?= Modules::run('helper/create_url', 'accounting/print_trial_balance'); ?>">
                    <small>(*klik untuk cetak laporan)</small>
                    <input type="hidden" value="<?= $this->encrypt->encode(json_encode($data_print)); ?>" name="data_result">
                    <button type="submit" class="btn btn-primary "><i class="fa fa-file-pdf-o"></i> Cetak EXCEL</button>
                </form>
            </div>
        </div>
    </div>
    <!-- /.card-body -->
</div>