<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Recapitulation extends CI_Controller
{
    var $location = 'data_recapitulation/';
    var $tb_name = '';
    var $module_name = 'recapitulation';
    var $js_page = 'recapitulation';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function list_data_sales()
    {
        $id_user = $this->session->userdata('us_id');
        $this->db->select('
            tb_sales.*,
            tb_member.name AS member_name
            ');
        $this->db->from('tb_sales');
        $this->db->join('tb_member', 'tb_sales.id_member = tb_member.id', 'left');
        $this->db->order_by('tb_sales.id', 'DESC');
        $this->db->where(['tb_sales.created_by' => $this->session->userdata('us_id'), 'tb_sales.report_status' => 0]);
        $get_data = $this->db->get()->result();
        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->member_name;
            $row[] = 'Rp.' . number_format($data_table->grand_total, 0, '.', '.');
            $row[] = $data_table->created_date;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_data_deposito()
    {
        $id_user = $this->session->userdata('us_id');
        $this->db->select('
            tb_deposito.*,
            tb_member.code AS member_name
            ');
        $this->db->from('tb_deposito');
        $this->db->join('tb_member', 'tb_deposito.id_member = tb_member.id', 'left');
        $this->db->order_by('tb_deposito.id', 'DESC');
        $this->db->where(['tb_deposito.created_by' => $this->session->userdata('us_id'), 'tb_deposito.report_status' => 0, 'tb_deposito.status' => 1]);
        $get_data = $this->db->get()->result();
        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->member_name;
            $row[] = 'Rp.' . number_format($data_table->total, 0, '.', '.');
            $row[] = $data_table->created_date;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function index()
    {
        $count_data_sales       = $this->db->select('
            SUM(tb_sales.cash_payment) AS sum_cash_payment,
            SUM(tb_sales.rest_payment) AS sum_rest_payment,
            SUM(tb_sales.deposito_payment) sum_deposito_payment,
            SUM(tb_sales.point_payment) AS sum_point_payment,
            SUM(tb_sales.credit_price) AS sum_credit_price,
            SUM(tb_sales.grand_total) AS sum_grand_total,
            SUM(tb_sales.grand_total_real_price) AS sum_grand_total_real_price,
            SUM(tb_sales.grand_total_sales) AS sum_grand_total_sales,
            SUM(tb_sales.pph_price) AS sum_total_pph_price,
            SUM(tb_sales.ppn_price) AS sum_total_ppn_price,
            SUM(tb_sales.grand_total_hpp) AS sum_grand_total_hpp,
            SUM(tb_sales.total_discount_product) AS sum_grand_total_discount,
            SUM(tb_sales.total_member_discount) AS sum_grand_total_member_discount,
            SUM(tb_sales.deposito_payment) AS sum_deposito_payment,
            SUM(tb_sales.point_payment) AS sum_point_payment,
            SUM(tb_sales.new_point) AS sum_new_point,
            COUNT(tb_sales.id) AS count_invoice,
            GROUP_CONCAT(tb_sales.id) AS list_id_sales
            ')->from('tb_sales')
            ->where(['tb_sales.created_by' => $this->session->userdata('us_id'), 'tb_sales.report_status' => 0])->get()->row();

        $count_data_deposito    = $this->db->select('
            SUM(total) AS sum_deposit,
            SUM(administration) AS sum_admin,
            SUM(price_top_up) AS sum_deposit_only,
            COUNT(tb_deposito.id)AS total_invoice,
            COUNT(distinct tb_deposito.id_member) AS total_member,
            GROUP_CONCAT(tb_deposito.id) AS list_deposito
            ')->where(['created_by' => $this->session->userdata('us_id'), 'report_status' => 0, 'status' => 1])->get('tb_deposito')->row();

        $get_data_usage = $this->db->select('SUM(price) AS price_usage, GROUP_CONCAT(id) AS list_id_usage')->where(['DATE(created_date)' => date('Y-m-d'), 'created_by' => $this->session->userdata('us_id'), 'status' => 0])->get('tb_usage')->row();
        $data['data_money_usage'] = $get_data_usage;

        $data['data_user'] = $this->db->where(['id' => $this->session->userdata('us_id')])->get('tb_user')->row();
        $data['data_sales'] = $count_data_sales;
        $data['data_deposit'] = $count_data_deposito;
        $get_user = $this->db->where(['id' => $this->session->userdata('us_id')])->get('tb_user')->row();
        $data['capital_money'] = $get_user->capital_money;
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "REKAPITULASI PENJUALAN KASIR";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin_top', $data);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function review_payment()
    {
        $this->validate_insert();
        $data_recapitulation = json_decode($this->encrypt->decode($this->input->post('data_recapitulation')), TRUE);
        $price  = str_replace('.', '', $this->input->post('price'));
        $note   = $this->input->post('note');

        $margin = $price - $data_recapitulation['total_price'];

        $html_respon = '
        <div class="col-md-4 text-center form-group border p-20  border-radius-5">
        <small>Total uang (Penjualan + TOP UP )</small>
        <h1 class="text-bold text-green">Rp.' . number_format($data_recapitulation['total_price'], 0, '.', '.') . '</h1>
        </div>
        <div class="col-md-4 text-center form-group border  p-20  border-radius-5">
        <small>Nominal Setor</small>
        <h1 class="text-bold text-green">Rp.' . number_format($price, 0, '.', '.') . '</h1>
        </div>
        <div class="col-md-4 text-center form-group border p-20  border-radius-5">
        <small>Selisih</small>
        <h1 class="text-bold text-green">Rp.' . number_format($margin, 0, '.', '.') . '</h1>
        </div>
        <div class="col-md-12 p-10 text-right">
        <small>(*klik untuk simpan)</small>
        <a href="javascript:void(0)" class="btn btn-success btn_do_save"><i class="fa fa-save"></i> Simpan Data</a>
        </div>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save()
    {
        $this->validate_insert();
        $this->db->trans_start();
        $data_recapitulation = json_decode($this->encrypt->decode($this->input->post('data_recapitulation')), TRUE);
        $price  = str_replace('.', '', $this->input->post('price'));
        $note   = $this->input->post('note');
        $margin = $price - $data_recapitulation['total_price'];
        $data_recapitulation['total_price_report'] = $price;
        $data_recapitulation['margin'] = $margin;
        $data_recapitulation['note'] = $note;
        $data_recapitulation['sales_date'] = date('Y-m-d');

        $data_accounting = json_decode($this->encrypt->decode($this->input->post('data_accounting')));

        $this->model->insert('tb_sales_recapitulation', $data_recapitulation);

        //update sales
        $array_update_sales = ['report_status' => TRUE];
        $this->model->update(array('created_by' => $this->session->userdata('us_id'), 'report_status' => 0), $array_update_sales, 'tb_sales');
        //update deposito
        $this->model->update(array('created_by' => $this->session->userdata('us_id'), 'report_status' => 0, 'status' => 1), $array_update_sales, 'tb_deposito');
        //update usage
        $this->model->update(array('created_by' => $this->session->userdata('us_id'), 'status' => 0), ['status' => 1], ' tb_usage');
        $html_respon = '
        <div class="p-20 bg-warning text-center border-radius-5">
        <h2><i class="fa fa-check"></i> DATA REKAPITULASI BERHASIL DISIMPAN !</h2>
        </div>
        ';
        $get_max_id = $this->db->select('MAX(id) AS max_id')->get('tb_sales_recapitulation')->row();

        //insert to accountant
        $this->insert_to_accountant($data_accounting, $get_max_id->max_id);
        $this->db->trans_complete();
        if ($this->db->trans_status() == false) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }

        $array_respon = [
            'id' => $get_max_id->max_id,
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    private function insert_to_accountant($array_accountant, $id_recapitulation)
    {
        $account_sales   = json_decode($this->db->where(['field' => 'book_account_sales'])->get('tb_setting')->row()->value);
        //insert debit and credit to account reception
        $description = 'Pendapatan penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
        $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $status_act = 6;
        // $cash_payment = $account_sales->credit_sales_income - 
        if ($array_accountant->grand_total_income) {
            //minus piutang
            $grand_total_income_fix = $array_accountant->grand_total_income;
            if ($array_accountant->grand_total_piutang) {
                $grand_total_income_fix = $array_accountant->grand_total_income - $array_accountant->grand_total_piutang;
            }
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_sales_income,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => $grand_total_income_fix,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );

            if ($array_accountant->grand_total_piutang) {
                //insert piutang
                $description = 'Piutang penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
                $this->model->insert(
                    'tb_book_account_has_detail',
                    [
                        'id_book_account' => $account_sales->debit_piutang,
                        'description' => $description,
                        'date' => date('Y-m-d'),
                        'debit' => $array_accountant->grand_total_piutang,
                        'credit' => 0,
                        'status_act' => $status_act,
                        'id_recapitulation' => $id_recapitulation,
                        'token' => $token
                    ]
                );
            }

            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_sales_income,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->grand_total_income,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        // $total_discount = $array_accountant->grand_total_discount + $array_accountant->grand_total_member_discount;

        // if ($total_discount) {
        //     //insert jurnal bonus
        //     $description = 'Potongan penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
        //     $this->model->insert(
        //         'tb_book_account_has_detail',
        //         [
        //             'id_book_account' => $account_sales->debit_bonus,
        //             'description' => $description,
        //             'date' => date('Y-m-d'),
        //             'debit' => $total_discount,
        //             'credit' => 0,
        //             'status_act' => $status_act,
        //             'id_recapitulation' => $id_recapitulation,
        //             'token' => $token
        //         ]
        //     );
        // }

        //hpp sales
        if ($array_accountant->grand_total_hpp) {
            $description = 'Hpp penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_hpp,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => $array_accountant->grand_total_hpp,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_hpp,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->grand_total_hpp,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //ppn
        if ($array_accountant->ppn_price) {
            $description = 'Pajak PPN penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_ppn,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => $array_accountant->ppn_price,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_ppn,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->ppn_price,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //pph
        if ($array_accountant->pph_price) {
            $description = 'Pajak PPH penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_pph,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => $array_accountant->pph_price,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_pph,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->pph_price,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //deposito payment 
        if ($array_accountant->deposit_payment) {
            $description = 'Pemakaian Deposito di penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_deposito,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->deposit_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_deposito,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'credit' => 0,
                    'debit' => $array_accountant->deposit_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //Poin payment 
        if ($array_accountant->point_payment) {
            $description = 'Pemakaian Poin di penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_point,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->point_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_point,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'credit' => 0,
                    'debit' => $array_accountant->point_payment,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        $status_act = 7;
        // new deposit
        if ($array_accountant->deposito_in) {
            $description = 'Top Up Deposito tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_deposito,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => $array_accountant->deposito_in,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_deposito,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->deposito_in,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );

            //deposito administration
            $description = 'administrasi Deposito tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_deposito_income,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => $array_accountant->administration_deposito,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_deposito_income,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => 0,
                    'credit' => $array_accountant->administration_deposito,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }

        //new point
        $status_act = 8;
        if ($array_accountant->new_point) {
            $description = 'Poin Baru di penjualan tanggal ' . date('d-m-Y') . ' , Setoran kasir  : ' . $this->session->userdata('us_name');
            $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->debit_point,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'debit' => $array_accountant->new_point,
                    'credit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
            $this->model->insert(
                'tb_book_account_has_detail',
                [
                    'id_book_account' => $account_sales->credit_point,
                    'description' => $description,
                    'date' => date('Y-m-d'),
                    'credit' => $array_accountant->new_point,
                    'debit' => 0,
                    'status_act' => $status_act,
                    'id_recapitulation' => $id_recapitulation,
                    'token' => $token
                ]
            );
        }
    }

    public function print_nota()
    {
        $id = $this->input->post('id');
        // $id = 9;
        $this->db->select('
            tb_sales_recapitulation.*,
            tb_user.name AS user_name
            ');
        $this->db->from('tb_sales_recapitulation');
        $this->db->join('tb_user', 'tb_sales_recapitulation.created_by = tb_user.id', 'left');
        $this->db->where(['tb_sales_recapitulation.id' => $id]);
        $get_data = $this->db->get()->row();
        // $get_data = $this->db->where(['id' => $id])->get('tb_sales_recapitulation')->row();
        $data['data_recapitulation'] = $get_data;
        // $this->load->view($this->location . 'invoice', $data);
        // exit;
        $html_respon = $this->load->view($this->location . 'invoice', $data, TRUE);

        $btn_print = '
        <button type="button" class="btn btn-block btn-lg btn-success btn_print"  onclick="printJS(' . "html_nota" . ', ' . "html" . ')">
        <i class="fa fa-print"></i> Cetak Nota
        </button>
        ';

        $array_respon = [
            'html_respon' => $html_respon,
            'btn_print' => $btn_print,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    // public function update_status()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $status = $this->input->post('status');
    //     $array_update = [
    //         'status' => $status
    //     ];
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(['status' => TRUE]);
    // }

    public function get_form_capital()
    {
        // $capital_money = $this->db->where(['field' => 'capital money'])->get('tb_setting')->row();
        $get_user = $this->db->where(['id' => $this->session->userdata('us_id')])->get('tb_user')->row();
        $html_respon = '
        <form class="form-capital">
        <div class="col-md-8 form-group">
        <label for="">Uang Modal</label>
        <input type="text" name="money" class="form-control money_only" value="' . number_format($get_user->capital_money, 0, '.', '.') . '">
        <span class="help-block"></span>
        </div>
        <div class="col-md-4">
        <label for="">&nbsp;</label><br>
        <button type="submit" class="btn btn-success btn_do_update_capital">Simpan Data</button>
        </div>
        </form>
        ';

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function update_modal()
    {
        $money = str_replace('.', '', $this->input->post('money'));
        $array_update = ['capital_money' => $money];
        $this->model->update(array('id' => $this->session->userdata('us_id')), $array_update, 'tb_user');
        echo json_encode(['status' => TRUE]);
    }

    public function history()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "REKAPITULASI PENJUALAN KASIR";
        $data['view_file'] = $this->location . 'view_history';
        $this->load->view('template/media_admin_top', $data);
    }
    public function list_history()
    {
        $id_user = $this->session->userdata('us_id');
        $get_data = $this->db->where(['created_by' => $id_user])->order_by('id', 'DESC')->get('tb_sales_recapitulation')->result();
        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->created_date;
            $row[] = $data_table->total_invoice . ' NOTA';
            $row[] = $data_table->total_invoice_deposito . ' NOTA';
            $row[] = 'Rp.' . number_format($data_table->total_omset_sales, 0, '.', '.');
            $row[] = 'Rp.' . number_format($data_table->total_price_deposito, 0, '.', '.');
            $row[] = 'Rp.' . number_format($data_table->total_price, 0, '.', '.');
            $row[] = 'Rp.' . number_format($data_table->total_price_report, 0, '.', '.');
            $row[] = 'Rp.' . number_format($data_table->margin, 0, '.', '.');
            $row[] = '
            <button type="button" onclick="get_invoice(' . "'" . $data_table->id . "'" . ')" class="btn btn-default"><i class="fa fa-print"></i></button> </a> || 
            <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($data_table->id) . '" title="detail" class="btn btn-default btn-detail"><i class="fa fa-list"></i></a>
            ';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function get_detail()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $get_data = $this->db->where(['id' => $id])->get('tb_sales_recapitulation')->row();
        $data['data_recapitulation'] = $get_data;
        $html_respon = $this->load->view($this->location . 'view_detail', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }
}
