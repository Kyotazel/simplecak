<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="table_list" class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal Setor</th>
                        <th>Total Nota Penjualan</th>
                        <th>Total Nota Deposito</th>
                        <th>Total Uang Penjualan</th>
                        <th>Total Uang Deposito</th>
                        <th>Total Uang Tunai</th>
                        <th>Total Setor</th>
                        <th>Margin</th>
                        <th width="150px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<span class="clearfix"></span>
<div class="col-md-8 bg-white d-none" id="html_nota">
</div>
<div class="col-md-4 d-none">
    <button type="button" class="btn_print" onclick="printJS('html_nota', 'html')">
        Print Form
    </button>
</div>

<div class="modal" id="modal_review" data-backdrop="static">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="card-body pad">
                <div class="content-html-review"></div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>