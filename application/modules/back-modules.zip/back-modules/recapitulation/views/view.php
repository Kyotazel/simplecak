<?php
//count moey current 
$total_sales = 0;
if (!empty($data_sales)) {
    // $total_sales        = ($capital_money->value + $data_sales->sum_cash_payment) - $data_sales->sum_rest_payment;
    $cash_price_sales   =  $data_sales->sum_cash_payment - $data_sales->sum_rest_payment;
    $total_sales        =  $data_sales->sum_cash_payment - $data_sales->sum_rest_payment;
}
// $total_sales =  +$total_sales;
$total_deposito     = isset($data_deposit->sum_deposit) ? $data_deposit->sum_deposit : 0;
$all_money          = $total_sales + $total_deposito + $capital_money;
$cashier_money      = $all_money - $data_money_usage->price_usage;

// print_r($data_deposit);
// exit;

$array_insert_recapitulation = [
    'total_invoice' => $data_sales->count_invoice == '' ? 0 : $data_sales->count_invoice,
    'total_omset_sales' => $data_sales->sum_grand_total == '' ? 0 : $data_sales->sum_grand_total,
    'cash_price_sales' => $cash_price_sales == '' ? 0 : $cash_price_sales,
    'deposito_price_sales' => $data_sales->sum_deposito_payment == '' ? 0 : $data_sales->sum_deposito_payment,
    'point_price_sales' => $data_sales->sum_point_payment == '' ? 0 : $data_sales->sum_point_payment,
    'total_credit_price' => $data_sales->sum_credit_price == '' ? 0 : $data_sales->sum_credit_price,
    'total_member' => $data_deposit->total_member == '' ? 0 : $data_deposit->total_member,
    'total_invoice_deposito' => $data_deposit->total_invoice == '' ? 0 : $data_deposit->total_invoice,
    'total_price_deposito' => $data_deposit->sum_deposit == '' ? 0 : $data_deposit->sum_deposit,
    'total_price' => $cashier_money,
    'capital_money' => $capital_money,
    'price_usage' => $data_money_usage->price_usage == '' ? 0 : $data_money_usage->price_usage,
    'date' => date('Y-m-d'),
    'list_id_sales' => $data_sales->list_id_sales == '' ? 0 : $data_sales->list_id_sales,
    'list_id_deposito' => $data_deposit->list_deposito == '' ? 0 : $data_deposit->list_deposito,
    'list_id_usage' => $data_money_usage->list_id_usage == '' ? 0 : $data_money_usage->list_id_usage,
    'created_by' => $this->session->userdata('us_id')
];
$data_encrypt_item = $this->encrypt->encode(json_encode($array_insert_recapitulation));

$array_accounting = [
    'grand_total_sales' => $data_sales->sum_grand_total_real_price,
    'grand_total_income' => $data_sales->sum_grand_total_sales,
    'grand_total_discount' => $data_sales->sum_grand_total_discount,
    'grand_total_piutang' => $data_sales->sum_credit_price,
    'grand_total_member_discount' => $data_sales->sum_grand_total_member_discount,
    'grand_total_hpp' => $data_sales->sum_grand_total_hpp,
    'ppn_price' => $data_sales->sum_total_ppn_price,
    'pph_price' => $data_sales->sum_total_pph_price,
    'deposit_payment' => $data_sales->sum_deposito_payment,
    'point_payment' => $data_sales->sum_point_payment,
    'new_point' => $data_sales->sum_new_point,
    'deposito_in' => $data_deposit->sum_deposit_only,
    'administration_deposito' => $data_deposit->sum_admin
];




?>
<div class="row">
    <div class="col-md-4">
        <!-- Widget: user widget style 1 -->
        <div class="card box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-green">
                <div class="widget-user-image">
                    <img class="img-circle" src="<?= base_url('assets/img/user.png') ?>" alt="User Avatar">
                </div>
                <!-- /.widget-user-image -->
                <h3 class="widget-user-username text-uppercase"><?= $data_user->name; ?></h3>
                <h5 class="widget-user-desc">KASIR</h5>
            </div>
            <div class="card-footer no-padding">
                <ul class="nav nav-stacked">
                    <li><a href="#">Uang Modal <h4 class="pull-right text-uppercase">Rp. <?= isset($capital_money) ? number_format($capital_money, 0, '.', '.') : 0; ?></h4><button class="btn btn-info btn-xs btn_update_modal"><i class="fa fa-edit"></i></button> </a></li>
                    <li><a href="#">Total Penjualan <h4 class="pull-right text-uppercase">Rp. <?= isset($total_sales) ? number_format($total_sales, 0, '.', '.') : 0; ?></h4></a></li>
                    <li><a href="#">Total TOP-UP <h4 class="pull-right">Rp. <?= isset($data_deposit->sum_deposit) ? number_format($data_deposit->sum_deposit, 0, '.', '.') : 0; ?></h4></a></li>
                </ul>
            </div>
        </div>
        <!-- /.widget-user -->
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <div class="col-md-12 p-20 border border-radius-5 cover_payment">
                    <form class="form-payment">
                        <div class="col-md-5 text-center form-group p-20 bg-warning border-radius-5">
                            <small>Total uang (Penjualan + TOP UP )</small>
                            <input type="hidden" name="data_recapitulation" value="<?= $data_encrypt_item; ?>">
                            <input type="hidden" name="data_accounting" value="<?= $this->encrypt->encode(json_encode($array_accounting)); ?>">
                            <h1 class="text-bold text-green">Rp.<?= number_format($cashier_money, 0, '.', '.'); ?></h1>
                        </div>
                        <div class="col-md-5 form-group text-center">
                            <div class="form-group">
                                <label for="">Nominal Setor :</label>
                                <input class="form-control p-20 fa-2x money_only" name="price">
                                <span class="help-block"></span>
                            </div>
                            <div class="form-group">
                                <label for="">Catatan :</label>
                                <textarea name="note" class="form-control" rows="3"></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <label for="">&nbsp;</label><br>
                            <button type="submit" class="btn btn-success btn-md p-10 btn_save"><i class="fa fa-save"></i> Simpan Setoran</button>
                        </div>
                    </form>

                </div>
                <div class="col-md-12 text-right p-10">
                    <a data-toggle="collapse" class="btn btn-info" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                        <i class="fa fa-tv"></i> Detail Rincian Uang
                    </a>
                </div>
                <span class="clearfix"></span>
                <div class="col-md-12 collapse" id="collapseExample">
                    <label class="label label-info col-md-3 mb-10 mt-10" style="padding:5px"><i class="fa fa-tv"></i> Rincian Total Uang Penjualan :</label>
                    <span class="clearfix"></span>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Uang Modal</small>
                        <h3>Rp.<?= isset($capital_money) ?  number_format($capital_money, 0, '.', '.') : '0'; ?></h3>
                    </div>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Total Uang Pembayaran</small>
                        <h3>Rp.<?= isset($data_sales->sum_cash_payment) ?  number_format($data_sales->sum_cash_payment, 0, '.', '.') : '0'; ?></h3>
                    </div>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Total Uang Kembali</small>
                        <h3>Rp.<?= isset($data_sales->sum_rest_payment) ?  number_format($data_sales->sum_rest_payment, 0, '.', '.') : 0; ?></h3>
                    </div>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Total Uang Penjualan</small>
                        <h3>Rp.<?= isset($data_sales->sum_grand_total) ? number_format($data_sales->sum_grand_total, 0, '.', '.') : 0; ?></h3>
                    </div>
                    <span class="clearfix"></span>
                    <label class="label label-info col-md-3 mb-10 mt-10" style="padding:5px"><i class="fa fa-tv"></i> Rincian Total Uang TOP UP :</label>
                    <span class="clearfix"></span>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Total Uang Deposito</small>
                        <h3>Rp.<?= isset($data_deposit->sum_deposit_only) ?  number_format($data_deposit->sum_deposit_only, 0, '.', '.') : 0; ?></h3>
                    </div>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Total Uang Administrasi</small>
                        <h3>Rp.<?= isset($data_deposit->sum_admin) ?  number_format($data_deposit->sum_admin, 0, '.', '.') : 0; ?></h3>
                    </div>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Total Uang Diterima</small>
                        <h3>Rp.<?= isset($data_deposit->sum_deposit) ?  number_format($data_deposit->sum_deposit, 0, '.', '.') : 0; ?></h3>
                    </div>
                    <span class="clearfix"></span>
                    <label class="label label-info col-md-3 mb-10 mt-10" style="padding:5px"><i class="fa fa-tv"></i> TOTAL PEMAKAIAN UANG :</label>
                    <span class="clearfix"></span>
                    <div class="col-md-3 p-10 border border-radius-5 text-center">
                        <small>Total Uang Dipakai</small>
                        <h3>Rp.<?= isset($data_money_usage->price_usage) ? number_format($data_money_usage->price_usage, 0, '.', '.') : 0; ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <span class="clearfix"></span>

    <div class="col-md-6">
        <div class="card box-success collapsed-box">
            <div class="card-header with-border">
                <h3 class="card-title"><i class="fa fa-shopping-cart"></i> DAFTAR NOTA PENJUALAN</h3>
                <div class="card-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                </div>
                <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-stripped table_data_sales" style="width: 100%;">
                        <thead>
                            <th>No</th>
                            <th>Kode Nota</th>
                            <th>Member</th>
                            <th>Grand Total</th>
                            <th>Waktu</th>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card box-success collapsed-box">
            <div class="card-header with-border">
                <h3 class="card-title"><i class="fa fa-money"></i> DAFTAR NOTA TOP-UP</h3>
                <div class="card-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-stripped table_data_deposito" style="width: 100%;">
                        <thead>
                            <th>No</th>
                            <th>Kode Nota</th>
                            <th>Member</th>
                            <th>Grand Total</th>
                            <th>Waktu</th>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
</div>

<span class="clearfix"></span>
<div class="col-md-8 bg-white d-none" id="html_nota">
</div>
<div class="col-md-4 d-none">
    <button type="button" class="btn_print" onclick="printJS('html_nota', 'html')">
        Print Form
    </button>
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="width:60%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>