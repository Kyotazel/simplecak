<?php
$get_profile    = $this->db->get('tb_profile')->row();
$get_ppn        = $this->db->where(['field' => 'ppn'])->get('tb_setting')->row()->value;
?>
<style>
    #invoice-POS {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, "Times New Roman", Georgia, serif;
        padding-right: 15px;
    }

    p {
        margin: 0;
        padding: 0;
    }

    .itemtext {
        font-size: 10px;
    }

    .small_text {
        font-size: 8px;
    }

    h3,
    h2,
    h5,
    h4 {
        padding: 0;
        margin: 0;
    }

    tr {
        padding: 0px;
        margin: 0px;
        line-height: 13px;
    }
</style>

<div id="invoice-POS">
    <center id="top">
        <div class="logo"></div>
        <div class="info">
            <img style="width:50px !important;" src="<?= base_url('upload/profile/' . $get_profile->image); ?>" alt="">
            <h3><?= $get_profile->name; ?></h3>
            <p class="itemtext">" <?= $get_profile->tagline; ?> "</p>
            <p align="center" class="small_text"><?= $get_profile->address . ' | ' . $get_profile->email; ?></p>
        </div>
        <!--End Info-->
    </center>
    <!--End InvoiceTop-->
    <br>

    <div id="mid">
        <div class="info">
            <!-- <p>
                Address : street city, state 0000</br>
                Email : JohnDoe@gmail.com</br>
            </p> -->
            <table>
                <tr>
                    <td width="80px;" class="itemtext">Tutup Shift</td>
                    <td width="5px" class="itemtext">:</td>
                    <td class="itemtext"><?= $data_recapitulation->created_date; ?></td>
                </tr>
                <tr>
                    <td width="80px;" class="itemtext">Kasir</td>
                    <td width="5px" class="itemtext">:</td>
                    <td class="itemtext"><?= $data_recapitulation->user_name; ?></td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    <!--End Invoice Mid-->
    <div id="bot">
        <div id="table">
            <table style="width: 100%;">
                <tr>
                    <td colspan="3">
                        <p align="center">REKAPITULASI PENJUALAN :</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>RINCIAN PENJUALAN :</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Nota</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= $data_recapitulation->total_invoice . ' NOTA'; ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Uang Modal</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->capital_money, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Omset</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->total_omset_sales, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Uang Tunai</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->cash_price_sales, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Deposito</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->deposito_price_sales, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Point</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->point_price_sales, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Piutang</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->total_credit_price, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>RINCIAN TOPUP :</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Nota TopUp</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= $data_recapitulation->total_invoice_deposito . ' NOTA'; ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Jml. Member Top Up</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= $data_recapitulation->total_member; ?></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>Total Uang Deposito</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->total_price_deposito, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>UANG DIPAKAI</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"><?= number_format($data_recapitulation->price_usage, 0, '.', '.'); ?></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>RESUME :</b></p>
                    </td>
                    <td class="tableitem">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>TOTAL WAJIB SETOR</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right">
                            <?= number_format($data_recapitulation->total_price, 0, '.', '.'); ?>
                        </p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>NOMINAL SETOR</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right">
                            <?= number_format($data_recapitulation->total_price_report, 0, '.', '.'); ?>
                        </p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>MARGIN</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right">
                            <?= number_format($data_recapitulation->margin, 0, '.', '.'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <hr style="border-top: 1px dashed black;">
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="2">
                        <p class="itemtext" align="left"><b>CATATAN :</b></p>
                    </td>
                    <td class="tableitem">
                        <p class="itemtext" align="right"></p>
                    </td>
                </tr>
                <tr class="service">
                    <td class="tableitem" colspan="3">
                        <p class="itemtext" align="left">
                            <?= $data_recapitulation->note; ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>
        <!--End Table-->

        <div id="legalcopy" style="margin-top: 20px;">
            <p class="itemtext" align="center">* <?= $get_profile->footer_note; ?> *</p>
        </div>

    </div>
    <!--End InvoiceBot-->
</div>
<!--End Invoice-->