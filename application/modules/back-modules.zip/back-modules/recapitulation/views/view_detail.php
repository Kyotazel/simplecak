<div class="col-md-8">
    <h3 class="mb-10"><i class="fa fa-shopping-cart"></i> RINCIAN UANG PENJUALAN</h3>
    <table class="table">
        <tr>
            <td width="200px">TOTAL NOTA</td>
            <td width="10px">:</td>
            <td><b><?= $data_recapitulation->total_invoice . ' NOTA'; ?></b></td>
        </tr>
        <tr>
            <td>UANG MODAL</td>
            <td>:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->capital_money, 0, '.', '.'); ?></b></td>
        </tr>
        <tr>
            <td>TOTAL OMSET PENJUALAN</td>
            <td>:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->total_omset_sales, 0, '.', '.'); ?></b></td>
        </tr>
        <tr>
            <td>TOTAL UANG TUNAI</td>
            <td>:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->cash_price_sales, 0, '.', '.'); ?></b></td>
        </tr>
        <tr>
            <td>TOTAL DEPOSITO</td>
            <td>:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->deposito_price_sales, 0, '.', '.'); ?></b></td>
        </tr>
        <tr>
            <td>TOTAL POINT</td>
            <td>:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->point_price_sales, 0, '.', '.'); ?></b></td>
        </tr>
        <tr>
            <td>TOTAL PIUTANG</td>
            <td>:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->total_credit_price, 0, '.', '.'); ?></b></td>
        </tr>
    </table>
    <hr>
    <h3><i class="fa fa-money"></i> RINCIAN UANG DEPOSITO</h3>
    <table class="table">
        <tr>
            <td width="200px">TOTAL NOTA DEPOSITO</td>
            <td>:</td>
            <td><b><?= $data_recapitulation->total_invoice_deposito . ' NOTA'; ?></b></td>
        </tr>
        <tr>
            <td>JUMLAH MEMBER TOP UP</td>
            <td>:</td>
            <td><b><?= $data_recapitulation->total_member . ' NOTA'; ?></b></td>
        </tr>
        <tr>
            <td>TOTAL UANG DEPOSITO</td>
            <td width="10px">:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->total_price_deposito, 0, '.', '.'); ?></b></td>
        </tr>
    </table>
    <hr>
    <h3><i class="fa fa-money"></i> TOTAL PEMAKAIAN UANG</h3>
    <table class="table">
        <tr>
            <td width="200px">TOTAL UANG DIPAKAI</td>
            <td width="10px">:</td>
            <td><b><?= 'Rp.' . number_format($data_recapitulation->price_usage, 0, '.', '.'); ?></b></td>
        </tr>
    </table>
</div>
<div class="col-md-4">
    <h2 class="text-center mb-10">Resume:</h2>
    <div class="border-radius-5 p-10 text-center bg-warning mb-10">
        <small>Total Wajib Setor</small>
        <h2><b><?= 'Rp.' . number_format($data_recapitulation->total_price, 0, '.', '.'); ?></b></h2>
    </div>
    <div class="border-radius-5 p-10 text-center bg-warning mb-10">
        <small>Nominal Setor</small>
        <h2><b><?= 'Rp.' . number_format($data_recapitulation->total_price_report, 0, '.', '.'); ?></b></h2>
    </div>
    <div class="border-radius-5 p-10 text-center bg-warning mb-10">
        <small>Margin</small>
        <h2><b><?= 'Rp.' . number_format($data_recapitulation->margin, 0, '.', '.'); ?></b></h2>
    </div>
    <div class="border-radius-5 p-10 text-center bg-warning mb-10">
        <small>Catatan:</small>
        <p><?= $data_recapitulation->note; ?></p>
    </div>
    <hr>
    <div class="mt-20 text-right">
        <small>(*klik untuk cetak nota)</small>
        <a href="javascript:void(0)" onclick="get_invoice('<?= $data_recapitulation->id; ?>')" class="btn btn-default">
            <i class="fa fa-print"></i> Cetak Nota
        </a>
    </div>
</div>