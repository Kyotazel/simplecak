var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/recapitulation';
var save_method;
var table_sales;
var table_has_paid;
var id_use;
$(document).ready(function(){
	table_sales= $('.table_data_sales').DataTable({
        "ajax": {
            "url": controller+"/list_data_sales",
            "type": "POST"
        }
    });

    table_deposito= $('.table_data_deposito').DataTable({
        "ajax": {
            "url": controller+"/list_data_deposito",
            "type": "POST"
        }
    });

    table_has_paid= $('#table_list').DataTable({
        "ajax": {
            "url": controller+"/list_history",
            "type": "POST"
        }
    });
    
    // table_has_paid= $('.table_reject').DataTable({
    //     "ajax": {
    //         "url": controller+"/list_reject",
    //         "type": "POST"
    //     }
    // });

    // shortcut.add("f3", function() {
    //     // Do something
    //     $('.btn_view_member').click();
    // });
    // shortcut.add("f4", function() {
    //     // Do something
    //     $('.btn_view_top_up').click();
    // });

    // shortcut.add("f4", function() {
    //     // Do something
    //     $(document).on('click', '#btn_save', function () { });
    // });
    

    // $('.table_payment').DataTable();
})

function reload_table(){
    table.ajax.reload(null, false); //reload datatable ajax
}

$('.btn_update_modal').click(function () {
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
    $('.modal-title').text('FORM UPDATE');
	  //defined form
      var formData = new FormData($('.form-payment')[0]);
      $.ajax({
       url: controller+'/get_form_capital',
       type: "POST",
       dataType :"JSON",
       success: function(data){
         if(data.status){
          $('#modal-form').modal('show');
          $('.html_respon_modal').html(data.html_respon);
      } 
      $('.btn_update_modal').button('reset');
  },
  error:function(jqXHR, textStatus, errorThrown)
  {
   $('.btn_update_modal').button('reset');
   alert_error('something wrong');
}
	  });//end ajax
  })

$(document).on('click', '.btn-detail', function () {
    var id = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
    $('.modal-title').text('DETAIL');
	  //defined form
      $.ajax({
        url: controller+'/get_detail',
        type: "POST",
        dataType :"JSON",
        data:{'id':id},
        success: function(data){
            if(data.status){
                $('#modal_review').modal('show');
                $('.content-html-review').html(data.html_respon);
            } 
            $('.btn_detail').button('reset');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_detail').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
  });

// $('.btn-detail').click(function () {
//     var id = $(this).data('id');
//     alert('ok');
//     // $('.form-group').removeClass('has-error');
//     // $('.help-block').empty();  
//     // $('.modal-title').text('FORM UPDATE');
// 	//   //defined form
//     // $.ajax({
//     // url: controller+'/get_detail',
//     // type: "POST",
//     // dataType :"JSON",
//     // data:{'id':id},
//     // success: function(data){
//     //     if(data.status){
//     //         $('#modal_review').modal('show');
//     //         $('.content-html-review').html(data.html_respon);
//     //     } 
//     //     $('.btn_detail').button('reset');
//     // },
//     //     error:function(jqXHR, textStatus, errorThrown)
//     //     {
//     //     $('.btn_detail').button('reset');
//     //     alert_error('something wrong');
//     //     }
//     // });//end ajax
// })

$(document).on('click', '.btn_do_update_capital', function (e) {
    e.preventDefault();
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan Disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $(this).button('loading');
            var formData = new FormData($('.form-capital')[0]);
            $.ajax({
                url: controller+'/update_modal',
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function(data){
                    if (data.status) {
                        $('#modal-form').modal('hide');
                        notif_success('data berhasil disimpan');
                        location.reload();
                    } else{
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                            $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                        }
                    }
                    $('.btn_do_update_capital').button('reset');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_do_update_capital').button('reset');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

$('.btn_save').click(function (e) {
    e.preventDefault();
    $(this).button('loading');
    var data_accounting = $(this).data('accounting');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();  
    $('.modal-title').text('KOREKSI KEMBALI');
	  //defined form
      var formData = new FormData($('.form-payment')[0]);
      formData.append('data_accounting',data_accounting);
      $.ajax({
       url: controller+'/review_payment',
       type: "POST",
       data: formData,
       contentType: false,
       processData : false,
       dataType :"JSON",
       success: function(data){
         if(data.status){
          $('#modal-form').modal('show');
          $('.html_respon_modal').html(data.html_respon);
      } else{
       for (var i = 0; i < data.inputerror.length; i++)
       {
           $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
           $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
       }
   }
   $('.btn_save').button('reset');
},
error:function(jqXHR, textStatus, errorThrown)
{
   $('.btn_save').button('reset');
   alert_error('something wrong');
}
	  });//end ajax
  })

$(document).on('click', '.btn_do_save', function () {
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan Disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $(this).button('loading');
            var formData = new FormData($('.form-payment')[0]);
            $.ajax({
                url: controller+'/save',
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function(data){
                    if (data.status) {
                        $('.cover_payment').html(data.html_respon);
                        $('#modal-form').modal('hide');
                        $('.html_respon_modal').html(data.html_respon);
                        get_invoice(data.id);
                        Swal.fire(
                            'BERHASIL!',
                            'Data Berhasil Disimpan!',
                            'success'
                            );
                    } else{
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                            $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                        }
                    }
                    $('.btn_do_save').button('reset');
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_do_save').button('reset');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

function get_invoice(id) {
    $('.overlay_loading').show();
    $.ajax({
        url: controller+'/print_nota',
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            $('#html_nota').html(data.html_respon);
            $('.btn_print').click();
            $('.overlay_loading').hide();
            // $('[name="data_product"]').val(data.data_product);
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_add_product').button('reset');
            $('.overlay_loading').hide();
            alert_error('something wrong');
        }
    });//end ajax
}





$(document).on('keyup', '.money_only', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
})

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}