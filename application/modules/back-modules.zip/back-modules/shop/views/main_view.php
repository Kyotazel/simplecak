<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <div class="mb-3 row">
            <h3 class="col-md-8">DAFTAR TOKO</h3>
            <div class="col-md-4 text-right">
                <?= Modules::run('security/create_access', '
                        <a href="javascript:void(0)" class="btn btn-primary-gradient btn_add btn-rounded" onclick="add_unit()"> <i class="fa fa-plus-circle" ></i> Tambah Data</a>
                    '); ?>
            </div>
        </div>
    </div>
    <div class="card-body">
        <table id="table_user" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>KODE</th>
                    <th>NAMA</th>
                    <th>ALAMAT</th>
                    <th>ACTION</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->

</div>



<div class="modal" id="modal_unit">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form kategori utama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>

            </div>
            <div class="card-body pad">
                <form role="form" id="form_unit">
                    <input type="hidden" name="id">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Kode Toko</label>
                            <input type="text" class="form-control" name="code" placeholder="masukan kode..">
                            <span class="help-block text-danger"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="masukan nama..">
                            <span class="help-block text-danger"></span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Alamat</label>
                            <textarea name="address" class="form-control" cols="30" rows="5"></textarea>
                            <span class="help-block text-danger"></span>
                        </div>
                        <div class="card-footer text-right">
                            <button type="button" onclick="save()" class="btn btn-lg btn-primary pull-right"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>