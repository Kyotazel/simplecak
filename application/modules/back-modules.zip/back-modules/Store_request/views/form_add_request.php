<div class="card">
    <div class="card-body">
        <div class="col-md-12 text-right">
            <a href="<?= base_url('store_request'); ?>" class="btn btn-default btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
        </div>
        <form class="form-input">
            <div class="col-md-12">
                <h3 class="p-10 mb-10">Form Pengadaan Barang</h3>
                <div class="col-md-12 border p-10 border-radius-5">
                    <div class="col-md-12 html_date_range">
                        <div class="col-md-3 form-group">
                            <label>Nama Pengadaan</label>
                            <input type="text" class="form-control" name="name">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Pilih Gudang</label>
                            <select name="id_supplier" class="form-control">
                                <?= $html_option_supplier; ?>
                            </select>
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Keterangan</label>
                            <textarea name="note" class="form-control" rows="2"></textarea>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <span class="clearfix"></span>
                    <hr>
                    <div class="col-md-12">
                        <input type="hidden" name="data_product">
                        <div class="col-md-3 form-group">
                            <label>Barcode Barang</label>
                            <input type="text" class="form-control" id="barcode" name="barcode">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Nama Produk</label>
                            <input type="text" id="product-name" class="form-control" name="product_name">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-2 form-group">
                            <label>Satuan Pengadaan</label>
                            <select name="unit" class="form-control" name="unit"></select>
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-2 form-group">
                            <label>Jumlah</label>
                            <input type="text" class="form-control" name="qty">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-2 form-group">
                            <label>&nbsp;</label><br>
                            <a href="javascript:void(0)" class="btn btn-default btn_add_item"><i class="fa fa-plus-circle"></i> Tambah Keranjang</a>
                            <span class="help-block"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 html_respon">
                <hr>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Kode Produk</th>
                            <th>Nama Produk</th>
                            <th>Satuan</th>
                            <th>Stok Tersisa</th>
                            <th>Harga Pokok SatuaN</th>
                            <th>Stok Pengadaan</th>
                            <th>Total Harga</th>
                            <th>Batal</th>
                        </tr>
                    </thead>
                    <tbody class="tbody_item">
                        <tr class="html_no_data">
                            <td colspan="7" class="text-center">
                                <div class="bg-empty-data"></div>
                                <h3 class="text-center text-muted mb-10">Pilihlah Data Produk Pengadaan Barang</h3>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="text-right mt-10">
                    <small class="">(*Klik untu simpan)</small>
                    <button type="button" class="btn btn-success btn_save"><i class="fa fa-save"></i> Simpan Data Pengadaan</button>
                </div>
            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>