<?php
$btn_payment = '';
if ($data_request->status == 0 && $data_request->status_warehouse == 0) {
    $btn_payment = '
                    <div class="text-center">
                        <small class="block  mb-10">(* klik untuk proses permintaan)</small>
                        <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($data_request->id) . '" class="btn btn-success btn_proceed"><i class="fa fa-send"></i> Proses Permintaan</a> || <a href="' . base_url('store_request') . '" class="btn btn-default"><i class="fa fa-arrow-left"></i> Lihat Data</a>
                    </div>
                ';
} elseif ($data_request->status == 0 && $data_request->status_warehouse == 1) {
    $btn_payment = '
                    <div class="text-center">
                        <a href="javascript:void(0)" disabled class="btn btn-success"><i class="fa fa-tv"></i> Permintaan Telah Diproses</a> || <a href="' . base_url('store_request') . '" class="btn btn-default"><i class="fa fa-arrow-left"></i> Lihat Data</a>
                    </div>
                ';
}
$html_note_reject = '';
if ($data_request->status == 2) {
    $html_note_reject = '   
                        <label>Catatan Pembatalan:</label>
                        <div class="p-10 bg-info">
                            <p>
                               ' . $data_request->reject_note . '
                            </p>
                        </div>
                        ';
}

$array_status = [
    0 => '<label class="label label-warning">Menunggu Penerimaan</label>',
    1 => '<label class="label label-success">Telah Diterima</label>',
    2 => '<label class="label label-default">Dibatalkan</label>'
];
?>
<div class="card">
    <div class="card-body">
        <div class="col-md-12 text-right">
            <a href="<?= base_url('store_request'); ?>" class="btn btn-default btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
        </div>
        <div class="col-md-4 mb-10 mt-10">
            <div class="text-center mb-10 p-10">
                <h3>Keterangan Pengadaaan</h3>
            </div>
            <div class="p-10 border-radius-5 shadow_div">
                <table class="table">
                    <tr>
                        <td width="150px">Kode</td>
                        <td width="5px">:</td>
                        <td><b><?= $data_request->code; ?></b></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><b><?= $data_request->name; ?></b></td>
                    </tr>
                    <tr>
                        <td>Grand Total</td>
                        <td>:</td>
                        <td><b>Rp.<?= number_format($data_request->grandtotal, 0, '.', '.'); ?></b></td>
                    </tr>
                    <tr>
                        <td>Total Item</td>
                        <td>:</td>
                        <td><b><?= $data_request->count_item; ?> ITEM</b></td>
                    </tr>
                    <tr>
                        <td>Gudang</td>
                        <td>:</td>
                        <td><b><?= $data_request->supplier_name ? $data_request->supplier_name : '-'; ?></b></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td>:</td>
                        <td><b><?= $data_request->date; ?></b></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td>:</td>
                        <td><b><?= isset($array_status[$data_request->status]) ? $array_status[$data_request->status] : '-'; ?></b></td>
                    </tr>
                </table>
                <label>Catatan:</label>
                <div class="p-10 bg-info">
                    <p>
                        <?= $data_request->note; ?>
                    </p>
                </div>
                <?= $html_note_reject; ?>
            </div>
        </div>

        <div class="col-md-8 ">
            <div class="text-left mb-10 p-10">
                <h3>Detail Pengadaaan</h3>
            </div>
            <table class="table table_detail_request">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Produk</th>
                        <th>Nama Produk</th>
                        <th>Satuan Produk</th>
                        <th>Satuan Pengadaan</th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th>Grand Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $counter = 0;
                    foreach ($data_detail as $item_detail) {
                        $counter++;

                        if (!empty($item_detail->conversion_name)) {
                            $unit_request = $item_detail->conversion_name . ' / ' . $item_detail->qty_conversion . ' ' . $item_detail->unit_name;
                        } else {
                            $unit_request = $item_detail->unit_name;
                        }

                        $conversion_name = $item_detail->conversion_name ? $item_detail->conversion_name : $item_detail->unit_name;

                        echo '
                                    <tr>
                                        <td>' . $counter . '</td>
                                        <td>' . $item_detail->product_code . '</td>
                                        <td>' . $item_detail->product_name . '</td>
                                        <td>' . $item_detail->unit_name . '</td>
                                        <td>' . $unit_request . '</td>
                                        <td>Rp.' . number_format($item_detail->price, 0, '.', '.') . ' / ' . $conversion_name . '</td>
                                        <td>' . $item_detail->qty . ' ' . $conversion_name . '</td>
                                        <td>Rp.' . number_format($item_detail->grandtotal, 0, '.', '.') . '</td>
                                    </tr>
                                ';
                    }
                    ?>
                </tbody>
            </table>

            <?= $btn_payment; ?>
        </div>
    </div>
</div>