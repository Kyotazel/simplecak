<div class="col-md-12">
    <!-- Custom Tabs -->
    <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_0" data-toggle="tab"><i class="fa fa-file-o"></i> Menunggu Diproses</a></li>
            <li><a href="#tab_3" data-toggle="tab"><i class="fa fa-check"></i> Diproses</a></li>
            <li><a href="#tab_1" data-toggle="tab"><i class="fa fa-check"></i> Telah Diterima</a></li>
            <li><a href="#tab_2" data-toggle="tab"><i class="fa fa-close"></i> Dibatalkan</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="tab_0">
                <div class="table-responsive">
                    <table class="table table-hover table_request" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Total Item</th>
                                <th>Grand Total</th>
                                <th>Keterangan</th>
                                <th>Gudang</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="tab_3">
                <div class="table-responsive">
                    <table class="table table-hover table_proceed" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Total Item</th>
                                <th>Grand Total</th>
                                <th>Keterangan</th>
                                <th>Gudang</th>
                                <th>Tanggal diproses</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="tab_1">
                <div class="table-responsive">
                    <table class="table table-hover table_receive" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Total Item</th>
                                <th>Grand Total</th>
                                <th>Penerima</th>
                                <th>Grand Total Diterima</th>
                                <th>Tanggal Diterima</th>
                                <th>Gudang</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="tab_2">
                <div class="table-responsive">
                    <table class="table table-hover table_reject" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Total Item</th>
                                <th>Grand Total</th>
                                <th>Tanggal Dibatalkan</th>
                                <th>Catatan</th>
                                <th>Gudang</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- /.tab-content -->
    </div>
    <!-- nav-tabs-custom -->
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>