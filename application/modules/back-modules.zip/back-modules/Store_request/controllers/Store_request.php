<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Store_request extends CI_Controller
{
    var $location = 'data_store_request/';
    var $tb_name = 'tb_requset';
    var $module_name = 'store_request';
    var $js_page = 'store_request';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        if ($this->session->userdata('us_id') == false) {
            redirect(base_url('login'));
        }
        $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = $this->tb_name;
        $simbol = 'RP';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_request")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_request WHERE id IN(SELECT MAX(id) FROM tb_request)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }



    public function index()
    {
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Data Permintaan TOko";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin', $data);
    }

    public function list_data_request()
    {
        $db_name = $this->tb_name;
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS supplier_name,
                            tb_user.name AS user_name
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $this->db->join('tb_user', 'tb_request.created_by = tb_user.id', 'left');
        $this->db->where(['tb_request.id_account_warehouse' => 0, 'tb_request.id_supplier' => $this->session->userdata('id_account_warehouse')]);
        $get_data = $this->db->where(['tb_request.status' => 0, 'tb_request.status_warehouse' => 0])->order_by('tb_request.id', 'DESC')->group_by('tb_request.id')->get()->result();
        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->date;
            $row[] = $data_table->name;
            $row[] = $data_table->count_item;
            $row[] = 'Rp.' . number_format($data_table->grandtotal, 0, '.', '.');
            $row[] = $data_table->note;
            $row[] = $data_table->supplier_name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = '
                        <a href="' . base_url('store_request/detail?data=' . urlencode($id_encrypt)) . '" class="btn btn-info btn_link">Detail</a>
                    ';
            $data[] = $row;
        }
        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_data_proceed()
    {
        $db_name = $this->tb_name;
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS supplier_name,
                            tb_user.name AS user_name
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $this->db->join('tb_user', 'tb_request.updated_by = tb_user.id', 'left');
        $this->db->where(['tb_request.id_account_warehouse' => 0, 'tb_request.id_supplier' => $this->session->userdata('id_account_warehouse')]);
        $get_data = $this->db->where(['tb_request.status' => 0, 'tb_request.status_warehouse' => 1])->order_by('tb_request.id', 'DESC')->group_by('tb_request.id')->get()->result();
        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->date;
            $row[] = $data_table->name;
            $row[] = $data_table->count_item;
            $row[] = 'Rp.' . number_format($data_table->grandtotal, 0, '.', '.');
            $row[] = $data_table->note;
            $row[] = $data_table->supplier_name;
            $row[] = $data_table->updated_date;
            $row[] = $data_table->user_name;
            $row[] = '
                        <a href="' . base_url('store_request/detail?data=' . urlencode($id_encrypt)) . '" class="btn btn-info btn_link">Detail</a>
                    ';
            $data[] = $row;
        }
        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_data_reject()
    {
        $db_name = $this->tb_name;
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS supplier_name,
                            tb_user.name AS user_name
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $this->db->join('tb_user', 'tb_request.created_by = tb_user.id', 'left');
        $this->db->where(['tb_request.id_account_warehouse' => 0, 'tb_request.id_supplier' => $this->session->userdata('id_account_warehouse')]);
        $get_data = $this->db->where(['tb_request.status' => 2])->order_by('tb_request.id', 'DESC')->group_by('tb_request.id')->get()->result();
        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->date;
            $row[] = $data_table->name;
            $row[] = $data_table->count_item;
            $row[] = 'Rp.' . number_format($data_table->grandtotal, 0, '.', '.');
            $row[] = $data_table->updated_date;
            $row[] = $data_table->reject_note;
            $row[] = $data_table->supplier_name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = '
                        <a href="' . base_url('store_request/detail?data=' . urlencode($id_encrypt)) . '" class="btn btn-default btn_link"><i class="fa fa-list"></i> Detail</a>
                    ';
            $data[] = $row;
        }
        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_data_receive()
    {
        $this->db->select('
            tb_request.*,
            COUNT(tb_request_has_product.id) AS count_item,
            tb_account_warehouse.name AS supplier_name,
            tb_user.name AS user_name,
            tb_receipt.received_by AS received_name,
            tb_receipt.grandtotal_receipt AS grand_total_receipt
        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $this->db->join('tb_receipt', 'tb_request.id = tb_receipt.id_request', 'left');
        $this->db->join('tb_user', 'tb_request.created_by = tb_user.id', 'left');
        $this->db->where(['tb_request.id_account_warehouse' => 0, 'tb_request.id_supplier' => $this->session->userdata('id_account_warehouse')]);
        $get_data = $this->db->where(['tb_request.status' => 1])->order_by('tb_request.id', 'DESC')->group_by('tb_request.id')->get()->result();

        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->date;
            $row[] = $data_table->name;
            $row[] = $data_table->count_item;
            $row[] = 'Rp.' . number_format($data_table->grandtotal, 0, '.', '.');
            $row[] = $data_table->received_name;
            $row[] = 'Rp.' . number_format($data_table->grand_total_receipt, 0, '.', '.');
            $row[] = $data_table->updated_date;
            $row[] = $data_table->supplier_name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = '
                        <a href="' . base_url('store_request/detail?data=' . urlencode($id_encrypt)) . '" class="btn btn-default btn_link"><i class="fa fa-list"></i> Detail</a>
                    ';
            $data[] = $row;
        }
        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_account_warehouse.name AS supplier_name
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_account_warehouse', 'tb_request.id_supplier = tb_account_warehouse.id', 'left');
        $get_data = $this->db->where(['tb_request.id' => $id])->group_by('tb_request.id')->get()->row();
        $data['data_request'] = $get_data;
        //get detail
        $this->db->select('
                            tb_request_has_product.*,
                            tb_product.code AS product_code,
                            tb_product.name AS product_name,
                            tb_product.qty_unit AS qty_unit,
                            tb_unit.name AS unit_name,
                            tb_product_has_conversion.name AS conversion_name,
                            tb_product_has_conversion.qty AS qty_conversion
                        ');
        $this->db->from('tb_request_has_product');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_request_has_product.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $get_data_detail = $this->db->where(['tb_request_has_product.id_request' => $id])->get()->result();
        $data['data_detail'] = $get_data_detail;

        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Detail Pengadaan";
        $data['view_file'] = $this->location . 'detail_request';
        $this->load->view('template/media_admin', $data);
    }

    public function cancel()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
                            tb_request.*,
                            COUNT(tb_request_has_product.id) AS count_item,
                            tb_supplier.name AS supplier_name
                        ');
        $this->db->from('tb_request');
        $this->db->join('tb_request_has_product', 'tb_request.id = tb_request_has_product.id_request', 'left');
        $this->db->join('tb_supplier', 'tb_request.id_supplier = tb_supplier.id', 'left');
        $get_data = $this->db->where(['tb_request.id' => $id])->group_by('tb_request.id')->get()->row();
        $data['data_request'] = $get_data;
        //get detail
        $this->db->select('
                            tb_request_has_product.*,
                            tb_product.code AS product_code,
                            tb_product.name AS product_name,
                            tb_product.qty_unit AS qty_unit,
                            tb_unit.name AS unit_name,
                            tb_product_has_conversion.name AS conversion_name,
                            tb_product_has_conversion.qty AS conversion_qty
                        ');
        $this->db->from('tb_request_has_product');
        $this->db->join('tb_product', 'tb_request_has_product.id_product = tb_product.id', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join('tb_product_has_conversion', 'tb_request_has_product.id_conversion_unit = tb_product_has_conversion.id', 'left');
        $get_data_detail = $this->db->where(['tb_request_has_product.id_request' => $id])->get()->result();
        $data['data_detail'] = $get_data_detail;

        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "Batalkan Pengadaan";
        $data['view_file'] = $this->location . 'form_cancel';
        $this->load->view('template/media_admin', $data);
    }

    public function save_reject()
    {
        $id     = $this->encrypt->decode($this->input->post('id'));
        $note   = $this->input->post('note');
        $array_update = [
            'status' => 2,
            'reject_note' => $note
        ];
        $this->model->update(array('id' => $id), $array_update, 'tb_request');
        echo json_encode(['status' => TRUE]);
    }

    public function proceed_request()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $array_update = [
            'status_warehouse' => 1,
            'updated_by' => $this->session->userdata('us_id')
        ];
        $this->model->update(array('id' => $id), $array_update, 'tb_request');
        echo json_encode(['status' => TRUE]);
    }
    // public function get_edit()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $get_data = $this->model->find(array('id' => $id), 'tb_point')->row_array();
    //     echo json_encode($get_data);
    // }
    // public function update()
    // {
    //     $this->validate_insert();
    //     $id        = $this->input->post('id');
    //     $price     = $this->input->post('price');
    //     $point     = $this->input->post('point');
    //     $note      = $this->input->post('note');
    //     //insert data
    //     $array_update = array(
    //         'min_price' => $price,
    //         'point' => $point,
    //         'note' => $note,
    //         'updated_date' => date('Y-m-d H:i:s'),
    //         'updated_by' => $this->session->userdata('us_id')
    //     );
    //     $this->model->update(array('id' => $id), $array_update, 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
    // public function delete()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $this->model->delete(array('id' => $id), 'tb_point');
    //     echo json_encode(array('status' => TRUE));
    // }
}
