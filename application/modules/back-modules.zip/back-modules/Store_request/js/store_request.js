var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/store_request';
var save_method;
var table_request;
var table_reject;
var table_receive;
var table_proceed;
var id_use;
$(document).ready(function(){
	table_request = $('.table_request').DataTable({
        "ajax": {
            "url": controller+"/list_data_request",
            "type": "POST"
        }
    });
    table_proceed = $('.table_proceed').DataTable({
        "ajax": {
            "url": controller+"/list_data_proceed",
            "type": "POST"
        }
    });
    table_reject = $('.table_reject').DataTable({
        "ajax": {
            "url": controller+"/list_data_reject",
            "type": "POST"
        }
    });
    table_receive = $('.table_receive').DataTable({
        "ajax": {
            "url": controller+"/list_data_receive",
            "type": "POST"
        }
    });
    $('.table_detail_request').DataTable();
    // console.log(controller);
})

function reload_table(){
     table.ajax.reload(null,false); //reload datatable ajax 
}

$(document).on('change', '#barcode', function (e) {
    e.preventDefault();
    
    $(".form-input").submit(function (e) {
        return false;
    });

    var barcode_current = $(this).val();
        $.ajax({
            url: controller + '/get_barcode_choosen/',
            type: "POST",
            dataType: "JSON",
            data:{'barcode':barcode_current},
            success: function (ui) {
                if (ui.status) {
                    $('#product-name').val(ui.item.label);
                    get_unit_request(ui.item.id);
                    $('[name="qty"]').focus();
                } else {
                    alert_error('barang tidak ditemukan');
                }
                
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    })

$('#product-name').autocomplete({
    source: controller + "/get_product_auto",
    select: function(event, ui) {
        event.preventDefault();
        console.log(ui.item);
        $('#product-name').val(ui.item.label);
        get_unit_request(ui.item.id);
        $('[name="qty"]').focus();
    }
});

function get_unit_request(id) {
    $.ajax({
	    url: controller+'/get_unit_request',
	    type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            $('[name="unit"]').html(data.html_respon);
            $('[name="data_product"]').val(data.data_product);
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_add_product').button('reset');
	       alert_error('something wrong');
	      }
	  });//end ajax
}

$('.btn_add_item').click(function () {
    var data_product = $('[name="data_product"]').val();
    var unit = $('[name="unit"]').val();
    var qty = $('[name="qty"]').val();

    if (data_product == '' || unit == '' || qty == '') {
        alert_error('lengkapi data');
    } else {
        $.ajax({
            url: controller+'/add_item_product',
            type: "POST",
            dataType: "JSON",
            data:{'data_product':data_product,'unit':unit,'qty':qty},
            success: function (data) {
                $('.html_no_data').remove();
                var chek_tr = $('.tr_' + data.id).length;
                if (chek_tr) {
                    $('.tr_' + data.id).remove();
                }
                $('.tbody_item').append(data.html_respon);
    
                $('#product-name').val('');
                $('#barcode').val('');
                $('[name="qty"]').val('');
                $('[name="unit"]').html('');
                $('[name="data_product"]').val('');
                $('#barcode').focus();
    
            },
              error:function(jqXHR, textStatus, errorThrown)
              {
               alert_error('something wrong');
              }
          });//end ajax
    }    
})


$(document).on('click', '.btn_save_reject', function (e) {
    e.preventDefault();
    $(this).button('loading');
    var id = $(this).data('id');
    var note = $('[name="note"]').val();
    $('.form-group').removeClass('has-error');
	$('.help-block').empty();  
    if (note == '') {
        $('[name="note"]').next().text('harus di isi');
        $('[name="note"]').parent().parent().addClass('has-error');
        $('.btn_save_reject').button('reset');
    }else{
        Swal.fire({
            title: 'Apakah anda yakin?',
            text: "Pengadaan ini akan dibatalkan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya,lanjutkan',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: controller+'/save_reject',
                    type: "POST",
                    data: {'id':id,'note':note},
                    dataType :"JSON",
                    success: function(data){ 
                        notif_success('data berhasil dibatalkan');
                        window.location.href = controller;
                    },
                    error:function(jqXHR, textStatus, errorThrown)
                    {
                        $('.btn_save_reject').button('reset');
                        alert_error('something wrong');
                    }
                });//end ajax
            } else {
                $('.btn_save_reject').button('reset');
            }
        })
    }
})

$(document).on('click', '.btn_cancel', function (e) {
    e.preventDefault();
    $(this).parent().parent().remove();
    var count_tr = $('.tbody_item').has('tr').length;
    if (count_tr == 0) {
        $('.tbody_item').html('<tr class="html_no_data"><td colspan="7" class="text-center"> <div class="bg-empty-data"></div><h3 class="text-center text-muted mb-10">Pilihlah Data Produk Pengadaan Barang</h3></td></tr>');
    }
})

// function del_tr(class_name) {
//     $(class_name).remove();
//     var count_tr = $('.tbody_item').has('tr').length;
//     if (count_tr == 0) {
//         $('.tbody_item').html('<tr class="html_no_data"><td colspan="7" class="text-center"> <div class="bg-empty-data"></div><h3 class="text-center text-muted mb-10">Pilihlah Data Produk Pengadaan Barang</h3></td></tr>');
//     }
// }



// $('.btn_add_product').click(function () {
//     $('.btn_save').button('reset');
// 	save_method = 'add';
// 	$('.form-group').removeClass('has-error');
//  	$('.help-block').empty();
//     $('.form-input')[0].reset();
// 	$('.modal-title').text('TAMBAH DATA');
// 	$('#modal-form').modal('show');
// })

$('.btn_save').click(function (e) {
    e.preventDefault();
    $(this).button('loading');
	$('.form-group').removeClass('has-error');
    $('.help-block').empty(); 
    var html_data = $('.tbody_item').html();
    $('.modal-title').text('Koreksi Kembali'); 
	  //defined form
    var formData = new FormData($('.form-input')[0]);
    formData.append('html_data', html_data);
	   var url;
	  $.ajax({
	    url: controller+'/preview_request',
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData : false,
	    dataType :"JSON",
	    success: function(data){
            if (data.status) {
                $('.html_respon_modal').html(data.html_respon);
                $('#modal-form').modal('show'); 
	      } else{
	        for (var i = 0; i < data.inputerror.length; i++)
	         {
	            $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
                $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                //qty tr
                $('.'+data.inputerror[i]).text(data.error_string[i]);

                if (data.inputerror[i] == 'qty_product') {
                    alert_error('data produk belum dipilih');
                }
	         }
	      }
	      $('.btn_save').button('reset');
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	        $('.btn_save').button('reset');
            alert_error('something wrong');
	      }
	  });//end ajax
})

$(document).on('click', '.btn_do_save', function (e) {
    e.preventDefault();
    $(this).button('loading');
	$('.form-group').removeClass('has-error');
	$('.help-block').empty();  
	  //defined form
	   var formData = new FormData($('.form-input')[0]);
	   var url;
	  $.ajax({
	    url: controller+'/save',
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData : false,
	    dataType :"JSON",
	    success: function(data){
            if (data.status) {
                notif_success('data berhasil disimpan');
                window.location.href = controller+'/detail?data='+data.id
	      } else{
                alert_error('something wrong');
	      }
	      $('.btn_do_save').button('reset');
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	        $('.btn_do_save').button('reset');
            alert_error('something wrong');
	      }
	  });//end ajax
})

$(document).on('click', '.btn_proceed', function () {
    var id = $(this).data('id');
    Swal.fire({
        title: 'Apakah anda yakin?',
        text: "data ini akan diproses",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: controller+'/proceed_request',
                type: "POST",
                data: {'id':id},
                dataType :"JSON",
                success: function(data){
                    location.reload();
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    $('.btn_proceed').button('reset');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
})

// $('.btn_save').click(function (e) {
//     e.preventDefault();
//     $(this).button('loading');
// 	$('.form-group').removeClass('has-error');
// 	$('.help-block').empty();  
// 	  //defined form
// 	   var formData = new FormData($('.form-input')[0]);
// 	   var url;
// 	  $.ajax({
// 	    url: controller+'/preview_request',
// 	    type: "POST",
// 	    data: formData,
// 	    contentType: false,
// 	    processData : false,
// 	    dataType :"JSON",
// 	    success: function(data){
//             if (data.status) {
//                 notif_success('data berhasil disimpan');
//                 window.location.href = controller+'/detail?data='+data.id
// 	      } else{
// 	        for (var i = 0; i < data.inputerror.length; i++)
// 	         {
// 	            $('[name="'+data.inputerror[i]+'"]').parent().addClass('has-error');
//                 $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
//                 //qty tr
//                 $('.'+data.inputerror[i]).text(data.error_string[i]);

//                 if (data.inputerror[i] == 'qty_product') {
//                     alert_error('data produk belum dipilih');
//                 }
// 	         }
// 	      }
// 	      $('.btn_save').button('reset');
// 	    },
// 	      error:function(jqXHR, textStatus, errorThrown)
// 	      {
// 	        $('.btn_save').button('reset');
//             alert_error('something wrong');
// 	      }
// 	  });//end ajax
// })


$(document).on("change", ".checkbox_status", function () {
    var id = $(this).val();
    if ($(this).prop('checked')) {
        status_active = 1;
    }else{
        status_active = 0;
    }
    $.ajax({
        url: controller+'/update_status',
        type: "POST",
        data: {'status':status_active,'id':id},
        dataType :"JSON",
        success: function(data){
                notif_success('status berhasil diupdate');
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_save').button('reset');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_edit', function () {
    var id = $(this).data('id');
    $('.modal-title').text('UPDATE DATA');
    $('.form-input')[0].reset();
	save_method = 'update';
	var PostData = {'id':id};
	$.ajax({
	    url: controller+'/get_edit',
	    type: "POST",
	    data: PostData,
	    dataType :"JSON",
        success: function (data) {
            id_use = data.id;  
            $('[name="price"]').val(data.min_price);
            $('[name="point"]').val(data.point);
            $('[name="note"]').val(data.note);
	      	$('#modal-form').modal('show'); 
	        $('.btn_save').button('reset');
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_save').button('reset');
	       alert_error('something wrong');
	      }
	  });//end ajax
})



$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
})