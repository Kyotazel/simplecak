<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Coa extends CommonController
{

    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    var $module_name = 'coa';
    var $module_directory = 'coa';
    var $module_js = ['coa'];
    var $app_data = [];

    private function _init()
    {
        $this->app_data['module_js']  = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['page_title']     = "Data Coa(Chart Of Account)";
        $this->app_data['view_file']     = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function list_activa_1()
    {

        $this->db->select('
            tb_book_account.*,
            st_user.username AS user_name,
            account_parent.code AS parent_code
            ');
        $this->db->from('tb_book_account');
        $this->db->join('st_user', 'tb_book_account.created_by = st_user.id ', 'left');
        $this->db->join('tb_book_account AS account_parent', 'tb_book_account.id_parent  = account_parent.id', 'left');
        $this->db->where(['tb_book_account.type_account' => 1, 'tb_book_account.isDeleted' => 'N']);
        $this->db->order_by('tb_book_account.code', 'ASC');
        // $this->db->order_by('tb_book_account.id_parent', 'ASC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;

            $btn_edit   = Modules::run('security/edit_access', '
            <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
            <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');

            $code = $data_table->id_parent == 0 ? '<span class="text-bold"> <i class="fa fa-tv"></i> ' . $data_table->code . '</span>' : '<span style="margin-left:12px;"> <i class="fa fa fa-circle-o"></i> ' . $data_table->code . '</span>';
            $bank_label = $data_table->status_bank ? ' <span class="badge badge-primary">Akun Bank</span>' : '';
            $row = array();
            $row[] = $no;
            $row[] = $code;
            $row[] = $data_table->name . ' ' . $bank_label;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }
    public function list_activa_2()
    {
        $this->db->select('
            tb_book_account.*,
            st_user.username AS user_name,
            account_parent.code AS parent_code
            ');
        $this->db->from('tb_book_account');
        $this->db->join('st_user', 'tb_book_account.created_by = st_user.id ', 'left');
        $this->db->join('tb_book_account AS account_parent', 'tb_book_account.id_parent  = account_parent.id', 'left');
        $this->db->where(['tb_book_account.type_account' => 2, 'tb_book_account.isDeleted' => 'N']);
        $this->db->order_by('tb_book_account.code', 'ASC');
        // $this->db->order_by('tb_book_account.id_parent', 'ASC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;

            $btn_edit   = Modules::run('security/edit_access', '
            <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
            <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');

            $code = $data_table->id_parent == 0 ? '<span class="text-bold"> <i class="fa fa-tv"></i> ' . $data_table->code . '</span>' : '<span style="margin-left:12px;"> <i class="fa fa fa-circle-o"></i> ' . $data_table->code . '</span>';

            $row = array();
            $row[] = $no;
            $row[] = $code;
            $row[] = $data_table->name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_capital()
    {
        $this->db->select('
            tb_book_account.*,
            st_user.username AS user_name,
            account_parent.code AS parent_code
            ');
        $this->db->from('tb_book_account');
        $this->db->join('st_user', 'tb_book_account.created_by = st_user.id ', 'left');
        $this->db->join('tb_book_account AS account_parent', 'tb_book_account.id_parent  = account_parent.id', 'left');
        $this->db->where(['tb_book_account.type_account' => 3, 'tb_book_account.isDeleted' => 'N']);
        $this->db->order_by('tb_book_account.code', 'ASC');
        // $this->db->order_by('tb_book_account.id_parent', 'ASC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;

            $code = $data_table->id_parent == 0 ? '<span class="text-bold"> <i class="fa fa-tv"></i> ' . $data_table->code . '</span>' : '<span style="margin-left:12px;"> <i class="fa fa fa-circle-o"></i> ' . $data_table->code . '</span>';
            $btn_edit   = Modules::run('security/edit_access', '
            <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
            <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');

            $row = array();
            $row[] = $no;
            $row[] = $code;
            $row[] = $data_table->name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_advatage()
    {
        $this->db->select('
            tb_book_account.*,
            st_user.username AS user_name,
            account_parent.code AS parent_code
            ');
        $this->db->from('tb_book_account');
        $this->db->join('st_user', 'tb_book_account.created_by = st_user.id ', 'left');
        $this->db->join('tb_book_account AS account_parent', 'tb_book_account.id_parent  = account_parent.id', 'left');
        $this->db->where(['tb_book_account.type_account' => 4, 'tb_book_account.isDeleted' => 'N']);
        $this->db->order_by('tb_book_account.code', 'ASC');
        // $this->db->order_by('tb_book_account.id_parent', 'ASC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $code = $data_table->id_parent == 0 ? '<span class="text-bold"> <i class="fa fa-tv"></i> ' . $data_table->code . '</span>' : '<span style="margin-left:12px;"> <i class="fa fa fa-circle-o"></i> ' . $data_table->code . '</span>';
            $btn_edit   = Modules::run('security/edit_access', '
            <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
            <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');
            $row = array();
            $row[] = $no;
            $row[] = $code;
            $row[] = $data_table->name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_cost()
    {
        $this->db->select('
            tb_book_account.*,
            st_user.username AS user_name,
            account_parent.code AS parent_code
            ');
        $this->db->from('tb_book_account');
        $this->db->join('st_user', 'tb_book_account.created_by = st_user.id ', 'left');
        $this->db->join('tb_book_account AS account_parent', 'tb_book_account.id_parent  = account_parent.id', 'left');
        $this->db->where(['tb_book_account.type_account' => 5, 'tb_book_account.isDeleted' => 'N']);
        $this->db->order_by('tb_book_account.code', 'ASC');
        // $this->db->order_by('tb_book_account.id_parent', 'ASC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $code = $data_table->id_parent == 0 ? '<span class="text-bold"> <i class="fa fa-tv"></i> ' . $data_table->code . '</span>' : '<span style="margin-left:12px;"> <i class="fa fa fa-circle-o"></i> ' . $data_table->code . '</span>';
            $btn_edit   = Modules::run('security/edit_access', '
            <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
            <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');
            $row = array();
            $row[] = $no;
            $row[] = $code;
            $row[] = $data_table->name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function list_hpp()
    {
        $this->db->select('
            tb_book_account.*,
            st_user.username AS user_name,
            account_parent.code AS parent_code
            ');
        $this->db->from('tb_book_account');
        $this->db->join('st_user', 'tb_book_account.created_by = st_user.id ', 'left');
        $this->db->join('tb_book_account AS account_parent', 'tb_book_account.id_parent  = account_parent.id', 'left');
        $this->db->where(['tb_book_account.type_account' => 6, 'tb_book_account.isDeleted' => 'N']);
        $this->db->order_by('tb_book_account.code', 'ASC');
        // $this->db->order_by('tb_book_account.id_parent', 'ASC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $code = $data_table->id_parent == 0 ? '<span class="text-bold"> <i class="fa fa-tv"></i> ' . $data_table->code . '</span>' : '<span style="margin-left:12px;"> <i class="fa fa fa-circle-o"></i> ' . $data_table->code . '</span>';
            $btn_edit   = Modules::run('security/edit_access', '
            <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
            <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');

            $row = array();
            $row[] = $no;
            $row[] = $code;
            $row[] = $data_table->name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }
    public function list_obligate()
    {
        $this->db->select('
            tb_book_account.*,
            st_user.username AS user_name,
            account_parent.code AS parent_code
            ');
        $this->db->from('tb_book_account');
        $this->db->join('st_user', 'tb_book_account.created_by = st_user.id ', 'left');
        $this->db->join('tb_book_account AS account_parent', 'tb_book_account.id_parent  = account_parent.id', 'left');
        $this->db->where(['tb_book_account.type_account' => 7, 'tb_book_account.isDeleted' => 'N']);
        $this->db->order_by('tb_book_account.code', 'ASC');
        // $this->db->order_by('tb_book_account.id_parent', 'ASC');
        $get_data = $this->db->get();
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            $code = $data_table->id_parent == 0 ? '<span class="text-bold"> <i class="fa fa-tv"></i> ' . $data_table->code . '</span>' : '<span style="margin-left:12px;"> <i class="fa fa fa-circle-o"></i> ' . $data_table->code . '</span>';
            $btn_edit   = Modules::run('security/edit_access', '
            <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
            <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');

            $row = array();
            $row[] = $no;
            $row[] = $code;
            $row[] = $data_table->name;
            $row[] = $data_table->created_date;
            $row[] = $data_table->user_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }


    private function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $id = $this->input->post('id');

        if (!empty($this->input->post('type_account')) && !empty($this->input->post('code'))) {
            $code           = $this->input->post('code');
            $type_account   = $this->input->post('type_account');
            $code_parent      = $this->encrypt->decode($this->input->post('id_parent'));

            $array_where = ['code' => $code, 'type_account' => $type_account, 'isDeleted' => 'N'];
            if (!empty($code_parent)) {
                $array_where['code'] = $code_parent . '-' . $code;
                $get_parent_current = $this->db->where(['code' => $code_parent, 'type_account' => $type_account, 'isDeleted' => 'N'])->get('tb_book_account')->row();
                $array_where['id_parent'] = $get_parent_current->id;
            }
            $get_data = $this->db->where($array_where)->get('tb_book_account')->row();
            if (!empty($get_data)) {
                $data['error_string'][] = 'Kode telah dipakai';
                $data['inputerror'][] = 'code';
                $data['status'] = FALSE;
            }
        }

        if ($this->input->post('code') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'code';
            $data['status'] = FALSE;
        }
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }
        if (empty($id)) {
            if ($this->input->post('type_account') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'type_account';
                $data['status'] = FALSE;
            }
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();

        $code           = $this->input->post('code');
        $type_account   = $this->input->post('type_account');
        $name   = $this->input->post('name');
        $code_parent      = $this->encrypt->decode($this->input->post('id_parent'));
        $get_parent_current = $this->db->where(['code' => $code_parent, 'type_account' => $type_account])->get('tb_book_account')->row();
        $is_bank = $this->input->post('is_bank');

        if (!empty($code_parent)) {
            $code = $code_parent . '-' . $code;
        }

        // //insert data
        $array_insert = array(
            'code' => $code,
            'name' => $name,
            'status_bank' => $is_bank ? $is_bank : 0,
            'type_account' => $type_account,
            'id_parent' => isset($get_parent_current->id) ? $get_parent_current->id : 0,
            'created_by' => $this->session->userdata('usr_id')
        );
        Modules::run('database/insert', 'tb_book_account', $array_insert);
        echo json_encode(array('status' => TRUE));
    }
    public function update_status()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $status = $this->input->post('status');
        $array_update = [
            'status' => $status
        ];
        $this->model->update(array('id' => $id), $array_update, 'tb_point');
        echo json_encode(['status' => TRUE]);
    }

    public function get_edit()
    {

        $get_json = json_decode($this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value, TRUE);
        $id = $this->encrypt->decode($this->input->post('id'));
        // $get_data = $this->model->find(array('id' => $id), 'tb_book_account')->row_array();
        $get_data = Modules::run('database/find', 'tb_book_account', ['id' => $id])->row_array();



        $get_data_header = $this->db->where(['type_account' => $get_data['type_account'], 'id_parent' => 0])->get('tb_book_account')->result();

        $html_option = '<option value="">TIDAK ADA</option>';
        foreach ($get_data_header as $item_header) {
            $selected = $item_header->id == $get_data['id_parent'] ? 'selected' : '';
            $html_option .= '<option ' . $selected . ' value="' . $this->encrypt->encode($item_header->code) . '">' . $item_header->code . ' - ' . $item_header->name . '</option>';
        }


        if ($get_data['id_parent']) {
            $explode_code = explode('-', $get_data['code']);


            $code_current = $explode_code[1];
        } else {
            $code_current = $get_data['code'];
        }


        //form bank
        $html_form_bank = '';
        if ($get_data['type_account'] == 1) {
            $checked = $get_data['status_bank'] ? 'checked' : '';
            $html_form_bank = '
            <label>&nbsp;</label><br><input name="is_bank" ' . $checked . ' class="is_bank" value="1" data-toggle="toggle" data-size="medium" data-onstyle="success" type="checkbox"> KAS / BANK
            ';
        }

        $text_name = $get_data['type_account'] . ' - ' . $get_json[$get_data['type_account']]['name'];
        $get_data['text_name'] = $text_name;
        $get_data['html_option'] = $html_option;
        $get_data['code_current'] = $code_current;
        $get_data['html_bank'] = $html_form_bank;
        echo json_encode($get_data);
    }

    private function validate_update()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $id = $this->input->post('id');
        $get_data_current = $this->db->where(['id' => $id])->get('tb_book_account')->row();

        if (!empty($this->input->post('type_account')) && !empty($this->input->post('code'))) {
            $code           = $this->input->post('code');
            $type_account   = $this->input->post('type_account');
            $code_parent      = $this->encrypt->decode($this->input->post('id_parent'));
            $array_where = ['code' => $code, 'type_account' => $type_account];
            if (!empty($code_parent)) {
                $array_where['code'] = $code_parent . '-' . $code;
                $get_parent_current = $this->db->where(['code' => $code_parent, 'type_account' => $type_account])->get('tb_book_account')->row();
                $array_where['id_parent'] = $get_parent_current->id;
            }


            if ($get_data_current->code != $array_where['code']) {
                $get_data = $this->db->where($array_where)->get('tb_book_account')->row();
                if (!empty($get_data)) {
                    $data['error_string'][] = 'Kode telah dipakai';
                    $data['inputerror'][] = 'code';
                    $data['status'] = FALSE;
                }
            }
        }

        if ($this->input->post('code') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'code';
            $data['status'] = FALSE;
        }
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }
        if (empty($id)) {
            if ($this->input->post('type_account') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'type_account';
                $data['status'] = FALSE;
            }
        }


        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function update()
    {
        $this->validate_update();
        $id        = $this->input->post('id');
        $code           = $this->input->post('code');
        $type_account   = $this->input->post('type_account');
        $name   = $this->input->post('name');
        $is_bank = $this->input->post('is_bank');
        $code_parent      = $this->encrypt->decode($this->input->post('id_parent'));
        $get_parent_current = $this->db->where(['code' => $code_parent, 'type_account' => $type_account])->get('tb_book_account')->row();

        if (!empty($code_parent)) {
            $code = $code_parent . '-' . $code;
        }
        //insert data
        $array_update = array(
            'code' => $code,
            'name' => $name,
            'status_bank' => $is_bank,
            'id_parent' => isset($get_parent_current->id) ? $get_parent_current->id : 0,
            'updated_by' => $this->session->userdata('us_id')
        );
        // $this->model->update(array('id' => $id), $array_update, 'tb_book_account');
        Modules::run('database/update', 'tb_book_account', ['id' => $id], $array_update);
        echo json_encode(array('status' => TRUE));
    }
    public function delete()
    {
        Modules::run('security/is_ajax');
        $id = $this->encrypt->decode($this->input->post('id'));

        Modules::run('database/update', 'tb_book_account', array('id' => $id), array("isDeleted" => "Y"));
        echo json_encode(array('status' => TRUE));
    }

    public function get_list_account()
    {
        $type = $this->input->post('type');
        $get_data_header = $this->db->where(['type_account' => $type, 'id_parent' => 0, 'isDeleted' => 'N'])->order_by('tb_book_account.code')->get('tb_book_account')->result();
        $html_respon = '<option value="">TIDAK ADA</option>';
        foreach ($get_data_header as $item_header) {
            $html_respon .= '<option value="' . $this->encrypt->encode($item_header->code) . '">' . $item_header->code . ' - ' . $item_header->name . '</option>';
        }
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function get_form_update_setting()
    {

        $name = $this->input->post('name');
        $get_data = $this->db->where(['field' => $name])->get('tb_setting')->row()->value;
        $array_data = json_decode($get_data);

        $array_view = [
            'book_account_reception_store' => 'form_update_reception_store',
            'book_account_reception_warehouse' => 'form_update_reception_warehouse',
            'book_account_debt' => 'form_book_account_debt',
            'book_account_credit' => 'form_book_account_credit',
            'book_account_sales' => 'form_book_account_sales',
            'book_account_deposito' => 'form_book_account_deposito',
            'book_account_other' => 'form_book_account_prive'
        ];
        $data['update_name'] = $name;
        $data['data_account'] = $array_data;
        $html_respon = $this->load->view($array_view[$name], $data, TRUE);
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }


    public function update_setting()
    {
        $account = $this->input->post('account');
        $update_name = $this->input->post('update_name');


        $array_update = [
            'value' => json_encode($account)
        ];
        $this->model->update(array('field' => $update_name), $array_update, 'tb_setting');
        echo json_encode(['status' => TRUE]);
    }

    public function get_setting_view()
    {
        $data['cek'] = '';
        $html_respon = $this->load->view('view_setting', $data, TRUE);
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function get_saldo_view()
    {

        $check_data = $this->db->where(['status' => 1])->get('tb_book_period')->row();
        $view_file = !empty($check_data) ? 'view_saldo' : 'empty_saldo';
        $data['data_period'] = $check_data;
        //get saldo current 
        $array_saldo = [];
        if (!empty($check_data)) {
            $get_saldo_current = $this->db->where(['id_period' => $check_data->id])->get('tb_book_period_has_saldo')->result();
            foreach ($get_saldo_current as $item_saldo) {
                $array_saldo[$item_saldo->id_book_account] = $item_saldo->saldo;
            }
        }
        $data['data_saldo'] = $array_saldo;
        $html_respon = $this->load->view($view_file, $data, TRUE);
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function get_form_update_modal()
    {
        $data['update_name'] = $this->input->post('update_name');


        $get_period_current = $this->db->where(['status' => 1])->get('tb_book_period')->row();
        $get_data_saldo = Modules::run('database/find', 'tb_book_period_has_saldo', ['id_period' => $get_period_current->id])->result();
        $array_saldo = [];
        foreach ($get_data_saldo as $item_saldo) {
            $array_saldo[$item_saldo->id_book_account] = $item_saldo->saldo;
        }
        $data['data_saldo'] = $array_saldo;

        $html_respon = $this->load->view('form_update_modal', $data, TRUE);

        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function save_saldo()
    {
        $get_period_current = $this->db->where(['status' => 1])->get('tb_book_period')->row();
        $array_account = $this->input->post('account');

        foreach ($array_account as $id_account => $value_account) {
            $current_value = str_replace('.', '', $value_account);
            $current_value = $current_value == '' ? 0 : $current_value;

            $check_data = $this->db->where(['id_book_account' => $id_account, 'id_period' => $get_period_current->id])->get('tb_book_period_has_saldo')->row();
            if (!empty($check_data)) {
                $array_update = [
                    'saldo' => $current_value
                ];
                Modules::run('database/update', 'tb_book_period_has_saldo', ['id_book_account' => $id_account, 'id_period' => $get_period_current->id], $array_update);
                // $this->model->update(array('id_book_account' => $id_account, 'id_period' => $get_period_current->id), $array_update, 'tb_book_period_has_saldo');
            } else {
                $array_insert = [
                    'id_period' => $get_period_current->id,
                    'id_book_account' => $id_account,
                    'saldo' => $current_value
                ];
                Modules::run('database/insert', 'tb_book_period_has_saldo', $array_insert);
                // $this->model->insert('tb_book_period_has_saldo', $array_insert);
            }
        }

        echo json_encode(['status' => TRUE]);
    }

    public function update_saldo_base_periode()
    {
        $active_periode     = $this->db->where(['status' => 1])->get('tb_book_period')->row();
        $get_yearly_saldo   = $this->db->where(['status' => 2, 'id_period' => $active_periode->id_parent])->get('tb_book_account_recapitulation')->result();

        //delete old data
        // $this->model->delete(['id_period' => $active_periode->id], 'tb_book_period_has_saldo');
        Modules::run('database/delete', 'tb_book_period_has_saldo', ['id_period' => $active_periode->id]);
        //insert new saldo
        foreach ($get_yearly_saldo as $item_saldo) {
            $array_insert = [
                'id_period' => $active_periode->id,
                'id_book_account' => $item_saldo->id_book_account,
                'saldo' => $item_saldo->saldo
            ];
            Modules::run('database/insert', 'tb_book_period_has_saldo', $array_insert);
        }
        echo json_encode(['status' => TRUE]);
    }

    //period
    public function get_form_add_period()
    {
        $data['list_period'] = $this->db->order_by('id_parent')->get('tb_book_period')->result();
        $data['cek'] = '';
        $html_respon = $this->load->view('form_add_period', $data, TRUE);
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function validate_insert_save_period()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $id = $this->input->post('id');
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date_from') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_from';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date_to') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date_to';
            $data['status'] = FALSE;
        }
        // if (empty($id)) {
        //     if ($this->input->post('type_account') == '') {
        //         $data['error_string'][] = 'harus diisi';
        //         $data['inputerror'][] = 'type_account';
        //         $data['status'] = FALSE;
        //     }
        // }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    private function change_date($date)
    {
        $explode_date = explode('-', $date);
        $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
        return $date_return;
    }

    public function save_period()
    {
        $this->validate_insert_save_period();
        // print_r($_POST);
        // exit;
        $id_parent = $this->input->post('id_parent') == false ? 0 : $this->input->post('id_parent');
        $name = $this->input->post('name');
        $date_from = $this->change_date($this->input->post('date_from'));
        $date_to = $this->change_date($this->input->post('date_to'));

        // //insert data
        $array_insert = array(
            'name' => $name,
            'date_from' => $date_from,
            'date_to' => $date_to,
            'status' => 0,
            'id_parent' => $id_parent
        );
        Modules::run('database/insert', 'tb_book_period', $array_insert);
        // $this->model->insert('tb_book_period', $array_insert);
        //get data current 
        $get_data_current = $this->db->select("MAX(id) AS max_id")->get('tb_book_period')->row();
        $this->insert_first_saldo($get_data_current->max_id, $id_parent);
        echo json_encode(array('status' => TRUE));
    }

    public function list_period()
    {
        $get_data = $this->db->order_by('id_parent')->get('tb_book_period');
        $data = array();
        $no = 0;
        foreach ($get_data->result() as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $status = $data_table->status ? 'on' : '';

            $btn_edit   = Modules::run('security/edit_access', '
                <a class="btn btn-sm btn-warning-gradient btn-rounded btn_edit_period" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="fa fa-edit"></i> edit</a>
            ');
            $btn_delete = Modules::run('security/delete_access', '
                <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove_period" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="fa fa-trash"></i> Hapus</a>
            ');
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->name;
            $row[] = $this->change_date($data_table->date_from) . ' s-d ' . $this->change_date($data_table->date_to);
            $row[] = '
                <div data-id="' . $data_table->id . '" class="main-toggle main-toggle-dark btn_update_status_period change_status ' . $status . '"><span></span></div>
            ';
            // $row[] = '<a class="btn btn-sm btn-primary-gradient btn_edit_period" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Edit"><i class="glyphicon glyphicon-pencil"></i> edit</a>
            //         <a class="btn btn-sm btn-danger-gradient btn-rounded btn_remove_period" href="javascript:void(0)" data-id="' . $id_encrypt . '" title="Hapus"><i class="glyphicon glyphicon-trash"></i> Hapus</a>';
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }
        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }
    public function delete_period()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $check_data = $this->db->where(['id_period' => $id])->get('tb_book_account_recapitulation')->num_rows();
        $data_current = $this->db->where(['id' => $id, 'status' => 1])->get('tb_book_period')->row();
        $status = TRUE;
        $status = $check_data > 0 || !empty($data_current) ? false : true;
        //get data current 
        if ($status) {
            // $this->model->delete(array('id' => $id), 'tb_book_period');
            Modules::run('database/delete', 'tb_book_period', ['id' => $id]);
        }
        echo json_encode(array('status' => $status));
    }

    public function get_form_update_period()
    {
        $id = $this->encrypt->decode($this->input->post('id'));
        $data['list_period'] = $this->db->where_not_in('id', [$id])->order_by('id_parent')->get('tb_book_period')->result();
        $get_data = $this->db->where(['id' => $id])->get('tb_book_period')->row();
        if ($get_data->id_parent == 0) {
            $data['list_period'] = [];
        }
        $data['data_current'] = $get_data;

        $html_respon = $this->load->view('form_add_period', $data, TRUE);
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function insert_first_saldo($id_current, $id_parent)
    {
        $array_saldo = [];
        if ($id_parent == false) {
            $get_book_account   = $this->db->where(['id_parent >' => 0])->get('tb_book_account')->result();
            //create 
            foreach ($get_book_account as $item_book_account) {
                $array_saldo[] = ['id' => $item_book_account->id, 'saldo' => $item_book_account->saldo];
            }
        } else {
            $get_saldo_current  = $this->db->where(['status' => 2, 'id_period' => $id_parent])->get('tb_book_account_recapitulation')->result();
            //create 
            foreach ($get_saldo_current as $item_book_account) {
                $array_saldo[] = ['id' => $item_book_account->id_book_account, 'saldo' => $item_book_account->saldo];
            }
        }

        foreach ($array_saldo as $item_saldo) {
            $array_insert = [
                'id_period' => $id_current,
                'id_book_account' => $item_saldo['id'],
                'saldo' => $item_saldo['saldo']
            ];
            Modules::run('database/insert', 'tb_book_period_has_saldo', $array_insert);

            // $this->model->insert('tb_book_period_has_saldo', $array_insert);
        }
    }

    public function update_period()
    {
        $id = $this->input->post('id');
        $name = $this->input->post('name');
        $date_from = $this->change_date($this->input->post('date_from'));
        $date_to = $this->change_date($this->input->post('date_to'));

        // //insert data
        $array_update = array(
            'name' => $name,
            'date_from' => $date_from,
            'date_to' => $date_to
        );
        Modules::run('database/update', 'tb_book_period', ['id' => $id], $array_update);
        echo json_encode(array('status' => TRUE));
    }
    public function update_status_period()
    {
        $id = $this->input->post('id');

        // $this->model->update(array('status' => 1), ['status' => 0], 'tb_book_period');
        Modules::run('database/update', 'tb_book_period', ['status' => 1], ['status' => 0]);
        Modules::run('database/update', 'tb_book_period', ['id' => $id], ['status' => 1]);
        // $this->model->update(array('id' => $id), ['status' => 1], 'tb_book_period');
        $array_respon = [
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    //setting
    public function get_form_update_setting_account()
    {
        Modules::run('security/is_ajax');
        $code = $this->input->post('code');
        $data['code'] = $code;

        $html_respon = '';
        if ($code == 'invoice-transaction') {
            $html_respon = $this->load->view('form_book_account_invoice_transaction', $data, TRUE);
        }

        if ($code == 'cost-transaction') {
            $html_respon = $this->load->view('form_book_cost_transaction', $data, TRUE);
        }

        if ($code == 'cost-other-transaction') {
            $html_respon = $this->load->view('form_book_other_cost_transaction', $data, TRUE);
        }

        if ($code == 'payment-credit') {
            $html_respon = $this->load->view('form_book_account_payment_credit', $data, TRUE);
        }

        if ($code == 'payment-debt') {
            $html_respon = $this->load->view('form_book_account_debt', $data, TRUE);
        }

        if ($code == 'prive') {
            $html_respon = $this->load->view('form_book_account_prive', $data, TRUE);
        }


        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function update_setting_account()
    {
        Modules::run('security/is_ajax');
        $code   = $this->input->post('code');
        $data   = $this->input->post('data');

        if ($code == 'invoice-transaction') {
            Modules::run('database/update', 'app_module_setting', ['params' => 'account_invoice_transaction'], ['value' => json_encode($data)]);
        }
        if ($code == 'cost-transaction') {
            Modules::run('database/update', 'app_module_setting', ['params' => 'account_cost_transaction'], ['value' => json_encode($data)]);
        }
        if ($code == 'cost-other-transaction') {
            Modules::run('database/update', 'app_module_setting', ['params' => 'account_other_cost_transaction'], ['value' => json_encode($data)]);
        }

        if ($code == 'payment-credit') {
            Modules::run('database/update', 'app_module_setting', ['params' => 'account_payment_credit'], ['value' => json_encode($data)]);
        }
        if ($code == 'payment-debt') {
            Modules::run('database/update', 'app_module_setting', ['params' => 'account_payment_debt'], ['value' => json_encode($data)]);
        }
        if ($code == 'prive') {
            Modules::run('database/update', 'app_module_setting', ['params' => 'account_prive'], ['value' => json_encode($data)]);
        }

        echo json_encode(['status' => TRUE]);
    }
}
