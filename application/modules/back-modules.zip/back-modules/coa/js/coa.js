var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';


var table_activa_1;
var table_activa_2;
var table_capital;
var table_advatage;
var table_cost;
var table_hpp;
var table_obligate;
var table_period;
var id_use;
var id_type_account;
var grand_total_activa;
var grand_total_obligate;

$(document).ready(function () {
    // datatable()

    table_activa_1= $('.table_activa_1').DataTable({
        "ajax": {
            "url": url_controller+"/list_activa_1"+'/?token='+_token_user,
            "type": "POST"
        }
    });
    table_activa_2= $('.table_activa_2').DataTable({
        "ajax": {
            "url": url_controller+"/list_activa_2"+'/?token='+_token_user,
            "type": "POST"
        }
    });

    table_capital= $('.table_capital').DataTable({
        "ajax": {
            "url": url_controller+"/list_capital"+'/?token='+_token_user,
            "type": "POST"
        }
    });

    table_advatage= $('.table_advatage').DataTable({
        "ajax": {
            "url": url_controller+"/list_advatage"+'/?token='+_token_user,
            "type": "POST"
        }
    });

    table_cost= $('.table_cost').DataTable({
        "ajax": {
            "url": url_controller+"/list_cost"+'/?token='+_token_user,
            "type": "POST"
        }
    });

    table_hpp = $('.table_hpp').DataTable({
        "ajax": {
            "url": url_controller+"/list_hpp"+'/?token='+_token_user,
            "type": "POST"
        }
    });

    table_obligate = $('.table_obligate').DataTable({
        "ajax": {
            "url": url_controller+"/list_obligate"+'/?token='+_token_user,
            "type": "POST"
        }
    });

    get_saldo_view();
    get_setting_view();

});




function reload_table(){
    table_activa_1.ajax.reload(null, false); //reload datatable ajax
    table_activa_2.ajax.reload(null, false); //reload datatable ajax
    table_advatage.ajax.reload(null, false); //reload datatable ajax
    table_capital.ajax.reload(null, false); //reload datatable ajax
    table_cost.ajax.reload(null, false); //reload datatable ajax
    table_hpp.ajax.reload(null, false); //reload datatable ajax
    table_obligate.ajax.reload(null, false); //reload datatable ajax
}
function reload_table_period(){
    table_period.ajax.reload(null, false); //reload datatable ajax
}



$('.btn_add').click(function () {
    save_method = 'add';
    var name = $(this).data('name');
    var id_account = $(this).data('account');
    $('.html_respon_bank').html('');
    var html_bank = '';
    if (id_account == 1) {
        var html_bank = ' <label>&nbsp;</label><br><input name="is_bank" class="is_bank" value="1" data-toggle="toggle" data-size="medium" data-onstyle="success" type="checkbox"> KAS / BANK';
        $('.html_respon_bank').html(html_bank);
        // $('.is_bank').bootstrapToggle();
    }

    var text = id_account + ' - ' + name;
    id_use = id_account;
    get_list_account(id_account);
    // $('.btn_save');
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    $('.form-input')[0].reset();
    $('.modal-title').text('TAMBAH DATA');
    $('#modal-form').modal('show');
    $('.text-account').text(text);
});


function get_list_account(type) {
    $.ajax({
        url: url_controller + '/get_list_account'+'/?token='+_token_user,
        type: "POST",
        data: { 'type': type },
        dataType: "JSON",
        success: function (data) {
            $('[name="id_parent"]').html(data.html_respon);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_edit');
            alert_error('something wrong');
        }
    });//end ajax
}





$('.btn_save').click(function (e) {
    e.preventDefault();
    
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    var url;
    if(save_method=='add'){
        url = '/save';
        formData.append('type_account', id_use);
	   }else{
           url = '/update';
        formData.append('id', id_use);
        formData.append('type_account', id_type_account);
	   }
    $.ajax({
        url: url_controller + url+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                alert_success('Data Berhasil Disimpan');
                reload_table();
                $('#modal-form').modal('hide');
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-danger');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            $('.btn_save');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_save');
            alert_error('something wrong');
        }
    });//end ajax
});


$(document).on('click', '.btn_edit', function () {
    
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    $('.btn_save');
    var id = $(this).data('id');
    $('.modal-title').text('UPDATE DATA');
    $('.form-input')[0].reset();
    save_method = 'update';
    $.ajax({
        url: url_controller + '/get_edit'+'/?token='+_token_user,
        type: "POST",
        data: { 'id': id },
        dataType: "JSON",
        success: function (data) {
            id_use = data.id;
            id_type_account = data.type_account;
            $('[name="code"]').val(data.code_current);
            $('[name="name"]').val(data.name);
            $('.text-account').text(data.text_name);
            $('[name="id_parent"]').html(data.html_option);
            $('.html_respon_bank').html(data.html_bank);
            $('#modal-form').modal('show');
            $('.btn_edit');
            $('.is_bank').bootstrapToggle();    
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_edit');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_remove', function () {
    var id = $(this).data('id');
    $.ajax({
        url: url_controller + '/delete'+'/?token='+_token_user,
        type: "POST",
        data: { 'id': id },
        dataType: "JSON",
        success: function (data) {
            $('#modal-form').modal('hide');
            alert_success('data berhasil dihapus');
            reload_table();
            $('.btn_remove');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_remove');
            alert_error('something wrong');
        }
    });//end ajax
});


$(document).on('click', '.btn_edit_account', function (e) { 

    
    var name = $(this).data('name');
    $('.modal-title').text('Update Data Akun');
    $.ajax({
        url: url_controller + '/get_form_update_setting'+'/?token='+_token_user,
        type: "POST",
        data: { 'name': name },
        dataType: "JSON",
        success: function (data) {
            $('#modal-update').modal('show');
            $('.html_respon').html(data.html_respon);
            $('.btn_edit_account');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_edit_account');
            alert_error('something wrong');
        }
    });//end ajax
});



// $('.btn_edit_account').click(function () {
//     
//     var name = $(this).data('name');
//     $.ajax({
//         url: url_controller + '/get_form_update_setting',
//         type: "POST",
//         data: { 'name': name },
//         dataType: "JSON",
//         success: function (data) {
//             $('#modal-update').modal('show');
//             $('.html_respon').html(data.html_respon);
//             $('.btn_edit_account');
//         },
//         error: function (jqXHR, textStatus, errorThrown) {
//             $('.btn_edit_account');
//             alert_error('something wrong');
//         }
//     });//end ajax
// });

$(document).on('click', '.btn_update_account', function (e) {
    e.preventDefault();
    
    var caption = $(this).data('caption');
    var update_name = $(this).data('name');
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-input-update')[0]);
    formData.append('update_name', update_name);
    $.ajax({
        url: url_controller + '/update_setting'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            $('.btn_update_account');
            if (data.status) {
                alert_success('Data Berhasil Disimpan');
                // reload_table();
                $('#modal-update').modal('hide');
                get_setting_view();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-danger');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_update_account');
            alert_error('something wrong');
        }
    });//end ajax
});

function get_setting_view() {
    $.ajax({
        url: url_controller + '/get_setting_view'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        success: function (data) {
            $('.html_respon_setting').html(data.html_respon);
             table_period = $('#table_period').DataTable({
                    "ajax": {
                        "url": url_controller+"/list_period"+'/?token='+_token_user,
                        "type": "POST"
                    }
                });
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert_error('something wrong');
        }
    });//end ajax
}


function get_saldo_view() {
    $.ajax({
        url: url_controller + '/get_saldo_view'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        success: function (data) {
            $('.html_respon_saldo').html(data.html_respon);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_edit');
            alert_error('something wrong');
        }
    });//end ajax
}

$(document).on('click', '.btn_update_capital', function () {
    var update_name = $(this).data('updatename');
    
    $.ajax({
        url: url_controller + '/get_form_update_modal'+'/?token='+_token_user,
        type: "POST",
        data:{'update_name':update_name},
        dataType: "JSON",
        success: function (data) {
            $('#modal-update-capital').modal('show');
            $('.html_respon_modal').html(data.html_respon);
            $('.btn_update_capital');
            count_price();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_update_capital');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('keyup', '.account', function () {
    count_price();
});

function count_price() {
    var grand_total_account_1 = 0;
    $(".account_1").each(function () {
        value_define = $(this).val().length ? $(this).val() : '0';
        value_define = value_define.charAt(0) == 0 ? '0' : value_define; 
        var value_current = parseInt(delete_dot_value(value_define));
        grand_total_account_1 += value_current;
        grand_total_activa = grand_total_account_1;
        $('.text_account_1').text('Rp. ' + money_function(String(grand_total_account_1)));
    });

    var grand_total_account_2 = 0;
    $(".account_2").each(function () {
        value_define = $(this).val().length ? $(this).val() : '0';
        var value_current = parseInt(delete_dot_value(value_define));
        grand_total_account_2 += value_current;
        grand_total_obligate = grand_total_account_2;
        $('.text_account_2').text('Rp. ' + money_function(String(grand_total_account_2)));
    });
}

$(document).on('click', '.btn_save_update_modal', function (e) {
    e.preventDefault();
    if (grand_total_obligate == grand_total_activa) {

        swal({
            title: 'SALDO AKAN DISIMPAN?',
            text: "pastikan saldo sudah terisi dengan benar",
            type: 'warning',
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ya , Lanjutkan",
            cancelButtonText: "Batal",
            closeOnConfirm: true,
            closeOnCancel: true
        },
        function(isConfirm) {
            if (isConfirm) {
                showLoading();
                var formData = new FormData($('.form-update-saldo')[0]);
                // formData.append('update_name', update_name);
                $.ajax({
                    url: url_controller + '/save_saldo'+'/?token='+_token_user,
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: "JSON",
                    success: function (data) {
                        $('.btn_save_update_modal');
                        if (data.status) {
                            hideLoading();
                            alert_success('Data Berhasil Disimpan');
                            // reload_table();
                            $('#modal-update-capital').modal('hide');
                            get_saldo_view();
                        } else {
                            for (var i = 0; i < data.inputerror.length; i++) {
                                $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-danger');
                                $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                            }
                        }
                        
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        hideLoading();
                        alert_error('something wrong');
                    }
                });//end ajax
            }
        });
    
    } else {
        
        swal(
            'MAAF TOTAL TIDAK SAMA',
            'total aktiva harus sama dengan total modal dan kewajiban',
            'warning'
        );
    }

    
});


$(document).on('click', '.btn_update_base_periode', function (e) {
    e.preventDefault();
    swal({
        title: 'SALDO AKAN DIUPDATE?',
        text: "saldo awal akan disesuaikan dengan saldo akhir tahun pada periode sebelumnya.",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            //defined form
            
            // formData.append('update_name', update_name);
            $.ajax({
                url: url_controller + '/update_saldo_base_periode'+'/?token='+_token_user,
                type: "POST",
                dataType: "JSON",
                success: function (data) {
                    $('.btn_update_base_periode');
                    if (data.status) {
                        alert_success('Data Berhasil Disimpan');
                        // reload_table();
                        // $('#modal-update-capital').modal('hide');
                        get_saldo_view();
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-danger');
                            $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                        }
                    }
                        
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $('.btn_update_base_periode');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    });
    
});






//-------------period ------------------------------
$(document).on('click', '.btn_add_period', function (e) { 
    save_method = 'add';
    
    var name = $(this).data('name');
    $('.modal-title').text('Tambah Data Periode');
    $.ajax({
        url: url_controller + '/get_form_add_period'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        success: function (data) {
            $('#modal-update').modal('show');
            $('.html_respon').html(data.html_respon);
            $('.btn_add_period');

            $('.datepicker_form').datepicker({
                autoclose: true,
                format: 'dd-mm-yyyy'
            });
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_add_period');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_save_period', function (e) {
    e.preventDefault();
    
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-input-period')[0]);
    var url = '';
    if (save_method == 'add') {
        url = 'save_period';
    } else {
        url = 'update_period';
    }

    $.ajax({
        url: url_controller + '/'+url+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            $('.btn_save_period');
            if (data.status) {
                alert_success('Data Berhasil Disimpan');
                reload_table_period()
                $('#modal-update').modal('hide');
                // get_setting_view();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-danger');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_save_period');
            alert_error('something wrong');
        }
    });//end ajax
});
$(document).on('click', '.btn_edit_period', function (e) { 
    save_method = 'edit';
    
    var id = $(this).data('id');
    $('.modal-title').text('Update Data Periode');
    $.ajax({
        url: url_controller + '/get_form_update_period'+'/?token='+_token_user,
        type: "POST",
        data: { 'id': id },
        dataType: "JSON",
        success: function (data) {
            $('#modal-update').modal('show');
            $('.html_respon').html(data.html_respon);
            $('.btn_edit_period');

            $('.datepicker_form').datepicker({
                autoclose: true,
                format: 'dd-mm-yyyy'
            });
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_edit_period');
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('change', '.datepicker_form', function () {
    $(this).val();
});



$(document).on('click', '.btn_remove_period', function () {
    var id = $(this).data('id');
    swal({
        title: 'Apakah anda yakin?',
        text: "data ini akan dihapus",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,hapus data',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: url_controller + '/delete_period'+'/?token='+_token_user,
                type: "POST",
                data: { 'id': id },
                dataType: "JSON",
                success: function (data) {
                    if (data.status) {
                        reload_table_period();
                        alert_success('data berhasil dihapus');
                    } else {
                        swal(
                            'DATA TIDAK BOLEH DIHAPUS',
                            'data ini telah digunakan dan tidak boleh dihapus.',
                            'warning'
                        );
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $('.btn_remove_period');
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});


$(document).on('click', '.update_account_setting', function () {
    showLoading();
    code = $(this).data('code');
    $.ajax({
        url: url_controller + '/get_form_update_setting_account'+'/?token='+_token_user,
        type: "POST",
        data: { 'code': code },
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            $('#modal-update').modal('show');
            $('.html_respon').html(data.html_respon);
            $(document).find('.form-input-update-setting').find('select').chosen();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_save_account_setting', function (e) {
    e.preventDefault();
    showLoading();
    code = $(this).data('code');
    $('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-input-update-setting')[0]);
    formData.append('code', code);
    $.ajax({
        url: url_controller + '/update_setting_account'+'/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                alert_success('Data Berhasil Disimpan');
                // reload_table();
                $('#modal-update').modal('hide');
                get_setting_view();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});



$(document).on('keyup', '.money_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    var money = money_function(qty, '');
    $(this).val(money);
})

function money_function(angka, prefix) {
    
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    return rupiah;
}


$(document).on("click", ".btn_update_status_period", function () {
    var id = $(this).data('id');
    if ($(this).hasClass('on')) {
        alert_error('Tidak boleh di nonaktifkan');
        return false;
    }
    $(this).toggleClass('on');
    $.ajax({
        url: url_controller+'/update_status_period'+'/?token='+_token_user,
        type: "POST",
        data: {'id':id},
        dataType :"JSON",
        success: function (data) {
            $('.btn_update_status_period');
            alert_success('status berhasil diupdate');
            reload_table_period();
            get_saldo_view();
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            $('.btn_update_status_period');
            alert_error('something wrong');
        }
    });//end ajax
});


function delete_dot_value(value) {
    var array_value = value.split('.');
    var count_array = array_value.length;
    payment_value = value;
    for (var i = 0; i < count_array; i++) {
        payment_value = payment_value.replace('.', '');
    };
    return payment_value;
}

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
});


