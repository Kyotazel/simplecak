<style>
    #datepickers-container {
        z-index: 100000 !important;
    }
</style>
<div class="card">
    <div class="card-body">

        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab" aria-selected="true">
                    <i class="fas fa-shopping-bag mr-1"></i> <span class="d-none d-md-inline-block">AKTIVA LANCAR</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab2" role="tab" aria-selected="false">
                    <i class="fas fa-building mr-1"></i> <span class="d-none d-md-inline-block">AKTIVA TETAP</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab3" role="tab" aria-selected="false">
                    <i class="fas fa-money-bill mr-1"></i> <span class="d-none d-md-inline-block">MODAL / EKUITAS</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab4" role="tab" aria-selected="false">
                    <i class="fas fa-chart-bar mr-1"></i> <span class="d-none d-md-inline-block">PENDAPATAN</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab5" role="tab" aria-selected="false">
                    <i class="fas fa-minus-square mr-1"></i> <span class="d-none d-md-inline-block">BIAYA</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab6" role="tab" aria-selected="false">
                    <i class="fas fa-shopping-cart mr-1"></i> <span class="d-none d-md-inline-block">HARGA POKOK PENJUALAN (HPP)</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab7" role="tab" aria-selected="false">
                    <i class="fas fa-file mr-1"></i> <span class="d-none d-md-inline-block">KEWAJIBAN</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab8" role="tab" aria-selected="false">
                    <i class="fas fa-cog mr-1"></i> <span class="d-none d-md-inline-block">PENGATURAN</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab9" role="tab" aria-selected="false">
                    <i class="fas fa-cog mr-1"></i> <span class="d-none d-md-inline-block">SALDO AWAL AKUN</span>
                </a>
            </li>

        </ul>

        <!-- Tab panes -->
        <div class="tab-content p-3">
            <div class="tab-pane active" id="tab1" role="tabpanel">
                <div class="row">
                    <div class="col-md-6 pull-left">
                        <section class="content-header no-padding no-margin">
                            <h4><i class=" fa fa-shopping-bag"></i> 01 - AKTIVA LANCAR </h4>
                        </section>
                    </div>
                    <div class="col-md-6 pull-right text-right">
                        <small>(*klik untuk tambah data)</small>
                        <a href="javascript:void(0)" data-account="1" data-name="AKTIVA LANCAR" class="btn btn-primary btn-rounded  mb-2 btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                    </div>
                </div>
                <span class="clearfix"></span>
                <div class="table-responsive mt-10">
                    <table class="table table-hover table_activa_1" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane " id="tab2" role="tabpanel">
                <div class="row">
                    <div class="col-md-6 pull-left">
                        <section class="content-header no-padding no-margin">
                            <h4><i class=" fa fa-building"></i> 02 - AKTIVA TETAP </h4>
                        </section>
                    </div>
                    <div class="col-md-6 pull-right text-right">
                        <small>(*klik untuk tambah data)</small>
                        <a href="javascript:void(0)" data-account="2" data-name="AKTIVA TETAP" class="btn btn-primary btn-rounded  mb-2 btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                    </div>
                </div>
                <span class="clearfix"></span>
                <div class="table-responsive mt-10">
                    <table class="table table-hover table_activa_2" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane " id="tab3" role="tabpanel">
                <div class="row">
                    <div class="col-md-6 pull-left">
                        <section class="content-header no-padding no-margin">
                            <h4><i class="fas fa-money-bill"></i> 03 - Modal / Ekuitas </h4>
                        </section>
                    </div>
                    <div class="col-md-6 pull-right text-right">
                        <small>(*klik untuk tambah data)</small>
                        <a href="javascript:void(0)" data-account="3" data-name="MODAL" class="btn btn-primary btn-rounded  mb-2 btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                    </div>
                </div>
                <span class="clearfix"></span>
                <div class="table-responsive mt-10">
                    <table class="table table-hover table_capital" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane " id="tab4" role="tabpanel">
                <div class="row">
                    <div class="col-md-6 pull-left">
                        <section class="content-header no-padding no-margin">
                            <h4><i class="fas fa-chart-bar"></i> 04 - PENDAPATAN </h4>
                        </section>
                    </div>
                    <div class="col-md-6 pull-right text-right">
                        <small>(*klik untuk tambah data)</small>
                        <a href="javascript:void(0)" data-account="4" data-name="PENDAPATAN" class="btn btn-primary btn-rounded  mb-2 btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                    </div>
                </div>
                <span class="clearfix"></span>
                <div class="table-responsive mt-10">
                    <table class="table table-hover table_advatage" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane " id="tab5" role="tabpanel">
                <div class="row">
                    <div class="col-md-6 pull-left">
                        <section class="content-header no-padding no-margin">
                            <h4><i class="fas fa-minus-square"></i> 05 - BIAYA </h4>
                        </section>
                    </div>
                    <div class="col-md-6 pull-right text-right">
                        <small>(*klik untuk tambah data)</small>
                        <a href="javascript:void(0)" data-account="5" data-name="BIAYA" class="btn btn-primary btn-rounded  mb-2 btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                    </div>
                </div>
                <span class="clearfix"></span>
                <div class="table-responsive mt-10">
                    <table class="table table-hover table_cost" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane " id="tab6" role="tabpanel">
                <div class="row">
                    <div class="col-md-6 pull-left">
                        <section class="content-header no-padding no-margin">
                            <h4><i class=" fa fa-shopping-cart"></i> 06 - HARGA POKOK PENJUALAN (HPP) </h4>
                        </section>
                    </div>
                    <div class="col-md-6 pull-right text-right">
                        <small>(*klik untuk tambah data)</small>
                        <a href="javascript:void(0)" data-account="6" data-name="HARGA POKOK PENJUALAN (HPP)" class="btn btn-primary btn-rounded  mb-2 btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                    </div>
                </div>
                <span class="clearfix"></span>
                <div class="table-responsive mt-10">
                    <table class="table table-hover table_hpp" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane " id="tab7" role="tabpanel">
                <div class="row">
                    <div class="col-md-6 pull-left">
                        <section class="content-header no-padding no-margin">
                            <h4><i class=" fa fa-file"></i> 07 - KEWAJIBAN </h4>
                        </section>
                    </div>
                    <div class="col-md-6 pull-right text-right">
                        <small>(*klik untuk tambah data)</small>
                        <a href="javascript:void(0)" data-account="7" data-name="KEWAJIBAN" class="btn btn-primary btn-rounded  mb-2 btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                    </div>
                </div>
                <span class="clearfix"></span>
                <div class="table-responsive mt-10">
                    <table class="table table-hover table_obligate" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Tanggal input</th>
                                <th>Petugas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="tab8" role="tabpanel">
                <div class="html_respon_setting"></div>
            </div>
            <div class="tab-pane " id="tab9" role="tabpanel">
                <div class="html_respon_saldo"></div>
            </div>

        </div>

    </div>
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content border-radius-5 shadow">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <form class="form-input">
                        <div class="row">
                            <div class="col-md-12 border p-2 border-radius-5 text-center mb-3">
                                <h4 class="text-bold text-green text-account"></h4>
                            </div>
                            <div class="col-md-8 form-group">
                                <label for="">SUB AKUN DARI :</label>
                                <select name="id_parent" class="form-control">
                                    <option value="">TIDAK ADA</option>
                                </select>
                                <span class="help-block text-danger"></span>
                            </div>
                            <div class="col-md-4 html_respon_bank"></div>
                            <span class="clearfix"></span>

                            <div class="col-md-4 form-group">
                                <label for="">Kode Rekening</label>
                                <input type="text" name="code" class="form-control">
                                <span class="help-block text-danger"></span>
                            </div>
                            <div class="col-md-8 form-group">
                                <label for="">Nama Rekening</label>
                                <input type="text" name="name" class="form-control">
                                <span class="help-block text-danger"></span>
                            </div>
                            <div class="col-md-12 form-group text-right">
                                <label for="">&nbsp;</label><br>
                                <button type="submit" class="btn btn-success btn_save">Simpan Data</button>
                                <span class="help-block text-danger"></span>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>



<div class="modal fade in" id="modal-update">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content border-radius-5 shadow">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal fade in" id="modal-update-capital" data-backdrop="static">
    <div class="modal-dialog" style="max-width:90%;">
        <div class="modal-content border-radius-5 shadow">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>