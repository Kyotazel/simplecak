<style>
    tr.odd td:first-child,
    tr.even td:first-child {
        padding-left: 4em;
    }
</style>
<div class="main-content">

    <div class="page-content">

        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="page-title mb-1"><?php echo $title ?></h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active"><?php echo $subtitle ?></li>
                        </ol>
                    </div>
                    <div class="col-md-4">
                        <div class="float-right d-md-block">
                            <div class="dropdown">
                                <button class="btn btn-light btn-rounded dropdown-toggle" type="button" onclick="modal_show()">
                                    <i class="mdi mdi-plus-thick mr-1"></i> Tambah Data
                                </button>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- end page title end breadcrumb -->

        <div class="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="header-title mb-4">View Data</h5>
                                <br>
                                <div class="table-responsive">
                                    <table id="data-table" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <th style="width: 10%;">No</th>
                                            <th>Type AKun</th>
                                            <th>Group AKun</th>
                                            <th>Kode AKun</th>
                                            <th>AKun</th>
                                            <th style="width: 15%;"></th>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->


            </div> <!-- container-fluid -->
        </div>
        <!-- end page-content-wrapper -->
    </div>
    <!-- End Page-content -->


    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    2021 © GOEXPERT.
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div>
    </footer>
</div>
<!-- end main content-->

<div class="modal fade" tabindex="-1" id="modal-data">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form id="form-data">
                    <input type="hidden" name="id" id="id" />
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Type Akun</label>
                                <select class="form-control" name="type" id="type" onChange="getGroup()">
                                </select>
                                <ul class="parsley-errors-list filled" aria-hidden="false"></ul>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Group Akun</label>
                                <select class="form-control" name="group" id="group"></select>
                                <ul class="parsley-errors-list filled" aria-hidden="false"></ul>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label>Kode Akun</label>
                                <input type="text" class="form-control" name="code" id="code"></input>
                                <ul class="parsley-errors-list filled" aria-hidden="false"></ul>
                            </div>
                        </div>
                        <div class="col-8">
                            <div class="form-group">
                                <label>Akun</label>
                                <input type="text" class="form-control" name="akun" id="akun"></input>
                                <ul class="parsley-errors-list filled" aria-hidden="false"></ul>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" onclick="save()"><i class="fas fa-save"></i> Simpan Data</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" id="modal-akun">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form id="form-akun">
                    <input type="hidden" name="id_akun" id="id_akun" />
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Type Akun</label>
                                <input type="text" class="form-control" name="type_akun" id="type_akun">
                                <ul class="parsley-errors-list filled" aria-hidden="false"></ul>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" onclick="save_akun()"><i class="fas fa-save"></i> Update Data</button>
            </div>
        </div>
    </div>
</div>