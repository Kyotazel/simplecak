<?php
$list_account = $this->db->where(['params' => 'list_account'])->get('app_module_setting')->row()->value;
$array_main_account = json_decode($list_account, TRUE);

$get_all_account = $this->db->where(['isDeleted=' => 'N'])->order_by('code')->get('tb_book_account')->result();
$array_account = [];
foreach ($get_all_account as $item_account) {
    $array_account[$item_account->id] = $item_account->type_account . '-' . $item_account->code . ' ' . $item_account->name;
}

//account transaction
$account_invoice = $this->db->where(['params' => 'account_invoice_transaction'])->get('app_module_setting')->row()->value;
$account_cost_transaction = $this->db->where(['params' => 'account_cost_transaction'])->get('app_module_setting')->row()->value;
$account_other_cost_transaction = $this->db->where(['params' => 'account_other_cost_transaction'])->get('app_module_setting')->row()->value;

$account_payment_debt = $this->db->where(['params' => 'account_payment_debt'])->get('app_module_setting')->row()->value;
$account_payment_credit = $this->db->where(['params' => 'account_payment_credit'])->get('app_module_setting')->row()->value;
$account_prive = $this->db->where(['params' => 'account_prive'])->get('app_module_setting')->row()->value;

$array_account_invoice = json_decode($account_invoice);
$array_account_cost_transaction = json_decode($account_cost_transaction);
$array_account_other_cost_transaction = json_decode($account_other_cost_transaction);

$array_account_payment_debt = json_decode($account_payment_debt);
$array_account_payment_credit = json_decode($account_payment_credit);
$array_account_prive = json_decode($account_prive);




?>
<div class="card box-solid">
    <div class="card-body">

        <div class="row text-right">
            <div class="col-md-6 text-left">
                <div class="content-header no-padding no-margin">
                    <h4> <i class=" fa fa-calendar"></i> Periode Akuntansi </h4>
                </div>
            </div>
            <div class="col-md-6 mb-10">
                <small>(* klik untuk update saldo)</small>
                <a href="javascript:void(0)" class="btn btn-primary btn-rounded  btn_add_period"><i class="fa fa-plus-circle"></i> Tambah Data Periode</a>
            </div>
        </div>
        <span class="clearfix"></span>
        <div class="table-responsive col-md-12 mt-3">
            <table class="table" id="table_period" width="100%">
                <thead>
                    <tr>
                        <th style="width: 80px;">No</th>
                        <th>Nama Periode</th>
                        <th>Tanggal Periode</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <hr class="col-md-12">
        <div class="row">
            <div class="col-md-12">
                <h4 class="text-bold text-uppercase text-left">Pengaturan Pemakaian Akun :</h4>
                <div class="row">
                    <div class="col-12 p-3 row shadow-3 rounded-10 mb-2">
                        <h3 class="card-title col-12 text-left"><i class="fas fa-file"></i> AKUN TRANSAKSI INVOICE</h3>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_invoice->akun_kas]) ? $array_account[$array_account_invoice->akun_kas] : '-'; ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-capitalize">akun pendapatan</td>
                                    <td>:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_invoice->akun_pendapatan]) ? $array_account[$array_account_invoice->akun_pendapatan] : '-'; ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-capitalize">akun kas piutang</td>
                                    <td>:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_invoice->akun_kas_piutang]) ? $array_account[$array_account_invoice->akun_kas_piutang] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas pajak</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_invoice->akun_kas_pajak]) ? $array_account[$array_account_invoice->akun_kas_pajak] : '-'; ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-capitalize">akun kewajiban pajak</td>
                                    <td>:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_invoice->akun_kewajiban_pajak]) ? $array_account[$array_account_invoice->akun_kewajiban_pajak] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <a href="javascript:void(0)" class="update_account_setting btn btn-warning-gradient btn-rounded " data-code="invoice-transaction"><i class="fas fa-pen"></i> Update</a>
                        </div>
                    </div>
                    <div class="col-12 p-3 row shadow-3 rounded-10 mb-2">
                        <h3 class="card-title col-12 text-left"><i class="fas fa-file"></i> AKUN PEMBAYARAN PIUTANG</h3>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas piutang</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_payment_credit->akun_kas_piutang]) ? $array_account[$array_account_payment_credit->akun_kas_piutang] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun Kas</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_payment_credit->akun_kas]) ? $array_account[$array_account_payment_credit->akun_kas] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <a href="javascript:void(0)" class="update_account_setting btn btn-warning-gradient btn-rounded " data-code="payment-credit"><i class="fas fa-pen"></i> Update</a>
                        </div>
                    </div>
                    <div class="col-12 p-3 row shadow-3 rounded-10 mb-2">
                        <h3 class="card-title col-12 text-left"><i class="fas fa-file"></i> AKUN PEMBAYARAN HUTANG</h3>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas Hutang</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_payment_debt->akun_kas_hutang]) ? $array_account[$array_account_payment_debt->akun_kas_hutang] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kewajiban Hutang</td>
                                    <td s tyle="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_payment_debt->akun_kewajiban_hutang]) ? $array_account[$array_account_payment_debt->akun_kewajiban_hutang] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <a href="javascript:void(0)" class="update_account_setting btn btn-warning-gradient btn-rounded " data-code="payment-debt"><i class="fas fa-pen"></i> Update</a>
                        </div>
                    </div>
                    <div class="col-12 p-3 row shadow-3 rounded-10 mb-2">
                        <h3 class="card-title col-12 text-left"><i class="fas fa-file"></i> AKUN TRANSAKSI OPERASIONAL</h3>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_cost_transaction->akun_kas]) ? $array_account[$array_account_cost_transaction->akun_kas] : '-'; ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-capitalize">akun biaya</td>
                                    <td>:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_cost_transaction->akun_biaya]) ? $array_account[$array_account_cost_transaction->akun_biaya] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas Hutang</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_cost_transaction->akun_kas_hutang]) ? $array_account[$array_account_cost_transaction->akun_kas_hutang] : '-'; ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-capitalize">akun kewajiban hutang</td>
                                    <td>:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_cost_transaction->akun_kewajiban_hutang]) ? $array_account[$array_account_cost_transaction->akun_kewajiban_hutang] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <a href="javascript:void(0)" class="update_account_setting btn btn-warning-gradient btn-rounded " data-code="cost-transaction"><i class="fas fa-pen"></i> Update</a>
                        </div>
                    </div>
                    <div class="col-12 p-3 row shadow-3 rounded-10 mb-2">
                        <h3 class="card-title col-12 text-left"><i class="fas fa-file"></i> AKUN TRANSAKSI PEMBIAYAAN LAINNYA</h3>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_other_cost_transaction->akun_kas]) ? $array_account[$array_account_other_cost_transaction->akun_kas] : '-'; ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-capitalize">akun biaya</td>
                                    <td>:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_other_cost_transaction->akun_biaya]) ? $array_account[$array_account_other_cost_transaction->akun_biaya] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun kas Hutang</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_other_cost_transaction->akun_kas_hutang]) ? $array_account[$array_account_other_cost_transaction->akun_kas_hutang] : '-'; ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-capitalize">akun kewajiban Hutang</td>
                                    <td>:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_other_cost_transaction->akun_kewajiban_hutang]) ? $array_account[$array_account_other_cost_transaction->akun_kewajiban_hutang] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <a href="javascript:void(0)" class="update_account_setting btn btn-warning-gradient btn-rounded " data-code="cost-other-transaction"><i class="fas fa-pen"></i> Update</a>
                        </div>
                    </div>
                    <div class="col-12 p-3 row shadow-3 rounded-10 mb-2">
                        <h3 class="card-title col-12 text-left"><i class="fas fa-file"></i> AKUN LAINNYA</h3>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">akun Prive</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_prive->akun_prive]) ? $array_account[$array_account_prive->akun_prive] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-5">
                            <table class="" style="text-align: left;">
                                <tr>
                                    <td style="width: 200px;" class="text-capitalize">Akun Modal Atas Pendapatan</td>
                                    <td style="width: 10px;">:</td>
                                    <td>
                                        <b><?= isset($array_account[$array_account_prive->akun_revenue]) ? $array_account[$array_account_prive->akun_revenue] : '-'; ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-2">
                            <a href="javascript:void(0)" class="update_account_setting btn btn-warning-gradient btn-rounded " data-code="prive"><i class="fas fa-pen"></i> Update</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>