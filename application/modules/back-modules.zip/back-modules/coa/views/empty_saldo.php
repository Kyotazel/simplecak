<div class="card box-solid">
    <div class="card-body">
        <div class="col-md-12 text-center" style="padding: 20px;">
            <h2>TIDAK ADA PERIODE AKTIF</h2>
        </div>
    </div>
</div>