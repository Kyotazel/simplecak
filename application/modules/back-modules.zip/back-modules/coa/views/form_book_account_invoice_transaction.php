<?php
$account_invoice = $this->db->where(['params' => 'account_invoice_transaction'])->get('app_module_setting')->row()->value;
$array_account_invoice = json_decode($account_invoice);
// $get_data = $this->db->where(['field' => $update_name])->get('tb_setting')->row()->value;
$get_data_activa = $this->db->where(['type_account' => 1, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();
$get_data_obligate = $this->db->where(['type_account' => 7, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();
$get_data_income = $this->db->where(['type_account' => 4, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();
?>
<form class="form-input-update-setting">
    <h4 class="mb-10 tex-center"><i class="fa fa-tv"></i> AKUN TRANSAKSI INVOICE</h4>
    <span class="clearfix"></span>
    <div class="row">
        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun kas</label>
            <select name="data[akun_kas]" id="" class="form-control">
                <?php
                foreach ($get_data_activa as $item) {
                    $selected = $item->id == $array_account_invoice->akun_kas ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>
        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun pendapatan</label>
            <select name="data[akun_pendapatan]" id="" class="form-control">
                <?php
                foreach ($get_data_income as $item) {
                    $selected = $item->id == $array_account_invoice->akun_pendapatan ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>

        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun kas pajak</label>
            <select name="data[akun_kas_pajak]" id="" class="form-control">
                <?php
                foreach ($get_data_activa as $item) {
                    $selected = $item->id == $array_account_invoice->akun_kas_pajak ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>
        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun kewajiban pajak</label>
            <select name="data[akun_kewajiban_pajak]" id="" class="form-control">
                <?php
                foreach ($get_data_obligate as $item) {
                    $selected = $item->id == $array_account_invoice->akun_kewajiban_pajak ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>
        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun kas piutang</label>
            <select name="data[akun_kas_piutang]" id="" class="form-control">
                <?php
                foreach ($get_data_activa as $item) {
                    $selected = $item->id == $array_account_invoice->akun_kas_piutang ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>

        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-success btn_save_account_setting" data-code="<?= $code; ?>">Simpan Data</button>
        </div>
    </div>
</form>