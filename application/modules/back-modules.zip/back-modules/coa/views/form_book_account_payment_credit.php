<?php
$account_payment_credit = $this->db->where(['params' => 'account_payment_credit'])->get('app_module_setting')->row()->value;
$array_account_payment_credit = json_decode($account_payment_credit);

$get_data_activa = $this->db->where(['type_account' => 1, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();


?>

<form class="form-input-update-setting">
    <h4 class="mb-10 tex-center"><i class="fa fa-tv"></i> AKUN PEMBAYARAN PIUTANG</h4>
    <span class="clearfix"></span>
    <div class="col-md-12 form-group">
        <label for="">akun kas piutang </label>
        <select name="data[akun_kas_piutang]" id="" class="form-control">
            <?php
            foreach ($get_data_activa as $item_activa) {
                $selected = $item_activa->id == $array_account_payment_credit->akun_kas_piutang ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_activa->id . '">' . $item_activa->code . ' ' . $item_activa->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-12 form-group">
        <label for="">Akun Kas</label>
        <select name="data[akun_kas]" id="" class="form-control">
            <?php
            foreach ($get_data_activa as $item_activa) {
                $selected = $item_activa->id == $array_account_payment_credit->akun_kas ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_activa->id . '">' . $item_activa->code . ' ' . $item_activa->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-12 text-right">
        <button type="submit" class="btn btn-success btn_save_account_setting" data-code="<?= $code; ?>">Simpan Data</button>
    </div>
</form>