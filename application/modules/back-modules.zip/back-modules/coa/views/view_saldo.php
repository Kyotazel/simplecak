<?php
$get_start_date = $this->db->where(['params' => 'start_period'])->get('app_module_setting')->row()->value;
$explode_date = explode('-', $get_start_date);

$html_update_base_period = '';
if ($data_period->id_parent > 0) {
    $html_update_base_period = '
        &nbsp; || &nbsp;
        <a href="javascript:void(0)" data-updatename="obligate" class="btn btn-success btn_update_base_periode"><i class="fa fa-refresh"></i> UPDATE DARI PERIODE SEBELUMNYA</a>
    ';
}

?>
<div class="card box-solid">
    <div class="card-body">
        <div class="row text-right">
            <div class="col-md-6 text-left">
                <div class="content-header no-padding no-margin">
                    <h4> <i class=" fa fa-calendar"></i> PERIODE AKTIF <span class="badge badge-primary"> : <?= $data_period->name;  ?></span> </h4>
                </div>
            </div>
            <div class="col-md-6 pull-right mb-10">
                <small>(* klik untuk update saldo)</small>
                <a href="javascript:void(0)" data-updatename="obligate" class="btn btn-primary btn_update_capital btn-rounded "><i class="fa fa-pencil"></i> UPDATE DATA MANUAL</a>
                <?= $html_update_base_period; ?>
            </div>
        </div>
        <span class="clearfix"></span>
        <hr class="mb-10 no-margin no-padding">
        <div class="row">
            <div class="col-md-6 border-right">
                <h4 class="mb-10"><i class="fa fa-tv"></i> AKTIVA :</h4>
                <div class="table-responsive">
                    <table class="table table-hover" style="text-align: left;">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Saldo Awal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $grand_total_activa = 0;
                            $get_data_account_1 = $this->db->where(['type_account' => 1, 'id_parent >' => 0])->order_by('code')->get('tb_book_account')->result();
                            $get_data_account_2 = $this->db->where(['type_account' => 2, 'id_parent >' => 0])->order_by('code')->get('tb_book_account')->result();
                            foreach ($get_data_account_1 as $item_account) {
                                $saldo_current = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;
                                echo '
                                    <tr>
                                        <td>1-' . $item_account->code . '</td>
                                        <td class="text-uppercase">' . $item_account->name . '</td>
                                        <td>Rp ' . number_format($saldo_current, 0, '.', '.') . '</td>
                                    </tr>
                                ';
                                $grand_total_activa += $saldo_current;
                            }
                            foreach ($get_data_account_2 as $item_account) {
                                $saldo_current = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;
                                echo '
                                    <tr>
                                        <td>2-' . $item_account->code . '</td>
                                        <td class="text-uppercase">' . $item_account->name . '</td>
                                        <td>Rp ' . number_format($saldo_current, 0, '.', '.') . '</td>
                                    </tr>
                                ';
                                $grand_total_activa += $saldo_current;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-6 ">
                <h4 class="mb-10 text-uppercase"><i class="fa fa-tv"></i> Kewajiban & Modal :</h4>
                <div class="table-responsive">
                    <table class="table table-hover" style="text-align: left;">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Saldo Awal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $grand_total_obligate = 0;
                            $get_data_obligate = $this->db->where(['type_account' => 7, 'id_parent >' => 0])->order_by('code')->get('tb_book_account')->result();
                            $get_data_modal = $this->db->where(['type_account' => 3, 'id_parent >' => 0])->order_by('code')->get('tb_book_account')->result();
                            foreach ($get_data_obligate as $item_account) {
                                $saldo_current = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;
                                $grand_total_obligate += $saldo_current;
                                echo '
                                    <tr>
                                        <td>7-' . $item_account->code . '</td>
                                        <td class="text-uppercase">' . $item_account->name . '</td>
                                        <td>Rp ' . number_format($saldo_current, 0, '.', '.') . '</td>
                                    </tr>
                                ';
                            }
                            foreach ($get_data_modal as $item_account) {
                                $saldo_current = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;
                                $grand_total_obligate += $saldo_current;
                                echo '
                                    <tr>
                                        <td>4-' . $item_account->code . '</td>
                                        <td class="text-uppercase">' . $item_account->name . '</td>
                                        <td>Rp ' . number_format($saldo_current, 0, '.', '.') . '</td>
                                    </tr>
                                ';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <span class="clearfix"></span>
            <div class="col-md-6 border-right text-right">
                <div class="col-md-6 pull-right  p-10 border border-radius-5">
                    <label for="">Total Saldo :</label>
                    <h2 class="text-bold text-green">Rp. <?= number_format($grand_total_activa, 0, '.', '.'); ?></h2>
                </div>
            </div>
            <div class="col-md-6  text-right">
                <div class="col-md-6 pull-right  p-10 border border-radius-5">
                    <label for="">Total Saldo :</label>
                    <h2 class="text-bold text-green">Rp. <?= number_format($grand_total_obligate, 0, '.', '.'); ?></h2>
                </div>
            </div>
        </div>
    </div>
</div>