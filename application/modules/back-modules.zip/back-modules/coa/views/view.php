<!-- <div class="card-header text-right">
    <small>(*Klik untuk tambah piutang)</small>
    <a href="<?= base_url('request_warehouse/add'); ?>" class="btn btn-success"><i class="fa fa-credit-card"></i> Tambah Data Pengadaan</a>
</div> -->
<div class="page-content-wrapper">
    <div class="container-fluid">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab_0" data-toggle="tab"><i class=" fa fa-shopping-bag"></i> AKTIVA LANCAR</a></li>
                    <li><a href="#tab_1" data-toggle="tab"><i class="fa fa-building"></i> AKTIVA TETAP</a></li>
                    <li><a href="#tab_2" data-toggle="tab"><i class="fa fa-money"></i> MODAL</a></li>
                    <li><a href="#tab_3" data-toggle="tab"><i class="fa fa-line-chart"></i> PENDAPATAN</a></li>
                    <li><a href="#tab_4" data-toggle="tab"><i class="fa fa-minus-square"></i> BIAYA</a></li>
                    <li><a href="#tab_5" data-toggle="tab"><i class="fa fa-shopping-cart"></i> HARGA POKOK PENJUALAN (HPP)</a></li>
                    <li><a href="#tab_6" data-toggle="tab"><i class="fa fa-file"></i> KEWAJIBAN</a></li>
                    <li><a href="#tab_7" data-toggle="tab"><i class="fa fa-gears"></i> PENGATURAN</a></li>
                    <li><a href="#tab_8" data-toggle="tab"><i class="fa fa-gears"></i> SALDO AWAL AKUN</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tab_0">
                        <div class="col-md-6 pull-left">
                            <section class="content-header no-padding no-margin">
                                <h1><i class=" fa fa-shopping-bag"></i> 01 - AKTIVA LANCAR </h1>
                            </section>
                        </div>
                        <div class="col-md-6 pull-right text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-account="1" data-name="AKTIVA LANCAR" class="btn btn-default btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="table-responsive mt-10">
                            <table class="table table-hover table_activa_1" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Tanggal input</th>
                                        <th>Petugas</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_1">
                        <div class="col-md-6 pull-left">
                            <section class="content-header no-padding no-margin">
                                <h1><i class=" fa fa-building"></i> 02 - AKTIVA TETAP </h1>
                            </section>
                        </div>
                        <div class="col-md-6 pull-right text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-account="2" data-name="AKTIVA TETAP" class="btn btn-default btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="table-responsive mt-10">
                            <table class="table table-hover table_activa_2" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Tanggal input</th>
                                        <th>Petugas</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_2">
                        <div class="col-md-6 pull-left">
                            <section class="content-header no-padding no-margin">
                                <h1><i class=" fa fa-money"></i> 03 - MODAL </h1>
                            </section>
                        </div>
                        <div class="col-md-6 pull-right text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-account="3" data-name="MODAL" class="btn btn-default btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="table-responsive mt-10">
                            <table class="table table-hover table_capital" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Tanggal input</th>
                                        <th>Petugas</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_3">
                        <div class="col-md-6 pull-left">
                            <section class="content-header no-padding no-margin">
                                <h1><i class=" fa fa-line-chart"></i> 04 - PENDAPATAN </h1>
                            </section>
                        </div>
                        <div class="col-md-6 pull-right text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-account="4" data-name="PENDAPATAN" class="btn btn-default btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="table-responsive mt-10">
                            <table class="table table-hover table_advatage" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Tanggal input</th>
                                        <th>Petugas</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_4">
                        <div class="col-md-6 pull-left">
                            <section class="content-header no-padding no-margin">
                                <h1><i class=" fa fa-minus-square-o"></i> 05 - BIAYA </h1>
                            </section>
                        </div>
                        <div class="col-md-6 pull-right text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-account="5" data-name="BIAYA" class="btn btn-default btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="table-responsive mt-10">
                            <table class="table table-hover table_cost" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Tanggal input</th>
                                        <th>Petugas</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_5">
                        <div class="col-md-6 pull-left">
                            <section class="content-header no-padding no-margin">
                                <h1><i class=" fa fa-shopping-cart"></i> 06 - HARGA POKOK PENJUALAN (HPP) </h1>
                            </section>
                        </div>
                        <div class="col-md-6 pull-right text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-account="6" data-name="HARGA POKOK PENJUALAN (HPP)" class="btn btn-default btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="table-responsive mt-10">
                            <table class="table table-hover table_hpp" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Tanggal input</th>
                                        <th>Petugas</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_6">
                        <div class="col-md-6 pull-left">
                            <section class="content-header no-padding no-margin">
                                <h1><i class=" fa fa-file"></i> 07 - KEWAJIBAN </h1>
                            </section>
                        </div>
                        <div class="col-md-6 pull-right text-right">
                            <small>(*klik untuk tambah data)</small>
                            <a href="javascript:void(0)" data-account="7" data-name="KEWAJIBAN" class="btn btn-default btn_add"><i class="fa fa-plus-circle"></i> Tambah Akun</a>
                        </div>
                        <span class="clearfix"></span>
                        <div class="table-responsive mt-10">
                            <table class="table table-hover table_obligate" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Tanggal input</th>
                                        <th>Petugas</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_7">
                        <div class="html_respon_setting"></div>
                    </div>
                    <div class="tab-pane" id="tab_8">
                        <div class="html_respon_saldo"></div>
                    </div>
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->
        </div>
    </div>
</div>



<div class="modal fade in" id="modal-form">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content border-radius-5 shadow">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">TAMBAH DATA AKUN</h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <form class="form-input">
                        <div class="col-md-12 border p-10 border-radius-5 text-center mb-10">
                            <h5 class="text-bold text-green text-account"></h5>
                        </div>
                        <div class="col-md-5 form-group">
                            <label for="">SUB AKUN DARI :</label>
                            <select name="id_parent" class="form-control">
                                <option value="">TIDAK ADA</option>
                            </select>
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-4 html_respon_bank"></div>
                        <span class="clearfix"></span>

                        <div class="col-md-3 form-group">
                            <label for="">Kode Rekening</label>
                            <input type="text" name="code" class="form-control">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-7 form-group">
                            <label for="">Nama Rekening</label>
                            <input type="text" name="name" class="form-control">
                            <span class="help-block"></span>
                        </div>
                        <div class="col-md-2 form-group">
                            <label for="">&nbsp;</label><br>
                            <button type="submit" class="btn btn-success btn_save">Simpan Data</button>
                            <span class="help-block"></span>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>



<div class="modal fade in" id="modal-update">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content border-radius-5 shadow">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">UPDATE SETTING</h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal fade in" id="modal-update-capital">
    <div class="modal-dialog" style="max-width:90%;">
        <div class="modal-content border-radius-5 shadow">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">UPDATE SETTING</h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>