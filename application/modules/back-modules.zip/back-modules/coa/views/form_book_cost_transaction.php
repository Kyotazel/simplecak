<?php
$account_cost_transaction = $this->db->where(['params' => 'account_cost_transaction'])->get('app_module_setting')->row()->value;
$array_account_setting = json_decode($account_cost_transaction);
// $get_data = $this->db->where(['field' => $update_name])->get('tb_setting')->row()->value;
$get_data_activa = $this->db->where(['type_account' => 1, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();
$get_data_obligate = $this->db->where(['type_account' => 7, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();
$get_data_cost = $this->db->where(['type_account' => 5, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();
?>
<form class="form-input-update-setting">
    <h4 class="mb-10 tex-center"><i class="fa fa-tv"></i> AKUN TRANSAKSI OPERASIONAL</h4>
    <span class="clearfix"></span>
    <div class="row">
        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun kas</label>
            <select name="data[akun_kas]" id="" class="form-control">
                <?php
                foreach ($get_data_activa as $item) {
                    $selected = $item->id == $array_account_setting->akun_kas ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>
        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun Biaya</label>
            <select name="data[akun_biaya]" id="" class="form-control">
                <?php
                foreach ($get_data_cost as $item) {
                    $selected = $item->id == $array_account_setting->akun_biaya ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>

        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun kas hutang</label>
            <select name="data[akun_kas_hutang]" id="" class="form-control">
                <?php
                foreach ($get_data_activa as $item) {
                    $selected = $item->id == $array_account_setting->akun_kas_hutang ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>
        <div class="col-md-6 form-group">
            <label for="" class="text-capitalize">akun kewajiban Hutang</label>
            <select name="data[akun_kewajiban_hutang]" id="" class="form-control">
                <?php
                foreach ($get_data_obligate as $item) {
                    $selected = $item->id == $array_account_setting->akun_kewajiban_hutang ? 'selected' : '';
                    echo '
                        <option ' . $selected . ' value="' . $item->id . '">' . $item->code . ' ' . $item->name . '</option>
                    ';
                }
                ?>
            </select>
            <span class="help-block"></span>
        </div>

        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-success btn_save_account_setting" data-code="<?= $code; ?>">Simpan Data</button>
        </div>
    </div>
</form>