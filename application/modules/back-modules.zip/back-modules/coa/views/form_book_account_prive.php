<?php
$account_prive = $this->db->where(['params' => 'account_prive'])->get('app_module_setting')->row()->value;
$array_account_prive = json_decode($account_prive);
$get_data_capital = $this->db->where(['type_account' => 3, 'id_parent !=' => 0, 'isDeleted' => 'N'])->order_by('code')->get('tb_book_account')->result();

// print_r(json_encode(['debit' => 0]));

?>

<form class="form-input-update-setting">
    <h4 class="mb-10 tex-center"><i class="fa fa-tv"></i> AKUN LAIN NYA</h4>
    <span class="clearfix"></span>
    <div class="col-md-12 form-group">
        <label for="">Akun PRIVE</label>
        <select name="data[akun_prive]" id="" class="form-control">
            <?php
            foreach ($get_data_capital as $item_capital) {
                $selected = $item_capital->id == $array_account_prive->akun_prive ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_capital->id . '">' . $item_capital->code . ' ' . $item_capital->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-12 form-group">
        <label for="">Akun modal atas Pendapatan</label>
        <select name="data[akun_revenue]" id="" class="form-control">
            <?php
            foreach ($get_data_capital as $item_capital) {
                $selected = $item_capital->id == $array_account_prive->akun_revenue ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_capital->id . '">' . $item_capital->code . ' ' . $item_capital->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-12 text-right">
        <button type="submit" class="btn btn-success btn_save_account_setting" data-code="<?= $code; ?>">Simpan Data</button>
    </div>
</form>