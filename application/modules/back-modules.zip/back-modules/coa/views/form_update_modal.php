<form class="form-update-saldo">
    <div class="row">
        <div class="col-md-6 border-right">
            <h3 class="mb-10"><i class="fa fa-tv"></i> AKTIVA :</h3>
            <div class="table-responsive">
                <table class="table table-hover" style="text-align: left;">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th width="200px">Saldo Awal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $grand_total_activa = 0;
                        $get_data_account_1 = $this->db->where(['type_account' => 1, 'id_parent >' => 0])->get('tb_book_account')->result();
                        $get_data_account_2 = $this->db->where(['type_account' => 2, 'id_parent >' => 0])->get('tb_book_account')->result();
                        foreach ($get_data_account_1 as $item_account) {

                            $saldo = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;

                            echo '
                            <tr>
                                <td>1-' . $item_account->code . '</td>
                                <td class="text-uppercase">' . $item_account->name . '</td>
                                <td>
                                <input type="number" class="form-control  account account_1" value="' . $saldo . '" name="account[' . $item_account->id . ']">
                                </td>
                            </tr>
                        ';
                            $grand_total_activa += $item_account->saldo;
                        }
                        foreach ($get_data_account_2 as $item_account) {
                            $saldo = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;
                            echo '
                            <tr>
                                <td>2-' . $item_account->code . '</td>
                                <td class="text-uppercase">' . $item_account->name . '</td>
                                <td>
                                    <input type="number" class="form-control account account_1" value="' . $saldo . '" name="account[' . $item_account->id . ']">
                                </td>
                            </tr>
                        ';
                            $grand_total_activa += $item_account->saldo;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-6 ">
            <h3 class="mb-10"><i class="fa fa-tv"></i> Kewajiban & Modal :</h3>
            <div class="table-responsive">
                <table class="table table-hover" style="text-align: left;">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th width="200px">Saldo Awal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $grand_total_obligate = 0;
                        $get_data_obligate = $this->db->where(['type_account' => 7, 'id_parent >' => 0])->get('tb_book_account')->result();
                        $get_data_modal = $this->db->where(['type_account' => 3, 'id_parent >' => 0])->get('tb_book_account')->result();
                        foreach ($get_data_obligate as $item_account) {
                            $grand_total_obligate += $item_account->saldo;
                            $saldo = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;
                            echo '
                            <tr>
                                <td>7-' . $item_account->code . '</td>
                                <td class="text-uppercase">' . $item_account->name . '</td>
                                <td>
                                    <input type="number" class="form-control account account_2" value="' . $saldo . '" name="account[' . $item_account->id . ']">
                                </td>
                            </tr>
                        ';
                        }
                        foreach ($get_data_modal as $item_account) {
                            $grand_total_obligate += $item_account->saldo;
                            $saldo = isset($data_saldo[$item_account->id]) ? $data_saldo[$item_account->id] : 0;
                            echo '
                            <tr>
                                <td>4-' . $item_account->code . '</td>
                                <td class="text-uppercase">' . $item_account->name . '</td>
                                <td>
                                    <input type="number" class="form-control account account_2" value="' . $saldo . '" name="account[' . $item_account->id . ']">
                                </td>
                            </tr>
                        ';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <span class="clearfix"></span>
        <div class="col-md-6 border-right text-right">
            <div class="col-md-6 pull-right  p-10 border border-radius-5">
                <label for="">Total Saldo :</label>
                <h2 class="text-bold text-green text_account_1">Rp. <?= number_format($grand_total_activa, 0, '.', '.'); ?></h2>
            </div>
        </div>
        <div class="col-md-6  text-right">
            <div class="col-md-6 pull-right  p-10 border border-radius-5">
                <label for="">Total Saldo :</label>
                <h2 class="text-bold text-green text_account_2">Rp. <?= number_format($grand_total_obligate, 0, '.', '.'); ?></h2>
            </div>
        </div>
    </div>

    <div class="col-md-12 text-right mt-10">
        <button type="submit" class="btn btn-warning-gradient btn-rounded btn-lg btn_save_update_modal"> <i class="fa fa-send"></i> Simpan Data Saldo <i class="fa fa-paper-plane"></i></button>
    </div>
</form>