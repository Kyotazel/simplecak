<?php
$get_data = $this->db->where(['field' => $update_name])->get('tb_setting')->row()->value;
$get_data_activa    = $this->db->where(['type_account' => 1, 'id_parent !=' => 0])->order_by('code')->get('tb_book_account')->result();
$get_data_cost      = $this->db->where(['type_account' => 5, 'id_parent !=' => 0])->order_by('code')->get('tb_book_account')->result();

?>

<form class="form-input-update">
    <h3 class="mb-10 tex-center"><i class="fa fa-tv"></i> AKUN PERSEDIAAN BARANG GUDANG</h3>
    <span class="clearfix"></span>
    <div class="col-md-6 form-group">
        <label for="">Akun Debit</label>
        <select name="account[debit]" id="" class="form-control">
            <?php
            foreach ($get_data_activa as $item_activa) {
                $selected = $item_activa->id == $data_account->debit ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_activa->id . '">' . $item_activa->code . ' ' . $item_activa->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-6 form-group">
        <label for="">Akun Kredit</label>
        <select name="account[credit]" id="" class="form-control">
            <?php
            foreach ($get_data_activa as $item_activa) {
                $selected = $item_activa->id == $data_account->credit ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_activa->id . '">' . $item_activa->code . ' ' . $item_activa->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-6 form-group">
        <label for="">Akun Biaya Pajak</label>
        <select name="account[debit_cost]" id="" class="form-control">
            <?php
            foreach ($get_data_cost as $item_activa) {
                $selected = $item_activa->id == $data_account->debit_cost ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_activa->id . '">' . $item_activa->code . ' ' . $item_activa->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-6 form-group">
        <label for="">Akun Potongan Biaya</label>
        <select name="account[debit_discount]" id="" class="form-control">
            <?php
            foreach ($get_data_activa as $item_activa) {
                $selected = $item_activa->id == $data_account->debit_discount ? 'selected' : '';
                echo '
                        <option ' . $selected . ' value="' . $item_activa->id . '">' . $item_activa->code . ' ' . $item_activa->name . '</option>
                    ';
            }
            ?>
        </select>
        <span class="help-block"></span>
    </div>
    <div class="col-md-12 text-right">
        <button type="submit" class="btn btn-success btn_update_account" data-name="<?= $update_name; ?>">Simpan Data</button>
    </div>
</form>