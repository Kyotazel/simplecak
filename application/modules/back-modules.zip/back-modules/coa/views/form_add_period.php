<?php
function change_date($date)
{
    $explode_date = explode('-', $date);
    $date_return = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
    return $date_return;
}


$id = '';
$name = '';
$date_from = '';
$date_to = '';

if (!empty($data_current)) {
    $id = $data_current->id;
    $name = $data_current->name;
    $date_from = change_date($data_current->date_from);
    $date_to = change_date($data_current->date_to);
}
?>

<form class="form-input-period">
    <div class="row">
        <div class="col-md-12 form-group">
            <label for="">Nama Periode</label>
            <input type="hidden" class="form-control" name="id" value="<?= $id; ?>">
            <input type="text" class="form-control" name="name" value="<?= $name; ?>">
            <span class="help-block"></span>
        </div>
        <?php
        if (!empty($list_period)) {

            $html_option = '';
            foreach ($list_period as $item_period) {
                $html_option .= '
                    <option value="' . $item_period->id . '">' . $item_period->name . '</option>
                ';
            }

            echo '
            <div class="col-md-12 form-group">
                <label for="">Periode Sebelumnya</label>
                <select name="id_parent" class="form-control">
                    ' . $html_option . '
                </select>
                <span class="help-block"></span>
            </div>
            
            ';
        }
        ?>
        <span class="clearfix"></span>
        <div class="col-md-6 form-group">
            <label for="">Tanggal Awal Periode</label>
            <input type="text" class="form-control bg-white datepicker_form" data-language="en" readonly value="<?= $date_from; ?>" name="date_from">
            <span class="help-block"></span>
        </div>
        <div class="col-md-6 form-group">
            <label for="">Tanggal Akhir periode</label>
            <input type="text" class="form-control bg-white datepicker_form" data-language="en" readonly name="date_to" value="<?= $date_to; ?>">
            <span class="help-block"></span>
        </div>
        <div class="col-md-12 text-right">
            <small>(*klik untuk simpan)</small>
            <button type="submit" class="btn btn-primary btn_save_period"><i class="fa"></i> Simpan Data</button>
        </div>
    </div>
</form>