

var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var id_use = 0;
var table;

$(document).ready(function () {
    // alert('ok');
    // table = $('#table_list').DataTable({
    //     "ajax": {
    //         "url": url_controller + "list_data",
    //         "type": "POST"
    //     }
    // });
    
    // table = $('#table_list_stock').DataTable({
    //     "ajax": {
    //         "url": url_controller + "list_data_stock_opname",
    //         "type": "POST"
    //     }
    // });

    // all_item = 0;
    // count_item();
    
    $('.chosen').chosen();
});
//end document ready 

function reload_table() {
    table.ajax.reload(null, false); //reload datatable ajax 
}



$(document).on('change', '#barcode', function (e) {
    e.preventDefault();
    
    $(".form-input").submit(function (e) {
        return false;
    });

    var barcode_current = $(this).val();
        $.ajax({
            url: url_controller + '/get_barcode_choosen/',
            type: "POST",
            dataType: "JSON",
            data:{'barcode':barcode_current},
            success: function (ui) {
                if (ui.status) {
                    $('#product-name').val(ui.item.label);
                    get_unit_request(ui.item.id);
                    $('[name="qty"]').focus();
                } else {
                    alert_error('barang tidak ditemukan');
                }
                
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
    })

$('#product-name').autocomplete({
    source: url_controller + "/get_product_auto",
    select: function(event, ui) {
        event.preventDefault();
        console.log(ui.item);
        $('#product-name').val(ui.item.label);
        get_unit_request(ui.item.id);
        $('[name="qty"]').focus();
    }
});

function get_unit_request(id) {
    $.ajax({
	    url: url_controller+'/get_unit_request',
	    type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function (data) {
            $('[name="unit"]').html(data.html_respon);
            $('[name="data_product"]').val(data.data_product);
	    },
	      error:function(jqXHR, textStatus, errorThrown)
	      {
	       $('.btn_add_product');
	       alert_error('something wrong');
	      }
	  });//end ajax
}

$(document).on('keypress', '[name="qty"]', function (event) {
    if (event.keyCode === 13) { 
        $('.btn_add_item').click();
    } 
});

$('.btn_add_item').click(function () {
    var data_product = $('[name="data_product"]').val();
    var unit = $('[name="unit"]').val();
    var qty = $('[name="qty"]').val();

    if (data_product == '' || unit == '' || qty == '') {
        alert_error('lengkapi data');
    } else {
        $.ajax({
            url: url_controller+'/add_item_product',
            type: "POST",
            dataType: "JSON",
            data:{'data_product':data_product,'unit':unit,'qty':qty},
            success: function (data) {
                $('.html_no_data').remove();
                var chek_tr = $('.tr_' + data.id).length;
                if (chek_tr) {
                    $('.tr_' + data.id).remove();
                }
                $('.tbody_item').append(data.html_respon);
    
                $('#product-name').val('');
                $('#barcode').val('');
                $('[name="qty"]').val('');
                $('[name="unit"]').html('');
                $('[name="data_product"]').val('');
                $('#barcode').focus();
    
            },
              error:function(jqXHR, textStatus, errorThrown)
              {
               alert_error('something wrong');
              }
          });//end ajax
    }    
})

$(document).on('click', '.btn_cancel', function (e) {
    e.preventDefault();
    $(this).parent().parent().remove();
    var count_tr = $('.tbody_item').has('tr').length;
    if (count_tr == 0) {
        $('.tbody_item').html('<tr class="html_no_data"><td colspan="8" class="text-center"><h3 class="text-center text-muted mb-10">Pilihlah Data Produk Stok Barang</h3></td></tr>');
    }
})

// function add_product() {
//     var id_product;
//     $("input[name='id_product_choosen[]']").each(function() {
//         id_product = $(this).val() + "." + id_product;
//     });

//     showLoading();
//     $('.modal-title').text('Tambah Keraanjang Stok')
//     $.ajax({
//         url: url_controller + "get_product/" + id_product,
//         type: "GET",
//         dataType: "HTML",
//         success: function(data) {
//             hideLoading();
//             $('.content-html-product').html(data);
//             $('.table-product').DataTable();
//             // notif_success('cek');
//             $('#modal_product').modal('show');
//         },
//         error: function(jqXHR, textStatus, errorThrown) {
//             alert('error process');
// showLoading();
//         }
//     });
// }

// $('.add_chart_stock').click(function() {
//     showLoading();
//     var formData = new FormData($('#form_add_stock')[0]);
//     $.ajax({
//         url: url_controller + 'get_product_add_stock',
//         type: "POST",
//         data: formData,
//         contentType: false,
//         processData: false,
//         dataType: "HTML",
//         success: function(data) {
//             hideLoading();
//             $('#modal_product').modal('hide');
//             $('.add_content').append(data);
//             count_item();
//         },
//         error: function(jqXHR, textStatus, errorThrown) {
//             alert('error process');
// showLoading();
//         }

//     });
// })


// $('.add_content').on('click', '.clear_html', function() {
//     var html_target = $(this).parent().parent();
//     html_target.remove();
//     count_item();
//     // alert('cek');
// });

// $('.add_content').on('keyup', '.number_type', function() {
//     var new_val = money_function($(this).val());
//     $(this).val(new_val);
// });


$('.show_review').click(function() {
    $(this);
    $('.help-block').empty();
    $('.modal-title').text('koreksi Kembali');
    var formData = new FormData($('.form-stock-choosen')[0]);
    $.ajax({
        url: url_controller + 'get_review_stock',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if (data.status) {
                $('.content-html-review').html(data.html_respon);
                $('#modal_review').modal('show');
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    if (data.inputerror[i] == 'product') {
                        Swal.fire(
                            'Produk Kosong',
                            'produk belum dipilih',
                            'warning'
                        );
                    } else {
                        $('.' + data.inputerror[i]).parent().addClass('has-error');
                        $('.' + data.inputerror[i]).next().text(data.error_string[i]);
                    }
                }
            }
            $('.show_review');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.show_review');
            alert_error('error process');
        }
    });
})

$(document).on('click', '.btn_save_stock', function () {
    var grand_total = $(this).data('grandtotal');
    swal({
        title: "Apakah anda yakin?",
        text: "data akan Disimpan!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
        function (isConfirm) {
            if (isConfirm) {
               
                $('.help-block').empty();
                $('.modal-title').text('koreksi Kembali');
                var formData = new FormData($('.form-stock-choosen')[0]);
                formData.append('grand_total', grand_total);
                $.ajax({
                    url: url_controller + 'save',
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: "JSON",
                    success: function (data) {
                        if (data.status) {
                            window.location.href = url_controller + 'history_stock';
                        } else {
                            for (var i = 0; i < data.inputerror.length; i++) {
                                $('.' + data.inputerror[i]).parent().addClass('has-error');
                                $('.' + data.inputerror[i]).next().text(data.error_string[i]);
                            }
                        }
                        $('.btn_save_stock');
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        $('.btn_save_stock');
                        alert_error('error process');
                    }
                });
            }
        });
    
});

$(document).on('click', '.btn_detail_stock', function () {
    var id = $(this).data('id');
    $.ajax({
            url: url_controller + 'get_detail_stock',
            type: "POST",
            data: {'id':id},
            dataType: "JSON",
            success: function(data) {
                $('#modal_detail').modal('show');
                $('.html_respon_modal').html(data.html_respon);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert_error('error process');
            }
        });
})

$(document).on('click', '.btn_conversion', function () {
    $(this);
    var id = $(this).data('id');
    $.ajax({
            url: url_controller + 'get_conversion_stock',
            type: "POST",
            data: {'id':id},
            dataType: "JSON",
            success: function (data) {
                    $('.btn_conversion');
                    $('#modal_review').modal('show');
                    $('.html_respon_modal').html(data.html_respon);
                },
            error: function (jqXHR, textStatus, errorThrown) {
                    $('.btn_conversion');
                    alert_error('error process');
                }
        });
})
// $('.save_stock_opname').click(function() {
//     showLoading();
//     $('#modal_review').modal('hide');
//     var formData = new FormData($('.form-stock-choosen')[0]);
//     $.ajax({
//         url: url_controller + 'save',
//         type: "POST",
//         data: formData,
//         contentType: false,
//         processData: false,
//         dataType: "HTML",
//         success: function(data) {
//             hideLoading();
//             notif_success('data berhasil disimpan..!');
//             window.location.href = url_controller + 'history_stock';
//         },
//         error: function(jqXHR, textStatus, errorThrown) {
//             alert('error process');
// showLoading();
//         }
//     });
// })


$(document).on('click', '.btn_search', function (e) {
    e.preventDefault();
    $(this);
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    $.ajax({
        url: url_controller + "search_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon').html(data.html_respon);
                notif_success('selesai');
                $(".pagination").rPage();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_search');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_search');
            alert_error('something wrong');
        }

    });
});


//pagination 
$(document).on('click', '.page-link', function () {
    var page_number = $(this).data('ci-pagination-page');
    $(this).text('load..');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    formData.append('page', page_number);
    $.ajax({
        url: url_controller + "search_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('.html_respon').html(data.html_respon);
                notif_success('selesai');
                $(".pagination").rPage();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.' + data.inputerror[i]).parent().addClass('has-error');
                    $('.' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            $('.btn_search');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_search');
            alert_error('something wrong');
        }

    });
});

$(document).on('keyup', '.money_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    var money = money_function(qty, '');
    $(this).val(money);
})

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    return rupiah;
}