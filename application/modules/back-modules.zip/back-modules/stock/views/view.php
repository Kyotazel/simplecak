<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
        <a href="<?php echo base_url('stock/add'); ?>" class="btn btn-default pull-right btn_link"><i class="fa fa-plus"></i> Tambah STOK BARANG</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="table_list" class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Barcode</th>
                        <th>Nama Barang</th>
                        <th>Satuan</th>
                        <th>stok</th>
                        <th>Status Stok</th>
                        <th>Tgl Stok Terakhir</th>
                        <th width="150px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal_review">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>