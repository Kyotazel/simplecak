<div class="col-md-12 mb-10">
    <h2 class="text-green"><?= strtoupper($data_product->name); ?></h2>
    <label for="">STOK : <b><?= $data_product->stock . ' ' . $data_product->unit_name; ?></b></label>
</div>
<div class="col-md-12">
    <table class="table">
        <thead>
            <tr>
                <th>Nama Konversi</th>
                <th>Qty</th>
                <th>Stok Produk</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!empty($data_conversion)) {
                foreach ($data_conversion as $item_conversion) {
                    $unit_stok      = $data_product->stock % $item_conversion->qty;
                    $conversion_qty = ($data_product->stock - $unit_stok) / $item_conversion->qty;

                    $html_stock = '';
                    if ($data_product->stock > 0) {
                        if ($conversion_qty > 0) {
                            $html_stock .= $conversion_qty . ' ' . $item_conversion->name;
                        }
                        if ($unit_stok > 0) {
                            $html_stock .= '<br>' . $unit_stok . ' ' . $data_product->unit_name;
                        }
                    } else {
                        $html_stock = 'STOK KOSONG';
                    }

                    echo '
                        <tr>
                            <td>' . $item_conversion->name . '</td>
                            <td>' . $item_conversion->qty . $data_product->unit_name . '</td>
                            <td>
                                ' . $html_stock . '
                            </td>
                        </tr>
                    ';
                }
            } else {
                echo '
                    <tr>
                        <td colspan="3">
                            <h4 class="text-muted">TIDAK ADA KONVERSI STOK</h4>
                        </td>
                    </tr>
                ';
            }

            ?>
        </tbody>
    </table>
</div>