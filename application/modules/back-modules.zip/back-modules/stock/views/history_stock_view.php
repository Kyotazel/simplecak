<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header text-right">
        <a href="<?= Modules::run('helper/create_url', 'stock/add'); ?>" class="btn btn-primary-gradient btn-rounded btn_link"><i class="fa fa-plus"></i> Tambah STOK BARANG</a>
    </div>
    <div class="card-body">
        <table id="table_list_stock" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Kode Penerimaan</th>
                    <th>Tanggal Stok</th>
                    <th>Gudang</th>
                    <th>Total Item</th>
                    <th>Grand Total</th>
                    <th>aksi</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal_detail" data-backdrop="static">
    <div class="modal-dialog" style="min-width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">DETAIL</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>