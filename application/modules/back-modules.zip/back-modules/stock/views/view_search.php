<div class="card">
    <div class="card-body">
        <div class="col-12 p-0">
            <div class="mb-3 row">
                <h3 class="col-md-8">DAFTAR STOK PRODUK</h3>
                <div class="col-md-4 text-right">
                    <?= Modules::run('security/create_access', '
                        <a href="' . Modules::run('helper/create_url', 'product/add') . '" class="btn btn-primary-gradient btn_add btn-rounded" > <i class="fa fa-plus-circle" ></i> Tambah Data</a>
                    '); ?>
                </div>
            </div>
        </div>
        <form class="form-input">
            <div class="row border rounded p-3">
                <div class="col-md-4">
                    <label>DEVISI</label>
                    <select name="id_devision[]" multiple class="form-control chosen">
                        <option value="">TIDAK ADA</option>
                        <?php
                        foreach ($data_devision as $item_main_category) {
                            echo '<option value="' . $item_main_category->id . '">' . $item_main_category->name . '</option>';
                        }
                        ?>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-4">
                    <label>KATEGORI</label>
                    <select name="id_category[]" multiple class="form-control chosen">
                        <option value="">TIDAK ADA</option>
                        <?php
                        foreach ($data_category as $item_data) {
                            echo '<option value="' . $item_data->id . '">' . $item_data->name . '</option>';
                        }
                        ?>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-4">
                    <label>Gudang</label>
                    <select name="id_warehouse" class="form-control chosen">
                        <?php
                        foreach ($data_warehouse as $item_data) {
                            $selected = $item_data->is_default == 1 ? 'selected' : '';
                            echo '<option ' . $selected . ' value="' . $item_data->id . '">' . $item_data->name . '</option>';
                        }
                        ?>
                    </select>
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-3 mt-2">
                    <label>Kode</label>
                    <input type="text" class="form-control" name="code">
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-7 mt-2">
                    <label>Nama Produk</label>
                    <input type="text" class="form-control" name="name">
                    <span class="help-block" style="color:red;"></span>
                </div>
                <div class="col-md-2 text-right mt-2" style="padding:0 !important;margin:0 !important;">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-primary btn-rounded btn_search btn-block"> <i class="fa fa-search"></i> Cari Data </button>
                </div>
            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>
<div class="html_respon"></div>