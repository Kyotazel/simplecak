<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table_data">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Devisi</th>
                        <th>kategori</b></th>
                        <th>Satuan</b></th>
                        <th>stok minimal</b></th>
                        <th>Stok</th>
                        <th>Status Stok</b></th>
                        <th>tgl input</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = $start_no;
                    foreach ($data_product as $data_table) {

                        // $persentage = (($data_table->price - $data_table->main_price) / $data_table->main_price) * 100;

                        if ($data_table->stock_qty <= $data_table->stock_minimum) {
                            $status_stock = '<label class="badge badge-warning">Stok kurang</label>';
                        } else {
                            $status_stock = '<label class="badge badge-success">Stok Cukup</label>';
                        }
                        $no++;
                        echo '
                            <tr>
                                <td>' . $no . '</td>
                                <td>' . $data_table->code . '</td>
                                <td>' . $data_table->name . '</td>
                                <td>' . $data_table->devision_name . '</td>
                                <td>' . $data_table->category_name . '</td>
                                <td>' . $data_table->unit_name . '</td>
                                <td>' . $data_table->stock_minimum . '</td>
                                <td>' . $data_table->stock_qty . '</td>
                                <td>' . $status_stock . '</td>
                                <td>' . $data_table->created_date . '</td>
                                <td><a class="btn btn-info btn_link" href="' . Modules::run('helper/create_url', 'product/detail?data=' . urlencode($this->encrypt->encode($data_table->id))) . '" title="detail"><i class="fa fa-tv"></i></a></td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-4">
                    <!--Tampilkan pagination-->
                    <?php echo $html_pagination; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.box-body -->
</div>