<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header">
    </div>
    <div class="card-body">
        <div class="html-review">
            <div class="col-md-12 text-right">
                <a href="<?= base_url('stock'); ?>" class="btn btn-primary-gradient btn-rounded btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
            </div>
            <form class="form-stock-choosen">
                <div class="row">
                    <div class="col-md-3">
                        <label>Kode Stok</label>
                        <input type="text" name="code" value="<?php echo $code_stock; ?>" style="background-color:#fff;" readonly class="form-control code-stock">
                    </div>
                    <div class="col-md-3">
                        <label>tanggal Stok</label>
                        <input type="text" name="date" value="<?php echo $date_stock; ?>" style="background-color:#fff;" class="form-control date-stock" readonly>
                    </div>
                </div>
                <span class="clearfix"></span>
                <hr>
                <div class="col-md-12 row">
                    <input type="hidden" name="data_product">
                    <div class="col-md-3 form-group">
                        <label>Barcode Barang</label>
                        <input type="text" class="form-control" id="barcode" name="barcode">
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Nama Produk</label>
                        <input type="text" id="product-name" class="form-control" name="product_name">
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-2 form-group">
                        <label>Satuan Stok</label>
                        <select name="unit" class="form-control" name="unit"></select>
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-2 form-group">
                        <label>Jumlah</label>
                        <input type="text" class="form-control" name="qty">
                        <span class="help-block"></span>
                    </div>
                    <div class="col-md-2 form-group">
                        <label>&nbsp;</label><br>
                        <a href="javascript:void(0)" class="btn btn-primary-gradient btn-rounded btn_add_item"><i class="fa fa-plus-circle"></i> Tambah</a>
                        <span class="help-block"></span>
                    </div>
                </div>
                <span class="clearfix"></span>
                <hr>
                <label>Detail Barang:</label>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th width="110px">Satuan</th>
                            <th width="110px">Sisa Stok</th>
                            <th class="next_clear">Harga Pokok Satuan</th>
                            <th class="next_clear">Stok Baru</th>
                            <th class="next_clear">Harga / unit</th>
                            <th class="next_clear">Batal</th>
                        </tr>
                    </thead>
                    <tbody class="add_content tbody_item">
                        <tr class="html_no_data">
                            <td colspan="10" class="text-center">
                                <h3 class="text-center text-muted mb-10">Pilihlah Data Produk Stok Barang</h3>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
        <hr>
        <div class="text-right">
            <button type="button" class="btn btn-lg btn-primary-gradient btn-rounded show_review"><i class="fa fa-save"></i> Simpan Stok</button>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal_product" data-backdrop="static">
    <div class="modal-dialog" style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Form Member</h4>
            </div>
            <div class="card-body pad">
                <div class="content-html-product"></div>
                <div align="center">
                    <button class="btn btn-primary-gradient btn-rounded btn-block btn-lg add_chart_stock" style="width:70%;"><i class="fa fa-plus"></i> Tambah Keranjang</button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary-gradient btn-rounded pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>

<div class="modal" id="modal_review" data-backdrop="static">
    <div class="modal-dialog" style="min-width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="content-html-review"></div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>