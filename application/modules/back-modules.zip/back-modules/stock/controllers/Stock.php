<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stock extends BackendController
{
    var $module_name        = 'stock';
    var $module_directory   = 'stock';
    var $module_js          = ['stock'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_warehouse'] = Modules::run('database/find', 'tb_account_warehouse', ['type' => 1])->result();
        $this->app_data['data_devision'] = Modules::run('database/find', 'tb_main_category', ['type' => 1])->result();
        $this->app_data['data_category'] =  Modules::run('database/find', 'tb_main_category', ['type' => 2])->result();

        $this->app_data['page_title'] = "Stok Barang";
        $this->app_data['view_file'] = 'view_search';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_code()
    {
        $number_text = 0;
        $db_name = 'tb_stock';
        $simbol = 'ST';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select code AS max_code  from $db_name WHERE id IN(SELECT MAX(id) FROM $db_name)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function search_data()
    {
        $id_devision = $this->input->post('id_devision');
        $id_category     = $this->input->post('id_category');
        $code     = $this->input->post('code');
        $name         = $this->input->post('name');
        $page          = $this->input->post('page');
        $id_warehouse = $this->input->post('id_warehouse');


        $array_where = [];
        $array_where_in = [];
        if (!empty($code)) {
            $array_query['like']['tb_product.code'] = $code . ',both';
        }
        if (!empty($id_devision)) {
            $array_where_in['tb_product.id_main_category'] = $id_devision;
        }

        if (!empty($id_category)) {
            $array_where_in['tb_product.id_sub_category '] = $id_category;
        }
        $limit_data = 25;

        $limit_data = 25;
        if (!empty($page) && $page != 'undefined') {
            $start_page = ($page * $limit_data) - $limit_data;
            $data['start_no'] = $start_page;
        } else {
            $start_page = 0;
            $data['start_no'] = 0;
        }

        $array_query = [
            'select' => '
                tb_product.code,
                tb_product.id,
                tb_product.name,
                tb_product.main_price,
                tb_product.price_1,
                tb_product.price_2,
                tb_product.price_3,
                tb_product.price_4,
                tb_product.stock_minimum,
                tb_product.stock,
                tb_product.created_date,
                tb_main_category.name AS devision_name,
                category.name AS category_name,
                tb_merk.name AS merk_name,
                tb_unit.name AS unit_name,
                tb_barcode_product.barcode AS barcode,
                tb_product_has_stock.stock_qty
            ',
            'from' => 'tb_product',
            'join' => [
                'tb_main_category , tb_product.id_main_category = tb_main_category.id , left',
                'tb_main_category AS category, tb_product.id_sub_category = category.id , left',
                'tb_merk,tb_product.id_merk = tb_merk.id,left',
                'tb_unit , tb_product.id_unit = tb_unit.id , left',
                'tb_barcode_product , tb_product.id = tb_barcode_product.id_product , left',
                'tb_product_has_stock , tb_product.id = tb_product_has_stock.id_product AND tb_product_has_stock.id_warehouse = ' . $id_warehouse . ' , left'
            ],
            'limit' => [
                'start' => $start_page,
                'limit' => $limit_data
            ]
        ];

        if (!empty($array_where)) {
            $array_query['where'] = $array_where;
        }
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }
        if (!empty($name)) {
            $array_query['like']['tb_product.name'] = $name . ',both';
        }
        // count data 
        // $get_query = $main_query . ' LIMIT ' . $start_page . ',' . $limit_data;
        $get_data_product = Modules::run('database/get', $array_query)->result();

        $data['data_product'] = $get_data_product;

        //remove limit
        unset($array_query['limit']);
        $array_query['select'] = 'COUNT(tb_product.id) AS count_data';
        $count_all_data = Modules::run('database/get', $array_query)->row();
        $count_all = $count_all_data->count_data;



        $num_links = floor($count_all / $limit_data);
        $html_pagination_item = '';
        $counter = 0;
        for ($i = 0; $i < 20; $i++) {
            $counter++;
            if ($counter > $num_links) {
                continue;
            }
            $active = $page == $counter ? 'active' : '';
            $html_pagination_item .= '<li class="page-item ' . $active . '"><a class="page-link btn_pagination" data-ci-pagination-page="' . $counter . '"  href="javascript:void(0)">' . $counter . '</a></li>';
        }

        $html_pagination = '
        <div class="pagging text-center">
        <nav aria-label="Page navigation example">
        <ul class="pagination">
        ' . $html_pagination_item . '
        </ul>
        </nav>
        </div>
        ';
        $data['html_pagination'] = $html_pagination;
        $html_respon = $this->load->view('view_search_result', $data, TRUE);
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    // public function list_data()
    // {
    //     $db_name = 'tb_product';
    //     // $get_all_data = $this->db->query("select a.id,a.code,a.name,a.stock,a.qty_unit,b.name as unit_name, c.name as base_unit_name from $db_name a 
    //     // 								left join tb_unit b on a.id_unit = b.id
    //     // 								left join tb_base_unit c on b.id_base_unit = c.id 
    //     // 								 order by a.id DESC");
    //     $this->db->select('
    //         tb_product.*,
    //         tb_main_category.name AS main_category_name,
    //         tb_merk.name AS merk_name,
    //         tb_unit.name AS unit_name,
    //         tb_barcode_product.barcode AS barcode,
    //         MAX(tb_detail_stock.created_date) AS max_date
    //         ');
    //     $this->db->from('tb_product');
    //     $this->db->join('tb_main_category', 'tb_product.id_main_category = tb_main_category.id', 'left');
    //     $this->db->join('tb_merk', 'tb_product.id_merk = tb_merk.id', 'left');
    //     $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
    //     $this->db->join('tb_barcode_product', 'tb_product.id = tb_barcode_product.id_product', 'left');
    //     $this->db->join('tb_detail_stock', 'tb_product.id = tb_detail_stock.id_product', 'left');
    //     $this->db->order_by('tb_product.id', 'DESC');
    //     $this->db->group_by('tb_product.id');
    //     $get_all_data = $this->db->get();

    //     $data = array();
    //     $no = 0;
    //     foreach ($get_all_data->result() as $data_table) {
    //         //get last price 
    //         $id_product = $data_table->id;

    //         if ($data_table->stock <= $data_table->stock_minimum) {
    //             $status_stock = '<label class="label label-warning">Stok kurang</label>';
    //         } else {
    //             $status_stock = '<label class="label label-success">Stok Cukup</label>';
    //         }


    //         $no++;
    //         $row = array();
    //         $row[] = $no;
    //         $row[] = $data_table->code;
    //         $row[] = $data_table->barcode;
    //         $row[] = $data_table->name;
    //         $row[] = $data_table->unit_name;
    //         $row[] = number_format($data_table->stock, 0, '.', '.') . ' ' . $data_table->unit_name;
    //         $row[] = $status_stock;
    //         $row[] = $data_table->max_date;
    //         $row[] = '
    //         <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($data_table->id) . '" class="btn btn-default btn_conversion"><i class="fa fa-tv"></i> Lihat Konversi</a>
    //         ';
    //         $data[] = $row;
    //     }

    //     $ouput = array(
    //         "data" => $data
    //     );
    //     echo json_encode($ouput);
    // }

    // public function add()
    // {
    //     $this->app_data['data_warehouse'] = $this->db->get('tb_account_warehouse')->result();
    //     $this->app_data['date_stock'] = date('d-m-Y');
    //     $this->app_data['code_stock'] = $this->get_code();

    //     $this->app_data['page_title'] = "Data Stok";
    //     $this->app_data['view_file'] = 'add';
    //     echo Modules::run('template/main_layout', $this->app_data);
    // }

    public function get_product_auto()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $get_data_product = $this->db->query("select 
                a.id, 
                a.name,
                a.price,
                a.main_price,
                a.stock,
                b.name as unit_name
                from tb_product a 
                left join tb_unit b on a.id_unit = b.id   
                where a.name like '%$term%'  LIMIT 10 ")->result();
            if (!empty($get_data_product)) {
                foreach ($get_data_product as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->name,
                        'id' => $data_product->id,
                        'price' => $data_product->price,
                        'main_price' => $data_product->main_price,
                        'unit_name' => $data_product->unit_name,
                        'stock' => $data_product->stock
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_barcode_choosen()
    {
        $barcode = $this->input->post('barcode');
        $data_product = $this->db->query("select 
            a.id, 
            a.name,
            a.price,
            a.main_price,
            a.stock,
            b.name as unit_name
            from tb_product a 
            left join tb_unit b on a.id_unit = b.id 
            left join tb_barcode_product d on a.id = d.id_product
            where d.barcode = '$barcode' ")->row();

        if (!empty($data_product)) {
            $array_result = array(
                'label' => $data_product->name,
                'id' => $data_product->id,
                'price' => $data_product->price,
                'main_price' => $data_product->main_price,
                'unit_name' => $data_product->unit_name,
                'stock' => $data_product->stock
            );
            $array_respon = [
                'status' => TRUE,
                'item' => $array_result
            ];
        } else {
            $array_respon = [
                'status' => FALSE
            ];
        }
        echo json_encode($array_respon);
    }

    public function get_unit_request()
    {
        $id = $this->input->post('id');
        $get_data_current = $this->db->where(['id' => $id])->get('tb_product')->row();
        $data_unit = $this->db->where(['id' => $get_data_current->id_unit])->get('tb_unit')->row();
        //get other conversion
        $get_all_conversion = $this->db->where(['id_product' => $id])->order_by('qty')->get('tb_product_has_conversion')->result();
        $array_value = [
            'id' => 0,
            'name' => $data_unit->name,
            'qty' => 1
        ];
        $html_option = '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $data_unit->name . '</option>';
        foreach ($get_all_conversion as $item_conversion) {
            $array_value = [
                'id' => $item_conversion->id,
                'name' => $item_conversion->name,
                'qty' => $item_conversion->qty
            ];
            $html_option .= '<option value="' . $this->encrypt->encode(json_encode($array_value)) . '">' . $item_conversion->name . '</option>';
        }

        $array_respon = [
            'html_respon' => $html_option,
            'status' => TRUE,
            'data_product' => $this->encrypt->encode(json_encode($get_data_current))
        ];
        echo json_encode($array_respon);
    }


    public function insert_update_stock_qty($data)
    {
        $id_product = $data['id_product'];
        $id_warehouse = $data['id_warehouse'];
        $stock_qty = $data['stock_qty'];
        $id_transaction = $data['id_transaction'];
        $type_transaction = $data['type_transaction'];

        $get_data = Modules::run('database/find', 'tb_product_has_stock', ['id_product' => $id_product, 'id_warehouse' => $id_warehouse])->row();
        $stock_old = 0;
        if (!empty($get_data)) {
            //update
            $stock_old = $get_data->stock_qty;
            $new_stock = $stock_qty + $get_data->stock_qty;

            if ($type_transaction == 3) {
                $new_stock = $stock_qty; // stock opname
            }

            $array_update = ['stock_qty' => $new_stock];
            Modules::run('database/update', 'tb_product_has_stock', ['id' => $get_data->id], $array_update);
        } else {
            //insert
            $stock_old = 0;
            $new_stock = $stock_qty;
            $array_insert = [
                'id_product' => $id_product,
                'id_warehouse' => $id_warehouse,
                'stock_qty' => $stock_qty
            ];
            Modules::run('database/insert', 'tb_product_has_stock', $array_insert);
        }

        //insert stock card
        $array_stock_card = [
            'type_transaction' => $type_transaction,
            'id_transaction' => $id_transaction,
            'id_product' => $id_product,
            'id_warehouse' => $id_warehouse,
            'stock_qty_in' => $stock_qty,
            'stock_qty_out' => 0,
            'stock_qty_rest' => $new_stock
        ];
        $this->insert_stock_card($array_stock_card);

        return true;
    }

    public function insert_stock_card($data)
    {
        $type_transaction   = $data['type_transaction'];
        $id_transaction     = $data['id_transaction'];
        $id_product         = $data['id_product'];
        $id_warehouse       = $data['id_warehouse'];
        $stock_qty_in       = $data['stock_qty_in'];
        $stock_qty_out      = $data['stock_qty_out'];
        $stock_qty_rest     = $data['stock_qty_rest'];
        $created_by         = $this->session->userdata('us_id');

        $array_insert = [
            'type_transaction' => $type_transaction,
            'id_transaction' => $id_transaction,
            'id_product' => $id_product,
            'id_warehouse' => $id_warehouse,
            'stock_qty_in' => $stock_qty_in,
            'stock_qty_out' => $stock_qty_out,
            'stock_qty_rest' => $stock_qty_rest,
            'created_by' => $created_by
        ];
        Modules::run('database/insert', 'tb_product_has_card', $array_insert);
    }

    // public function add_item_product()
    // {
    //     //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $get_data_product = json_decode($this->encrypt->decode($this->input->post('data_product')));
    //     $unit         = json_decode($this->encrypt->decode($this->input->post('unit')));
    //     $qty           = $this->input->post('qty');
    //     $data_unit = $this->db->where(['id' => $get_data_product->id_unit])->get('tb_unit')->row();
    //     $unit_current = $this->db->where(['id' => $get_data_product->id_unit])->get('tb_unit')->row();

    //     $total_price = $get_data_product->main_price * ($qty * $unit->qty);
    //     if ($get_data_product->stock > 0) {
    //         //count data base unit
    //         if ($unit->qty) {
    //             if ($unit->qty) {
    //                 $base_unit_val = $get_data_product->stock % $unit->qty;
    //             } else {
    //                 $base_unit_val = 0;
    //             }

    //             //count unit val
    //             $unit_val      = ($get_data_product->stock - $base_unit_val) / $unit->qty;
    //             // stock current
    //             $stock_current = '';
    //             if ($unit_val > 0) {
    //                 $stock_current .= number_format($unit_val, 0, '.', '.') . '&nbsp;' . $unit->name;
    //             }
    //             if ($base_unit_val > 0) {
    //                 if ($unit_val > 0) {
    //                     $stock_current .= '<br>';
    //                 }
    //                 $stock_current .= number_format($base_unit_val, 0, '.', '.') . '&nbsp;' . $data_unit->name;
    //             }
    //         } else {
    //             $stock_current = number_format($get_data_product->stock, 0, '.', '.') . '&nbsp;' . $data_unit->name;
    //         }
    //     } else {
    //         $stock_current = '<span style="color:red;">0 ' . $data_unit->name . '</span>';
    //     }

    //     $get_data_product->html_stock = $stock_current;
    //     $data_encrypt = $this->encrypt->encode(json_encode($get_data_product));

    //     $price_current = $get_data_product->main_price * $unit->qty;

    //     $html_respon = '
    //     <tr class="tr_' . $get_data_product->id . '">
    //     <input type="hidden" name="data_product[' . $get_data_product->id . ']" value="' . $data_encrypt . '">
    //     <input type="hidden" name="id_conversion[' . $get_data_product->id . ']" value="' . $this->encrypt->encode(json_encode($unit)) . '">
    //     <input type="hidden" name="total_price[' . $get_data_product->id . ']" value="' . $this->encrypt->encode($total_price) . '">
    //     <input type="hidden" name="unit[' . $get_data_product->id . ']" value="' . $unit_current->name . '">
    //     <td>' . $get_data_product->code . '</td>
    //     <td>' . $get_data_product->name . '</td>
    //     <td>' . $data_unit->name . '</td>
    //     <td>' . $stock_current . '</td>
    //     <td><input type="hidden" name="price[' . $get_data_product->id . ']" value="' . $price_current . '"> Rp.' . number_format($get_data_product->main_price, 0, '.', '.') . '</td>
    //     <td>                                       
    //     ' . $qty . ' ' . $unit->name . '
    //     <input type="hidden" name="qty_product[' . $get_data_product->id . ']" value="' . $qty . '" class="form-control">
    //     </td>
    //     <td>
    //     <div class="form-group">
    //     <input type="text" name="price[' . $get_data_product->id . ']" value="' . number_format($price_current, 0, '.', '.') . '" class="form-control money_only price_' . $get_data_product->id . '">
    //     <span class="help-block"></span>
    //     </div>
    //     </td>
    //     <td>
    //     <a href="javascript:void(0)" class="btn btn-danger btn_cancel"><i class="fa fa-times"></i></a>
    //     </td>
    //     </tr>
    //     ';

    //     $array_respon = [
    //         'id' => $get_data_product->id,
    //         'status' => TRUE,
    //         'html_respon' => $html_respon
    //     ];
    //     echo json_encode($array_respon);
    // }

    //------------------ stock opname part ----------------------------



    // public function validate_review()
    // {

    //     $data = array();
    //     $data['error_string'] = array();
    //     $data['inputerror'] = array();
    //     $data['status'] = TRUE;

    //     // print_r($_POST);
    //     // exit;
    //     // $new_stock = $this->input->post('new_stock');
    //     // foreach ($new_stock as $key_new_stock => $val_new_stock) {
    //     //     $val_new_stock = str_replace('.', '', $val_new_stock);
    //     //     if ($val_new_stock == '' || $val_new_stock == 0) {
    //     //         $data['error_string'][] = 'belum diisi atau tidak boleh 0';
    //     //         $data['inputerror'][] = 'new_stock_' . $key_new_stock;
    //     //         $data['status'] = FALSE;
    //     //     }
    //     // }



    //     if (!isset($_POST['qty_product'])) {
    //         $data['error_string'][] = 'produk belum dpilih';
    //         $data['inputerror'][] = 'product';
    //         $data['status'] = FALSE;
    //     } else {
    //         $new_price = $this->input->post('price');
    //         foreach ($new_price as $key_new_price => $val_new_price) {
    //             $val_new_price = str_replace('.', '', $val_new_price);
    //             if ($val_new_price == '' || $val_new_price == 0) {
    //                 $data['error_string'][] = 'belum diisi atau tidak boleh 0';
    //                 $data['inputerror'][] = 'price_' . $key_new_price;
    //                 $data['status'] = FALSE;
    //             }
    //         }
    //     }

    //     if ($data['status'] == FALSE) {
    //         echo json_encode($data);
    //         exit();
    //     }
    // }

    // public function get_review_stock()
    // {
    //     $this->validate_review();
    //     $code = $this->input->post('code');
    //     $date = date('Y-m-d');
    //     $array_data_product = $this->input->post('data_product');
    //     $array_conversion = $this->input->post('id_conversion');
    //     $array_price = $this->input->post('price');
    //     $array_qty_product = $this->input->post('qty_product');
    //     $array_unit = $this->input->post('unit');

    //     $data_html_tr = '';
    //     $counter = 0;
    //     $grand_total = 0;
    //     foreach ($array_price as $key_price => $value_price) {
    //         $counter++;
    //         $data_product_current = json_decode($this->encrypt->decode($array_data_product[$key_price]));
    //         $data_conversion      = json_decode($this->encrypt->decode($array_conversion[$key_price]));
    //         $unit_current         = $array_unit[$key_price];


    //         if ($data_conversion->id) {
    //             $html_conversion = $data_conversion->name . '( ' . $data_conversion->qty . ' ' . $unit_current . ' ) ';
    //         } else {
    //             $html_conversion = $unit_current;
    //         }

    //         $total_price = str_replace('.', '', $array_qty_product[$key_price]) * str_replace('.', '', $array_price[$key_price]);
    //         $grand_total += $total_price;
    //         $data_html_tr .= '
    //         <tr>
    //         <td>' . $counter . '</td>
    //         <td>' . $data_product_current->code . '</td>
    //         <td>' . $data_product_current->name . '</td>
    //         <td>' . $data_product_current->html_stock . '</td>
    //         <td>Rp.' . number_format($data_product_current->main_price, 0, '.', '.') . '</td>
    //         <td>' . $html_conversion . '</td>
    //         <td>' . $array_qty_product[$key_price] . ' ' . $data_conversion->name . '</td>
    //         <td>Rp.' . $array_price[$key_price] . ' / ' . $data_conversion->name . '</td>
    //         <td>Rp.' . number_format($total_price, 0, '.', '.') . '</td>
    //         </tr>
    //         ';
    //     }

    //     $data_html = '
    //     <div class="table-responsive">
    //     <table class="table table-striped">
    //     <thead>
    //     <tr>
    //     <th>No</th>
    //     <th>Kode</th>
    //     <th>Nama Barang</th>
    //     <th>Sisa Stok</th>
    //     <th>Harga Satuan</th>
    //     <th>Satuan pengadaan</th>
    //     <th>Stok Baru</th>
    //     <th>Harga / unit</th>
    //     <th>Total</th>
    //     </tr>
    //     </thead>
    //     <tbody>
    //     ' . $data_html_tr . '
    //     <tr>
    //     <td colspan="8" class="text-center">
    //     <h3>GRAND TOTAL</h3>
    //     </td>
    //     <td>
    //     <h3>Rp.' . number_format($grand_total, 0, '.', '.') . '</h3>
    //     </td>
    //     </tr>
    //     </tbody>
    //     </table>
    //     </div>
    //     <div class="p-20 text-right">
    //     <small>(* Klik untuk simpan data)</small>
    //     <a href="javascript:void(0)" data-grandtotal = "' . $this->encrypt->encode($grand_total) . '" class="btn btn-success btn_save_stock"><i class="fa fa-save"></i> Simpan Stok</a>
    //     </div>
    //     ';
    //     $array_respon = [
    //         'html_respon' => $data_html,
    //         'status' => TRUE
    //     ];
    //     echo json_encode($array_respon);
    // }


    // public function save()
    // {
    //     $code = $this->get_code();

    //     $date = date('Y-m-d');
    //     $grand_total = $this->encrypt->decode($this->input->post('grand_total'));

    //     $array_data_product = $this->input->post('data_product');
    //     $array_conversion = $this->input->post('id_conversion');
    //     $array_price = $this->input->post('price');
    //     $array_qty_product = $this->input->post('qty_product');
    //     $array_unit = $this->input->post('unit');

    //     $this->db->trans_start();
    //     $array_insert_stock = array(
    //         'code' => $code,
    //         'date' => $date,
    //         'grand_total' => $grand_total,
    //         'created_by' => $this->session->userdata('us_id')
    //     );
    //     Modules::run('database/insert', 'tb_stock', $array_insert_stock);
    //     // $this->model->insert('tb_stock', $array_insert_stock);

    //     //insert detail
    //     $get_id_stock = $this->db->query("select id from tb_stock where code = '$code' ")->row_array();
    //     foreach ($array_price as $key_price => $value_price) {
    //         $data_product_current = json_decode($this->encrypt->decode($array_data_product[$key_price]));
    //         $data_conversion      = json_decode($this->encrypt->decode($array_conversion[$key_price]));
    //         $unit_current         = $array_unit[$key_price];
    //         $total_price = str_replace('.', '', $array_qty_product[$key_price]) * str_replace('.', '', $array_price[$key_price]);
    //         $real_stock = $data_conversion->qty * str_replace('.', '', $array_qty_product[$key_price]);
    //         $main_price = str_replace('.', '', $array_price[$key_price]) / $data_conversion->qty;

    //         $array_insert_detail = array(
    //             'id_stock_opname' => $get_id_stock['id'],
    //             'id_product' => $key_price, //key new price == id product
    //             'id_conversion_unit' => $data_conversion->id,
    //             'margin' => $data_product_current->stock,
    //             'new_stock' => $real_stock,
    //             'main_price' => $main_price,
    //             'stock_rest' => $real_stock,
    //             'unit_price' => str_replace('.', '', $array_price[$key_price]),
    //             'total_price' => $total_price,
    //             'created_by' => $this->session->userdata('us_id')
    //         );
    //         Modules::run('database/insert', 'tb_detail_stock', $array_insert_detail);
    //         //upadate stock
    //         $new_stock_current  = $real_stock + $data_product_current->stock;
    //         $array_update_stock_product = array(
    //             'stock' => $new_stock_current
    //         );
    //         Modules::run('database/update', 'tb_product', ['id' => $key_price], $array_update_stock_product);
    //     }

    //     //insert to accountant
    //     // $this->insert_to_accountant($grand_total, $code, $get_id_stock['id']);

    //     $this->db->trans_complete();
    //     if ($this->db->trans_status() == false) {
    //         $this->db->trans_rollback();
    //     } else {
    //         $this->db->trans_commit();
    //     }
    //     echo json_encode(array('status' => TRUE));
    // }

    // // private function insert_to_accountant($grand_total_product, $code, $id)
    // // {
    // //     //insert accountant
    // //     $account_reception_store        = json_decode($this->db->where(['field' => 'book_account_reception_store'])->get('tb_setting')->row()->value);

    // //     $account_reception_warehouse   = json_decode($this->db->where(['field' => 'book_account_reception_warehouse'])->get('tb_setting')->row()->value);
    // //     //insert debit and credit to account reception
    // //     $description_receiption = 'Stok Manual, kode stok : ' . $code;
    // //     $token = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
    // //     $this->model->insert(
    // //         'tb_book_account_has_detail',
    // //         [
    // //             'id_book_account' => $account_reception_store->debit,
    // //             'description' => $description_receiption,
    // //             'date' => date('Y-m-d'),
    // //             'debit' => $grand_total_product,
    // //             'credit' => 0,
    // //             'status_act' => 3,
    // //             'id_stock' => $id,
    // //             'token' => $token
    // //         ]
    // //     );
    // //     $this->model->insert(
    // //         'tb_book_account_has_detail',
    // //         [
    // //             'id_book_account' => $account_reception_warehouse->credit,
    // //             'description' => $description_receiption,
    // //             'date' => date('Y-m-d'),
    // //             'debit' => 0,
    // //             'credit' => $grand_total_product,
    // //             'status_act' => 3,
    // //             'id_stock' => $id,
    // //             'token' => $token
    // //         ]
    // //     );
    // // }

    // //------------------- end stock card ------------------------
    // public function history_stock()
    // {

    //     $this->app_data['page_title'] = "Daftar Produk";
    //     $this->app_data['view_file'] = 'history_stock_view';
    //     echo Modules::run('template/main_layout', $this->app_data);
    // }
    // public function list_data_stock_opname()
    // {
    //     // $get_data = $this->db->query("SELECT a.*, COUNT(b.id) as counter_result FROM tb_stock a 
    //     //                             LEFT JOIN tb_detail_stock b on  b.id_stock_opname = a.id GROUP by a.id order by a.id DESC");
    //     $this->db->select('
    //         tb_stock.*,
    //         tb_account_warehouse.name AS warehouse_name,
    //         COUNT(tb_detail_stock.id) AS counter_result,
    //         tb_receipt.code AS code_receipt
    //         ');
    //     $this->db->from('tb_stock');
    //     $this->db->join('tb_detail_stock', 'tb_stock.id = tb_detail_stock.id_stock_opname', 'left');
    //     $this->db->join('tb_receipt', 'tb_stock.id_receipt = tb_receipt.id', 'left');
    //     $this->db->join('tb_account_warehouse', 'tb_stock.id_supplier = tb_account_warehouse.id', 'left');
    //     $this->db->group_by('tb_stock.id');
    //     $this->db->order_by('tb_stock.id', 'DESC');
    //     $this->db->where(['tb_stock.id_account_warehouse' => 0]);
    //     $get_data = $this->db->get();
    //     $data = array();
    //     $no = 0;
    //     foreach ($get_data->result() as $data_table) {
    //         $date_explode = explode('-', $data_table->date);
    //         $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[0];
    //         $no++;
    //         $row = array();
    //         $row[] = $no;
    //         $row[] = $data_table->code;
    //         $row[] = $data_table->code_receipt ? $data_table->code_receipt : '-';
    //         $row[] = $date_html;
    //         $row[] = $data_table->warehouse_name;
    //         $row[] = number_format($data_table->counter_result, 0, '.', '.') . ' Barang';
    //         $row[] = 'Rp.' . number_format($data_table->grand_total, 0, '.', '.');
    //         $row[] = '<a class="btn btn-sm btn-primary-gradient btn_detail_stock" href="javascript:void(0)" title="detail stok opname" data-id="' . $this->encrypt->encode($data_table->id) . '" ><i class="fa fa-list"></i> Detail</a>';
    //         $data[] = $row;
    //     }
    //     $ouput = array(
    //         "data" => $data
    //     );
    //     echo json_encode($ouput);
    // }

    // public function get_detail_stock()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     // $get_data = $this->db->query("select a.*,b.code,b.date as date_stock,b.grand_total,c.code as code_product,c.name as product_name,c.qty_unit,d.name as unit_name,e.name as base_unit_name
    //     // 								from tb_detail_stock a
    //     // 								left join tb_stock b on a.id_stock_opname = b.id 
    //     // 								left join tb_product c on a.id_product = c.id
    //     // 								left join tb_unit d on c.id_unit = d.id 
    //     // 								left join tb_base_unit e on d.id_base_unit = e.id 
    //     //                                 where a.id_stock_opname  = '$id' ")->result();

    //     $this->db->select('
    //         tb_stock.*,
    //         tb_account_warehouse.name AS warehouse_name,
    //         tb_detail_stock.margin,
    //         tb_detail_stock.new_stock,
    //         tb_detail_stock.unit_price,
    //         tb_detail_stock.total_price,
    //         tb_product.code AS code_product,
    //         tb_product.name AS product_name,
    //         tb_unit.name AS unit_name,
    //         tb_product_has_conversion.name AS conversion_name,
    //         tb_product_has_conversion.qty AS qty_conversion
    //         ');
    //     $this->db->from('tb_stock');
    //     $this->db->join('tb_detail_stock', 'tb_stock.id = tb_detail_stock.id_stock_opname', 'left');
    //     $this->db->join('tb_product', 'tb_detail_stock.id_product = tb_product.id', 'left');
    //     $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
    //     $this->db->join('tb_product_has_conversion', 'tb_detail_stock.id_conversion_unit = tb_product_has_conversion.id', 'left');
    //     $this->db->join('tb_account_warehouse', 'tb_stock.id_supplier = tb_account_warehouse.id', 'left');
    //     $this->db->where(['tb_stock.id' => $id]);
    //     $get_data = $this->db->get()->result();

    //     $date_explode = explode('-', $get_data[0]->date);
    //     $date_html = $date_explode[2] . '-' . $date_explode[1] . '-' . $date_explode[2];

    //     $data_html = '';
    //     $data_html .= '
    //     <div class="col-md-12">
    //     <div class="col-md-3">
    //     <label>Kode Stok :</label>
    //     <h4>' . $get_data[0]->code . '</h4>
    //     </div>
    //     <div class="col-md-3">
    //     <label>Tanggal Stok :</label>
    //     <h4>' . $date_html . '</h4>
    //     </div>
    //     <div class="col-md-3">
    //     <label>Grand Total :</label>
    //     <h4>Rp.' . number_format($get_data[0]->grand_total, 0, '.', '.') . '</h4>
    //     </div>
    //     <div class="col-md-3">
    //     <label>Gudang :</label>
    //     <h4>' . $get_data[0]->warehouse_name . '</h4>
    //     </div>
    //     </div>
    //     <span class="clearfix"></span>
    //     <br>
    //     <table class="table table-bordered table_detail">
    //     <thead>
    //     <tr>
    //     <th>No</th>
    //     <th>Kode</th>
    //     <th>Nama Barang</th>
    //     <th>Stok Awal</th>
    //     <th>Satuan Pengadaan</th>
    //     <th>Stok Baru</th>
    //     <th>Harga Per unit</th>
    //     <th>Total Harga</th>
    //     </tr>
    //     </thead>
    //     <tbody>
    //     ';
    //     $no = 0;
    //     foreach ($get_data as $data_table) {

    //         if ($data_table->conversion_name) {
    //             $html_conversion = $data_table->conversion_name . ' ( ' . $data_table->qty_conversion . ' ' . $data_table->unit_name . ' )';

    //             $mod_stock  = $data_table->new_stock % $data_table->qty_conversion;
    //             $stock_unit = ($data_table->new_stock - $mod_stock) / $data_table->qty_conversion;
    //             $html_stock = '';
    //             if ($stock_unit > 0) {
    //                 $html_stock .= $stock_unit . ' ' . $data_table->conversion_name;
    //             }
    //             if ($mod_stock > 0) {
    //                 $html_stock .= $mod_stock . ' ' . $data_table->unit_name;
    //             }

    //             $unit_name = $data_table->conversion_name;
    //         } else {
    //             $html_conversion = $data_table->unit_name;
    //             $html_stock = $data_table->new_stock . ' ' . $data_table->unit_name;
    //             $unit_name = $data_table->unit_name;
    //         }

    //         $no++;
    //         $data_html .= '
    //         <tr>
    //         <td>' . $no . '</td>
    //         <td>' . $data_table->code_product . '</td>
    //         <td>' . $data_table->product_name . '</td>
    //         <td>' . number_format($data_table->margin, 0, '.', '.') . '&nbsp;' . $data_table->unit_name . '</td>
    //         <td>' . $html_conversion . '</td>
    //         <td>' . $html_stock . '</td>
    //         <td>Rp.' . number_format($data_table->unit_price, 0, '.', '.') . '/&nbsp;' . $unit_name . '</td>
    //         <td>Rp.' . number_format($data_table->total_price, 0, '.', '.') . '</td>
    //         </tr>
    //         ';
    //     }
    //     $data_html .= '
    //     <tr>
    //     <td colspan="7" align="center">GRAND TOTAL</td>
    //     <td>Rp.' . number_format($get_data[0]->grand_total, 0, '.', '.') . '</td>
    //     </tr>
    //     </tbody>
    //     <table>
    //     ';

    //     $array_respon = [
    //         'status' => TRUE,
    //         'html_respon' => $data_html
    //     ];
    //     echo json_encode($array_respon);
    // }

    // public function get_conversion_stock()
    // {
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $this->db->select('
    //         tb_product.*,
    //         tb_unit.name AS unit_name
    //         ');
    //     $this->db->from('tb_product');
    //     $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
    //     $this->db->where([' tb_product.id' => $id]);
    //     $get_product        = $this->db->get()->row();
    //     $get_conversion     = $this->db->where(['id_product' => $id])->get('tb_product_has_conversion')->result();

    //     $data['data_product'] = $get_product;
    //     $data['data_conversion'] = $get_conversion;

    //     $html_respon = $this->load->view('view_conversion', $data, TRUE);
    //     $array_respon = [
    //         'status' => TRUE,
    //         'html_respon' => $html_respon
    //     ];
    //     echo json_encode($array_respon);
    // }
}
