<div class="col-md-12">
    <table class="table table-hover table-data">
        <thead>
            <tr>
                <th>No</th>
                <th>Invoice</th>
                <th>Tanggal Piutang</th>
                <th>Nama Pelanggan</th>
                <th>Tanggal Jatuh Tempo</th>
                <th>Total</th>
                <th>Piutang</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $counter = 0;
            foreach ($data_csv as $item_csv) {
                $counter++;
                $class_bg = '';
                if (!empty($item_csv['customer'])) {
                    $class_bg = $item_csv['id_customer'] && !empty($item_csv['customer']) ? 'text-primary' : 'text-danger';
                }

                echo '
                        <tr class="' . $class_bg . '">
                            <td>' . $counter . '</td>
                            <td>' . $item_csv['invoice_code'] . '</td>
                            <td>' . $item_csv['invoice_date'] . '</td>
                            <td>' . $item_csv['customer'] . '</td>
                            <td>' . $item_csv['due_date'] . '</td>
                            <td>Rp.' . number_format($item_csv['price'], 0, '.', '.') . '</td>
                            <td>Rp.' . number_format($item_csv['rest_price'], 0, '.', '.') . '</td>
                        </tr>
                    ';
            }
            $encypt_data_save = $this->encrypt->encode(json_encode($data_csv));
            ?>
        </tbody>
    </table>
    <hr>
    <div class="mt-3 text-right">
        <form class="form-save-import">
            <small>(*klik untuk simpan data)</small>
            <input type="hidden" value="<?= $encypt_data_save; ?>" name="data">
            <button class="btn btn-primary btn_save_import">Simpan Data Piutang</button>
        </form>
    </div>
</div>