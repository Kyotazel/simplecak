<?php
$conf_ppn = Modules::run('helper/get_config', 'ppn_tax', true);
$ppn_tax = 0;
foreach ($conf_ppn as $item_ppn) {
    if ($item_ppn['params']) {
        $ppn_tax = $item_ppn['value'];
    }
}
?>
<div class="text-center shadow-3 p-3">
    <span class="badge badge-light tx-14">Kode Invoice :</span>
    <span class="h3 d-block">#<?= $data_credit->invoice_code; ?></span>
</div>
<form class="form-horizontal form_update_credit mt-3">
    <div class="col-md-12 mt-10">
        <?php
        if (!empty($data_invoice)) {
            echo '
                    <div class="form-group">
                        <label for="inputPassword3" class="control-label">Total Harga</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text font-weight-bold" style="padding:0 10px;">Rp.</div>
                            </div>
                            <input type="text" name="total_price" class="form-control bg-white font-weight-bold money_only count_price" value="' . number_format($data_invoice->total_price, 0, '.', '.') . '">
                        </div>
                        <span class="help-block text-danger notif_total_price"></span>
                    </div>
                    <div class="form-group d-flex m-0">
                        <label for="inputPassword3" class="control-label">Pajak PPN (' . $ppn_tax . ' %) &nbsp;&nbsp;</label>
                        <div data-value="' . $ppn_tax . '" class="main-toggle main-toggle-dark change_status_ppn_update ' . ($data_invoice->ppn_value ? 'on' : '') . '"><span></span></div>&nbsp;&nbsp;
                        <label for="" class="tx-18 font-weight-bold text-total-ppn">Rp.' . number_format($data_invoice->ppn_price, 0, '.', '.') . '</label>
                        <span class="help-block text-danger notif_ppn"></span>
                    </div>
                    <div class="form-group m-0">
                        <label for="inputPassword3" class="control-label">Diskon</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text font-weight-bold" style="padding:0 10px;">Rp.</div>
                            </div>
                            <input type="text" name="discount" class="form-control bg-white font-weight-bold money_only count_price" value="' . number_format($data_invoice->discount_price, 0, '.', '.') . '">
                        </div>
                        <span class="help-block text-danger notif_discount"></span>
                    </div>
                    <div class="form-group p-2 border-dashed">
                        <label for="inputPassword3" class="control-label">Total Invoice</label>
                        <label for="" class="d-block h3 text-total-invoice">Rp.' . number_format($data_invoice->total_invoice, 0, '.', '.') . '</label>
                    </div>
                ';
        } else {
            $html_option_credit = '';
            foreach ($credit_account as $item_account) {
                $selected = $item_account->id == $id_credit_account ? 'selected' : '';
                $html_option_credit .= '
                        <option ' . $selected . ' value="' . $item_account->id . '">' . $item_account->type_account . '-' . $item_account->code . ' ' . $item_account->name . '</option>
                    ';
            }

            $html_option_debit = '';
            foreach ($debit_account as $item_account) {
                $selected = $item_account->id == $id_debit_account ? 'selected' : '';
                $html_option_debit .= '
                        <option ' . $selected . ' value="' . $item_account->id . '">' . $item_account->type_account . '-' . $item_account->code . ' ' . $item_account->name . '</option>
                    ';
            }

            echo '
                <div class="form-group">
                    <label for="inputPassword3" class="control-label">Total Harga</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text font-weight-bold" style="padding:0 10px;">Rp.</div>
                        </div>
                        <input type="text" name="price" class="form-control bg-white font-weight-bold money_only" value="' . number_format($data_credit->price, 0, '.', '.') . '">
                    </div>
                    <span class="help-block text-danger notif_price"></span>
                </div>
                <hr>
                <span class="bagde badge-light tx-15"><i class="fa fa-tv"></i> Jurnal</span>
                <div class="form-group mb-3">
                    <label for="inputEmail3"  control-label">Akun Kas Piutang</label>
                    <select name="debit_account" class="form-control chosen" id="">
                        ' . $html_option_debit . '
                    </select>
                </div>
                <div class="form-group mb-3">
                    <label for="inputEmail3"  control-label">Akun Pendapatan Piutang</label>
                    <select name="credit_account" class="form-control chosen" id="">
                        ' . $html_option_credit . '
                    </select>
                </div>
            ';
        }
        ?>
        <div>

        </div>
        <hr>
        <div class="form-group m-0">
            <label for="inputPassword3" class="control-label">Tanggal Piutang</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text font-weight-bold" style="padding:0 10px;"><i class="fa fa-calendar"></i></div>
                </div>
                <input type="text" name="date" class="form-control bg-white font-weight-bold datepicker" readonly value="<?= Modules::run('helper/change_date', $data_credit->date, '-'); ?>">
            </div>
            <span class="help-block text-danger notif_date"></span>
        </div>
        <div class="form-group m-0">
            <label for="inputPassword3" class="control-label">Jatuh Tempo</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text font-weight-bold" style="padding:0 10px;"><i class="fa fa-calendar"></i></div>
                </div>
                <input type="text" name="due_date" class="form-control bg-white font-weight-bold datepicker" readonly value="<?= Modules::run('helper/change_date', $data_credit->deadline, '-'); ?>">
            </div>
            <span class="help-block text-danger notif_due_date"></span>
        </div>
        <div class="form-group m-0">
            <label for="inputPassword3" class="control-label">Keterangan</label>
            <textarea name="description" class="form-control" rows="5"><?= $data_credit->description; ?></textarea>
            <span class="help-block text-danger notif_description"></span>
        </div>
        <div class="form-group text-right mt-2">
            <small>(*Klik untuk simpan data)</small>
            <button type="submit" data-id="<?= $this->encrypt->encode($data_credit->id); ?>" class="btn btn-primary btn-rounded btn_do_update">Update Data</button>
        </div>
    </div>
</form>