<?php
$btn_payment = '';
if ($data_credit->status == FALSE) {
    $btn_payment = '
                        <a href="' . Modules::run('helper/create_url', 'credit/add_payment?data=' . urlencode($this->encrypt->encode($data_credit->id))) . '" class="btn btn-rounded btn-primary"><i class="fas fa-paper-plane"></i> Tambah Data Pembayaran</a>
                    ';
    $btn_payment = Modules::run('security/edit_access', $btn_payment);
}

if (strtotime($data_credit->deadline) < strtotime(date('Y-m-d'))) {
    //expired
    $label_expired = $data_credit->status ? '-' : '<span class="badge badge-pill badge-danger tx-14">Telah Jatuh Tempo</span>';
} else {
    //expired
    $label_expired = $data_credit->status ? '-' : '<span class="badge badge-pill badge-warning tx-14">Belum Jatuh Tempo</span>';
}



$age_credit = Modules::run('helper/interval_date', $data_credit->date, date('Y-m-d'));



$btn_edit = '';
$btn_cancel = '';
if ($data_credit->status == 0) {
    $btn_edit = Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $data_credit->id . '" class="btn btn-warning-gradient btn-rounded btn_edit_credit"><i class="fa fa-edit"></i> Update data</a> ');
    $btn_cancel = Modules::run('security/delete_access', ' <a href="javascript:void(0)" data-id="' . $data_credit->id . '" class="btn btn-light btn-rounded btn_reject"><i class="fa fa-times"></i> Batalkan Invoice</a> ');
}

$conf_status_credit = Modules::run('helper/get_config', 'status_credit', true);
$array_status_credit = [];
foreach ($conf_status_credit as $key => $value) {
    $array_status_credit[$value['value']] = [
        'params' => $value['params'],
        'label' => $value['label']
    ];
}

$status_credit = isset($array_status_credit[$data_credit->status]) ? $array_status_credit[$data_credit->status]['label'] : '';
$badge_status_credit = isset($array_status_credit[$data_credit->status]) ? $array_status_credit[$data_credit->status]['params'] : '';

$category_invoice = Modules::run('helper/get_config', 'invoice_type');

?>

<div class="card">
    <div class="card-header text-white bg-primary-gradient">
        <div class="row">
            <h5 class="col-8 m-0">Keterangan Piutang | Kode Transaksi : <b>#<?= $data_credit->code; ?></b></h5>
            <div class="col-4 text-right">
                <a href="<?= Modules::run('helper/create_url', 'credit'); ?>" class="btn btn-light btn-rounded btn_link font-weight-bold"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
            </div>
        </div>
    </div>

    <div class="card-body shadow-none">
        <div class="row">
            <div class="col-4 text-center shadow-3 p-3">
                <span class="badge badge-light tx-14">Kode Invoice :</span>
                <span class="h3 d-block">#<?= $data_credit->invoice_code; ?></span>
                <div class="border-dashed p-2">
                    <small class="d-block text-muted"><i class="fa fa-sticky-note text-muted"></i> Keterangan Piutang :</small>
                    <p class="m-0 p-0">
                        <?= $data_credit->description; ?>
                    </p>
                </div>
                <?php
                if ($data_credit->status == 2) {
                    echo '
                            <div class="col-md-12 mt-2 alert alert-outline-danger mg-b-0">
                                <div class="plan-card text-center">
                                    <h6 class="text-drak text-uppercase mt-2">PIUTANG INVOICE ( # ' . $data_credit->invoice_code . ') TELAH DIBATALKAN PADA TANGGAL <b>' . Modules::run('helper/date_indo', $data_credit->reject_date, '-') . '</b> OLEH <b>' . $data_credit->reject_user . '</b></h6>
                                </div>
                                <div class=" p-2 text-center">
                                    <small class="d-block"><i class="fa fa-sticky-note"></i> Catatan Pembatalan :</small>
                                    <p class="m-0 p-0">' . $data_credit->reject_note . '</p>
                                </div>
                            </div>
                        ';
                }
                ?>
                <div class="mt-2">
                    <?= $btn_edit . '&nbsp;' . $btn_cancel; ?>
                </div>
            </div>
            <div class="col-8 row">
                <div class="col-12 mb-2">
                    <span class="badge badge-light tx-14">Customer :</span>
                    <div class="row border-dashed">
                        <div class="col">
                            <div class=" mt-2 mb-2 text-primary text-uppercase h4"><b><?= $data_credit->member_name; ?></b></div>
                            <p class="tx-12" style="white-space: break-spaces;"><?= $data_credit->member_address; ?></p>
                        </div>
                        <div class="col-auto align-self-center ">
                            <div class="feature mt-0 mb-0">
                                <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                if (!empty($data_invoice)) {
                    echo '
                            <div class="col-12 mb-2">
                                <span class="badge badge-light tx-14">Detail Invoice :</span>
                                <div class="row border-dashed">
                                    <div class="col-md-3 border-right">
                                        <small>Total harga: <span class="badge badge-pill badge-light tx-12">' . (isset($category_invoice[$data_invoice->type]) ? $category_invoice[$data_invoice->type] : '-') . '</span></small>
                                        <label for="" class="m-0 h4 d-block">Rp.' . number_format($data_invoice->total_price, 0, '.', '.') . '</label>
                                    </div>
                                    <div class="col-md-3 border-right">
                                        <small>PPN: <span class="badge badge-pill badge-light">' . $data_invoice->ppn_value . ' %</span></small>
                                        <label for="" class="m-0 h4 d-block">Rp.' . number_format($data_invoice->ppn_price, 0, '.', '.') . '</label>
                                        <small class="d-block">(' . number_format($data_invoice->total_price, 0, '.', '.') . ' + ' . number_format($data_invoice->ppn_price, 0, '.', '.') . ')</small>
                                    </div>
                                    <div class="col-md-3 border-right">
                                        <small>Discount:</small>
                                        <label for="" class="m-0 h4 d-block">Rp.' . number_format($data_invoice->discount_price, 0, '.', '.') . '</label>
                                        <small class="d-block">(' . number_format($data_invoice->grand_total_price, 0, '.', '.') . ' - ' . number_format($data_invoice->discount_price, 0, '.', '.') . ')</small>
                                    </div>
                                    <div class="col-md-3">
                                        <small>Total Invoice:</small>
                                        <label for="" class="m-0 h4 d-block">Rp.' . number_format($data_invoice->total_invoice, 0, '.', '.') . '</label>
                                    </div>
                                </div>
                            </div>
                        ';
                }
                ?>

                <div class="col-6 row align-items-center border-right">
                    <div class="col-6">
                        <span class="badge badge-light tx-14">Nominal Piutang :</span>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text font-weight-bold" style="padding:0 10px;">Rp.</div>
                            </div>
                            <input type="text" class="form-control border-dashed bg-white font-weight-bold" readonly value="<?= number_format($data_credit->price, 0, '.', '.'); ?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <span class="badge badge-light tx-14">Sisa Tanggungan :</span>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text font-weight-bold" style="padding:0 10px;">Rp.</div>
                            </div>
                            <input type="text" class="form-control border-dashed bg-white font-weight-bold" readonly value="<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?>">
                        </div>
                    </div>
                    <div class="row col-8 mt-2">
                        <div class="col">
                            <div class="">
                                <span class="badge badge-light tx-14">Total Dibayar :</span>
                            </div>
                            <div class="h3 mt-1 mb-1"><b>Rp.<?= number_format($data_credit->total_payment, 0, '.', '.'); ?></b><span class="text-success tx-13 ml-2"></span></div>
                        </div>
                        <div class="col-auto align-self-center ">
                            <div class="feature mt-0 mb-0">
                                <i class="fe fe-monitor project bg-primary-transparent text-primary "></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <span class="badge badge-pill badge-<?= $badge_status_credit; ?> tx-14"><?= $status_credit; ?></span>
                    </div>
                </div>
                <div class="col-6 row align-items-center">
                    <div class="col-6">
                        <span class="badge badge-light tx-14">Tanggal Piutang :</span>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text font-weight-bold" style="padding:0 10px;"><i class="fa fa-calendar"></i></div>
                            </div>
                            <input type="text" class="form-control border-dashed bg-white font-weight-bold" readonly value="<?= Modules::run('helper/date_indo', $data_credit->date, '-'); ?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <span class="badge badge-light tx-14">Jatuh Tempo :</span>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text font-weight-bold" style="padding:0 10px;"><i class="fa fa-calendar"></i></div>
                            </div>
                            <input type="text" class="form-control border-dashed bg-white font-weight-bold" readonly value="<?= Modules::run('helper/date_indo', $data_credit->deadline, '-'); ?>">
                        </div>
                    </div>
                    <div class="col-12 mt-1">
                        <label class="d-block">
                            <span class="badge badge-light tx-14">Usia Piutang :</span>
                            <span class="h3 font-weight-bold"><?= $data_credit->status == 0 ? $age_credit->days . ' HARI' : '-'; ?> </span>
                            <?= $label_expired; ?>
                        </label>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="">
            <!-- <h3 class="text-green mb-10">Form Pembayaran :</h3> -->
            <form class="form-horizontal form_payment">
                <div class="col-md-12 mt-10">
                    <div class="row">
                        <div class="col-8">
                            <h5 class="text-green m-0"><span class="badge-light badge tx-18"><i class="fe fe-monitor "></i> Detail Angsuran Pembayaran</span></h5>
                        </div>
                        <div class="col-4 text-right">
                            <?= $btn_payment; ?>
                        </div>
                        <?php
                        $data['payment_method'] = Modules::run('helper/get_config', 'payment_method');
                        foreach ($data_detail as $item_detail) {
                            $data['payment'] = $item_detail;
                            $html_data = $this->load->view('_partials/component_list_payment', $data, TRUE);
                            echo $html_data;
                        }
                        if (empty($data_detail)) {
                            echo '
                                <div class="col-12 text-center py-5 shadow-3">
                                    <div class="plan-card text-center">
                                        <i class="fas fa-file plan-icon text-primary"></i>
                                        <h6 class="text-drak text-uppercase mt-2">Data Kosong</h6>
                                        <small class="text-muted">Tidak ada pembayaran.</small>
                                    </div>
                                </div>
                                ';
                        }
                        ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <div class="html_respon_modal"></div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>