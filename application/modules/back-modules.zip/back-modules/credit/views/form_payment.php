<?php
$btn_payment = '';
if ($data_credit->status == FALSE) {
    $btn_payment = '
                        <a href="' . base_url('admin/credit/add_payment?data=' . urlencode($this->encrypt->encode($data_credit->id))) . '" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Tambah Data Pembayaran</a>
                    ';
}

if (strtotime($data_credit->deadline) < strtotime(date('Y-m-d'))) {
    //expired
    $label_expired = '<label class="text-danger text-bold font-weight-bold">Telah Jatuh Tempo</label>';
} else {
    //expired
    $label_expired = '<label class="text-success text-bold font-weight-bold">Belum Jatuh Tempo</label>';
}
$payment_method = Modules::run('helper/get_config', 'payment_method');

?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-8">
            <div class="card">
                <div class="card-body">
                    <form class="form-horizontal form_payment">
                        <div class="row">
                            <div class="col-md-8">
                                <h3>Form Pembayaran</h3>
                            </div>
                            <div class="col-md-4 text-right">
                                <a href="<?= Modules::run('helper/create_url', 'credit/detail?data=' . urlencode($this->encrypt->encode($data_credit->id))); ?>" class="btn btn-primary btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                            </div>
                        </div>

                        <div class="col-md-12 text-center mb-3 row">
                            <div class="col-md-12">
                                <small class="text-center">Kode Invoice :</small>
                                <h2 class="text-center">#<?= $data_credit->invoice_code; ?></h2>
                                <div class=" p-3 shadow div_center" style="width:450px;margin:0 auto;">
                                    <small class="text-red">Sisa Tanggungan :</small>
                                    <h2 class="text-red">Rp.<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?></h2>
                                    <div class="alert alert-outline-warning rounded-10" role="alert">
                                        <small><i class="fa fa-credit-card"></i> Saldo Dompet Customer</small> : <strong class="tx-20"> Rp.<?= number_format($data_credit->saldo_customer, 0, '.', '.'); ?></strong>
                                        <label for="" class="d-block m-0">(<i class="fa fa-user"></i> <?= $data_credit->member_name; ?>)</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 mt-10">
                            <div class="form-group row mb-3">
                                <label for="inputEmail3" class="col-sm-3 control-label">Nominal Pembayaran (Rp)</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <input type="text" class="form-control form-control-lg money_only" name="price" style="font-size:20px;">
                                    </div>
                                    <span class="help-block text-danger notif_price"></span>
                                </div>
                            </div>

                            <div class="form-group row mb-3">
                                <label for="inputEmail3" class="col-sm-3 control-label">Metode Pembayaran</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <select name="payment_method" class="form-control chosen">
                                            <option value="">Pilih Metode Pembayaran</option>
                                            <?php
                                            foreach ($payment_method as $key => $value) {
                                                echo ' <option value="' . $this->encrypt->encode($key) . '">' . $value . '</option> ';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <span class="help-block text-danger notif_method_payment"></span>
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label for="inputEmail3" class="col-sm-3 control-label">Tanggal Pembayaran</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <input type="text" class="form-control form-control-lg datepicker bg-white" readonly name="date" style="font-size:20px;">
                                    </div>
                                    <span class="help-block text-danger notif_date"></span>
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label for="inputPassword3" class="col-sm-3 control-label">Keterangan</label>

                                <div class="col-sm-9">
                                    <textarea name="note" class="form-control" rows="8"></textarea>
                                    <span class="help-block text-danger notif_note"></span>
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label for="inputPassword3" class="col-sm-3 control-label">Upload Bukti Pembayaran (Optional)</label>
                                <div class="col-sm-5">
                                    <input type="file" class="form-control" name="upload" onchange="loadImg('#frame')">
                                    <span class="help-block text-danger"></span>
                                </div>
                                <div class="col-sm-4">
                                    <img id="frame" width="100px" height="100px" />
                                </div>
                            </div>
                            <div class="form-group text-right border-top pt-3">
                                <small>(*Klik untuk simpan data)</small>
                                <button type="submit" data-id="<?= $this->encrypt->encode($data_credit->id); ?>" class="btn btn-primary btn_preview">Simpan Data Pembayaran</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="max-width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 html_payment_preview row"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>