<div class="main-content">
    <div class="page-content">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="page-title mb-1"><?php echo $title ?></h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active"><?php echo $subtitle ?></li>
                        </ol>
                    </div>
                    <div class="col-md-4">
                        <div class="float-right d-md-block">
                            <div class="dropdown">
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- end page title end breadcrumb -->

        <div class="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form class="form-import">
                                    <div class="row">
                                        <div class="col-md-6 html_code">
                                            <div class="col-md-12 form-group">
                                                <label>Masukan CSV</label>
                                                <input type="file" class="form-control" name="upload" accept=".csv">
                                                <span class="help-block text-danger"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">&nbsp;</label><br>
                                            <button type="submit" class="btn btn-primary btn_do_import"><i class="fa fa-search"></i> Proses Data</button>
                                            &nbsp;|&nbsp;
                                            <a href="<?= base_url('credit'); ?>"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                                        </div>

                                    </div>
                                </form>
                                <hr>
                                <div class="html_respon mt-2">
                                    <div class="bg-empty-data"></div>
                                    <h5 class="text-center text-muted">Isilah form import terlebih dahulu</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->


            </div> <!-- container-fluid -->
        </div>
        <!-- end page-content-wrapper -->
    </div>
    <!-- End Page-content -->
</div>