<?php
if (strtotime($data_credit->deadline) < strtotime(date('Y-m-d'))) {
    //expired
    $label_expired = '<label class="label label-warning">Telah Jatuh Tempo</label>';
} else {
    //expired
    $label_expired = '<label class="label label-success">Belum Jatuh Tempo</label>';
}
?>

<div class="text-center shadow-3 p-3">
    <span class="badge badge-light tx-14">Kode Invoice :</span>
    <span class="h3 d-block">#<?= $data_credit->invoice_code; ?></span>
    <div class="border-dashed p-2">
        <small class="d-block text-muted"><i class="fa fa-sticky-note text-muted"></i> Keterangan Piutang :</small>
        <p class="m-0 p-0">
            <?= $data_credit->description; ?> </p>
    </div>
    <small class="text-center">Sisa Tanggungan :</small>
    <h2 class="text-red p-3 text-center div_center">Rp.<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?></h2>
</div>
<form class="form-horizontal form_reject mt-3">
    <div class="col-md-12 mt-10">
        <div class="form-group">
            <label for="inputPassword3" class="control-label">Keterangan Pembatalan</label>
            <textarea name="note" class="form-control" rows="8"></textarea>
            <span class="help-block text-danger"></span>
        </div>
        <div class="form-group text-right">
            <small>(*Klik untuk simpan data)</small>
            <button type="submit" data-id="<?= $this->encrypt->encode($data_credit->id); ?>" class="btn btn-primary btn-rounded btn_save_reject">Lanjutkan Pembatalan</button>
        </div>
    </div>
</form>