<?php
$label_status = $payment->status ? '<span class="badge badge-success tx-12">Lunas</span>' : '<span class="badge badge-light tx-12">Belum Lunas</span>';
$payment_text = isset($payment_method[$payment->payment_method]) ? $payment_method[$payment->payment_method] : '-';
?>
<div class="col-12 p-2 shadow-3 row mb-2">
    <div class="col-2 border-right">
        <small class="d-block"><i class="fa fa-calendar text-muted"></i> Tanggal Pembayaran :</small>
        <label for="" class="m-0 font-weight-bold tx-16 d-block"> <?= Modules::run('helper/date_indo', $payment->date, '-'); ?></label>
        <?= $label_status; ?>
        <a href="javascript:void(0)" data-id="<?= $payment->id; ?>" class="btn btn-danger btn-sm btn_delete_payment float-right"><i class="fa fa-trash"></i> </a>
    </div>
    <div class="col-4 border-right">
        <small class="d-block text-muted"><i class="fa fa-sticky-note text-muted"></i> Catatan Pembayaran :</small>
        <div class=""><?= nl2br($payment->note); ?></div>
    </div>
    <div class="col-3 border-right row">
        <div class="col-6">
            <small class="d-block text-muted"><i class="fa fa-tv text-muted"></i> Metode Pembayaran :</small>
            <label for="" class="m-0 font-weight-bold h4 d-block"> <?= $payment_text; ?></label>
        </div>
        <div class="col-6">
            <?php
            if (!empty($payment->image)) {
                echo '
                    <img src="' . base_url('upload/payment/' . $payment->image) . '" width="80px" height="80px" style="object-fit:cover;" class="border-dashed" alt="">
                    ';
            }
            ?>
        </div>
    </div>
    <div class="col-3">
        <div class="row">
            <div class="col">
                <div class=""><small class="text-muted">Nominal Pembayaran :</small></div>
                <div class="h4 mt-1 mb-1"><b>Rp.<?= number_format($payment->payment_price, 0, '.', '.') ?></b><span class="text-success tx-13 ml-2"></span></div>
            </div>
            <div class="col-auto align-self-center ">
                <div class="feature mt-0 mb-0">
                    <i class="fe fe-monitor project bg-primary-transparent text-primary "></i>
                </div>
            </div>
        </div>
    </div>
</div>