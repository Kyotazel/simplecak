
<div class="container">
    <div class="row justify-content-center">
        <div class="col-8">
            <div class="card">
                <div class="card-body">
                    <form class="form-input-credit">
                        <div class="row mb-3">
                            <div class="col-md-8">
                                <h3>Form Input Piutang </h3>
                            </div>
                            <div class="col-md-4 text-right">
                                <a href="<?= Modules::run('helper/create_url', 'credit'); ?>" class="btn btn-primary btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Customer</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <select name="id_customer" class="form-control chosen">
                                        <?= $html_option_member; ?>
                                    </select>
                                </div>
                                <span class="help-block text-danger notif_id_customer"></span>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Kode Invoice</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="text" class="form-control form-control-lg" name="invoice" style="font-size:20px;">
                                </div>
                                <span class="help-block text-danger notif_invoice"></span>
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Nominal Piutang (Rp)</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="text" class="form-control form-control-lg money_only" name="price" style="font-size:20px;">
                                </div>
                                <span class="help-block text-danger notif_price"></span>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Tanggal Piutang</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="text" class="form-control datepicker bg-white" readonly name="date">
                                </div>
                                <span class="help-block text-danger notif_date"></span>
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Tanggal Jatuh Tempo</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="text" class="form-control datepicker bg-white" readonly name="due_date">
                                </div>
                                <span class="help-block text-danger notif_due_date"></span>
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Keterangan</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <textarea name="description" class="form-control" rows="13"></textarea>
                                </div>
                                <span class="help-block text-danger notif_description"></span>
                            </div>
                        </div>
                        <hr>
                        <span class="bagde badge-light tx-15"><i class="fa fa-tv"></i> Jurnal</span>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Akun Kas Piutang</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <select name="debit_account" class="form-control chosen" id="">
                                        <?php
                                        foreach ($debit_account as $item_account) {
                                            echo '
                                                    <option value="' . $item_account->id . '">' . $item_account->type_account . '-' . $item_account->code . ' ' . $item_account->name . '</option>
                                                ';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <span class="help-block text-danger notif_debit_account"></span>
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-sm-3 control-label">Akun Pendapatan Piutang</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <select name="credit_account" class="form-control chosen" id="">
                                        <?php
                                        foreach ($credit_account as $item_account) {
                                            echo '
                                                    <option value="' . $item_account->id . '">' . $item_account->type_account . '-' . $item_account->code . ' ' . $item_account->name . '</option>
                                                ';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <span class="help-block text-danger notif_debit_account"></span>
                            </div>
                        </div>
                        <div class="form-group text-right border-top pt-3">
                            <small>(*Klik untuk simpan data)</small>
                            <button type="submit" class="btn btn-primary btn_save">Simpan Data Piutang</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade in" id="modal-form">
    <div class="modal-dialog " style="max-width:50%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h2 class="text-center">Preview Pembayaran</h2>
                            <div class="col-md-12 text-center">
                                <small class="text-center">sisa Tanggungan :</small>
                                <h3 class="text-red  shadow div_center p-3" style="width:300px;margin:0 auto;">Rp.<?= number_format($data_credit->rest_credit, 0, '.', '.'); ?></h3>
                            </div>
                        </div>
                        <div class="col-md-12 html_payment_preview row"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>