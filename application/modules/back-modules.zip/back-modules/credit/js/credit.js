var controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var table_paid;
var table_has_paid;
var id_use;
var ppn_price = 0;
var ppn_value = 0;
$(document).ready(function(){
    if ($('.table_credit').length) {
        list_data_credit();
    }
    

    // $('.table_payment').DataTable();
    $('.datepicker_form').datepicker();
    $('.chosen').chosen();
});


$('.btn_search').click(function (e) {
    e.preventDefault();
	//   //defined form
    list_data_credit();
});

function list_data_credit() {
    showLoading();
    var formData = new FormData($('#form-search')[0]);
    // formData.append('status_search', status);
    $.ajax({
        url: controller+'list_data/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if ($.fn.DataTable.isDataTable('.table_credit')) {
                table.destroy();
            }
            table = $('.table_credit').DataTable({
                data: data.list.data
            });

            $(document).find('#cover-search').remove();
            $('.form-print').append(`
                <div id="cover-search"><input type="hidden" name="search" value="`+data.search+`"></div>
            `);
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
	});//end ajax
}


$('.btn_add').click(function () {
    hideLoading();
    save_method = 'add';
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('.form-input')[0].reset();
    $('.modal-title').text('TAMBAH DATA');
    $('#modal-form').modal('show');
});

$('.btn_save').click(function (e) {
    e.preventDefault();
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-input-credit')[0]);
    var url;
    $.ajax({
        url: controller + '/save',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                alert_success('Data Berhasil Disimpan');
                window.location.href = controller+'detail?data='+data.id;
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.notif_' + data.inputerror[i]).parent().addClass('has-error');
                    $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
            hideLoading();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_edit_credit', function () {
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    var id_credit = $(this).data('id');
    $.ajax({
        url: controller + '/get_form_edit',
        type: "POST",
        data: {'id':id_credit},
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.modal-title').text('UPDATE DATA');
                $('.html_respon_modal').html(data.html_respon);
                $('#modal-form').modal('show');
                $('.html_respon_modal').find('.datepicker').datepicker({
                    autoclose: true,
                    format: 'dd-mm-yyyy'
                });
                $('.html_respon_modal').find('.chosen').chosen();
            } 
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_do_update', function (e) {
    e.preventDefault();
    var id = $(this).data('id');
    swal({
        title: 'Apakah anda yakin?',
        text: "data akan diupdate",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,simpan data',
        cancelButtonText: 'Batal'
    },
    function(isConfirm) {
        if (isConfirm) {
            showLoading();
            var formData = new FormData($('.form_update_credit')[0]);
            formData.append('ppn_price', ppn_price);
            formData.append('ppn_value', ppn_value);
            formData.append('id', id);
            $.ajax({
                url: controller + '/update_credit',
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    hideLoading();
                    if (data.status) {
                        alert_success('data berhasil disimpan');
                        location.reload();
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('.notif_' + data.inputerror[i]).parent().parent().addClass('has-error');
                            $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                        }
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    hideLoading();
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});



$(document).on('click', '.change_status_ppn_update', function () {
    $(this).toggleClass('on');
    count_update_invoice();
});

$(document).on('keyup', '.count_price', function () { 
    count_update_invoice();
});
function count_update_invoice() {
    var total_price = $(document).find('[name="total_price"]').val();
    var discount = $(document).find('[name="discount"]').val();
    ppn_value = 0;
    if ($('.change_status_ppn_update').hasClass('on')) {
        ppn_value = $('.change_status_ppn_update').data('value');
    }
    ppn_price = 0;
    if (parseInt(ppn_value) > 0) {
         ppn_price = (parseInt(ppn_value)/100) * parseInt(clear_dot_value(total_price));
    }


    var total_invoice = (parseInt(clear_dot_value(total_price)) + ppn_price) - parseInt(clear_dot_value(discount));
    $(document).find('.text-total-ppn').text('Rp.' + money_function(ppn_price.toString()));
    $(document).find('.text-total-invoice').text('Rp.' + money_function(total_invoice.toString()));
}



$('.btn_preview').click(function (e) {
    e.preventDefault();
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    var src_image = $('#frame').attr('src');
    var html_resume_credit = $('.html_resume_credit').html();
    // $('.html_resume_credit_modal').html(html_resume_credit);
    //defined form
    var id = $(this).data('id');
    var formData = new FormData($('.form_payment')[0]);
    formData.append('id', id);
    $.ajax({
        url: controller + '/preview_save_payment',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.html_payment_preview').html(data.html_respon);
                $('#modal-form').modal('show');
                $(document).find('.image_proof').attr("src", src_image);
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('.notif_' + data.inputerror[i]).parent().parent().addClass('has-error');
                    $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                }
            }
           
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_save_payment', function () {
    var id = $(this).data('id');
    swal({
        title: 'Apakah anda yakin?',
        text: "simpan data pembayaran",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,simpan data',
        cancelButtonText: 'Batal'
    },
    function(isConfirm) {
        if (isConfirm) {
            showLoading();
            var formData = new FormData($('.form_payment')[0]);
            formData.append('id', id);
            $.ajax({
                url: controller + '/save_payment',
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    showLoading();
                    if (data.status) {
                        alert_success('data berhasil disimpan');
                        window.location.href = controller + '/detail?data=' + data.id_encrypt
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('.notif_' + data.inputerror[i]).parent().parent().addClass('has-error');
                            $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                        }
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    hideLoading();
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});

function loadImg(target_container){
    $(target_container).attr('src', URL.createObjectURL(event.target.files[0]));
}

$(document).on('click', '.btn_delete_payment', function () {
    var id = $(this).data('id');
    swal({
        title: 'Apakah anda yakin?',
        text: "hapus data pembayaran",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Hapus Data',
        cancelButtonText: 'Batal'
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: controller + '/delete_payment',
                type: "POST",
                data: {'id':id},
                dataType: "JSON",
                success: function (data) {
                    location.reload();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert_error('something wrong');
                }
            });//end ajax
        }
    })
});


// $(document).on("change", ".checkbox_status", function () {
//     var id = $(this).val();
//     if ($(this).prop('checked')) {
//         status_active = 1;
//     }else{
//         status_active = 0;
//     }
//     $.ajax({
//         url: controller+'/update_status',
//         type: "POST",
//         data: {'status':status_active,'id':id},
//         dataType :"JSON",
//         success: function(data){
//                 alert_success('status berhasil diupdate');
//         },
//         error:function(jqXHR, textStatus, errorThrown)
//         {
//             hideLoading();
//             alert_error('something wrong');
//         }
//     });//end ajax
// });

$(document).on('click', '.btn_reject', function () {
    var id = $(this).data('id');
    $('.modal-title').text('BATALKAN PIUTANG');
    save_method = 'update';
    var PostData = { 'id': id };
    $.ajax({
        url: controller + '/get_form_reject',
        type: "POST",
        data: PostData,
        dataType: "JSON",
        success: function (data) {
            id_use = data.id;
            $('.html_respon_modal').html(data.html_respon);
            $('#modal-form').modal('show');
            hideLoading();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_save_reject', function (e) {
    e.preventDefault();
    var id = $(this).data('id');
    var note = $('[name="note"]').val();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    if (note == '') {
        hideLoading();
        $('[name="note"]').next().text('harus di isi');
        $('[name="note"]').parent().parent().addClass('has-error');
    } else {
        swal({
            title: 'Apakah anda yakin?',
            text: "Piutang ini akan dibatalkan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya,lanjutkan',
            cancelButtonText: 'Batal'
        },
        function (isConfirm) {
            if (isConfirm) {
                showLoading();
                $.ajax({
                    url: controller + '/save_reject',
                    type: "POST",
                    data: { 'id': id, 'note': note },
                    dataType: "JSON",
                    success: function (data) {
                        $('#modal-form').modal('hide');
                        alert_success('data berhasil dibatalkan');
                        location.reload();
                        hideLoading();
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        hideLoading();
                        alert_error('something wrong');
                    }
                });//end ajax
            }
        });
    }
});

$('[name="type_search"]').change(function () {
    var type = $(this).val();
    if (type == '1') {
        $('.html_date_range').show();
        $('.html_code').hide();
    } else {
        $('.html_date_range').hide();
        $('.html_code').show();
    }
});


$('.btn_search_credit').click(function (e) {
    e.preventDefault();
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-search')[0]);
    $.ajax({
        url: controller + '/get_history_credit',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                // alert_success('Data Berhasil Disimpan');
                $('.html_respon').html(data.html_respon);
                $('#table_history').DataTable();
                $('.table_history').DataTable();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$('.btn_search_payment').click(function (e) {
    e.preventDefault();
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-search')[0]);
    $.ajax({
        url: controller + '/get_history_payment',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                // alert_success('Data Berhasil Disimpan');
                $('.html_respon').html(data.html_respon);
                $('#table_history').DataTable();
                $('.table_history').DataTable();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            hideLoading();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.reset_date', function () {
    type = $(this).data('date');
    if (type == 'date-from') {
        $('[name="date_from"]').val('');
    }
    if (type == 'date-to') {
        $('[name="date_to"]').val('');
    }
});

$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
});

$(document).on('keyup', '.money_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    var money = money_function(qty, '');
    $(this).val(money);
});

$('.btn_do_import').click(function (e) {
    e.preventDefault();
    swal.showLoading();
    showLoading();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //defined form
    var formData = new FormData($('.form-import')[0]);
    var url;
    $.ajax({
        url: controller + '/do_import_data',
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                alert_success('Prview Data');
                $('.html_respon').html(data.html_respon);
                $('.table-data').DataTable();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }
    });//end ajax
});

$(document).on('click', '.btn_save_import', function (e) {
    e.preventDefault();
    swal({
        title: 'Apakah anda yakin?',
        text: "Data piutang akan disimpan",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,lanjutkan',
        cancelButtonText: 'Batal'
    },
    function(isConfirm) {
        if (isConfirm) {
            var formData = new FormData($('.form-save-import')[0]);
             swal.showLoading();
            var url;
            $.ajax({
                url: controller + '/save_import_data',
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
                    hideLoading();
                    if (data.status) {
                        location.href = controller;
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    hideLoading();
                    alert_error('something wrong');
                }
            });//end ajax
        } else {
            $('.btn_save_reject').button('reset');
        }
    });
});

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    // return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    return rupiah;
}


function clear_dot_value(value) {
	var array_value = value.split(".");
	var count_array = array_value.length;
	payment_value = value;
	for (var i = 0; i < count_array; i++) {
		payment_value = payment_value.replace(".", "");
	}
	return payment_value;
}
