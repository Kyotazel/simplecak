<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Credit extends CommonController
{
    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    var $module_name = 'credit';
    var $module_directory = 'credit';
    var $module_js = ['credit'];
    var $app_data = [];

    private function _init()
    {
        $this->app_data['module_js']  = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function get_code()
    {
        $number_text = 0;
        $simbol = 'CD';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_credit")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_credit WHERE id IN(SELECT MAX(id) FROM tb_credit)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function get_payment_code()
    {
        $number_text = 0;
        $simbol = 'PC';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        $get_data_exist = $this->db->query("select max(code) as max_code from tb_credit_has_payment")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function index()
    {
        $this->app_data['data_customer']     = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();
        $this->app_data['page_title']     = "Data Piutang";
        $this->app_data['view_file']     = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        Modules::run('security/is_ajax');
        $date_from  = Modules::run('helper/change_date', $this->input->post('date_from'), '-');
        $date_to    = Modules::run('helper/change_date', $this->input->post('date_to'), '-');
        $status_expired  = $this->input->post('status_expired');
        $invoice = $this->input->post('invoice');
        $arr_customer = $this->input->post('customer');

        $array_where = [];
        $array_where_in = [];
        $array_where['tb_credit.status'] = 0;

        if ($date_from) {
            $array_where['tb_credit.date >='] = $date_from;
        }
        if ($date_to) {
            $array_where['tb_credit.date <='] = $date_to;
        }
        if ($status_expired) {

            if ($status_expired == 1) {
                $array_where['tb_credit.deadline >='] = date('Y-m-d');
            }
            if ($status_expired == 2) {
                $array_where['tb_credit.deadline <='] = date('Y-m-d');
            }
        }
        if ($invoice) {
            $array_where['tb_credit.invoice_code'] = $invoice;
        }
        if (!empty($arr_customer)) {
            $array_where_in['tb_credit.id_customer '] = $arr_customer;
        }

        $array_query = [
            'select' => '
                tb_credit.*,
                COUNT(tb_credit_has_payment.id) AS count_paid,
                mst_customer.name AS member_name,
                mst_customer.name AS member_name,
                st_user.username AS user_name
            ',
            'from' => 'tb_credit',
            'join' => [
                'tb_credit_has_payment,tb_credit.id = tb_credit_has_payment.id_credit,left',
                'mst_customer,tb_credit.id_customer = mst_customer.id ,left',
                'st_user,tb_credit.created_by = st_user.id,left'
            ],
            'where' => $array_where,
            'group_by' => 'tb_credit.id',
            'order_by' => 'tb_credit.id,DESC'
        ];
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }

        $get_data = Modules::run('database/get', $array_query)->result();

        $data = array();
        $no = 0;
        foreach ($get_data as $data_table) {

            $id_encrypt = $this->encrypt->encode($data_table->id);
            $no++;
            if (strtotime(date('Y-m-d')) > strtotime($data_table->deadline)) {
                //expired
                $label_expired = '<label class="text-danger font-weight-bold">Telah Jatuh Tempo</label>';
            } else {
                //expired
                $label_expired = '<label class="text-primary font-weight-bold">Belum Jatuh Tempo</label>';
            }
            //reject button
            $btn_reject = '';
            // if ($data_table->count_paid == 0 && $data_table->sales_code == '') {
            //     $btn_reject = ' <li><a href="javascript:void(0)" class="btn_reject" data-id="' . $id_encrypt . '"><i class="fa fa-close"></i> Batalkan Piutang</a></li>';
            // };

            $tgl1 = strtotime($data_table->date);
            $tgl2 = strtotime(date('Y-m-d'));
            $jarak = $tgl2 - $tgl1;
            $hari = $jarak / 60 / 60 / 24;


            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->invoice_code;
            $row[] = ' 
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                            </div>
                            <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($data_table->price, 0, '.', '.') . '">
                        </div>
                    ';
            $row[] = '
                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                    </div>
                    <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($data_table->total_payment, 0, '.', '.') . '">
                </div>
                <small>Jml Angsuran :</small> <span class="badge badge-primary"> ' . $data_table->count_paid . ' Kali</span>
            ';
            // $row[] = 'Rp.' . number_format($data_table->total_payment, 0, '.', '.');
            $row[] = '
                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text" style="padding:0 10px;">Rp.</div>
                    </div>
                    <input type="text" class="form-control form-control-sm bg-white" readonly value="' . number_format($data_table->rest_credit, 0, '.', '.') . '">
                </div>
            ';
            $row[] = '<span class="badge badge-primary">Tgl Piutang</span><br>' . Modules::run('helper/date_indo',  $data_table->date, '-') . '<span class="badge badge-primary">Tgl Jatuh Tempo</span><br>' . Modules::run('helper/date_indo',  $data_table->deadline, '-');
            $row[] =  round($hari);
            $row[] = $label_expired;
            $row[] = $data_table->member_name;
            $row[] = '

                    <div class="btn-group mt-1 mr-1">
                        <a class="btn btn-primary" href="' . base_url('admin/credit/detail?data=' . urlencode($id_encrypt)) . '" class="btn btn-default btn_link">Detail</a>
                        <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        </button>
                        <div class="dropdown-menu" x-placement="top-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(76px, -174px, 0px);">
                            <a class="dropdown-item" href="' . base_url('admin/credit/add_payment?data=' . urlencode($id_encrypt)) . '"><i class="fa fa-send"></i> Masukan Pembayaran</a>
                        </div>
                    </div>
            ';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        $array_respon = ['list' => $ouput];
        echo json_encode($array_respon);
    }

    public function add()
    {
        $get_data_member = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();
        $html_option_member = '<option value="">Tidak ada</option>';
        foreach ($get_data_member as $item_member) {
            $id_member_encrypt = $this->encrypt->encode($item_member->id);
            $html_option_member .= '<option value="' . $id_member_encrypt . '">' . $item_member->name . '</option>';
        }
        $this->app_data['html_option_member'] = $html_option_member;

        $this->app_data['debit_account'] = Modules::run('database/find', 'tb_book_account', ['type_account' => 1, 'id_parent >' => 0])->result();
        $this->app_data['credit_account'] = Modules::run('database/find', 'tb_book_account', ['type_account' => 4, 'id_parent >' => 0])->result();

        $this->app_data['data_customer']     = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();
        $this->app_data['page_title']     = "Data Piutang";
        $this->app_data['view_file']     = 'form_add';
        echo Modules::run('template/main_layout', $this->app_data);
    }
    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }
        if (!empty($_POST['price'])) {
            $price = $this->input->post('price');
            $price = str_replace('.', '', $price);
            $price = (int) $price;
            if ($price <=  0) {
                $data['error_string'][] = 'tidak boleh 0';
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }
        }
        if ($this->input->post('id_customer') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'id_customer';
            $data['status'] = FALSE;
        }

        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }
        if ($this->input->post('due_date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'due_date';
            $data['status'] = FALSE;
        }
        if ($this->input->post('invoice') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'invoice';
            $data['status'] = FALSE;
        }
        if ($this->input->post('description') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'description';
            $data['status'] = FALSE;
        }

        if ($this->input->post('debit_account') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'debit_account';
            $data['status'] = FALSE;
        }

        if ($this->input->post('credit_account') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'credit_account';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();

        $code       = $this->get_code();
        $price     = $this->input->post('price');
        $price     = str_replace('.', '', $price);
        $invoice = $this->input->post('invoice');

        $id_customer = $this->encrypt->decode($this->input->post('id_customer'));
        $description       = $this->input->post('description');
        $date = Modules::run('helper/change_date', $this->input->post('date'), '-');
        $due_date = Modules::run('helper/change_date', $this->input->post('due_date'), '-');

        $credit_account = $this->input->post('credit_account');
        $debit_account = $this->input->post('debit_account');

        //insert data
        $array_insert = array(
            'code' => $code,
            'id_customer' => $id_customer,
            'invoice_code' => $invoice,
            'price' => $price,
            'date' => $date,
            'rest_credit' => $price,
            'deadline' => $due_date,
            'description' => $description,
            'created_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/insert', 'tb_credit', $array_insert);
        $get_data = Modules::run('database/find', 'tb_credit', ['code' => $code])->row();
        //push accounting
        $array_accounting = [
            'debit_account' => $debit_account,
            'credit_account' => $credit_account,
            'price' => $price,
            'date' => $date,
            'description' => $description,
            'id_transaction' => $get_data->id
        ];
        Modules::run('accounting/insert_credit_manual', 'insert', $array_accounting);
        echo json_encode(array('status' => TRUE, 'id' => urlencode($this->encrypt->encode($get_data->id))));
    }

    public function get_form_edit()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $data['data_credit'] = Modules::run('database/find', 'tb_credit', ['id' => $id])->row();
        $data['data_invoice'] = Modules::run('database/find', 'tb_invoice', ['id' =>  $data['data_credit']->id_invoice])->row();

        $data['debit_account'] = Modules::run('database/find', 'tb_book_account', ['type_account' => 1, 'id_parent >' => 0])->result();
        $data['credit_account'] = Modules::run('database/find', 'tb_book_account', ['type_account' => 4, 'id_parent >' => 0])->result();

        $get_journal = Modules::run('database/find', 'tb_book_account_has_detail', ['status_act' => 17, 'id_transaction' => $id])->result();
        $id_debit_account = 0;
        $id_credit_account = 0;
        foreach ($get_journal as $item_journal) {
            if ($item_journal->debit > 0) {
                $id_debit_account = $item_journal->id_book_account;
            }
            if ($item_journal->credit > 0) {
                $id_credit_account = $item_journal->id_book_account;
            }
        }
        $data['id_debit_account'] = $id_debit_account;
        $data['id_credit_account'] = $id_credit_account;

        $html_respon = $this->load->view('form_update_credit', $data, TRUE);
        $array_respon = ['status' => TRUE, 'html_respon' => $html_respon];
        echo json_encode($array_respon);
    }

    public function validate_update_credit()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $id = $this->encrypt->decode($this->input->post('id'));
        $get_credit = Modules::run('database/find', 'tb_credit', ['id' => $id])->row();
        $get_invoice = Modules::run('database/find', 'tb_invoice', ['id' => $get_credit->id_invoice])->row();

        if (empty($get_invoice)) {
            if ($this->input->post('price') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }
            if (!empty($_POST['price'])) {
                $price = $this->input->post('price');
                $price = str_replace('.', '', $price);
                $price = (int) $price;
                if ($price <=  0) {
                    $data['error_string'][] = 'tidak boleh 0';
                    $data['inputerror'][] = 'price';
                    $data['status'] = FALSE;
                } else {
                    if ($price < $get_credit->total_payment) {
                        $data['error_string'][] = 'nominal piutang harus lebih besar dari nominal yang telah dibayar yaitu ( Rp. ' . number_format($price, 0, '.', '.') . ')';
                        $data['inputerror'][] = 'price';
                        $data['status'] = FALSE;
                    }
                }
            }
        } else {
            if ($this->input->post('total_price') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'total_price';
                $data['status'] = FALSE;
            }
            if (!empty($_POST['total_price'])) {
                $price = $this->input->post('total_price');
                $price = str_replace('.', '', $price);
                $price = (int) $price;
                if ($price <=  0) {
                    $data['error_string'][] = 'tidak boleh 0';
                    $data['inputerror'][] = 'total_price';
                    $data['status'] = FALSE;
                } else {
                    if ($price < $get_credit->total_payment) {
                        $data['error_string'][] = 'nominal piutang harus lebih besar dari nominal yang telah dibayar yaitu ( Rp. ' . number_format($price, 0, '.', '.') . ')';
                        $data['inputerror'][] = 'total_price';
                        $data['status'] = FALSE;
                    }
                }
            }
        }

        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }
        if ($this->input->post('due_date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'due_date';
            $data['status'] = FALSE;
        }
        if ($this->input->post('description') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'description';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function update_credit()
    {
        Modules::run('security/is_ajax');
        $this->validate_update_credit();

        $debit_account = $this->input->post('debit_account');
        $credit_account = $this->input->post('credit_account');

        $id = $this->encrypt->decode($this->input->post('id'));
        $get_credit = Modules::run('database/find', 'tb_credit', ['id' => $id])->row();

        if ($get_credit->id_invoice) {

            $total_price  = str_replace('.', '', $this->input->post('total_price'));
            $discount  = str_replace('.', '', $this->input->post('discount'));
            $ppn_price  = str_replace('.', '', $this->input->post('ppn_price'));
            $ppn_value  = str_replace('.', '', $this->input->post('ppn_value'));
            $total_invoice = ($total_price + $ppn_price) - $discount;

            //update invoice
            $array_update_invoice = [
                'total_price' => $total_price,
                'ppn_value' => $ppn_value,
                'ppn_price' => $ppn_price,
                'grand_total_price' => ($total_price + $ppn_price),
                'discount_price' => $discount,
                'total_invoice' => $total_invoice
            ];
            Modules::run('database/update', 'tb_invoice', ['id' => $get_credit->id_invoice], $array_update_invoice);
        } else {
            $total_invoice  = str_replace('.', '', $this->input->post('price'));

            $total_price  = 0;
            $discount  = 0;
            $ppn_price  = 0;
            $ppn_value  = 0;
        }

        $date   = Modules::run('helper/change_date', $this->input->post('date'), '-');
        $due_date = Modules::run('helper/change_date', $this->input->post('due_date'), '-');
        $description = $this->input->post('description');
        $new_rest_credit = $total_invoice - $get_credit->total_payment;

        $array_update = [
            'price' => $total_invoice,
            'rest_credit' => $new_rest_credit,
            'date' => $date,
            'deadline' => $due_date,
            'description' => $description
        ];
        Modules::run('database/update', 'tb_credit', ['id' => $id], $array_update);

        //PUSH ACCOUNTING
        if ($get_credit->id_invoice) {
            //send accounting
            $array_data = [
                'total_tagihan' => $total_invoice,
                'total_pajak' => $ppn_price,
                'piutang' => $total_invoice,
                'kode_invoice' => $get_credit->invoice_code,
                'id_tagihan' => $get_credit->id_invoice,
                'tanggal' => $date,
                'deskripsi' => $description
            ];
            Modules::run('accounting/update_invoice_bol', $array_data);
        } else {
            $array_accounting = [
                'debit_account' => $debit_account,
                'credit_account' => $credit_account,
                'price' => $total_invoice,
                'date' => $date,
                'description' => $description,
                'id_transaction' => $id
            ];
            Modules::run('accounting/insert_credit_manual', 'update', $array_accounting);
        }

        //for LOG
        $array_before = [
            'price' => $get_credit->price,
            'date' => $get_credit->date,
            'due_date' => $get_credit->deadline,
            'description' => $get_credit->description
        ];
        $array_after = [
            'price' => $total_invoice,
            'date' => $date,
            'due_date' => $due_date,
            'description' => $description
        ];

        $array_insert_log = [
            'id_credit' => $id,
            'json_data_before' => json_encode($array_before),
            'json_data_after' => json_encode($array_after),
            'created_by' => $this->session->userdata('us_id')
        ];
        Modules::run('database/insert', 'tb_credit_has_log', $array_insert_log);

        echo json_encode(['status' => TRUE]);
    }

    //================================= PAYMENT =================================================================

    public function add_payment()
    {
        $id = $this->encrypt->decode($this->input->get('data'));

        $this->db->select('
            tb_credit.*,
            COUNT(tb_credit_has_payment.id) AS count_paid,
            mst_customer.name AS member_name,
            mst_customer.name AS member_name,
            mst_customer.saldo AS saldo_customer,
            st_user.username AS user_name
        ');
        $this->db->from('tb_credit');
        $this->db->join('tb_credit_has_payment', 'tb_credit.id = tb_credit_has_payment.id_credit', 'left');
        $this->db->join('mst_customer', 'tb_credit.id_customer = mst_customer.id ', 'left');
        $this->db->join('st_user', 'tb_credit.created_by = st_user.id ', 'left');
        $this->db->where(['tb_credit.id' => $id]);
        $this->db->order_by('tb_credit.id', 'DESC');
        $this->db->group_by('tb_credit.id');

        $get_data = $this->db->get()->row();
        $this->app_data['data_credit'] = $get_data;
        //get detail
        $this->db->select('
            tb_credit_has_payment.*,
            st_user.username AS user_name
            ');
        $this->db->from('tb_credit_has_payment');
        $this->db->join('st_user', 'tb_credit_has_payment.created_by = st_user.id', 'left');
        $this->db->where(['tb_credit_has_payment.id_credit' => $id]);
        $get_data_detail = $this->db->get()->result();

        $this->app_data['data_detail'] = $get_data_detail;
        $this->app_data['page_title']     = "Pembayaran Piutang";
        $this->app_data['view_file']     = 'form_payment';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function validate_save_payment()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if ($this->input->post('price') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'price';
            $data['status'] = FALSE;
        }
        if ($this->input->post('note') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'note';
            $data['status'] = FALSE;
        }
        if ($this->input->post('date') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'date';
            $data['status'] = FALSE;
        }
        if ($this->encrypt->decode($this->input->post('payment_method')) == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'payment_method';
            $data['status'] = FALSE;
        }

        if (!empty($_POST['price'])) {
            $price = $this->input->post('price');
            $price = str_replace('.', '', $price);
            $price = (int) $price;
            if ($price <=  0) {
                $data['error_string'][] = 'tidak boleh 0';
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }

            $id   = $this->encrypt->decode($this->input->post('id'));
            $get_credit = $this->db->where(['id' => $id])->get('tb_credit')->row();
            $payment_method = $this->encrypt->decode($this->input->post('payment_method'));
            if ($price > $get_credit->rest_credit && $payment_method == 4) {
                $data['error_string'][] = 'Maksimal Rp.' . number_format($get_credit->rest_credit, 0, '.', '.');
                $data['inputerror'][] = 'price';
                $data['status'] = FALSE;
            }

            if ($payment_method == 4) {
                $get_member = Modules::run('database/find', 'mst_customer', ['id' => $get_credit->id_customer])->row();
                if ($price > $get_member->saldo) {
                    $data['error_string'][] = 'saldo dompet customer maksimal Rp.' . number_format($get_member->saldo, 0, '.', '.');
                    $data['inputerror'][] = 'price';
                    $data['status'] = FALSE;
                }
            }
        }
        if ($this->input->post('note') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'note';
            $data['status'] = FALSE;
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }
    public function preview_save_payment()
    {
        $this->validate_save_payment();
        $payment_method = Modules::run('helper/get_config', 'payment_method');

        $id     = $this->encrypt->decode($this->input->post('id'));
        $payment_method_item     = $this->encrypt->decode($this->input->post('payment_method'));
        $date   = $this->input->post('date');
        $price  = $this->input->post('price');
        $price  = str_replace('.', '', $price);
        $note   = $this->input->post('note');
        $get_price = $this->db->where(['id' => $id])->get('tb_credit')->row();

        if ($price >= $get_price->rest_credit) {
            $label_status   = '<label class="label label-success">LUNAS</label>';
            $rest_payment   = $price - $get_price->rest_credit;
            $rest_credit    = 0;
        } else {
            $label_status   = '<label class="label label-warning">BELUM LUNAS</label>';
            $rest_payment   = 0;
            $rest_credit    = $get_price->rest_credit - $price;
        }

        $this->db->select('
            tb_credit.*,
            COUNT(tb_credit_has_payment.id) AS count_paid,
            mst_customer.name AS member_name,
            mst_customer.address AS member_address,
            st_user.username AS user_name
        ');
        $this->db->from('tb_credit');
        $this->db->join('tb_credit_has_payment', 'tb_credit.id = tb_credit_has_payment.id_credit', 'left');
        $this->db->join('mst_customer', 'tb_credit.id_customer = mst_customer.id ', 'left');
        $this->db->join('st_user', 'tb_credit.created_by = st_user.id ', 'left');
        $this->db->where(['tb_credit.id' => $id]);
        $this->db->order_by('tb_credit.id', 'DESC');
        $this->db->group_by('tb_credit.id');

        $get_data = $this->db->get()->row();

        $payment_method_text = isset($payment_method[$payment_method_item]) ? $payment_method[$payment_method_item] : '';
        $payment_date = Modules::run('helper/date_indo', Modules::run('helper/change_date', $date, '-'), '-');

        $rest_payment = $price - $get_data->rest_credit;
        $html_rest_payment = '';
        if ($rest_payment > 0) {
            $html_rest_payment = '
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="">Sisa Pembayaran</div>
                                <div class="h3 mt-2 mb-2"><b>Rp.' . number_format($rest_payment, 0, '.', '.') . '</b></div>
                            </div>
                            <div class="col-auto align-self-center ">
                                <div class="feature mt-0 mb-0">
                                    <i class="ti-gift project bg-success-transparent text-success "></i>
                                </div>
                            </div>
                        </div>
                        <div class="">
                            <small class="mb-1">Uang sisa pembayaran secara otomatis akan tersimpan di saldo dompet customer.</small>
                        </div>
                    </div>
                </div>
            ';
        }

        $html_respon = '
        <div class="col-md-12">
            <h2 class="text-center">Preview Pembayaran</h2>
            <div class="col-md-12 text-center">
                <small class="text-center">sisa Tanggungan :</small>
                <h3 class="text-red  shadow div_center p-3" style="width:300px;margin:0 auto;">Rp.' . number_format($get_data->rest_credit, 0, '.', '.') . '</h3>
            </div>
        </div>
        <div class="col-6 mt-3">
            <label class="font-weight-bold"><i class="fa fa-user"></i> Data Customer :</label>
            <div class="row col-12">
                <div class="col">
                    <div class="h3 mt-2 mb-2 text-primary"><b>' . $get_data->member_name . '</b></div>
                    <p class="tx-12">' . $get_data->member_address . '</p>
                </div>
                <div class="col-auto align-self-center ">
                    <div class="feature mt-0 mb-0">
                        <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                    </div>
                </div>
            </div>
            <hr>
            <label class="font-weight-bold"><i class="fa fa-tv"></i> Metode Pembayaran : <span class="tx-18 font-weight-bold badge badge-light">' . $payment_method_text . '</span></label>
            <hr>
            <label class="font-weight-bold"><i class="fa fa-tv"></i> Metode Pembayaran : <span class="tx-18 font-weight-bold badge badge-light">' . $payment_date . '</span></label>
            <hr>
            <img src="" class="image_proof" style="width:200px;" alt="">
        </div>
        <div class="col-md-6 border-dashed p-2 mt-3">
            <div class="box box-solid">
                <div class="box-header with-border">
                    <h5 class="box-title">Pembayaran :</h5>
                </div>
                <div class="box-body no-padding">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <div class="media my-2">
                                <div class="media-body">
                                    <p class="text-muted mb-2">Dibayar</p>
                                    <h3 class="mb-0">Rp.' . number_format($price, 0, '.', '.') . '</h3>
                                </div>
                                <div class="icons-lg ml-2 align-self-center">
                                    <span class="uim-svg" style=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em"><path class="uim-quaternary" d="M12,14.19531a1.00211,1.00211,0,0,1-.5-.13379l-9-5.19726a1.00032,1.00032,0,0,1,0-1.73242l9-5.19336a1.00435,1.00435,0,0,1,1,0l9,5.19336a1.00032,1.00032,0,0,1,0,1.73242l-9,5.19726A1.00211,1.00211,0,0,1,12,14.19531Z"></path><path class="uim-tertiary" d="M21.5,11.13184,19.53589,9.99847,12.5,14.06152a1.0012,1.0012,0,0,1-1,0L4.46411,9.99847,2.5,11.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path><path class="uim-primary" d="M21.5,15.13184l-1.96411-1.13337L12.5,18.06152a1.0012,1.0012,0,0,1-1,0L4.46411,13.99847,2.5,15.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path></svg></span>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media my-2">
                                <div class="media-body">
                                    <p class="text-muted mb-2">Sisa Tagihan </p>
                                    <h3 class="mb-0">Rp.' . number_format($rest_credit, 0, '.', '.') . '</h3>
                                </div>
                                <div class="icons-lg ml-2 align-self-center">
                                    <span class="uim-svg" style=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em"><path class="uim-quaternary" d="M12,14.19531a1.00211,1.00211,0,0,1-.5-.13379l-9-5.19726a1.00032,1.00032,0,0,1,0-1.73242l9-5.19336a1.00435,1.00435,0,0,1,1,0l9,5.19336a1.00032,1.00032,0,0,1,0,1.73242l-9,5.19726A1.00211,1.00211,0,0,1,12,14.19531Z"></path><path class="uim-tertiary" d="M21.5,11.13184,19.53589,9.99847,12.5,14.06152a1.0012,1.0012,0,0,1-1,0L4.46411,9.99847,2.5,11.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path><path class="uim-primary" d="M21.5,15.13184l-1.96411-1.13337L12.5,18.06152a1.0012,1.0012,0,0,1-1,0L4.46411,13.99847,2.5,15.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path></svg></span>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media my-2">
                                <div class="media-body">
                                    <p class="text-muted mb-2">Status Lunas</p>
                                    <h3 class="mb-0">' . $label_status . '</h3>
                                </div>
                                <div class="icons-lg ml-2 align-self-center">
                                    <span class="uim-svg" style=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em"><path class="uim-quaternary" d="M12,14.19531a1.00211,1.00211,0,0,1-.5-.13379l-9-5.19726a1.00032,1.00032,0,0,1,0-1.73242l9-5.19336a1.00435,1.00435,0,0,1,1,0l9,5.19336a1.00032,1.00032,0,0,1,0,1.73242l-9,5.19726A1.00211,1.00211,0,0,1,12,14.19531Z"></path><path class="uim-tertiary" d="M21.5,11.13184,19.53589,9.99847,12.5,14.06152a1.0012,1.0012,0,0,1-1,0L4.46411,9.99847,2.5,11.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path><path class="uim-primary" d="M21.5,15.13184l-1.96411-1.13337L12.5,18.06152a1.0012,1.0012,0,0,1-1,0L4.46411,13.99847,2.5,15.13184a1.00032,1.00032,0,0,0,0,1.73242l9,5.19726a1.0012,1.0012,0,0,0,1,0l9-5.19726a1.00032,1.00032,0,0,0,0-1.73242Z"></path></svg></span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="no-padding no-margin">
                    <label>Catatan:</label>
                <div class="border p-2 rounded-10">
                    <p>' . $note . '</p>
                </div>
                ' . $html_rest_payment . '
            </div>
        </div>
        <div class="col-md-12 text-center p-2">
            <button class="btn btn-primary btn-block btn_save_payment" data-id="' . $this->encrypt->encode($id) . '">Simpan Pembayaran</button>
        </div>
        ';
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save_payment()
    {
        $this->validate_save_payment();
        $id     = $this->encrypt->decode($this->input->post('id'));
        $price  = $this->input->post('price');
        $price  = str_replace('.', '', $price);
        $note   = $this->input->post('note');
        $get_price = $this->db->where(['id' => $id])->get('tb_credit')->row();
        $code = $this->get_payment_code();
        $payment_method_item     = $this->encrypt->decode($this->input->post('payment_method'));
        $date   = Modules::run('helper/change_date', $this->input->post('date'), '-');
        $image = '';
        if (isset($_FILES['upload']['name']) && !empty($_FILES['upload']['name'])) {
            $image = $this->upload_image();
        }

        if ($price >= $get_price->rest_credit) {
            $status_payment  = TRUE;
            $rest_payment   = $price - $get_price->rest_credit;
            $rest_credit    = 0;
            $payment_value  = $get_price->rest_credit;
        } else {
            $status_payment  = FALSE;
            $rest_payment   = 0;
            $rest_credit    = $get_price->rest_credit - $price;
            $payment_value  = $get_price->rest_credit - $rest_credit;
        }

        //rest payment 
        $rest_payment = $price - $get_price->rest_credit;

        //insert payment
        $array_insert_payment = [
            'code' => $code,
            'id_credit' => $id,
            'credit_price' => $get_price->rest_credit,
            'payment_price' => $payment_value,
            'rest_credit' => $rest_credit,
            'payment_value' => $price,
            'rest_payment_value' => $rest_payment,
            'date' => $date,
            'payment_method' => $payment_method_item,
            'note' => $note,
            'image' => $image,
            'status' => $status_payment,
            'created_by' => $this->session->userdata('us_id')
        ];
        Modules::run('database/insert', 'tb_credit_has_payment', $array_insert_payment);
        //updated credit
        $total_payment = $get_price->price - $rest_credit;
        $array_update_credit = [
            'total_payment' => $total_payment,
            'rest_credit' => $rest_credit,
            'status' => $status_payment,
            'updated_by' => $this->session->userdata('usr_id')
        ];
        Modules::run('database/update', 'tb_credit', ['id' => $id], $array_update_credit);

        //push aaccounting
        $get_payment_id = $this->db->select('id')->where(['code' => $code])->get('tb_credit_has_payment')->row();
        $get_credit = $this->db->where(['id' => $id])->get('tb_credit')->row();
        $array_insert_accounting = ['total_bayar' => $payment_value, 'id_payment' => $get_payment_id->id, 'kode_invoice' => $get_credit->invoice_code, 'tanggal' => $date];
        // Modules::run('accounting/payment_invoice_bol', $array_insert_accounting);

        //insert deposito
        if ($rest_payment > 0) {
            $array_insert_deposito = [
                'id_credit_payment' => $get_payment_id->id,
                'id_customer' => $get_credit->id_customer,
                'price' => $rest_payment,
                'date' => $date
            ];
            Modules::run('deposito/insert_deposito_credit', $array_insert_deposito);
        }

        //use deposito
        if ($payment_method_item == 4) {
            $array_insert_deposito = [
                'id_credit_payment' => $get_payment_id->id,
                'id_customer' => $get_credit->id_customer,
                'price' => $price,
                'date' => $date
            ];
            Modules::run('deposito/use_deposito_credit', $array_insert_deposito);
        }

        // Modules::run('emailing/payment', $get_payment_id->id);

        //create array respon 
        $array_respon = [
            'id_encrypt' => urlencode($this->encrypt->encode($id)),
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    private function upload_image()
    {
        $config['upload_path']          = realpath(APPPATH . '../upload/payment');
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('upload')) //upload and validate
        {
            $data['inputerror'][] = 'upload_banner';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            $upload_data = $this->upload->data();
            $image_name = $upload_data['file_name'];
            return $image_name;
        }
    }

    public function delete_payment()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_payment = $this->db->where(['id' => $id])->get('tb_credit_has_payment')->row();
        $get_credit = $this->db->where(['id' => $get_payment->id_credit])->get('tb_credit')->row();

        $total_payment  = $get_credit->total_payment - $get_payment->payment_value;
        $rest_credit    = $get_credit->rest_credit + $get_payment->payment_value;

        $status = 2;
        if ($get_credit->status != 2) {
            $status = $rest_credit > 0 ? 0 : 1;
        }

        Modules::run('database/delete', 'tb_credit_has_payment', ['id' => $id]);
        $array_update = [
            'total_payment' => $total_payment,
            'rest_credit' => $rest_credit,
            'status' => $status
        ];
        Modules::run('database/update', 'tb_credit', ['id' => $get_credit->id], $array_update);

        //delete journal
        Modules::run('accounting/delete_payment_invoice_bol', $id);

        echo json_encode(['status' => TRUE]);
    }

    public function detail()
    {
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->db->select('
            tb_credit.*,
            COUNT(tb_credit_has_payment.id) AS count_paid,
            mst_customer.name AS member_name,
            mst_customer.address AS member_address,
            st_user.username AS user_name,
            reject_user.name As reject_user
        ');
        $this->db->from('tb_credit');
        $this->db->join('tb_credit_has_payment', 'tb_credit.id = tb_credit_has_payment.id_credit', 'left');
        $this->db->join('mst_customer', 'tb_credit.id_customer = mst_customer.id ', 'left');
        $this->db->join('st_user', 'tb_credit.created_by = st_user.id ', 'left');
        $this->db->join('st_user AS reject_user', 'tb_credit.reject_by = reject_user.id ', 'left');
        $this->db->where(['tb_credit.id' => $id]);
        $this->db->order_by('tb_credit.id', 'DESC');
        $this->db->group_by('tb_credit.id');
        $get_data = $this->db->get()->row();
        $this->app_data['data_credit'] = $get_data;
        //get invoice current
        $this->app_data['data_invoice'] = Modules::run('database/find', 'tb_invoice', ['id' => $get_data->id_invoice])->row();

        //get detail
        $this->db->select('
            tb_credit_has_payment.*,
            st_user.username AS user_name
            ');
        $this->db->from('tb_credit_has_payment');
        $this->db->join('st_user', 'tb_credit_has_payment.created_by = st_user.id', 'left');
        $this->db->where(['tb_credit_has_payment.id_credit' => $id]);
        $this->db->order_by('tb_credit_has_payment.date', 'DESC');
        $get_data_detail = $this->db->get()->result();

        $this->app_data['data_detail'] = $get_data_detail;

        $this->app_data['page_title']     = "Data Detail";
        $this->app_data['view_file']     = 'view_detail';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_form_reject()
    {
        $id = $this->input->post('id');
        $data['data_credit'] = Modules::run('database/find', 'tb_credit', ['id' => $id])->row();

        $html_respon = $this->load->view('form_reject', $data, TRUE);
        $array_respon = [
            'html_respon' => $html_respon,
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }

    public function save_reject()
    {
        Modules::run('security/is_ajax');
        $id     =  $this->encrypt->decode($this->input->post('id'));
        $get_data = Modules::run('database/find', 'tb_credit', ['id' => $id])->row();
        $note   = $this->input->post('note');
        $array_update = [
            'status' => 2,
            'reject_note' => $note,
            'reject_date' => date('Y-m-d'),
            'reject_by' => $this->session->userdata('us_id'),
            'updated_by' => $this->session->userdata('us_id')
        ];
        Modules::run('database/update', 'tb_credit', ['id' => $id], $array_update);

        //push accounting
        if ($get_data->id_invoice) {
            Modules::run('accounting/cancel_invoice', $get_data->id_invoice);
        } else {
            Modules::run('accounting/cancel_credit', $id);
        }

        echo json_encode(['status' => TRUE]);
    }
    public function history_credit()
    {
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();
        // echo modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "Riwayat Piutang";
        $this->app_data['view_file']     = 'form_history_credit';
        echo Modules::run('template/main_layout', $this->app_data);
    }
    public function validate_get_history_credit()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $type = $this->input->post('type_search');
        if ($type == 1) {
            if ($this->input->post('date_from') == '' && $this->input->post('date_to') == '') {
                $data['error_string'][] = 'salah satu harus diisi';
                $data['inputerror'][] = 'date_from';
                $data['status'] = FALSE;

                $data['error_string'][] = 'salah satu harus diisi';
                $data['inputerror'][] = 'date_to';
                $data['status'] = FALSE;
            }
        } else {
            if ($this->input->post('code') == '') {
                $data['error_string'][] = 'harus diisi';
                $data['inputerror'][] = 'code';
                $data['status'] = FALSE;
            }
        }
        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function get_history_credit()
    {
        $this->validate_get_history_credit();

        $array_customer = $this->input->post('customer');
        $type_search    = $this->input->post('type_search');
        $type           = $this->input->post('type');
        $code           = $this->input->post('code');
        $status = $this->encrypt->decode($this->input->post('status'));
        $status_expired = $this->input->post('status_expired');




        if ($type_search == 1) {

            $date_from      = $this->input->post('date_from');
            $date_to        = $this->input->post('date_to');

            $date_from_sql = '';
            if ($date_from) {
                $explode_date_from = explode('-', $date_from);
                $date_from_sql = $explode_date_from[2] . '-' . $explode_date_from[1] . '-' . $explode_date_from[0];
                $array_where['tb_credit.date >='] = $date_from_sql;
            }
            $date_to_sql = '';
            if ($date_to) {
                $explode_date_to = explode('-', $date_to);
                $date_to_sql = $explode_date_to[2] . '-' . $explode_date_to[1] . '-' . $explode_date_to[0];
                $array_where['tb_credit.date <='] = $date_to_sql;
            }


            if ($status != '') {
                $array_where['tb_credit.status'] = $status;
            }



            if ($status_expired) {
                if ($status_expired == 1) {
                    $array_where['tb_credit.deadline > '] = date('Y-m-d');
                    // $array_where['tb_credit.status'] = 0;
                }

                if ($status_expired == 2) {
                    $array_where['tb_credit.deadline < '] = date('Y-m-d');
                    // $array_where['tb_credit.status'] = 0;
                }
            }



            $this->db->select('
            tb_credit.*,
            COUNT(tb_credit_has_payment.id) AS count_paid,
            mst_customer.name AS member_name,
            mst_customer.name AS member_name,
            st_user.username AS user_name
            ');
            $this->db->from('tb_credit');
            $this->db->join('tb_credit_has_payment', 'tb_credit.id = tb_credit_has_payment.id_credit', 'left');
            $this->db->join('mst_customer', 'tb_credit.id_customer = mst_customer.id ', 'left');
            $this->db->join('st_user', 'tb_credit.created_by = st_user.id ', 'left');
            $this->db->where($array_where);
            if (!empty($array_customer)) {
                $this->db->where_in('tb_credit.id_customer', $array_customer);
            }

            $this->db->order_by('tb_credit.id', 'DESC');
            $this->db->group_by('tb_credit.id');
            $get_data = $this->db->get()->result();

            $data['data_credit'] = $get_data;
            $data['data_param'] = ['date_from' => $date_from_sql, 'date_to' => $date_to_sql, 'status_lunas' => $status, 'status_expired' => $status_expired];
            $html_respon = $this->load->view('view_search_result_list', $data, TRUE);
        } else {
            //base on code
            $code = $this->input->post('code');
            $id = $this->encrypt->decode($this->input->get('data'));
            $this->db->select('
                tb_credit.*,
                COUNT(tb_credit_has_payment.id) AS count_paid,
                mst_customer.name AS member_name,
                mst_customer.address AS member_address,
                st_user.username AS user_name
            ');
            $this->db->from('tb_credit');
            $this->db->join('tb_credit_has_payment', 'tb_credit.id = tb_credit_has_payment.id_credit', 'left');
            $this->db->join('mst_customer', 'tb_credit.id_customer = mst_customer.id ', 'left');
            $this->db->join('st_user', 'tb_credit.created_by = st_user.id ', 'left');
            $this->db->where(['tb_credit.invoice_code' => $code]);
            $this->db->order_by('tb_credit.id', 'DESC');
            $this->db->group_by('tb_credit.id');

            $get_data = $this->db->get()->row();
            $data['data_credit'] = $get_data;
            //get detail
            $this->db->select('
            tb_credit_has_payment.*,
            st_user.username AS user_name
            ');
            $this->db->from('tb_credit_has_payment');
            $this->db->join('st_user', 'tb_credit_has_payment.created_by = st_user.id', 'left');
            $this->db->where(['tb_credit_has_payment.id_credit' => $get_data->id]);
            $get_data_detail = $this->db->get()->result();

            $data['data_detail'] = $get_data_detail;

            if (empty($get_data)) {
                $html_respon = '
                <div class="bg-empty-data"></div>
                <h3 class="text-center text-muted text-capitalize">data tidak ditemukan</h3>
                <h5 class="text-center mt-10 text-muted">Kode Piutang <b> ' . $code . '</b> Tidak ditemukan</h5>
                ';
            } else {
                $html_respon = $this->load->view('view_detail', $data, TRUE);
            }
        }
        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function history_payment()
    {
        $this->app_data['data_customer'] = Modules::run('database/find', 'mst_customer', ['isDeleted' => 'N'])->result();
        // echo modules::run('template/media_admin', $data);
        $this->app_data['page_title']     = "Riwayat Data Pembayaran";
        $this->app_data['view_file']     = 'form_history_payment';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_history_payment()
    {
        $this->validate_get_history_credit();
        $type_search    = $this->input->post('type_search');
        $type           = $this->input->post('type');
        $code           = $this->input->post('code');
        $status = $this->encrypt->decode($this->input->post('status'));
        $id_customer = $this->input->post('id_customer');
        $date_from      = $this->input->post('date_from');
        $date_to        = $this->input->post('date_to');

        if ($type_search == 1) {

            $text_title = '';

            $date_from_sql = '';
            if ($date_from) {
                $explode_date_from = explode('-', $date_from);
                $date_from_sql = $explode_date_from[2] . '-' . $explode_date_from[1] . '-' . $explode_date_from[0];
                $array_where['tb_credit_has_payment.date >='] = $date_from_sql;
            }
            $date_to_sql = '';
            if ($date_to) {
                $explode_date_to = explode('-', $date_to);
                $date_to_sql = $explode_date_to[2] . '-' . $explode_date_to[1] . '-' . $explode_date_to[0];
                $array_where['tb_credit_has_payment.date <='] = $date_to_sql;
            }

            if (!empty($id_customer)) {
                $this->db->where_in('tb_credit.id_customer', $id_customer);
            }
        } else {
            $array_where = [
                'tb_credit.invoice_code' => $code
            ];
        }
        //get data payment
        $this->db->select(
            '
            tb_credit_has_payment.*,
            tb_credit.price AS price_credit,
            tb_credit.date AS date_credit,
            tb_credit.code AS credit_code,
            tb_credit.invoice_code,
            mst_customer.name AS member_name,
            mst_customer.address AS member_address,
            st_user.username AS user_name
            '
        );
        $this->db->from('tb_credit_has_payment');
        $this->db->join('tb_credit', 'tb_credit_has_payment.id_credit = tb_credit.id', 'left');
        $this->db->join('mst_customer', 'tb_credit.id_customer = mst_customer.id ', 'left');
        $this->db->join('st_user', 'tb_credit_has_payment.created_by = st_user.id ', 'left');
        $this->db->where($array_where);
        $get_data = $this->db->get()->result();

        $data['data_credit'] = $get_data;
        $data['params'] = ['date_from' => $date_from, 'date_to' => $date_to];
        $html_respon = $this->load->view('view_search_payment_list', $data, TRUE);


        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function print_credit()
    {
        $data_print = $this->encrypt->decode($this->input->post('data'));
        $array_print = json_decode($data_print, TRUE);
        $data_print = $array_print['data_print'];
        $spesification = $array_print['param'];

        $text_title_period = '';



        if ($spesification['date_from']) {
            $text_title_period = 'PER TANGGAL AWAL : ' . Modules::run('helper/change_date', $spesification['date_from'], '-');
        }

        if ($spesification['date_to']) {
            $text_title_period = 'PER TANGGAL AKHIR : ' . Modules::run('helper/change_date', $spesification['date_to'], '-');
        }

        if ($spesification['date_from'] && $spesification['date_to']) {
            $text_title_period = 'PERIODE : ' . Modules::run('helper/change_date', $spesification['date_from'], '-') . ' s/d ' . Modules::run('helper/change_date', $spesification['date_to'], '-');
        }


        $data_resume = $array_print['resume'];
        $array_status = [
            0 => 'BELUM LUNAS',
            1 => 'TELAH LUNAS'
        ];
        $status_lunas = isset($array_status[$spesification['status_lunas']]) && $spesification['status_lunas'] != ''  ? $array_status[$spesification['status_lunas']] : 'SEMUA';
        // $status_lunas 


        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('50');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:K2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:K2');
        $sheet->getStyle('A1:K2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:K2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA PIUTANG');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:K3');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', $text_title_period . ' | STATUS LUNAS : ' . $status_lunas);
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "F4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE INVOICE');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'PELANGGAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'JATUH TEMPO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'TOTAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F4', 'TELAH DIBAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G4', 'JML ANGSURAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H4', 'PIUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I4', 'UMUR (hr)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J4', 'STATUS LUNAS');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K4', 'STATUS JATUH TEMPO');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_print as $item_print) {

            $status_lunas_text = $item_print['status_lunas'] ? 'LUNAS' : 'BELUM LUNAS';

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['invoice_code']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $item_print['tgl_piutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($item_print['customer']));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $item_print['tgl_jatuh_tempo']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['total_piutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $item_print['total_bayar']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $item_print['total_angsuran']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $item_print['sisa_piutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume,  $item_print['usia']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $status_lunas_text);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $sheet_number_resume, $item_print['status_jatuh_tempo']);

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        $sheet_number_resume++;
        $sheet->mergeCells('A' . $sheet_number_resume . ':D' . $sheet_number_resume);
        $sheet->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'RESUME');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_resume['total_piutang']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_resume['telah_bayar']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_resume['jumlah_angsuran']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_resume['belum_bayar']);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->getFont()->setBold(true);

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA PIUTANG  ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_list_data()
    {

        $this->db->select('
            tb_credit.*,
            COUNT(tb_credit_has_payment.id) AS count_paid,
            mst_customer.name AS member_name,
            mst_customer.name AS member_name,
            st_user.username AS user_name
            ');
        $this->db->from('tb_credit');
        $this->db->join('tb_credit_has_payment', 'tb_credit.id = tb_credit_has_payment.id_credit', 'left');
        $this->db->join('mst_customer', 'tb_credit.id_customer = mst_customer.id ', 'left');
        $this->db->join('st_user', 'tb_credit.created_by = st_user.id ', 'left');
        $this->db->where(['tb_credit.status' => 0]);
        $this->db->order_by('tb_credit.id', 'DESC');
        $this->db->group_by('tb_credit.id');
        $get_data = $this->db->get()->result();

        $text_title_period = 'PER TANGGAL AKHIR : ' . Modules::run('public_function/date_indo', date('Y-m-d'));

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('50');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:K2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:K2');
        $sheet->getStyle('A1:K2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:K2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA PIUTANG');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:K3');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', $text_title_period . ' | STATUS LUNAS : BELUM LUNAS');
        $sheet->getStyle('A3:K3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "F4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE INVOICE');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'PELANGGAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'JATUH TEMPO');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'TOTAL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F4', 'TELAH DIBAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G4', 'JML ANGSURAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H4', 'PIUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I4', 'UMUR (hr)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J4', 'STATUS LUNAS');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K4', 'STATUS JATUH TEMPO');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        $total_piutang = 0;
        $total_bayar = 0;
        $jumlah_angsuran = 0;
        $total_sisa = 0;

        foreach ($get_data as $data_table) {
            $status_lunas_text = $data_table->status ? 'LUNAS' : 'BELUM LUNAS';
            $status_jatuh_tempo = '';
            if (strtotime($data_table->deadline) <= strtotime(date('Y-m-d'))) {
                $status_jatuh_tempo = $data_table->status ? '-' : 'Telah Jatuh Tempo';
            } else {
                $status_jatuh_tempo = $data_table->status ? '-' : 'Belum Jatuh Tempo';
            }

            $tgl1 = strtotime($data_table->date);
            $tgl2 = strtotime(date('Y-m-d'));
            $jarak = $tgl2 - $tgl1;
            $hari = $jarak / 60 / 60 / 24;


            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $data_table->invoice_code);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->date);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($data_table->member_name));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->deadline);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->price);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->total_payment);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_table->count_paid);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->rest_credit);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume,  round($hari));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $status_lunas_text);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $sheet_number_resume, $status_jatuh_tempo);

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);

            $total_piutang += $data_table->price;
            $total_bayar += $data_table->total_payment;
            $jumlah_angsuran += $data_table->count_paid;
            $total_sisa += $data_table->rest_credit;
        }
        $sheet_number_resume++;
        $sheet->mergeCells('A' . $sheet_number_resume . ':D' . $sheet_number_resume);
        $sheet->getStyle('A' . $sheet_number_resume . ':D' . $sheet_number_resume)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, 'RESUME');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $total_piutang);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $total_bayar);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $jumlah_angsuran);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $total_sisa);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':K' . $sheet_number_resume)->getFont()->setBold(true);


        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA PIUTANG  ' . $text_title_period . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function print_payment()
    {
        $data = json_decode($this->encrypt->decode($this->input->post('data_print')), TRUE);
        $data_print = $data['data_print'];
        $spesification = $data['param'];

        $text_title_period = '';


        if ($spesification['date_from']) {
            $text_title_period = 'PER TANGGAL AWAL : ' . $spesification['date_from'];
        }

        if ($spesification['date_to']) {
            $text_title_period = 'PER TANGGAL AKHIR : ' . $spesification['date_to'];
        }
        if ($spesification['date_from'] && $spesification['date_to']) {
            $text_title_period = 'PERIODE : ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'];
        }

        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('20');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('50');
        $sheet->getColumnDimension('D')->setWidth('20');
        $sheet->getColumnDimension('E')->setWidth('20');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('20');
        $sheet->getColumnDimension('I')->setWidth('20');
        $sheet->getColumnDimension('J')->setWidth('20');
        $sheet->getColumnDimension('K')->setWidth('20');

        //bold style 
        $sheet->getStyle("A1:K2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:H2');
        $sheet->getStyle('A1:H2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:H2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA PIUTANG');
        $sheet->getStyle('A3:H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $sheet->mergeCells('A3:H3');
        $sheet->getStyle('A3:H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', $text_title_period);
        $sheet->getStyle('A3:H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A4"; // or any value
        $to = "H4"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', 'KODE INVOICE');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B4', 'TANGGAL PIUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C4', 'TOTAL PIUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D4', 'SISA PIUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E4', 'PEMBAYARAN');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F4', 'SISA PIUTANG');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G4', 'TANGGAL BAYAR');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H4', 'STATUS PIUTANG');
        $sheet_number_resume = 4;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':H' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':H' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );

        foreach ($data_print as $item_print) {

            // $status_lunas_text = $item_print['status_lunas'] ? 'LUNAS' : 'BELUM LUNAS';

            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $item_print['invoice']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $item_print['tanggal_piutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume,  $item_print['total_piutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $item_print['sisa_piutang']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $item_print['jumlah_bayar']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $item_print['sisa_tanggugan']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $item_print['tanggal_bayar']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $item_print['status_piutang']);

            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':H' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }

        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA PIUTANG  ' . $spesification['date_from'] . ' s/d ' . $spesification['date_to'] . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function import()
    {
        $data['view_file']      = "form_import";
        $data['title']          = "Import Piutang"; // untuk header pada bagian atas data
        $data['subtitle']       = "Import Piutang"; // untuk subtitle pada bagian atas data
        $data['module']         = $this->module; //variable module untuk di controller template/media   
        $data['js_page']        = $this->js_page; // nama file js pada assets/js_system
        $data['page_title']     = 'Import Piutang'; // untuk title pada tab

        echo modules::run('template/media_admin', $data);
    }

    public function validate_do_import_data()
    {
        Modules::run('security/is_ajax');
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->encrypt->decode($this->input->post('id'));
        if ($_FILES['upload']['name'] == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'upload';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    private function do_upload_file()
    {
        $config['upload_path']          = realpath(APPPATH . '../uploads/about');
        $config['allowed_types']        = 'csv';
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('upload')) //upload and validate
        {
            $data['inputerror'][] = 'upload';
            $data['error_string'][] = 'Upload error: ' . $this->upload->display_errors('', ''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            return $this->upload->data('file_name');
        }
    }

    public function do_import_data()
    {
        $file_name = $this->do_upload_file();
        $file_content = fopen('uploads/about/' . $file_name, "r");
        $counter = 0;
        $array_data_csv = [];
        while (($data_csv = fgetcsv($file_content, 1000, ",")) !== FALSE) {

            $counter++;
            if ($counter == 1) {
                continue;
            }
            if ($data_csv[0] == '') {
                continue;
            }

            $invoice_code = $data_csv[0];
            $invoice_date = $data_csv[1];
            $customer     = $data_csv[2];
            $due_date     = $data_csv[3];
            $price        = $data_csv[4];
            $rest_price   = $data_csv[5];

            $id_customer = 0;
            $get_member = $this->db->where(['nama' => $customer])->get('mst_customer')->row();
            if (!empty($get_member)) {
                $id_customer = $get_member->Idcust;
            }

            $array_data_csv[] = [
                'invoice_code' => $invoice_code,
                'invoice_date' => $invoice_date,
                'customer' => $customer,
                'id_customer' => $id_customer,
                'due_date' => $due_date,
                'price' => $price,
                'rest_price' => $rest_price
            ];
        }
        $data['data_csv'] = $array_data_csv;
        $html_respon = $this->load->view('view_import_result', $data, TRUE);


        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function save_import_data()
    {
        Modules::run('security/is_ajax');
        $data_csv = json_decode($this->encrypt->decode($this->input->post('data')));
        foreach ($data_csv as $item_csv) {
            $code = $this->get_code();
            $description = 'Import Manual tanggal ' . date('d-m-Y') . '. Piutang AN: ' . $item_csv->customer;

            $check_invoice = $this->db->where(['invoice_code' => $item_csv->invoice_code])->get('tb_credit')->row();
            if (!empty($check_invoice)) {
                continue;
            }
            $array_insert = [
                'invoice_code' => $item_csv->invoice_code,
                'code' => $code,
                'description' => $description,
                'price' => $item_csv->price,
                'total_payment' => ($item_csv->price - $item_csv->rest_price),
                'rest_credit' => $item_csv->rest_price,
                'date' => $item_csv->invoice_date,
                'deadline' => $item_csv->due_date,
                'id_customer' => $item_csv->id_customer
            ];
            Modules::run('database/insert', 'tb_credit', $array_insert);
        }
        echo json_encode(['status' => TRUE]);
    }


    // ================================================= API FUNCTION ==============================================
    public function insert_credit($invoice, $price)
    {
        $get_invoice = Modules::run('database/find', 'tb_invoice', ['code' => $invoice])->row();
        $code = $this->get_code();

        if (!empty($get_invoice)) {
            $description = 'Piutang customer dengan kode invoice : ' . $get_invoice->code;
            $array_insert = [
                'invoice_code' => $get_invoice->code,
                'code' => $code,
                'description' => $description,
                'price' => $price,
                'rest_credit' => $price,
                'date' => $get_invoice->invoice_date,
                'deadline' => $get_invoice->due_date,
                'id_customer' => $get_invoice->id_customer,
                'id_invoice' => $get_invoice->id
            ];
            Modules::run('database/insert', 'tb_credit', $array_insert);
        }
    }

    public function test()
    {
        echo Modules::run('credit/insert_credit', 'S-INV-2021-12-00089', 1000000);
    }
}
