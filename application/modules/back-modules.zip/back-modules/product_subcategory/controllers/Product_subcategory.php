<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Product_subcategory extends BackendController
{
    var $module_name        = 'product_subcategory';
    var $module_directory   = 'product_subcategory';
    var $module_js          = ['product_subcategory'];
    var $app_data           = [];
    var $type               = 3;


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['category'] = Modules::run('database/find', 'tb_main_category', ['type' => 2])->result();
        $this->app_data['page_title'] = "Daftar Kategori";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        $array_query = [
            'select' => '
                tb_main_category.*,
                devisi.name AS devisi_name
            ',
            'from' => 'tb_main_category',
            'where' => [
                'tb_main_category.type' => $this->type
            ],
            'join' => [
                'tb_main_category AS devisi, tb_main_category.id_parent = devisi.id, left'
            ],
            'order_by' => 'id,DESC'
        ];

        $get_all_data = Modules::run('database/get', $array_query);

        $data = array();
        $no = 0;
        foreach ($get_all_data->result() as $data_table) {
            $btn_edit = Modules::run('security/edit_access', '<a class="btn btn-sm btn-rounded btn-warning-gradient" href="javascript:void(0)" title="Edit" onclick="edit_unit(' . "'" . $data_table->id . "'" . ')"><i class="glyphicon glyphicon-pencil"></i> edit</a>');
            $btn_delete = Modules::run('security/delete_access', '<a class="btn btn-sm btn-rounded btn-danger-gradient" href="javascript:void(0)" title="Hapus" onclick="delete_unit(' . "'" . $data_table->id . "'" . ')"><i class="glyphicon glyphicon-trash"></i> delete</a>');

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $data_table->code;
            $row[] = $data_table->name;
            $row[] = $data_table->devisi_name;
            $row[] = $btn_edit . $btn_delete;
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );
        echo json_encode($ouput);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        // if ($this->input->post('code') == '') {
        //     $data['error_string'][] = 'harus diisi';
        //     $data['inputerror'][] = 'code';
        //     $data['status'] = FALSE;
        // } else {
        //     $get_data = $this->db->where(['code' => $this->input->post('code')])->get('tb_main_category')->row();
        //     if (!empty($get_data)) {
        //         $data['error_string'][] = 'Kode Telah Dipakai';
        //         $data['inputerror'][] = 'code';
        //         $data['status'] = FALSE;
        //     }
        // }
        if ($this->input->post('name') == '') {
            $data['error_string'][] = 'nama harus diisi';
            $data['inputerror'][] = 'name';
            $data['status'] = FALSE;
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save()
    {
        $this->validate_insert();
        //insert data

        $name     = $this->input->post('name');
        $code     = $this->input->post('code');
        $devisi   = $this->input->post('devisi');
        $array_insert = array(
            'code' => $code,
            'id_parent' => $devisi,
            'name' => $name,
            'type' => $this->type,
            'created_date' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/insert', 'tb_main_category', $array_insert);
        echo json_encode(array('status' => TRUE));
    }

    public function get_edit($id)
    {
        $get_data = Modules::run('database/find', 'tb_main_category', ['id' => $id])->row_array();
        echo json_encode($get_data);
    }

    public function update()
    {
        $this->validate_insert();
        $id         = $this->input->post('id');
        $name     = $this->input->post('name');
        $code     = $this->input->post('code');
        $devisi   = $this->input->post('devisi');
        //insert data
        $array_update = array(
            'id_parent' => $devisi,
            'code' => $code,
            'name' => $name,
            'updated_by' => $this->session->userdata('us_id')
        );
        Modules::run('database/update', 'tb_main_category', ['id' => $id], $array_update);
        echo json_encode(array('status' => TRUE));
    }

    public function delete($id)
    {
        Modules::run('database/delete', 'tb_main_category', ['id' => $id]);
        echo json_encode(array('status' => TRUE));
    }
}
