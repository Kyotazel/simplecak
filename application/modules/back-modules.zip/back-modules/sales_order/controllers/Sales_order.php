<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales_order extends BackendController
{
    var $module_name        = 'sales_order';
    var $module_directory   = 'sales_order';
    var $module_js          = ['sales_order'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['data_main_category'] = $this->db->order_by('name')->get('tb_main_category')->result();
        $this->app_data['data_merk'] = $this->db->order_by('name')->get('tb_merk')->result();

        $this->app_data['page_title'] = "Data Sales Order";
        $this->app_data['view_file'] = 'view';
        echo Modules::run('template/main_layout', $this->app_data);
    }


    public function get_code()
    {
        $number_text = 0;
        $simbol = 'RP';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_request")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code  from tb_request WHERE id IN(SELECT MAX(id) FROM tb_request)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function search_data()
    {

        $start_date     = Modules::run('helper/change_date', $this->input->post('start_date'), '-');
        $end_date       = Modules::run('helper/change_date', $this->input->post('end_date'), '-');
        $status           = $this->input->post('status');
        $page           = $this->input->post('page');

        $limit_data = 25;
        if (!empty($page) && $page != 'undefined') {
            $start_page = ($page * $limit_data) - $limit_data;
            $data['start_no'] = $start_page;
        } else {
            $start_page = 0;
            $data['start_no'] = 0;
        }

        if ($status == '') {
            $array_query = [
                'select' => '
                    tb_sales.*,
                    mst_customer.name as customer,
                    a.name as sales,
                    b.name as employee
                ',
                'from' => 'tb_sales',
                'join' => [
                    'mst_customer , tb_sales.id_member = mst_customer.id , left',
                    'mst_employee as a, tb_sales.id_sales = a.id , left',
                    'mst_employee as b, tb_sales.created_by = b.id , left',
                ],
                'where' => [
                    'date >=' => $start_date,
                    'date <=' => $end_date
                ],
                'limit' => [
                    'start' => $start_page,
                    'limit' => $limit_data
                ],
                'order_by' => 'tb_sales.status, ASC'
            ];
        } else {
            $array_query = [
                'select' => '
                    tb_sales.*,
                    mst_customer.name as customer,
                    a.name as sales,
                    b.name as employee
                ',
                'from' => 'tb_sales',
                'join' => [
                    'mst_customer , tb_sales.id_member = mst_customer.id , left',
                    'mst_employee as a, tb_sales.id_sales = a.id , left',
                    'mst_employee as b, tb_sales.created_by = b.id , left',
                ],
                'where' => [
                    'date >=' => $start_date,
                    'date <=' => $end_date,
                    'status =' => $status
                ],
                'limit' => [
                    'start' => $start_page,
                    'limit' => $limit_data
                ]
            ];
        }

        // count data 
        // $get_query = $main_query . ' LIMIT ' . $start_page . ',' . $limit_data;
        $get_data = Modules::run('database/get', $array_query)->result();

        /* print_r($this->db->last_query());
        exit; */
        $data['data_sales'] = $get_data;

        //remove limit
        unset($array_query['limit']);
        $array_query['select'] = 'COUNT(tb_sales.id) AS count_data';
        $count_all_data = Modules::run('database/get', $array_query)->row();
        $count_all = $count_all_data->count_data;



        $num_links = floor($count_all / $limit_data);
        $html_pagination_item = '';
        $counter = 0;
        for ($i = 0; $i < 20; $i++) {
            $counter++;
            if ($counter > $num_links) {
                continue;
            }
            $active = $page == $counter ? 'active' : '';
            $html_pagination_item .= '<li class="page-item ' . $active . '"><a class="page-link btn_pagination" data-ci-pagination-page="' . $counter . '"  href="javascript:void(0)">' . $counter . '</a></li>';
        }

        $html_pagination = '
        <div class="pagging text-center">
        <nav aria-label="Page navigation example">
        <ul class="pagination">
        ' . $html_pagination_item . '
        </ul>
        </nav>
        </div>
        ';
        $data['html_pagination'] = $html_pagination;



        $html_respon = $this->load->view('view_search_result', $data, TRUE);


        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function get_detail_sales()
    {

        $id_sales = $this->encrypt->decode($this->input->post('id'));
        $get_data_detail = $this->db->query("select a.*,
         b.code as code_sales,
         b.grand_total,
         b.ppn,
         b.ppn_price,
         b.pph,
         b.pph_price,
         b.grand_total_sales,
         b.payment,
         b.rest_payment,
         b.date,
         b.credit_status,
         b.credit_price,
         c.name,
         c.code as product_code,
         c.qty_unit,
         c.code as code_product,
         d.name as unit_name,
         f.name as member_name,
         i.name AS conversion_name,
         i.qty AS conversion_qty
         from tb_detail_sales a 
         left join tb_sales b on a.id_sales = b.id
         left join tb_product c on a.id_product = c.id 
         left join tb_unit d on c.id_unit = d.id 
         left join mst_customer f on b.id_member = f.id
         left join tb_product_has_conversion i on a.id_conversion_unit = i.id 
         where a.id_sales = '$id_sales'
         ")->result();
        // print_r($get_data_detail[0]);
        // exit;
        $date_order_explode = explode('-', $get_data_detail[0]->date);
        $date_order_html = $date_order_explode[2] . '-' . $date_order_explode[1] . '-' . $date_order_explode[0];
        //status
        /* $status_credit  = $get_data_detail[0]->credit_status ? '<label class="label label-success">TRUE</label>' : '-';
        $label_credit   = $get_data_detail[0]->credit_price > 0 ? 'Rp.' . number_format($get_data_detail[0]->credit_price, 0, '.', '.') : '-'; */
        //create html form
        $html_delivery = '';
        // if ($get_data_detail[0]->delivery_status) {
        //     $html_delivery = '
        //                         <div class="col-md-6 p-10  border-radius-5 pull-right">
        //                             <h3>Alamat Tujuan:</h3>
        //                             <table class="table">
        //                                 <tr>
        //                                     <td width="200px">Kode Pengiriman</td>
        //                                     <td width="10px">:</td>
        //                                     <td><b>' . $get_data_detail[0]->delivery_code . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Kepada</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->receiver . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Tujuan</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->kec . '&nbsp;-&nbsp;' . $get_data_detail[0]->city . '&nbsp;-&nbsp;' . $get_data_detail[0]->province . '</b></td>
        //                                 </tr>
        //                                 <tr>
        //                                     <td>Alamat Lengkap</td>
        //                                     <td>:</td>
        //                                     <td><b>' . $get_data_detail[0]->address . '</b></td>
        //                                 </tr>
        //                             </table>
        //                         </div>
        //                     ';
        // }


        $data_html = '
        <table class="col-md-6">
        <tr>
        <td width="200px" height="30px">Kode</td>
        <td width="5px">:</td>
        <td>' . $get_data_detail[0]->code_sales . '</td>
        </tr>
        <tr>
        <td width="100px" height="30px">Tanggal</td>
        <td width="5px">:</td>
        <td>' . $date_order_html . '</td>
        </tr>
        <tr>
        <td width="100px" height="30px">Member</td>
        <td width="5px">:</td>
        <td>' . $get_data_detail[0]->member_name . '</td>
        </tr>
        </table>
        <table class="col-md-6">
        <tr>
        <td width="200px" height="30px">Grand Total</td>
        <td width="5px">:</td>
        <td>Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</td>
        </tr>
        
        </table>
        <span class="clearfix"></span>
        <hr>
        <span class="clearfix"></span>
        <table class="table">
        <thead>
        <tr>
        <th>No</th>
        <th>Kode</th>
        <th>nama</th>
        <th>Harga Satuan</th>
        <th>Jumlah Beli</th>
        <th>Diskon</th>
        <th>Bonus</th>
        <th>Total</th>
        </tr>
        </thead>
        <tbody>
        ';
        //get data here
        $no = 0;
        foreach ($get_data_detail as $data_detail) {
            $no++;
            //count base qty buy 

            if ($data_detail->conversion_name) {
                $label_qty_buy = '';
                $unit_value = $data_detail->qty % $data_detail->conversion_qty;
                $conversion_value = ($data_detail->qty - $unit_value) / $data_detail->conversion_qty;

                if ($conversion_value > 0) {
                    $conversion_qty = $data_detail->conversion_qty * $conversion_value;
                    $label_qty_buy .= $conversion_value . ' ' . $data_detail->conversion_name . '( ' . $conversion_qty . ' ' . $data_detail->unit_name . ')' . '<br>';
                }
                if ($unit_value > 0) {
                    $label_qty_buy .= $unit_value . ' ' . $data_detail->unit_name;
                }
            } else {
                $label_qty_buy = $data_detail->qty . ' ' . $data_detail->unit_name;
            }

            $data_html .= '
            <tr>
            <td>' . $no . '</td>	
            <td>' . $data_detail->product_code . '</td>
            <td>' . $data_detail->name . '</td>
            <td>' . number_format($data_detail->price, 0, '.', '.') . '</td>
            <td>' . $label_qty_buy . '</td>
            <td>' . $data_detail->discount . '% ( Rp.' . number_format($data_detail->price_discount, 0, '.', '.') . ' )' . '</td>
            <td>' . $data_detail->bonus . '</td>
            <td>' . number_format($data_detail->total_price, 0, '.', '.') . '</td>
            </tr>
            ';
        } //end foreach
        $data_html .= '
        <tr>
        <td colspan="6" class="text-right">Total Pembelian</td>
        <td>:</td>
        <td><b>Rp.' . number_format($get_data_detail[0]->grand_total_sales, 0, '.', '.') . '</b></td>
        </tr>
        <tr>
        <td colspan="6" class="text-right">PPN ' . $get_data_detail[0]->ppn . ' %</td>
        <td>:</td>
        <td><b> Rp.' . number_format($get_data_detail[0]->ppn_price, 0, '.', '.') . '</b></td>
        </tr>
        <tr>
        <td colspan="6" class="text-right">PPH ' . $get_data_detail[0]->pph . ' %</td>
        <td>:</td>
        <td><b> Rp.' . number_format($get_data_detail[0]->pph_price, 0, '.', '.') . '</b></td>
        </tr>
        <tr>
        <td colspan="6" class="text-right">GRAND TOTAL</td>
        <td>:</td>
        <td><b> Rp.' . number_format($get_data_detail[0]->grand_total, 0, '.', '.') . '</b></td>
        </tr>
        ';

        $data_html .= '
        </tbody>
        </table>
        <hr>
        ' . $html_delivery . '
        ';
        echo $data_html;
    }


    public function get_code_credit()
    {
        $number_text = 0;
        $simbol = 'CD';
        $first_number = 1;
        $code_pattern = substr(date('Y'), 2) . date('md');
        $code_pattern_like = $simbol . $code_pattern;
        // $get_data_exist = $this->db->query("select max(code) as max_code from tb_credit")->row_array();
        $get_data_exist = $this->db->query("select code AS max_code from tb_credit WHERE id IN(SELECT MAX(id) FROM tb_credit)")->row_array();
        if (!empty($get_data_exist['max_code'])) {
            $clean_simbol = substr($get_data_exist['max_code'], 2, strlen($get_data_exist['max_code']));
            $code = $clean_simbol + 1;
        } else {
            $code = $code_pattern . $first_number;
        }
        $code_return = $simbol . $code;
        return $code_return;
    }

    public function confirm_sales()
    {

        $id = $this->encrypt->decode($this->input->post('id'));
        $array_query = [
            'select' => '
                tb_sales.*,
                mst_customer.top_nota
            ',
            'from' => 'tb_sales',
            'join' => [
                'mst_customer , tb_sales.id_member = mst_customer.id , left',
            ],
            'where' => [
                'tb_sales.id =' => $id,
            ]
        ];

        $get_data = Modules::run('database/get', $array_query)->row();

        $credit_code = $this->get_code_credit();
        $deadline = date('Y-m-d', strtotime("+$get_data->top_nota days", strtotime(date('Y-m-d')))); //operasi penjumlahan tanggal sebanyak 6 hari
        //prepare for save
        $array_save_credit = [
            'code' => $credit_code,
            'id_transaction' => $id,
            'id_customer' => $get_data->id_member,
            'invoice_code' => $get_data->code,
            'description' => "piutang customer kode : " . $get_data->code,
            'price' => $get_data->grand_total,
            'rest_credit' => $get_data->grand_total,
            'date' => date('Y-m-d'),
            'deadline' => $deadline,
            'created_by' => $this->session->userdata('us_id')
        ];
        Modules::run('database/insert', 'tb_credit', $array_save_credit);
        //$this->model->insert('tb_credit', $array_save_credit);

        Modules::run('database/update', 'tb_sales', ['id' => $id], ['status' => '1']);
        $array_respon = [
            'status' => TRUE
        ];
        echo json_encode($array_respon);
    }
}
