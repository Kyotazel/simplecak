var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;

var save_method;
var table_data;
var id_use;
$(document).ready(function(){
})

function reload_table(){
     table.ajax.reload(null,false); //reload datatable ajax 
}



$(document).on('click', '.btn_search', function (e) {
    e.preventDefault();
    showLoading();
    $('.html_respon').html('');
    var id_current = $(this).data('id');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    //$('#modal_product').modal('hide');
    // showLoading();
    //defined form
    var formData = new FormData($('.form-input')[0]);
    $.ajax({
        url: url_controller + "search_data",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                $('.html_respon').html(data.html_respon);
                $(".pagination").rPage();
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoading();
            alert_error('something wrong');
        }

    });
});

$(document).on('click', '.btn_detail_sales', function (e) {
    e.preventDefault();
    showLoading();
    var id = $(this).data('id');
    // alert_error(id);
    // $('#modal_view_detail_sales').modal('show');
    showLoading();
    $('.modal-title').text('DETAIL');
    var url = url_controller + 'get_detail_sales';
    // var formData = new FormData($('#form_sales')[0]);
    $.ajax({
        url: url,
        type: "POST",
        data:{'id': id},
        dataType: "HTML",
        success: function(data) {
            hideLoading();
            $('.view_detail_sales').html(data);
            $('#modal_view_detail_sales').modal('show');
            // $('.table_view_sales').DataTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert_error('error process');
            hideLoading();
        }
    });
});


$(document).on('click', '.btn_confirm_sales', function (e) {
    e.preventDefault();
    var id = $(this).data('id');
    swal({
        title: 'Apakah anda yakin?',
        text: "confirm data sales order",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya,simpan data',
        cancelButtonText: 'Batal'
    },
    function(isConfirm) {
        if (isConfirm) {
            showLoading();
            var url;
            $.ajax({
                url: url_controller + '/confirm_sales',
                type: "POST",
                data: {'id':id},
                dataType: "JSON",
                success: function (data) {
                    if (data.status) {
                        alert_success('Data Berhasil Disimpan');
                        $('.btn_search').click();
                    } else {

                    }
                    hideLoading();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    hideLoading();
                    alert_error('something wrong');
                }
            });//end ajax   
        }
    });
});