<div class="card">
    <div class="card-header text-right">
    </div>

    <div class="card-body">
        <form class="form-input">
            <div class="row">
                <div class="col-md-4">
                    <label>Tanggal Awal</label>
                    <input type="text" name="start_date" id="start_date" class="form-control datepicker" />
                </div>
                <div class="col-md-4">
                    <label>Tanggal Akhir</label>
                    <input type="text" name="end_date" id="end_date" class="form-control datepicker" />
                </div>
                <div class="col-md-2">
                    <label>Status</label>
                    <select name="status" id="status" class="form-control">
                        <option value="">Semua</option>
                        <option value="0">Belum terkonfirmasi</option>
                        <option value="1">Telah terkonfirmasi</option>
                        <option value="2">Proses pengiriman</option>
                        <option value="3">Telah diterima</option>
                    </select>
                </div>
                <div class="col-md-2 text-right mt-2" style="padding:0 !important;margin:0 !important;">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-primary btn-rounded btn_search btn-block"> <i class="fa fa-search"></i> Cari Data </button>
                </div>
            </div>
        </form>
        <br />
        <!-- <div class="table-responsive">
            <table class="table table-hover table_data" width="100%">
                <thead>
                    <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Tanggal</th>
                    <th>Sales</th>
                    <th>Customer</th>
                    <th>Grand Total</th>
                    <th>Petugas</th>
                    <th>Aksi</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div> -->
    </div>
</div>


<div class="html_respon"></div>


<div class="modal" id="modal_view_detail_sales" tabindex="-1">
    <div class="modal-dialog" style="min-width:70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Form Sales Order</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="card-body pad">
                <div class="view_detail_sales">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light btn-rounded pull-left" data-dismiss="modal">Close</button>
                <!--  <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>