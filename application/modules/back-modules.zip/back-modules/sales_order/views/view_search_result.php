<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table_data">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Sales Order</th>
                        <th>Petugas</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $array_status = array('belum terkonfirmasi', 'telah terkonfirmasi', 'proses pengiriman', 'telah diterima');
                    $array_color = array('warning', 'success', 'primary', 'info');
                    $no = $start_no;
                    foreach ($data_sales as $data_table) {
                        $array_query['select']  = 'SUM(qty) AS count_data';
                        $array_query['from']    = 'tb_detail_sales';
                        $array_query['where']    = ['id_sales'=>$data_table->id];
                        $count_all_data = Modules::run('database/get', $array_query)->row();

                        $btn_confirm = '';
                        if ($data_table->status == 0) {
                            $btn_confirm = '<a class="btn btn-success btn-sm btn-rounded btn_link btn_confirm_sales" href="javascript:void(0)" title="set konfirmasi" data-id="'. $this->encrypt->encode($data_table->id) .'"><i class="fa fa-check"></i></a>';
                        }
                        $no++;
                        echo '
                            <tr>
                                <td style="vertical-align:middle;">' . $no . '</td>
                                <td>
                                    <h3 class="text-center"><span class="badge badge-light">'. $data_table->code .'</span></h3>
                                    <div class="p-1 rounded border-dashed d-block text-center text-capitalize font-weight-bold">
                                        <span class="text-primary text-uppercase">
                                        <small class="text-muted"><i class="fa fa-calendar"></i> '. $data_table->date .'</small>
                                    </div>

                                    <div class="row">
                                        <div class="col-6 border-dashed p-2">
                                            <small class="text-muted d-block"><i class="fa fa-info-circle"></i> Sales :</small>
                                            <label class=" text-grand-total-freight font-weight-bold m-0 tx-12 text-primary">'. strtoupper($data_table->sales) .'</label>
                                        </div>
                                        <div class="col-6 border-dashed p-2">
                                            <small class="text-muted d-block"><i class="fa fa-info-circle"></i> Customer :</small>
                                            <label class=" text-grand-total-freight font-weight-bold m-0 tx-12 text-primary">'. strtoupper($data_table->customer) .'</label>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <small for="" class="d-block text-muted"> Petugas Input:</small>
                                    <p class="border-dashed tx-13 p-1 mb-1">'. $data_table->employee .'</p>
                                    <small for="" class="d-block text-muted">Tanggal Input :</small>
                                    <p class="border-dashed tx-13 p-1 mb-1">'. $data_table->created_date .'</p>
                                </td>
                                <td style="vertical-align:middle;">
                                <small class="d-block text-muted">Total Qty :</small>
                                <label for="" class="font-weight-bold tx-16 text-primary">'. $count_all_data->count_data .'</label>
                                <small class="d-block text-muted">Grand Total :</small>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text font-weight-bold">
                                            Rp.
                                        </div>
                                    </div>
                                    <input value="'. number_format($data_table->grand_total, 0, '.', '.') .'" readonly="" data-target="text-count-13" data-qty="2" class="form-control font-weight-bold rupiah count_price_item bg-white border-dashed" name="price[13]" type="text">
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-6">
                                    '. $btn_confirm .'
                                    <a class="btn btn-primary btn-sm btn-rounded btn_link btn_detail_sales" data-id="'. $this->encrypt->encode($data_table->id) .'" href="javascrypt:void(0)" title="detail"><i class="fa fa-tv"></i></a>
                                    </div>
                                    <div class="col-6">
                                        <h4 class="text-right"><span class="badge badge-'. $array_color[$data_table->status] .'">'. $array_status[$data_table->status] .'</span></h4>
                                    </div>
                                </div>                                
                                </td>
                            </tr>
                        ';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-4">
                    <!--Tampilkan pagination-->
                    <?php echo $html_pagination; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.box-body -->
</div>