<?php
$array_month = [
    '01' => 'januari',
    '02' => 'februari',
    '03' => 'maret',
    '04' => 'april',
    '05' => 'mei',
    '06' => 'juni',
    '07' => 'juli',
    '08' => 'agustus',
    '09' => 'september',
    '10' => 'oktober',
    '11' => 'november',
    '12' => 'december'
];


?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title">RIWAYAT PENGGAJIAN</h4>
        <form class="form-search">
            <div class="row p-2 border-dashed">
                <div class="col-3">
                    <label for="">Periode Operasional</label>
                    <select name="period_operational[]" multiple class="form-control chosen">
                        <?php
                        foreach ($data_period as $item_data) {
                            echo '
                                    <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                ';
                        }
                        ?>
                    </select>
                </div>
                <div class="col-4">
                    <div class="row">
                        <div class="col-6">
                            <label for="">Tahun</label>
                            <select name="year[]" multiple class="form-control chosen">
                                <?php
                                $max_year = $year->max_year;
                                $min_year = $year->min_year;
                                echo '
                                    <option value="' . $min_year . '">' . $min_year . '</option>
                                ';

                                for ($i = 0; $i < ($max_year - $min_year); $i++) {
                                    echo '
                                        <option value="' . $min_year++ . '">' . $min_year++ . '</option>
                                    ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label for="">Bulan</label>
                            <select name="month[]" multiple class="form-control chosen">
                                <?php
                                foreach ($array_month as $key => $item_data) {
                                    echo '
                                    <option value="' . $key . '">' . strtoupper($item_data) . '</option>
                                ';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="row">
                        <div class="col-6">
                            <label for="">Devisi</label>
                            <select name="devision[]" multiple id="" class="form-control chosen">
                                <?php
                                foreach ($devision as $item_data) {
                                    echo '
                                    <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                ';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label for="">Jabatan</label>
                            <select name="position[]" multiple id="" class="form-control chosen">
                                <?php
                                foreach ($position as $item_data) {
                                    echo '
                                    <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                ';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-1">
                    <label for="">&nbsp;</label><br>
                    <button class="btn btn-primary btn_search_payroll"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
        <div class="col-md-12 html_respon mt-3">
            <div class="col-12 text-center">
                <div class="plan-card text-center">
                    <i class="fas fa-file plan-icon text-primary"></i>
                    <h6 class="text-drak text-uppercase mt-2">LAKUKAN PENCARIAN DATA</h6>
                    <small class="text-muted">Lakukan pencarian data terlebih dahulu</small>
                </div>
            </div>
        </div>
    </div>
</div>