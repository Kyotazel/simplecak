<?php
$array_month = [
    '01' => 'januari',
    '02' => 'februari',
    '03' => 'maret',
    '04' => 'april',
    '05' => 'mei',
    '06' => 'juni',
    '07' => 'juli',
    '08' => 'agustus',
    '09' => 'september',
    '10' => 'oktober',
    '11' => 'november',
    '12' => 'december'
];
?>
<div class="row">
    <div class="col-8">
        <div class="card">
            <div class="card-header bg-primary-gradient">
                <div class="row">
                    <h4 class="card-title m-0 col-12 p-0 text-white">Periode Penggajian :</h4>
                    <div class="p-2 border-dashed col-6 d-flex justify-content-center align-items-center text-white">
                        <small><i class="fa fa-check-circle"></i> Periode Operasional :</small>
                        <label for="" class="tx-16 font-weight-bold ml-2 text-uppercase m-0"><?= $data_period->period_name; ?></label>
                    </div>
                    <div class="p-2 border-dashed col-6 d-flex justify-content-center align-items-center text-white">
                        <small><i class="fa fa-check-circle"></i> Periode Penggajian :</small>
                        <label for="" class="tx-16 font-weight-bold ml-2 text-uppercase m-0"><?= $array_month[$data_period->month] . ' - ' . $data_period->year; ?></label>
                    </div>
                </div>
            </div>
            <div class="card-body">

                <form class="form-payroll">
                    <div class="row">
                        <div class="col-6 border-dashed p-2">
                            <label for="" class="font-weight-bold"><i class="fa fa-tv"></i> Resume Total Jam Kerja :</label>
                            <div class="form-group row mb-2">
                                <div class="col-4 text-right">
                                    <label class="m-0">Total jam Kerja</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <input class="form-control  font-weight-bold bg-white rupiah" name="total_hours_work" type="text">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                JAM
                                            </div>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_total_hours_work"></span>
                                </div>
                            </div>
                            <div class="form-group row mb-2">
                                <div class="col-4 text-right">
                                    <label class="m-0">Total jam Absen</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <input class="form-control  font-weight-bold  rupiah bg-white" name="total_hours_absen" type="text">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                JAM
                                            </div>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_total_hours_absen"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-6 border-dashed p-2">
                            <label for="" class="font-weight-bold"><i class="fa fa-tv"></i> Resume Total Hari kerja :</label>
                            <div class="form-group row mb-2">
                                <div class="col-4 text-right">
                                    <label class="m-0">Jumlah hari Kerja</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <input class="form-control  font-weight-bold   bg-white rupiah" name="total_day_work" type="text">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                HARI
                                            </div>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_total_day_work"></span>
                                </div>
                            </div>
                            <div class="form-group row mb-2">
                                <div class="col-4 text-right">
                                    <label class="m-0">Jumlah Hari Absen</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <input class="form-control  font-weight-bold rupiah   bg-white" name="total_day_absen" type="text">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                HARI
                                            </div>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_total_day_absen"></span>
                                </div>
                            </div>
                            <div class="form-group row mb-2">
                                <div class="col-4 text-right">
                                    <label class="m-0">Jumlah Hari Izin</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <input class="form-control  font-weight-bold rupiah   bg-white" name="total_day_permit" type="text">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                HARI
                                            </div>
                                        </div>
                                    </div>
                                    <span class="help-block text-danger notif_total_day_permit"></span>
                                </div>
                            </div>
                        </div>
                        <div class="mb-4 col-12 border-dashed p-2">
                            <label for="" class="font-weight-bold"><i class="fa fa-tv"></i> Nominal Gaji :</label>
                            <div class="form-group row mb-2">
                                <div class="col-2 text-right">
                                    <label class="m-0">Gaji Pokok</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                Rp.
                                            </div>
                                        </div>
                                        <input class="form-control  font-weight-bold count_salary rupiah bg-white" name="main_salary" type="text">
                                    </div>
                                    <span class="help-block text-danger notif_main_salary"></span>
                                </div>
                                <div class="col-5">
                                    <small>(* masukan gaji pokok)</small>
                                </div>
                            </div>
                            <div class="form-group row mb-2">
                                <div class="col-2 text-right">
                                    <label class="m-0">Tunjangan Jabatan</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                Rp.
                                            </div>
                                        </div>
                                        <input class="form-control  font-weight-bold count_salary rupiah bg-white" name="position_salary" type="text">
                                    </div>
                                    <span class="help-block text-danger notif_position_salary"></span>
                                </div>
                                <div class="col-5">
                                    <small>(* masukan gaji tunjangan jabatan)</small>
                                </div>
                            </div>
                            <div class="form-group row mb-2">
                                <div class="col-2 text-right">
                                    <label class="m-0">Bonus</label>
                                </div>
                                <div class="col-5">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                Rp.
                                            </div>
                                        </div>
                                        <input class="form-control  font-weight-bold count_salary rupiah count_price_item bg-white" name="bonus_salary" type="text">
                                    </div>
                                    <span class="help-block text-danger notif_bonus_salary"></span>
                                </div>
                                <div class="col-5">
                                    <small>(* masukan gaji bonus)</small>
                                </div>
                            </div>
                            <hr>
                            <label for="" class="font-weight-bold"><i class="fa fa-tv"></i> Nominal Gaji Lainnya :</label>
                            <div class="form-group row">
                                <div class="col-3">
                                    <label class="m-0">Nominal</label>
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                Rp.
                                            </div>
                                        </div>
                                        <input class="form-control  font-weight-bold add_other_salary rupiah bg-white" name="pattern_price_salary" type="text">
                                    </div>
                                    <span class="help-block notif_other_salary notif_pattern_price_salary text-danger"></span>
                                </div>
                                <div class="col-7">
                                    <label class="m-0">Keterangan</label>
                                    <input type="text" class="form-control add_other_salary " name="pattern_desc_salary">
                                    <span class="help-block notif_pattern_desc_salary text-danger"></span>
                                </div>
                                <div class="col-2">
                                    <label for="" class="m-0">&nbsp;</label><br>
                                    <a href="javascript:void(0)" class="btn btn-primary btn_add_other_salary"><i class="fa fa-plus"></i></a>
                                </div>
                            </div>
                            <div class="form-group row mt-2 ">
                                <div class="col-12 html_respon_other_salary"></div>
                                <div class="col-12 text-center p-3 html_empty_other_salary border-dashed">
                                    <div class="plan-card  col-12 d-flex justify-content-center align-items-center">
                                        <div class="feature widget-2 text-center mt-0 mr-3">
                                            <i class="fa fa-file project bg-primary-transparent mx-auto text-primary "></i>
                                        </div>
                                        <div>
                                            <h6 class="text-drak text-uppercase m-0">Data Kosong</h6>
                                            <small class="text-muted">Tidak ada data gaji tambahan.</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <label for="" class="font-weight-bold"><i class="fa fa-tv"></i> Nominal Potongan Gaji :</label>
                            <div class="form-group row">
                                <div class="col-3">
                                    <label class="m-0">Nominal</label>
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <div class="input-group-text font-weight-bold">
                                                Rp.
                                            </div>
                                        </div>
                                        <input class="form-control  font-weight-bold  rupiah bg-white add_cut_salary" name="pattern_price_cut" type="text">
                                    </div>
                                    <span class="help-block text-danger notif_pattern_price_cut"></span>
                                </div>
                                <div class="col-7">
                                    <label class="m-0">Keterangan</label>
                                    <input type="text" class="form-control add_cut_salary" name="pattern_desc_cut">
                                    <span class="help-block text-danger notif_pattern_desc_cut"></span>
                                </div>
                                <div class="col-2">
                                    <label for="" class="m-0">&nbsp;</label><br>
                                    <a href="javascript:void(0)" class="btn btn-primary btn_add_cut"><i class="fa fa-plus"></i></a>
                                </div>
                            </div>
                            <div class="col-12 html_respon_cut mt-2"></div>
                            <div class="form-group row mt-2 border-dashed html_empty_cut">
                                <div class="col-12 text-center p-3">
                                    <div class="plan-card  col-12 d-flex justify-content-center align-items-center">
                                        <div class="feature widget-2 text-center mt-0 mr-3">
                                            <i class="fa fa-file project bg-primary-transparent mx-auto text-primary "></i>
                                        </div>
                                        <div>
                                            <h6 class="text-drak text-uppercase m-0">Data Kosong</h6>
                                            <small class="text-muted">Tidak ada data potongan gaji.</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-4 ">
        <div class="card">
            <div class="card-body">
                <div class="mb-3 text-center">
                    <h4 class="card-title m-0">Resume Transaksi :</h4>
                    <div class="p-2 border-dashed">
                        <small class="d-block"><i class="fa fa-check-circle"></i> Total gaji :</small>
                        <h1 class="text-primary font-weight-bold total_salary" data-price="0">Rp.0</h1>
                    </div>
                </div>
                <div class="mb-3">
                    <h4 class="card-title m-0 text-center">Tambahkan Pegawai </h4>
                    <div class="p-2 border-dashed mt-1 html_employee">
                        <div class="plan-card  col-12 d-flex justify-content-center align-items-center">
                            <div class="feature widget-2 text-center mt-0 mr-3">
                                <i class="fa fa-user project bg-primary-transparent mx-auto text-primary "></i>
                            </div>
                            <div>
                                <h6 class="text-drak text-uppercase m-0 text-center">DATA PEGAWAI</h6>
                                <small class="text-muted">silahkan pilih pegawai untuk slip gaji ini .</small>
                            </div>
                        </div>
                        <div class="row border-top mt-2 pt-1">
                            <div class="col-6">
                                <label for="" class="m-0">Jabatan :</label>
                                <select name="position" class="form-control chosen payroll_position" id="">
                                    <option value="">Semua</option>
                                    <?php
                                    foreach ($option_position as $item_data) {
                                        echo '
                                                <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                            ';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-6">
                                <label for="" class="m-0">Devisi :</label>
                                <select name="devision" class="form-control chosen payroll_devision" id="">
                                    <option value="">Semua</option>
                                    <?php
                                    foreach ($option_devision as $item_data) {
                                        echo '
                                                <option value="' . $item_data->id . '">' . $item_data->name . '</option>
                                            ';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-12 mt-2">
                                <label for="" class="m-0">Pegawai :</label>
                                <select name="employee" class="form-control chosen payroll_employee" id=""></select>
                                <span class="help-block notif_employee text-danger"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3 text-center">
                    <div class="d-flex justify-content-center">
                        <h4 class="card-title m-0 ml-1">Tambahkan ke jurnal : &nbsp;</h4>
                        <div data-menu="horizontal" data-id="54" class="main-toggle main-toggle-dark change_status_jurnal"><span></span></div>
                    </div>
                    <div class="p-2 border-dashed mt-1 html_employee">
                        <div class="plan-card  col-12 d-flex justify-content-center align-items-center html_empty_jurnal">
                            <div class="feature widget-2 text-center mt-0 mr-3">
                                <i class="fa fa-file project bg-primary-transparent mx-auto text-primary "></i>
                            </div>
                            <div>
                                <h6 class="text-drak text-uppercase m-0">jurnal</h6>
                                <small class="text-muted">silahkan cetang untuk menambahkan jurnal .</small>
                            </div>
                        </div>

                        <div class="html_form_jurnal" style="display: none;">
                            <div class="form-group text-left">
                                <label for="">Akun Kas</label>
                                <select name="account_bank" class="form-control chosen" id="">
                                    <?php
                                    foreach ($account_bank as $item_account) {
                                        echo '
                                                <option value="' . $item_account->id . '">01-' . $item_account->code . ' - ' . $item_account->name . ' </option>
                                            ';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group text-left">
                                <label for="">Akun Biaya</label>
                                <select name="account_cost" class="form-control chosen" id="">
                                    <?php
                                    foreach ($account_cost as $item_account) {
                                        echo '
                                                <option value="' . $item_account->id . '">05-' . $item_account->code . ' - ' . $item_account->name . ' </option>
                                            ';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="mt-4 text-center">
                    <a href="javascript:void(0)" class="btn btn-warning-gradient btn-rounded font-weight-bold btn-lg btn_save_payroll" data-id="<?= $data_period->id; ?>" style="width: 80%;">Simpan Data <i class="fa fa-paper-plane"></i></a>
                    <hr>
                    <a href="<?= Modules::run('helper/create_url', 'payroll/detail?data=' . urlencode($this->encrypt->encode($data_period->id))) ?>" class="btn btn-light btn-rounded font-weight-bold btn-lg " style="width: 80%;"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>