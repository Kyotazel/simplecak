<?php
$array_month = [
    '01' => 'januari',
    '02' => 'februari',
    '03' => 'maret',
    '04' => 'april',
    '05' => 'mei',
    '06' => 'juni',
    '07' => 'juli',
    '08' => 'agustus',
    '09' => 'september',
    '10' => 'oktober',
    '11' => 'november',
    '12' => 'december'
];
$count_employee = Modules::run('database/find', 'mst_employee', ['isActive' => 'Y'])->result();

foreach ($period as $item_period) {
    $count_all_salary = Modules::run('database/find', 'tb_operational_salary', ['id_category_salary' => $item_period->id])->result();
    $percentage = round((count($count_all_salary) / count($count_employee)) * 100);
    $percentage = $percentage >= 100 ? 100 : $percentage;

    $btn_add = '<a href="' . Modules::run('helper/create_url', 'payroll/detail?data=' . urlencode($this->encrypt->encode($item_period->id))) . '" class="btn btn-warning-gradient btn-rounded font-weight-bold">Masuk ke transaksi <i class="fa fa-paper-plane"></i></a>';
    $btn_delete = Modules::run('security/delete_access', '<a href="javascript:void(0)" data-redirect="0" data-id="' . $item_period->id . '" class="btn btn-danger-gradient font-weight-bold btn-rounded btn_delete_group_salary"><i class="fa fa-trash"></i> Hapus</a>');

    echo '
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                <div class="card">
                    <div class="card-header bg-primary-gradient text-white p-3">
                        <div class="d-flex justify-content-between ">
                            <h4 class="card-title m-0 font-weight-bold text-white tx-16">' . $array_month[$item_period->month] . ' - ' . $item_period->year . '</h4>
                            <span class="badge badge-primary badge-pill tx-12 pr-2 pl-2">' . count($count_all_salary) . ' Slip Gaji</span>
                        </div>
                    </div>
                    <div class="card-body iconfont text-left ">
                        <div class="d-flex mb-0">
                            <div class="">
                                <h4 class="mb-1 font-weight-bold">Rp.' . number_format($item_period->total_all_salary, 0, '.', '.') . '</h4>
                                <p class="mb-2 tx-12 text-muted">Total gaji dalam Periode ini.</p>
                            </div>
                            <div class="card-chart bg-primary-transparent brround ml-auto mt-0">
                                <i class="typcn typcn-group-outline text-primary tx-24"></i>
                            </div>
                        </div>

                        <div class="progress progress-sm mt-2">
                            <div aria-valuemax="100" aria-valuemin="0" aria-valuenow="' . $percentage . '" class="progress-bar progress-bar-striped progress-bar-animated bg-primary wd-' . $percentage . 'p" role="progressbar"></div>
                        </div>
                        <small class="mb-0  text-muted">' . count($count_all_salary) . ' dari ' . count($count_employee) . ' pegawai<span class="float-right text-muted">' . $percentage . '%</span></small>
                    </div>
                    <div class="card-footer text-right d-flex justify-content-between">
                        ' . $btn_delete . $btn_add . '
                    </div>
                </div>
            </div>
        ';
}



if (empty($period)) {
    echo '
        <div class="card col-12">
            <div class="card-body">
                <div class="col-12 text-center">
                    <div class="plan-card text-center">
                        <i class="fas fa-truck plan-icon text-primary"></i>
                        <h6 class="text-drak text-uppercase mt-2">Data Kosong</h6>
                        <small class="text-muted">Tidak ada item periode penggajian.</small>
                    </div>
                </div>
            </div>
        </div>
    ';
}
