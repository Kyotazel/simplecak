<?php
$array_month = [
    '01' => 'januari',
    '02' => 'februari',
    '03' => 'maret',
    '04' => 'april',
    '05' => 'mei',
    '06' => 'juni',
    '07' => 'juli',
    '08' => 'agustus',
    '09' => 'september',
    '10' => 'oktober',
    '11' => 'november',
    '12' => 'december'
];
$count_employee = Modules::run('database/find', 'mst_employee', ['isActive' => 'Y'])->result();
$count_all_salary = Modules::run('database/find', 'tb_operational_salary', ['id_category_salary' => $data_period->id])->result();
$percentage = round((count($count_all_salary) / count($count_employee)) * 100);
$percentage = $percentage >= 100 ? 100 : $percentage;

$btn_back = '<a href="' . Modules::run('helper/create_url', 'payroll') . '" class="btn btn-light btn-rounded font-weight-bold"><i class="fa fa-arrow-circle-left"></i> Kembali </a>';
$btn_delete = Modules::run('security/delete_access', '<a href="javascript:void(0)" data-redirect="1" data-id="' . $data_period->id . '" class="btn btn-danger-gradient font-weight-bold btn-rounded btn_delete_group_salary"><i class="fa fa-trash"></i> Hapus</a>');

$btn_add = Modules::run('security/create_access', '<a href="' . Modules::run('helper/create_url', 'payroll/add?period=' . urlencode($this->encrypt->encode($data_period->id))) . '" data-id="' . $data_period->id . '" class="btn btn-primary-gradient font-weight-bold btn-rounded"><i class="fa fa-plus-circle"></i> Tambah Slip Gaji</a>');

?>
<div class="row">
    <div class="col-3">
        <div class="card">
            <div class="card-header bg-primary-gradient text-white p-3">
                <div class="d-flex justify-content-between ">
                    <h4 class="card-title m-0 font-weight-bold text-white tx-16"><?= $array_month[$data_period->month] . ' - ' . $data_period->year ?></h4>
                    <span class="badge badge-primary badge-pill tx-12 pr-2 pl-2"><?= count($count_all_salary); ?> Slip Gaji</span>
                </div>
            </div>
            <div class="card-body iconfont text-left ">
                <div class="d-flex mb-0">
                    <div class="">
                        <h4 class="mb-1 font-weight-bold">Rp.<?= number_format($data_period->total_all_salary, 0, '.', '.'); ?></h4>
                        <p class="mb-2 tx-12 text-muted">Total gaji dalam Periode ini.</p>
                    </div>
                    <div class="card-chart bg-primary-transparent brround ml-auto mt-0">
                        <i class="typcn typcn-group-outline text-primary tx-24"></i>
                    </div>
                </div>

                <div class="progress progress-sm mt-2">
                    <div aria-valuemax="100" aria-valuemin="0" aria-valuenow="0" class="progress-bar progress-bar-striped progress-bar-animated bg-primary wd-<?= $percentage; ?>p" role="progressbar"></div>
                </div>
                <small class="mb-0  text-muted"><?= count($count_all_salary) . ' dari ' . count($count_employee); ?> pegawai<span class="float-right text-muted"><?= $percentage; ?>%</span></small>
            </div>
            <div class="card-footer text-right d-flex justify-content-between">
                <?= $btn_back . $btn_delete; ?>
            </div>
        </div>
    </div>
    <div class="col-9">
        <div class="card">
            <div class="card-header row p-3">
                <h4 class="card-title col-6  tx-16">Daftar Slip Gaji </h4>
                <div class="col-6 text-right">
                    <?= $btn_back . '&nbsp;&nbsp;&nbsp;' . $btn_add; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table t-shadow table-bordered" id="table_data" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>pegawai</th>
                                <th>Detail Slip Gaji</th>
                            </tr>
                        </thead>
                        <tbody class="">
                            <?php
                            $counter = 0;
                            foreach ($data_salary as $item_salary) {
                                $counter++;
                                $btn_delete_item = Modules::run('security/delete_access', '<a href="javascript:void(0)" data-id="' . $item_salary->id . '" class="btn btn-danger-gradient font-weight-bold btn-rounded btn-sm btn_delete-salary"><i class="fa fa-trash"></i> Hapus</a>');


                                $html_other_salary = '';
                                $array_other_salary = json_decode($item_salary->other_salary);
                                $total_other_salary = 0;
                                foreach ($array_other_salary as $item_salary_detail) {
                                    $html_other_salary .= '
                                        <tr>
                                            <td>' . $item_salary_detail->name . '</td>
                                            <td><label for="" class="font-weight-bold m-0">Rp.' . number_format($item_salary_detail->price, 0, '.', '.') . '</label></td>
                                        </tr>
                                    ';
                                }

                                $html_cut_salary = '';
                                $array_cut_salary = json_decode($item_salary->cut_salary);
                                $total_cut_salary = 0;
                                foreach ($array_cut_salary as $item_salary_detail) {
                                    $html_cut_salary .= '
                                        <tr>
                                            <td>' . $item_salary_detail->name . '</td>
                                            <td><label for="" class="font-weight-bold m-0">Rp.' . number_format($item_salary_detail->price, 0, '.', '.') . '</label></td>
                                        </tr>
                                    ';
                                }

                                $total_salary = $item_salary->main_salary + $item_salary->position_salary + $item_salary->bonus_salary + $total_other_salary;


                                $html_detail = '
                                    <table class="table">
                                        <tr>
                                            <th colspan="2">Resume Total Jam Kerja :</th>
                                        </tr>
                                        <tr>
                                            <td style="width: 200px;">Total jam Kerja</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">' . $item_salary->total_work_hours . ' Jam</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Total jam Absen</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">' . $item_salary->total_absen_hours . ' Jam</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th colspan="2">Resume Total Hari kerja :</th>
                                        </tr>
                                        <tr>
                                            <td>Jumlah hari Masuk</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">' . $item_salary->total_work_day . ' Hari</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Jumlah hari Izin</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">' . $item_salary->total_permit_day . ' Hari</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Jumlah hari Absen</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">' . $item_salary->total_absen_day . ' hari</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th colspan="2">Detail Rincian Gaji :</th>
                                        </tr>
                                        <tr>
                                            <td>Gaji Pokok</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">Rp. ' . number_format($item_salary->main_salary, 0, '.', '.') . '</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Tunjangan Jabatan</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">Rp. ' . number_format($item_salary->position_salary, 0, '.', '.') . '</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Bonus</td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold">Rp. ' . number_format($item_salary->bonus_salary, 0, '.', '.') . '</label>
                                            </td>
                                        </tr>
                                        ' . $html_other_salary . '
                                        <tr>
                                            <td>Total Gaji: </td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold text-primary">Rp. 90.000</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th colspan="2">Detail Potongan Gaji :</th>
                                        </tr>
                                        ' . $html_cut_salary . '
                                        <tr>
                                            <td>Total Potongan Gaji </td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold text-primary">Rp. ' . number_format($total_cut_salary, 0, '.', '.') . '</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Diterima: </td>
                                            <td>
                                                <label for="" class="m-0 font-weight-bold text-primary tx-20">Rp. ' . number_format($item_salary->total_all_salary, 0, '.', '.') . '</label>
                                            </td>
                                        </tr>
                                    </table>
                                ';


                                echo '
                                    <tr>
                                            <td>' . $counter . '</td>
                                            <td>
                                                <div class="row">
                                                    <div class="row col-12 border-dashed p-2">
                                                        <div class="col">
                                                            <small class="d-block text-muted d-block"><i class="fa fa-check-circle"></i> Pegawai :</small>
                                                            <h3 class=" mt-2 mb-2 text-primary tx-uppercase"><b>' . $item_salary->employee_name . '</b></h3>
                                                            <p class="tx-12">' . $item_salary->employee_address . '</p>
                                                        </div>
                                                        <div class="col-auto align-self-center ">
                                                            <div class="feature mt-0 mb-0">
                                                                <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 border-dashed p-2">
                                                        <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Jabatan :</small>
                                                        <label for="" class="d-block text-uppercase font-weight-bold">' . $item_salary->position_name . '</label>
                                                    </div>
                                                    <div class="col-6 border-dashed p-2">
                                                        <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Devisi :</small>
                                                        <label for="" class="d-block text-uppercase font-weight-bold">' . $item_salary->devision_name . '</label>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-12 border-dashed p-2">
                                                        <div class="row m-0">
                                                            <div class="col-4 border-right ">
                                                                <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Masuk :</small>
                                                                <div class="input-group">
                                                                    <input class="form-control  font-weight-bold bg-white rupiah border-dashed" value="' . $item_salary->total_work_day . '" readonly name="total_hours_work" type="text">
                                                                    <div class="input-group-append">
                                                                        <div class="input-group-text font-weight-bold">
                                                                            HARI
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-4 border-right ">
                                                                <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Absen :</small>
                                                                <div class="input-group">
                                                                    <input class="form-control  font-weight-bold bg-white rupiah border-dashed" value="' . $item_salary->total_absen_day . '" readonly name="total_hours_work" type="text">
                                                                    <div class="input-group-append">
                                                                        <div class="input-group-text font-weight-bold">
                                                                            HARI
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-4 ">
                                                                <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Izin :</small>
                                                                <div class="input-group">
                                                                    <input class="form-control  font-weight-bold bg-white rupiah border-dashed" value="' . $item_salary->total_permit_day . '" readonly name="total_hours_work" type="text">
                                                                    <div class="input-group-append">
                                                                        <div class="input-group-text font-weight-bold">
                                                                            HARI
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 border-dashed p-2">
                                                        <small class="d-block text-muted mb-1"><i class="fa fa-check-circle"></i> Total gaji : </small>
                                                        <div class="d-flex mb-0">
                                                            <div class="">
                                                                <h5 class="mb-1 font-weight-bold">Rp. ' . number_format($total_salary, 0, '.', '.') . '<span class="text-success tx-13 ml-2"></span></h5>
                                                                <p class="mb-2 tx-12 text-muted">kalkulasi total semua penghitungan gaji.</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 border-dashed p-2">
                                                        <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Total Potongan :</small>
                                                        <div class="d-flex mb-0">
                                                            <div class="">
                                                                <h4 class="mb-1 font-weight-bold">Rp.' . number_format($total_cut_salary, 0, '.', '.') . '</h4>
                                                                <p class="mb-2 tx-12 text-muted"> kalkulasi total semua potongan gaji.</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 bg-gradient text-right p-2 d-flex align-items-center justify-content-end ">
                                                        <h4 class="card-title m-0">Total Diterima :</h4>
                                                        <h2 class="text-primary m-0 ml-3"><b>Rp.' . number_format($item_salary->total_all_salary, 0, '.', '.') . '</b></h2>
                                                    </div>
                                                    <div class="col-12 text-right">
                                                        ' . $btn_delete_item . '
                                                        <a class="btn btn-primary btn-sm btn-rounded" data-toggle="collapse" href="#view_' . $counter . '" role="button" aria-expanded="false" aria-controls="collapseExample">
                                                            <i class="fa fa-tv"></i> Detail Slip Gaji
                                                        </a>
                                                    </div>
                                                    <div class="collapse col-12 mt-2 " id="view_' . $counter . '">
                                                        <div class="card card-body">
                                                            ' . $html_detail . '
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    ';
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" id="modal_form_salary" data-backdrop="static">
    <div class="modal-dialog" style="max-width: 70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form id="form-data">
                    <div class="row">
                        <div class=""></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>