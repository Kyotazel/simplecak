<?php
$array_month = [
    '01' => 'januari',
    '02' => 'februari',
    '03' => 'maret',
    '04' => 'april',
    '05' => 'mei',
    '06' => 'juni',
    '07' => 'juli',
    '08' => 'agustus',
    '09' => 'september',
    '10' => 'oktober',
    '11' => 'november',
    '12' => 'december'
];
$html_option = '';
foreach ($array_month as $key => $item_month) {
    $html_option .= '
        <option value="' . $key . '">' . $item_month . '</option>
    ';
}
?>
<div class="row">
    <div class="col-5">
        <label for="">Periode Operasional :</label>
        <select name="period_search" class="form-control" id="">
            <?php
            $period_name = '';
            foreach ($period as $item_period) {
                $selected = $item_period->status ? 'selected' : '';
                if ($item_period->status) {
                    $period_name = $item_period->name;
                }
                echo '
                        <option ' . $selected . ' value="' . $item_period->id . '">' . $item_period->name . '</option>
                    ';
            }
            ?>
        </select>
    </div>
    <div class="col-3">
        <label for="">&nbsp;</label><br>
        <a href="javascript:void(0)" class="btn btn-primary-gradient font-weight-bold btn_add_salary"><i class="fa fa-plus-circle"></i> Tambah Periode Gaji</a>
    </div>
</div>

<div class="row row-sm mt-3 html_respon_salary"></div>

<div class="modal fade" tabindex="-1" id="modal_form">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form id="form-data">
                    <div class="row">
                        <div class="form-group col-12 text-center">
                            <small class="d-block">Periode Aktif :</small>
                            <h4 class="p-2 border-dashed"><?= $period_name; ?></h4>
                        </div>
                        <div class="form-group col-6">
                            <label>Bulan</label>
                            <select name="month" class="form-control text-uppercase" id=""><?= $html_option; ?></select>
                            <span class="help-block notif_month"></span>
                        </div>
                        <div class="form-group col-6">
                            <label>Tahun</label>
                            <input type="number" class="form-control" name="year" />
                            <span class="help-block notif_year"></span>
                        </div>

                        <div class="col-12 text-right">
                            <button type="submit" class="btn btn-primary btn_save_priod"><i class="fa fa-save"></i> Simpan Data</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>