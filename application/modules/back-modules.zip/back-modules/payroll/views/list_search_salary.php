<?php
$array_month = [
    '01' => 'januari',
    '02' => 'februari',
    '03' => 'maret',
    '04' => 'april',
    '05' => 'mei',
    '06' => 'juni',
    '07' => 'juli',
    '08' => 'agustus',
    '09' => 'september',
    '10' => 'oktober',
    '11' => 'november',
    '12' => 'december'
];

?>
<div class="table-responsive">
    <table class="table t-shadow table-bordered" id="table_data" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>pegawai</th>
                <th>Periode</th>
                <th>Detail Slip Gaji</th>
            </tr>
        </thead>
        <tbody class="">
            <?php
            $counter = 0;
            foreach ($data_salary as $item_salary) {
                $counter++;
                $btn_delete_item = Modules::run('security/delete_access', '<a href="javascript:void(0)" data-id="' . $item_salary->id . '" class="btn btn-danger-gradient font-weight-bold btn-rounded btn-sm btn_delete-salary"><i class="fa fa-trash"></i> Hapus</a>');


                $html_other_salary = '';
                $array_other_salary = json_decode($item_salary->other_salary);
                $total_other_salary = 0;
                foreach ($array_other_salary as $item_salary_detail) {
                    $html_other_salary .= '
                                        <tr>
                                            <td>' . $item_salary_detail->name . '</td>
                                            <td><label for="" class="font-weight-bold m-0">Rp.' . number_format($item_salary_detail->price, 0, '.', '.') . '</label></td>
                                        </tr>
                                    ';
                }

                $html_cut_salary = '';
                $array_cut_salary = json_decode($item_salary->cut_salary);
                $total_cut_salary = 0;
                foreach ($array_cut_salary as $item_salary_detail) {
                    $html_cut_salary .= '
                                        <tr>
                                            <td>' . $item_salary_detail->name . '</td>
                                            <td><label for="" class="font-weight-bold m-0">Rp.' . number_format($item_salary_detail->price, 0, '.', '.') . '</label></td>
                                        </tr>
                                    ';
                }

                $total_salary = $item_salary->main_salary + $item_salary->position_salary + $item_salary->bonus_salary + $total_other_salary;


                $html_detail = '
                                <table class="table">
                                    <tr>
                                        <th colspan="2">Resume Total Jam Kerja :</th>
                                    </tr>
                                    <tr>
                                        <td style="width: 200px;">Total jam Kerja</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">' . $item_salary->total_work_hours . ' Jam</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Total jam Absen</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">' . $item_salary->total_absen_hours . ' Jam</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Resume Total Hari kerja :</th>
                                    </tr>
                                    <tr>
                                        <td>Jumlah hari Masuk</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">' . $item_salary->total_work_day . ' Hari</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Jumlah hari Izin</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">' . $item_salary->total_permit_day . ' Hari</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Jumlah hari Absen</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">' . $item_salary->total_absen_day . ' hari</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Detail Rincian Gaji :</th>
                                    </tr>
                                    <tr>
                                        <td>Gaji Pokok</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">Rp. ' . number_format($item_salary->main_salary, 0, '.', '.') . '</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan Jabatan</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">Rp. ' . number_format($item_salary->position_salary, 0, '.', '.') . '</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Bonus</td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold">Rp. ' . number_format($item_salary->bonus_salary, 0, '.', '.') . '</label>
                                        </td>
                                    </tr>
                                    ' . $html_other_salary . '
                                    <tr>
                                        <td>Total Gaji: </td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold text-primary">Rp. 90.000</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Detail Potongan Gaji :</th>
                                    </tr>
                                    ' . $html_cut_salary . '
                                    <tr>
                                        <td>Total Potongan Gaji </td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold text-primary">Rp. ' . number_format($total_cut_salary, 0, '.', '.') . '</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Diterima: </td>
                                        <td>
                                            <label for="" class="m-0 font-weight-bold text-primary tx-20">Rp. ' . number_format($item_salary->total_all_salary, 0, '.', '.') . '</label>
                                        </td>
                                    </tr>
                                </table>
                            ';


                echo '
                    <tr>
                            <td>' . $counter . '</td>
                            <td>
                                <div class="row">
                                    <div class="row col-12 border-dashed p-2">
                                        <div class="col">
                                            <small class="d-block text-muted d-block"><i class="fa fa-check-circle"></i> Pegawai :</small>
                                            <h4 class=" mt-2 mb-2 text-primary tx-uppercase"><b>' . $item_salary->employee_name . '</b></h4>
                                            <p class="tx-12">' . $item_salary->employee_address . '</p>
                                        </div>
                                        <div class="col-auto align-self-center ">
                                            <div class="feature mt-0 mb-0">
                                                <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6 border-dashed p-2">
                                        <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Jabatan :</small>
                                        <label for="" class="d-block text-uppercase font-weight-bold">' . $item_salary->position_name . '</label>
                                    </div>
                                    <div class="col-6 border-dashed p-2">
                                        <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Devisi :</small>
                                        <label for="" class="d-block text-uppercase font-weight-bold">' . $item_salary->devision_name . '</label>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="row">
                                    <div class="col-12 p-2">
                                        <small class="d-block text-muted d-block"><i class="fa fa-check-circle"></i> Periode Operasional :</small>
                                        <h4 class=" mt-2 mb-2 text-primary tx-uppercase  d-block"><b>' . $item_salary->main_period_name . '</b></h4>
                                        <label for="" class="d-block text-uppercase font-weight-bold">' . $array_month[$item_salary->month_period] . ' - ' . $item_salary->year_period . '</label>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="row">
                                    <div class="col-12 border-dashed p-2">
                                        <div class="row m-0">
                                            <div class="col-4 border-right ">
                                                <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Masuk :</small>
                                                <div class="input-group">
                                                    <input class="form-control  font-weight-bold bg-white rupiah border-dashed" value="' . $item_salary->total_work_day . '" readonly name="total_hours_work" type="text">
                                                    <div class="input-group-append">
                                                        <div class="input-group-text font-weight-bold">
                                                            HARI
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-4 border-right ">
                                                <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Absen :</small>
                                                <div class="input-group">
                                                    <input class="form-control  font-weight-bold bg-white rupiah border-dashed" value="' . $item_salary->total_absen_day . '" readonly name="total_hours_work" type="text">
                                                    <div class="input-group-append">
                                                        <div class="input-group-text font-weight-bold">
                                                            HARI
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-4 ">
                                                <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Izin :</small>
                                                <div class="input-group">
                                                    <input class="form-control  font-weight-bold bg-white rupiah border-dashed" value="' . $item_salary->total_permit_day . '" readonly name="total_hours_work" type="text">
                                                    <div class="input-group-append">
                                                        <div class="input-group-text font-weight-bold">
                                                            HARI
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6 border-dashed p-2">
                                        <small class="d-block text-muted mb-1"><i class="fa fa-check-circle"></i> Total gaji : </small>
                                        <div class="d-flex mb-0">
                                            <div class="">
                                                <h5 class="mb-1 font-weight-bold">Rp. ' . number_format($total_salary, 0, '.', '.') . '<span class="text-success tx-13 ml-2"></span></h5>
                                                <p class="mb-2 tx-12 text-muted">kalkulasi total semua penghitungan gaji.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6 border-dashed p-2">
                                        <small class="d-block text-muted"><i class="fa fa-check-circle"></i> Total Potongan :</small>
                                        <div class="d-flex mb-0">
                                            <div class="">
                                                <h4 class="mb-1 font-weight-bold">Rp.' . number_format($total_cut_salary, 0, '.', '.') . '</h4>
                                                <p class="mb-2 tx-12 text-muted"> kalkulasi total semua potongan gaji.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 bg-gradient text-right p-2 d-flex align-items-center justify-content-end ">
                                        <div class="col-6 text-center">
                                            <a class="btn btn-primary btn-sm btn-rounded" data-toggle="collapse" href="#view_' . $counter . '" role="button" aria-expanded="false" aria-controls="collapseExample">
                                                <i class="fa fa-tv"></i> Detail Slip Gaji
                                            </a>
                                        </div>
                                        <h4 class="card-title m-0">Total Diterima :</h4>
                                        <h2 class="text-primary m-0 ml-3"><b>Rp.' . number_format($item_salary->total_all_salary, 0, '.', '.') . '</b></h2>
                                    </div>
                                    <div class="col-12 text-right">
                                    </div>
                                    <div class="collapse col-12 mt-2 " id="view_' . $counter . '">
                                        <div class="card card-body">
                                            ' . $html_detail . '
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    ';
            }
            ?>

        </tbody>
    </table>
</div>