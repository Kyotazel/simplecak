<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Payroll extends BackendController
{
    var $module_name        = 'payroll';
    var $module_directory   = 'payroll';
    var $module_js          = ['payroll'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['period'] = Modules::run('database/find', 'tb_operational_period', ['isDeleted' => 'N'])->result();
        $this->app_data['page_title'] = "Penggajian";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function load_salary()
    {
        Modules::run('security/is_ajax');
        $period = $this->input->post('period');

        $this->db->where(['isDeleted' => 'N', 'id_period' => $period]);
        $this->db->order_by('year');
        $this->db->order_by('month');
        $this->db->order_by('year');
        $get_all_period = $this->db->get('tb_operational_category_salary')->result();

        $data['period'] = $get_all_period;
        $html_respon = $this->load->view('list_salary', $data, TRUE);
        echo json_encode(['status' => true, 'html_respon' => $html_respon]);
    }

    private function validate_save()
    {
        Modules::run('security/is_ajax');
        $data = array();

        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->input->post('id');
        if ($this->input->post('year') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'year';
            $data['status'] = FALSE;
        }

        if ($this->input->post('month') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'month';
            $data['status'] = FALSE;
        }

        if ($data['status'] == TRUE) {
            $year    = $this->input->post('year');
            $month    = $this->input->post('month');

            $array_month = [
                '01' => 'januari',
                '02' => 'februari',
                '03' => 'maret',
                '04' => 'april',
                '05' => 'mei',
                '06' => 'juni',
                '07' => 'juli',
                '08' => 'agustus',
                '09' => 'september',
                '10' => 'oktober',
                '11' => 'november',
                '12' => 'december'
            ];

            $get_data = Modules::run('database/find', 'tb_operational_category_salary', ['year' => $year, 'month' => $month])->row();
            if (!empty($get_data)) {
                $data['error_string'][] = 'periode ' . $array_month[$month] . ' - ' . $year . ' Telah dibuat';
                $data['inputerror'][] = 'period';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_period()
    {
        $this->validate_save();

        $year    = $this->input->post('year');
        $month    = $this->input->post('month');
        $period = Modules::run('database/find', 'tb_operational_period', ['status' => 1])->row();
        $array_insert = [
            'id_period' => $period->id,
            'year' => $year,
            'month' => $month,
            'isDeleted' => 'N'
        ];
        Modules::run('database/insert', 'tb_operational_category_salary', $array_insert);
        echo json_encode(['status' => true]);
    }

    public function detail()
    {
        Modules::run('security/is_axist_data', ['method' => 'get', 'name' => 'data', 'encrypt' => true]);
        $id = $this->encrypt->decode($this->input->get('data'));
        $this->app_data['data_period'] = Modules::run('database/find', 'tb_operational_category_salary', ['id' => $id])->row();

        $array_quer_salary = [
            'select' => '
                tb_operational_salary.*,
                mst_employee.employee_number,
                mst_employee.name AS employee_name,
                mst_employee.address AS employee_address,
                mst_employee_division.name AS devision_name,
                mst_employee_position.name AS position_name
            ',
            'from' => 'tb_operational_salary',
            'join' => [
                'mst_employee, tb_operational_salary.id_employee = mst_employee.id, left',
                'mst_employee_division, mst_employee.id_mst_division = mst_employee_division.id, left',
                'mst_employee_position, mst_employee.id_mst_position = mst_employee_position.id, left'
            ],
            'where' => [
                'tb_operational_salary.id_category_salary' => $id
            ],
            'order_by' => 'tb_operational_salary.id, DESC'
        ];
        $get_all_salary = Modules::run('database/get', $array_quer_salary)->result();
        $this->app_data['data_salary'] = $get_all_salary;

        $this->app_data['page_title'] = "Detail Penggajian";
        $this->app_data['view_file'] = 'view_detail';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function add()
    {
        Modules::run('security/is_axist_data', ['method' => 'GET', 'name' => 'period', 'encrypt' => true, 'table_name' => 'tb_operational_category_salary']);
        $id = $this->encrypt->decode($this->input->get('period'));

        $array_query = [
            'select' => '
                tb_operational_category_salary.*,
                tb_operational_period.name AS period_name
            ',
            'from' => 'tb_operational_category_salary',
            'join' => [
                'tb_operational_period, tb_operational_category_salary.id_period = tb_operational_period.id, left'
            ],
            'where' => [
                'tb_operational_category_salary.id' => $id
            ]
        ];
        $get_period = Modules::run('database/get', $array_query)->row();
        $this->app_data['data_period'] = $get_period;

        $this->app_data['account_bank'] = Modules::run('database/find', 'tb_book_account', ['type_account' => 1, 'isDeleted' => 'N', 'id_parent >' => 0, 'status_bank' => 1])->result();
        $this->app_data['account_cost'] = Modules::run('database/find', 'tb_book_account', ['type_account' => 5, 'isDeleted' => 'N', 'id_parent >' => 0])->result();
        $this->app_data['option_position'] = Modules::run('database/find', 'mst_employee_position', ['isDeleted' => 'N'])->result();
        $this->app_data['option_devision'] = Modules::run('database/find', 'mst_employee_division', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "Tambah Data Penggajian";
        $this->app_data['view_file'] = 'form_add_payroll';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function get_employee_option()
    {
        Modules::run('security/is_ajax');
        $position = $this->input->post('position');
        $devision = $this->input->post('devision');

        $array_where = [

            'isDeleted' => 'N'
        ];
        if (!empty($position)) {
            $array_where['id_mst_position'] = $position;
        }
        if (!empty($devision)) {
            $array_where['id_mst_division'] = $devision;
        }
        $array_query = [
            'from' => 'mst_employee',
            'where' => $array_where,
            'order_by' => 'name'
        ];
        $get_all = Modules::run('database/get',  $array_query)->result();
        $html_respon = ' <option value="">Pilih Pegawai</option> ';
        foreach ($get_all as $item_data) {
            $html_respon .= '
                <option value="' . $item_data->id . '">' . strtoupper($item_data->employee_number) . ' - ' . strtoupper($item_data->name) . '</option>
            ';
        }
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    private function validate_save_payroll()
    {
        Modules::run('security/is_ajax');
        $data = array();

        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        // this validate if there is same file to be uploaded
        $id = $this->input->post('id');
        if ($this->input->post('total_hours_work') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'total_hours_work';
            $data['status'] = FALSE;
        }

        if ($this->input->post('total_hours_absen') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'total_hours_absen';
            $data['status'] = FALSE;
        }
        if ($this->input->post('total_day_work') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'total_day_work';
            $data['status'] = FALSE;
        }
        if ($this->input->post('total_day_absen') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'total_day_absen';
            $data['status'] = FALSE;
        }
        if ($this->input->post('total_day_permit') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'total_day_permit';
            $data['status'] = FALSE;
        }
        if ($this->input->post('main_salary') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'main_salary';
            $data['status'] = FALSE;
        }
        if ($this->input->post('payroll_employee') == '') {
            $data['error_string'][] = 'Harus Diisi';
            $data['inputerror'][] = 'employee';
            $data['status'] = FALSE;
        }


        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }

    public function save_payroll()
    {
        Modules::run('security/is_ajax');
        $this->validate_save_payroll();

        $total_hours_work   =  str_replace('.', '', $this->input->post('total_hours_work'));
        $total_hours_absen  =  str_replace('', '.', $this->input->post('total_hours_absen'));
        $total_day_work     =  str_replace('.', '', $this->input->post('total_day_work'));
        $total_day_absen    =  str_replace('.', '', $this->input->post('total_day_absen'));
        $total_day_permit   =  str_replace('.', '', $this->input->post('total_day_permit'));

        $main_salary        =  str_replace('.', '', $this->input->post('main_salary')) ? str_replace('.', '', $this->input->post('main_salary')) : 0;
        $position_salary    =  str_replace('.', '', $this->input->post('position_salary')) ? str_replace('.', '', $this->input->post('position_salary')) : 0;
        $bonus_salary       =  str_replace('.', '', $this->input->post('bonus_salary')) ? str_replace('.', '', $this->input->post('bonus_salary')) : 0;

        $other_salary_price     =  !empty($this->input->post('other_salary_price')) ? $this->input->post('other_salary_price') : [];
        $other_salary_desc      =  !empty($this->input->post('other_salary_desc')) ? $this->input->post('other_salary_desc') : [];

        $total_other_salary  = 0;
        $array_other_salary = [];
        foreach ($other_salary_desc as $key => $value) {
            $price = str_replace('.', '', $other_salary_price[$key]);
            $array_other_salary[] = [
                'name' => $other_salary_desc[$key],
                'price' => $other_salary_price[$key]
            ];
            $total_other_salary += $price;
        }

        $cut_salary_price       =  !empty($this->input->post('cut_salary_price')) ? $this->input->post('cut_salary_price') : [];
        $cut_salary_desc        =  !empty($this->input->post('cut_salary_desc')) ? $this->input->post('cut_salary_desc') : [];
        $array_other_cut     = [];
        $total_cut_salary  = 0;
        foreach ($cut_salary_desc as $key => $value) {
            $price = str_replace('.', '', $cut_salary_price[$key]);
            $array_other_cut[] = [
                'price' => $price,
                'name' => $cut_salary_desc[$key]
            ];
            $total_cut_salary += $price;
        }

        $grand_total_salary = ((int) $main_salary + (int) $bonus_salary + (int) $position_salary + (int) $total_other_salary) - (int) $total_cut_salary;

        $payroll_employee       =  $this->input->post('payroll_employee');
        $account_bank           =  $this->input->post('account_bank');
        $account_cost           =  $this->input->post('account_cost');
        $status_jurnal          =  $this->input->post('status_jurnal');
        $id_period              =  $this->input->post('id_period');

        $array_insert  = [
            'id_category_salary' => $id_period,
            'id_employee' => $payroll_employee,
            'total_work_hours' => $total_hours_work,
            'total_absen_hours' => $total_hours_absen,
            'total_work_day' => $total_day_work,
            'total_absen_day' => $total_day_absen,
            'total_permit_day' => $total_day_permit,
            'main_salary' => $main_salary,
            'position_salary' => $position_salary,
            'bonus_salary' => $bonus_salary,
            'other_salary' => json_encode($array_other_salary),
            'cut_salary' => json_encode($array_other_cut),
            'total_all_salary' => $grand_total_salary
        ];
        Modules::run('database/insert', 'tb_operational_salary', $array_insert);
        $get_max_data = $this->db->select('MAX(id) AS max_id')->where(['id_category_salary' => $id_period, 'id_employee' => $payroll_employee])->get('tb_operational_salary')->row();

        if ($status_jurnal) {
            $get_employee = Modules::run('database/find', 'mst_employee', ['id' => $payroll_employee])->row();
            $description = 'penggajian karyawan ( ' . $get_employee->employee_number . ' - ' . $get_employee->name . ' ) dengan total gaji : Rp.' . number_format($grand_total_salary, 0, '.', '.');

            $data_jurnal = [
                'deskripsi' => $description,
                'akun_kas' => $account_bank,
                'akun_biaya' => $account_cost,
                'nominal' => $grand_total_salary,
                'id_transaksi' => $get_max_data->max_id
            ];
            echo Modules::run('accounting/insert_salary', $data_jurnal);
        }

        //update category
        $this->update_grand_total_period_salary($id_period);

        $redirect = Modules::run('helper/create_url', 'payroll/detail?data=' . urlencode($this->encrypt->encode($id_period)));
        echo json_encode(['status' => TRUE, 'redirect' => $redirect]);
    }

    private function update_grand_total_period_salary($id)
    {
        $count_all = $this->db->select('
                        SUM(total_all_salary) AS grand_total_salary
                    ')
            ->where(['id_category_salary' => $id])
            ->get('tb_operational_salary')->row();
        $array_update = [
            'total_all_salary' => $count_all->grand_total_salary
        ];
        Modules::run('database/update', 'tb_operational_category_salary', ['id' => $id], $array_update);
    }

    public function delete_salary()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $get_data = Modules::run('database/find', 'tb_operational_salary', ['id' => $id])->row();

        //delete accounting
        Modules::run('database/delete', 'tb_book_account_has_detail', ['id_transaction' => $id, 'status_act' => 16]);
        //delete maindata
        Modules::run('database/delete', 'tb_operational_salary', ['id' => $id]);
        //update total price
        $this->update_grand_total_period_salary($get_data->id_category_salary);
        echo json_encode(['status' => TRUE]);
    }

    public function delete_group_salary()
    {
        Modules::run('security/is_ajax');
        $id         = $this->input->post('id');
        $redirect   = $this->input->post('redirect');
        $get_data = Modules::run('database/find', 'tb_operational_salary', ['id_category_salary' => $id])->result();
        foreach ($get_data as $item_salary) {
            //delete accounting
            Modules::run('database/delete', 'tb_book_account_has_detail', ['id_transaction' => $item_salary->id, 'status_act' => 16]);
            //delete maindata
            Modules::run('database/delete', 'tb_operational_salary', ['id' => $item_salary->id]);
        }
        //delete main data
        Modules::run('database/delete', 'tb_operational_category_salary', ['id' => $id]);
        echo json_encode(['status' => TRUE]);
    }

    public function history()
    {
        $this->app_data['data_period'] = Modules::run('database/find', 'tb_operational_period', ['isDeleted' => 'N'])->result();
        $this->app_data['year'] = $this->db->select('MAX(year) AS max_year, MIN(year) AS min_year')->where(['isDeleted' => 'N'])->get('tb_operational_category_salary')->row();
        $this->app_data['devision'] = Modules::run('database/find', 'mst_employee_division', ['isDeleted' => 'N'])->result();
        $this->app_data['position'] = Modules::run('database/find', 'mst_employee_position', ['isDeleted' => 'N'])->result();

        $this->app_data['page_title'] = "Riwayat Penggajian";
        $this->app_data['view_file'] = 'form_history';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function search_history()
    {
        Modules::run('security/is_ajax');
        $period_operational = $this->input->post('period_operational');
        $year = $this->input->post('year');
        $month = $this->input->post('month');
        $devision = $this->input->post('devision');
        $position = $this->input->post('position');

        $array_where_in = [];
        if (!empty($period_operational)) {
            $array_where_in['tb_operational_period.id'] = $period_operational;
        }
        if (!empty($year)) {
            $array_where_in['tb_operational_category_salary.year'] = $year;
        }
        if (!empty($month)) {
            $array_where_in['tb_operational_category_salary.month'] = $month;
        }
        if (!empty($devision)) {
            $array_where_in['mst_employee_division.id'] = $devision;
        }
        if (!empty($position)) {
            $array_where_in['mst_employee_position.id'] = $position;
        }

        $array_quer_salary = [
            'select' => '
            tb_operational_salary.*,
            mst_employee.employee_number,
            mst_employee.name AS employee_name,
            mst_employee.address AS employee_address,
            mst_employee_division.name AS devision_name,
            mst_employee_position.name AS position_name,
            tb_operational_category_salary.year AS year_period,
            tb_operational_category_salary.month AS month_period,
            tb_operational_period.name AS main_period_name
        ',
            'from' => 'tb_operational_salary',
            'join' => [
                'tb_operational_category_salary, tb_operational_salary.id_category_salary = tb_operational_category_salary.id, left',
                'tb_operational_period, tb_operational_category_salary.id_period = tb_operational_period.id, left',
                'mst_employee, tb_operational_salary.id_employee = mst_employee.id, left',
                'mst_employee_division, mst_employee.id_mst_division = mst_employee_division.id, left',
                'mst_employee_position, mst_employee.id_mst_position = mst_employee_position.id, left'
            ],
            'order_by' => 'tb_operational_salary.id, DESC'
        ];
        if (!empty($array_where_in)) {
            $array_quer_salary['where_in'] = $array_where_in;
        }
        $get_all_salary = Modules::run('database/get', $array_quer_salary)->result();
        $data['data_salary'] = $get_all_salary;
        $html_respon = $this->load->view('list_search_salary', $data, TRUE);
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    // public function update()
    // {
    //     Modules::run('security/is_ajax');
    //     $this->validate_save();

    //     $id     = $this->input->post('id');
    //     $name    = $this->input->post('name');
    //     $account_number   = $this->input->post('account_number');
    //     $account_name   = $this->input->post('account_name');

    //     $array_update = [
    //         'name' => $name,
    //         'account_number' => $account_number,
    //         'account_owner' => $account_name
    //     ];

    //     if (!empty($_FILES['media']['name'])) {
    //         $image_name = $this->upload_image();
    //         $array_update['image'] = $image_name;
    //     }
    //     Modules::run('database/update', 'mst_bank', ['id' => $id], $array_update);
    //     echo json_encode(['status' => true]);
    // }

    // public function delete_data()
    // {
    //     Modules::run('security/is_ajax');
    //     $id = $this->encrypt->decode($this->input->post('id'));
    //     $array_update = ['isDeleted' => 'Y'];
    //     Modules::run('database/update', 'mst_bank', ['id' => $id], $array_update);
    //     echo json_encode(['status' => true]);
    // }

    // public function export_excel()
    // {
    //     $array_query = [
    //         'select' => '
    //             mst_ship.*
    //         ',
    //         'from' => 'mst_ship',
    //         'where' => ['isDeleted' => 'N'],
    //         'order_by' => 'id, DESC'
    //     ];
    //     $get_data = Modules::run('database/get', $array_query)->result();
    //     error_reporting(0);
    //     $this->load->library("PHPExcel");
    //     //membuat objek
    //     $objPHPExcel = new PHPExcel();
    //     $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
    //     $sheet = $objPHPExcel->getActiveSheet();
    //     //set column 
    //     $sheet->getColumnDimension('A')->setWidth('5');
    //     $sheet->getColumnDimension('B')->setWidth('20');
    //     $sheet->getColumnDimension('C')->setWidth('50');
    //     $sheet->getColumnDimension('D')->setWidth('20');
    //     $sheet->getColumnDimension('E')->setWidth('20');
    //     $sheet->getColumnDimension('F')->setWidth('20');

    //     //bold style 
    //     $sheet->getStyle("A1:F2")->getFont()->setBold(true);
    //     $styleThinBlackBorderOutline = array(
    //         'borders' => array(
    //             'allborders' => array(
    //                 'style' => PHPExcel_Style_Border::BORDER_THIN,
    //                 'color' => array('argb' => 'FF000000'),
    //             ),
    //         ),
    //     );

    //     //marge and center
    //     $sheet->mergeCells('A1:F2');
    //     $sheet->getStyle('A1:F2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    //     $sheet->getStyle('A1:F2')->getFont()->setSize(18);
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA KAPAL');
    //     $sheet->getStyle('A3:F3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

    //     //sheet table resume 
    //     $from = "A3"; // or any value
    //     $to = "M3"; // or any value
    //     $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'KODE KAPAL');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'KAPAL');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'BATAS TONASE (GT)');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'BATAS KONTAINER');
    //     $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'TANGGAL BELI');
    //     $sheet_number_resume = 3;
    //     $no = 0;

    //     $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)
    //         ->applyFromArray($styleThinBlackBorderOutline);
    //     $sheet->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)->applyFromArray(
    //         array(
    //             'fill' => array(
    //                 'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //                 'color' => array('rgb' => '366092')
    //             ),
    //             'font'  => array(
    //                 'bold'  => true,
    //                 'color' => array('rgb' => 'FFFFFF'),
    //                 'size'  => 12
    //             )
    //         )
    //     );

    //     foreach ($get_data as $data_table) {
    //         $sheet_number_resume++;
    //         $no++;
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->code);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, strtoupper($data_table->name));
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->tonase_limit);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->container_slot);
    //         $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, Modules::run('helper/date_indo', $data_table->date_buy, '-'));
    //         $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':F' . $sheet_number_resume)
    //             ->applyFromArray($styleThinBlackBorderOutline);
    //     }
    //     //Set Title
    //     $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA KAPAL');
    //     //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
    //     $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    //     //Header
    //     header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    //     header("Cache-Control: no-store, no-cache, must-revalidate");
    //     header("Cache-Control: post-check=0, pre-check=0", false);
    //     header("Pragma: no-cache");
    //     header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    //     //Nama File
    //     header('Content-Disposition: attachment;filename="LAPORAN DATA KAPAL PER ' . date('d-m-Y') . '.xlsx"');
    //     //Download
    //     $objWriter->save("php://output");
    // }

    // public function export_pdf()
    // {
    //     $array_query = [
    //         'select' => '
    //             mst_ship.*
    //         ',
    //         'from' => 'mst_ship',
    //         'where' => ['isDeleted' => 'N'],
    //         'order_by' => 'id, DESC'
    //     ];
    //     $get_data = Modules::run('database/get', $array_query)->result();

    //     error_reporting(0);
    //     ob_clean();
    //     $data['data_ship'] = $get_data;
    //     //print_r($data['data_profile']);
    //     //exit;
    //     ob_start();
    //     $this->load->view('pdf_ship', $data);
    //     //print_r($html);
    //     //exit;
    //     $html = ob_get_contents();
    //     ob_end_clean();
    //     require_once('../assets/plugin/html2pdf/html2pdf.class.php');
    //     $pdf = new HTML2PDF('P', 'A4', 'en');
    //     $pdf->WriteHTML($html);
    //     $pdf->Output('LAPORAN DATA KAPAL PER -' . date('d-m-Y') . '.pdf', 'D');
    // }
}
