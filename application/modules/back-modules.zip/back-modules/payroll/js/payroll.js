var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var id_use = 0;
var table;
var status_jurnal = 0;



$(document).ready(function () {
    // var type = $('.container_list').data('type');
    // table = $('#table_data').DataTable({
    //     "ajax": {
    //         "url": url_controller+"list_data"+'/?token='+_token_user,
    //         "type": "POST",
    //     }
    // });
    if ($('.html_respon_salary').length) {
        load_salary();
    }
    $('.chosen').chosen();

    if ($('.payroll_employee').length) {
        option_employee();
    }

    $('#table_data').DataTable({
        "columns": [
            { "width": "5%" },
            { "width": "40%" },
            { "width": "55%" },
        ]
    });
});

function reload_table(){
    table.ajax.reload(null,false); //reload datatable ajax 
}

function load_salary() {
    var id_period = $('[name="period_search"]').val();
    showLoading();
    $.ajax({
        url: url_controller+'load_salary'+'/?token='+_token_user,
        type: "POST",
        data: {'period':id_period},
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            $('.html_respon_salary').html(data.html_respon);
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
    });//end ajax
}
$('[name="period_search"]').change(function () { 
    load_salary();
});


$('.btn_add_salary').click(function () {
    save_method = 'add';
	$('.form-group').removeClass('has-danger');
 	$('.help-block').empty();
 	$('#form-data')[0].reset();
	$('.modal-title').text('TAMBAH DATA');
    $('#modal_form').modal('show');
});


$('.btn_save_priod').click(function (e) {
    e.preventDefault();
    showLoading();
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
	  //defined form
    var formData = new FormData($('#form-data')[0]);
    $.ajax({
        url: url_controller+'save_period/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                notif({
                    msg: "<b>Sukses :</b> Data berhasil disimpan",
                    type: "success"
                });
                load_salary();
                $('#modal_form').modal('hide');
            } else{
                for (var i = 0; i < data.inputerror.length; i++)
                {
                    $('.notif_'+data.inputerror[i]).parent().addClass('has-danger');
                    $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                    
                    if (data.inputerror[i] == 'period') {
                        alert_error(data.error_string[i]);
                    }
                }
            }
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
	});//end ajax
});


$('.form-payroll').submit(function (e) { 
    e.preventDefault();
});

$(document).on('keyup', '.count_salary', function () { 
    count_all_salary();
});

function count_all_salary() {
    var total_salary = 0;
    var total_cuts = 0;
    $(document).find('.count_salary').each(function () {
        if($(this).val() !=''){
            var value = clear_dot_value($(this).val());
            console.log(value);
            total_salary += parseInt(value);
        }
    });
    $(document).find('.count_cut_salary').each(function () {
        if($(this).val() !=''){
            var value = clear_dot_value($(this).val());
            console.log(value);
            total_cuts += parseInt(value);
        }
    });

    var total_fix_salary = total_salary - total_cuts; 
    console.log(total_fix_salary);
    if (total_fix_salary < 0) {
        $('.total_salary').text('Rp. -' + money_function(total_fix_salary.toString()));
    } else {
        $('.total_salary').text('Rp.' + money_function(total_fix_salary.toString()));
    }
    
    $('.total_salary').data('price', total_fix_salary);
}

$(document).on('click', '.btn_add_other_salary', function () { 
    var pattern_price_salary = $('[name="pattern_price_salary"]').val();
    var desc = $('[name="pattern_desc_salary"]').val();

    $('.notif_pattern_price_salary').empty();
    $('.notif_pattern_desc_salary').empty();

    if (pattern_price_salary == '' || pattern_price_salary == '0' || parseInt(clear_dot_value(pattern_price_salary)) <= 0) {
        alert_error('nilai nominal tidak valid');
        $('.notif_pattern_price_salary').text('nilai nominal tidak valid');
        return false;
    }
    if (desc == '') {
        alert_error('deskripsi harus di isi');
        $('.notif_pattern_desc_salary').text('deskripsi harus di isi');
        return false;
    }

    var html_append = `
        <div class="form-group row item_other_salary">
            <div class="col-3 p-0 m-0">
                <div class="input-group">
                    <div class="input-group-append">
                        <div class="input-group-text font-weight-bold">
                            Rp.
                        </div>
                    </div>
                    <input class="form-control  font-weight-bold count_salary rupiah bg-white border-dashed" value="`+pattern_price_salary+`" readonly name="other_salary_price[]" type="text">
                </div>
            </div>
            <div class="col-7 p-0 m-0">
                <p class="p-2 border-dashed">`+desc+`</p>
                <input type="hidden" class="form-control bg-white" value="`+desc+`" readonly name="other_salary_desc[]">
            </div>
            <div class="col-2">
                <a href="javascript:void(0)" class="btn btn-danger btn_remove_other_salary"><i class="fa fa-times"></i></a>
            </div>
        </div>
    `;

    $('.html_respon_other_salary').append(html_append);
    $('.html_empty_other_salary').hide();
    $('.html_respon_other_salary').show();

    count_all_salary();
    $('[name="pattern_price_salary"]').val('');
    $('[name="pattern_desc_salary"]').val('');

    setTimeout(
        function() 
        {
          //do something special
        $('[name="pattern_price_salary"]').focus();
        }, 300);
});

$(document).on('keypress', '.add_other_salary', function (e) { 
    if(e.which == 13) {
        $('.btn_add_other_salary').click();
    }
});

$(document).on('click', '.btn_remove_other_salary', function () { 
    $(this).closest('.item_other_salary').remove();

    if ($('.html_respon_other_salary').find('.item_other_salary').length == false) {
        $('.html_empty_other_salary').show();
        $('.html_respon_other_salary').hide();
    }
    count_all_salary();
});

$(document).on('click', '.btn_add_cut', function () { 
    var pattern_price_salary = $('[name="pattern_price_cut"]').val();
    var desc = $('[name="pattern_desc_cut"]').val();

    $('.notif_pattern_desc_cut').empty();
    $('.notif_pattern_price_cut').empty();

    if (pattern_price_salary == '' || pattern_price_salary == '0' || parseInt(clear_dot_value(pattern_price_salary)) <= 0) {
        alert_error('nilai nominal tidak valid');
        $('.notif_pattern_price_cut').text('nilai nominal tidak valid');
        return false;
    }
    if (desc == '') {
        alert_error('deskripsi harus di isi');
        $('.notif_pattern_desc_cut').text('deskripsi harus di isi');
        return false;
    }

    var html_append = `
        <div class="form-group row item_cut_salary">
            <div class="col-3 p-0 m-0">
                <div class="input-group">
                    <div class="input-group-append">
                        <div class="input-group-text font-weight-bold">
                            Rp.
                        </div>
                    </div>
                    <input class="form-control  font-weight-bold count_cut_salary rupiah bg-white border-dashed" value="`+pattern_price_salary+`" readonly name="cut_salary_price[]" type="text">
                </div>
            </div>
            <div class="col-7 p-0 m-0">
                <p class="p-2 border-dashed">`+desc+`</p>
                <input type="hidden" class="form-control bg-white" value="`+desc+`" readonly name="cut_salary_desc[]">
            </div>
            <div class="col-2">
                <a href="javascript:void(0)" class="btn btn-danger btn_remove_cut_salary"><i class="fa fa-times"></i></a>
            </div>
        </div>
    `;

    $('.html_respon_cut').append(html_append);
    $('.html_empty_cut').hide();
    $('.html_respon_cut').show();

    count_all_salary();
    $('[name="pattern_price_cut"]').val('');
    $('[name="pattern_desc_cut"]').val('');

    setTimeout(
        function() 
        {
          //do something special
        $('[name="pattern_price_cut"]').focus();
        }, 300);
});

$(document).on('keypress', '.add_cut_salary', function (e) { 
    if(e.which == 13) {
        $('.btn_add_cut').click();
    }
});

$(document).on('click', '.btn_remove_cut_salary', function () { 
    $(this).closest('.item_cut_salary').remove();

    if ($('.html_respon_cut').find('.item_cut_salary').length == false) {
        $('.html_empty_cut').show();
        $('.html_respon_cut').hide();
    }
    count_all_salary();
});

$('.change_status_jurnal').click(function () { 
    $(this).toggleClass('on');
    status_jurnal = $(this).hasClass('on') ? 1 : 0;
    if (status_jurnal) {
        $('.html_empty_jurnal').hide();
        $('.html_form_jurnal').show();
    } else {
        $('.html_empty_jurnal').show();
        $('.html_form_jurnal').hide();
    }
});

function option_employee() {
    showLoading();
    var position = $('.payroll_position').val();
    var devision = $('.payroll_devision').val();

    $.ajax({
        url: url_controller+'get_employee_option'+'/?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'position':position,'devision':devision},
        success: function (data) {
            hideLoading();
            $('.payroll_employee').html(data.html_respon);
            $(".payroll_employee").val('').trigger("chosen:updated");
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }

    });//end ajax

}

$('.payroll_position').change(function () { 
    option_employee();
});
$('.payroll_devision').change(function () { 
    option_employee();
});

$('.btn_save_payroll').click(function (e) {
    e.preventDefault();
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
	  //defined form
    var payroll_employee = $('.payroll_employee').val();
    var account_bank = $('[name="account_bank"]').val();
    var account_cost = $('[name="account_cost"]').val();
    var status_jurnal = $('.change_status_jurnal').hasClass('on') ? 1 : 0;
    var id_period = $(this).data('id');

    var formData = new FormData($('.form-payroll')[0]);
    formData.append('payroll_employee', payroll_employee);
    formData.append('account_bank', account_bank);
    formData.append('account_cost', account_cost);
    formData.append('status_jurnal', status_jurnal);
    formData.append('id_period', id_period);

    swal({
        title: "Apakah anda yakin?",
        text: "data akan disimpan!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            showLoading();
            $.ajax({
                url: url_controller+'save_payroll/?token='+_token_user,
                type: "POST",
                data: formData,
                contentType: false,
                processData : false,
                dataType :"JSON",
                success: function (data) {
                    hideLoading();
                    if(data.status){
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil disimpan",
                            type: "success"
                        });
                        location.href = data.redirect;
                    } else {
                        notif_error('lengkapi data');
                        for (var i = 0; i < data.inputerror.length; i++)
                        {
                            $('.notif_'+data.inputerror[i]).parent().addClass('has-danger');
                            $('.notif_' + data.inputerror[i]).text(data.error_string[i]);
                            
                            if (data.inputerror[i] == 'period') {
                                alert_error(data.error_string[i]);
                            }
                        }
                    }
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                    hideLoading();
                }
            });//end ajax
        }
    });
    
});




// $(document).on('click', '.btn_edit', function () {
//     // swal.showLoading();
//     $('.form-group').removeClass('has-danger');
//     $('.help-block').empty();
//     id = $(this).data('id');
//     save_method = 'update';
//     $.ajax({
//         url: url_controller+'get_data'+'/?token='+_token_user,
//         type: "POST",
//         dataType: "JSON",
//         data:{'id':id},
//         success: function (data) {
//             swal.close();
//             id_use = data.id;
//             $('[name="name"]').val(data.name);
//             $('[name="account_number"]').val(data.account_owner);
//             $('[name="account_name"]').val(data.account_number);
//             $('#modal_form').modal('show');
//         },
//         error:function(jqXHR, textStatus, errorThrown)
//         {
//             swal.close();
//         }

//     });//end ajax

// });


$(document).on('click', '.btn_delete-salary', function () {
    id = $(this).data('id');
    swal({
        title: "Apakah anda yakin?",
        text: "data akan dihapus!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: url_controller+'delete_salary'+'/?token='+_token_user,
                type: "POST",
                dataType: "JSON",
                data:{'id':id,'status_group':true},
                success: function(data){
                    if (data.status) {
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil dihapus",
                            type: "success"
                        });
                        location.reload();
                    } 
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                }

            });//end ajax
        }
    });
});


$(document).on('click', '.btn_delete_group_salary', function () {
    id = $(this).data('id');
    var redirect_status = $(this).data('redirect');
    swal({
        title: "Apakah anda yakin?",
        text: "data akan dihapus!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Ya , Lanjutkan",
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: url_controller+'delete_group_salary'+'/?token='+_token_user,
                type: "POST",
                dataType: "JSON",
                data:{'id':id,'redirect':redirect_status},
                success: function(data){
                    if (data.status) {
                        notif({
                            msg: "<b>Sukses :</b> Data berhasil dihapus",
                            type: "success"
                        });
                        if (redirect_status == 1) {
                            location.href = url_controller;
                        } else {
                            load_salary();
                        }
                    } 
                },
                error:function(jqXHR, textStatus, errorThrown)
                {
                }

            });//end ajax
        }
    });
});


$('.btn_search_payroll').click(function (e) {
    e.preventDefault();
    showLoading();
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
	  //defined form
    var formData = new FormData($('.form-search')[0]);
    $.ajax({
        url: url_controller+'search_history/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                $('.html_respon').html(data.html_respon);
                $('#table_data').DataTable({
                    "columns": [
                        { "width": "5%" },
                        { "width": "30%" },
                        { "width": "20%" },
                        { "width": "45%" },
                    ]
                });
            } 
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
	});//end ajax
});



$(document).on('keyup', '.rupiah', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});

function clear_dot_value(value) {
    var array_value = value.split('.');
    var count_array = array_value.length;
    payment_value = value;
    for (var i = 0; i < count_array; i++) {
        payment_value = payment_value.replace('.', '');
    };
    return payment_value;
}

function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}


