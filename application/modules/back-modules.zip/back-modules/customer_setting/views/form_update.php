<form class="form-update">
    <div class="row">
        <?php
        foreach ($data_devision as $item_devision) {

            $get_limit = Modules::run('database/find', 'mst_customer_has_limit', ['id_customer' => $id_customer, 'id_product_devision' => $item_devision->id])->row();
            $get_price = Modules::run('database/find', 'mst_customer_has_price', ['id_customer' => $id_customer, 'id_product_devision' => $item_devision->id])->row();
            $get_top = Modules::run('database/find', ' mst_customer_has_top', ['id_customer' => $id_customer, 'id_product_devision' => $item_devision->id])->row();

            $limit = isset($get_limit->credit_limit) ? number_format($get_limit->credit_limit, 0, '.', '.') : 0;
            $price = isset($get_price->price) ? $get_price->price : 0;
            $top_nota = isset($get_top->top_nota) ? $get_top->top_nota : 0;
            $top_internal = isset($get_top->top_internal) ? $get_top->top_internal : 0;

            $html_option_price = '';
            foreach ($cat_price as $key => $value) {
                $selected = $key == $price ? 'selected' : '';
                $html_option_price .= '
                    <option ' . $selected . ' value="' . $key . '">' . $value . '</option>
                ';
            }

            echo '
                <div class="row p-2 border-dashed col-4">
                    <label for="" class="col-12">
                        <span class="badge badge-pill badge-light tx-12"></i> PENGATURAN ( ' . $item_devision->name . ' ) </span>
                    </label>
                    <div class="form-group col-12">
                        <label for="">Limit </label>
                        <input type="text" name="limit[' . $item_devision->id . ']" class="form-control rupiah" value="' . $limit . '">
                    </div>
                    <div class="form-group col-12">
                        <label for="">Harga </label>
                        <select name="price[' . $item_devision->id . ']" class="form-control" id="">' . $html_option_price . '</select>
                    </div>
                    <div class="form-group col-6">
                        <label for="">TOP NOTA </label>
                        <input name="top_nota[' . $item_devision->id . ']" type="text" class="form-control " value="' . $top_nota . '">
                    </div>
                    <div class="form-group col-6">
                        <label for="">TOP INTERNAL </label>
                        <input name="top_internal[' . $item_devision->id . ']" type="text" class="form-control" value="' . $top_internal . '">
                    </div>
                </div>
            ';
        }
        ?>
    </div>
    <div class="text-right mt-2">
        <button type="submit" data-id="<?= $id_customer; ?>" class="btn btn-warning-gradient btn-rounded font-weight-bold btn_update_price">Simpan Data</button>
    </div>
</form>