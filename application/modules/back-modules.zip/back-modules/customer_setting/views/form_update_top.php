<form action="" class="form_update_top">
    <div class="input-group mb-2">
        <div class="input-group-prepend">
            <div class="input-group-text font-weight-bold" style="width:80px" ;="">
                Nota
            </div>
        </div>
        <input type="number" value="<?= $data_customer->top_nota; ?>" name="nota" class="form-control bg-white font-weight-bold">
    </div>
    <div class="input-group mb-2">
        <div class="input-group-prepend">
            <div class="input-group-text font-weight-bold" style="width:80px" ;="">
                Internal
            </div>
        </div>
        <input type="number" value="<?= $data_customer->top_internal; ?>" name="internal" class="form-control bg-white font-weight-bold">
    </div>
    <div class="text-right">
        <button type="submit" class="btn btn-warning-gradient btn-rounded btn_save_top" data-id="<?= $data_customer->id ?>">Simpan Data <i class="fa fa-paper-plane"></i></button>
    </div>
</form>