<form action="" class="form_update_limit">
    <?php
    foreach ($data_limit as $item_limit) {
        // print_r($item_limit);
        echo '
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <div class="input-group-text font-weight-bold" style="width:80px" ;="">
                            ' . $item_limit->main_category . '
                        </div>
                    </div>
                    <input type="hidden" name="id_product_devision[]" value="' . $item_limit->id_devision . '">
                    <input type="text" name="price[]"  value="' . number_format($item_limit->credit_limit, 0, '.', '.') . '" class="form-control bg-white  font-weight-bold rupiah">
                </div>
            ';
    }
    ?>
    <div class="text-right">
        <button type="submit" class="btn btn-warning-gradient btn-rounded btn_save_limit" data-id="<?= $id_customer ?>">Simpan Data <i class="fa fa-paper-plane"></i></button>
    </div>
</form>