<style>
    .table tr td {
        vertical-align: top !important;
    }
</style>
<div class="row">
    <div class="col-lg-12 col-xl-12 col-md-12 container_list">
        <div class="card">
            <div class="card-body">
                <div class="mb-3 row">
                    <h3 class="col-md-8">Pengaturan Customer</h3>
                </div>
                <form class="form-search">
                    <div class="mb-2 border p-2 row rounded border-dashed">
                        <div class="form-group col-md-3">
                            <label>Jenis Customer ( Customer Type )</label>
                            <select name="customer_type[]" class="form-control chosen" multiple id="">
                                <?php foreach ($member_type as $item) {
                                    echo ' <option value="' . $item->id . '">' . $item->name . '</option> ';
                                } ?>
                            </select>
                            <span class="help-block notif_customer_type"></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Kelas Customer ( Customer Class )</label>
                            <select name="customer_class[]" class="form-control chosen" multiple id="">
                                <?php foreach ($member_class as $item) {
                                    echo ' <option value="' . $item->id . '">' . $item->name . '</option> ';
                                } ?>
                            </select>
                            <span class="help-block notif_customer_type"></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Nama</label>
                            <input class="form-control" name="name">
                        </div>
                        <div class="form-group col-md-2">
                            <label>Ktp</label>
                            <input class="form-control" name="ktp">
                        </div>
                        <div class="form-group col-md-1">
                            <label>&nbsp;</label><br>
                            <button class="btn btn-primary-gradient btn-rounded font-weight-bold btn-block btn_search"><i class="fa fa-search"></i> Cari</button>
                        </div>
                    </div>
                </form>
                <div class="table-responsive border-top  mt-2">
                    <table id="table_data" class="table table-bordered dt-responsive nowrap t-shadow" style="vertical-align:top;border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <th style="width: 5%;">No</th>
                            <th style="width: 30%;">NAMA LENGKAP</th>
                            <?php
                            foreach ($data_devision as $item_devision) {
                                echo '
                                        <th>' . $item_devision->name . '</th>
                                    ';
                            }
                            ?>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div class="text-right pt-3">
                    <form class="form-print" method="POST" action="<?= Modules::run('helper/create_url', 'customer/print'); ?>">
                        <small>(*klik untuk export)</small>
                        <button type="submit" name="print_excel" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-excel"></i> Cetak Excel</button>
                        <button type="submit" name="print_pdf" value="1" class="btn  btn-outline-dark"> <i class="mdi mdi-file-pdf"></i> Cetak PDF</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- end main content-->

<div class="modal fade" tabindex="-1" id="modal_form">
    <div class="modal-dialog" style="min-width: 70%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Input Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <div class="html_respon_modal"></div>
            </div>
        </div>
    </div>
</div>