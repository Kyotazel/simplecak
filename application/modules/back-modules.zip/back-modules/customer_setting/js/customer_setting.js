var url_controller = baseUrl + '/' + prefix_folder_admin + '/' + _controller + '/';
var save_method;
var id_use = 0;
var table;

$(document).ready(function () {
    // var type = $('.container_list').data('type');
    list_data();

    $('#employee_division').chosen();
    $('#employee_position').chosen();
    $('.chosen').chosen();
});

function reload_table(){
    table.ajax.reload(null,false); //reload datatable ajax 
}

$('.btn_search').click(function (e) {
    e.preventDefault();
	//   //defined form
    list_data();
});


function list_data() {
    showLoading();
    var formData = new FormData($('.form-search')[0]);
    $.ajax({
        url: url_controller+'list_data/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            swal.close();
            if ($.fn.DataTable.isDataTable('#table_data')) {
                table.destroy();
            }
            table = $('#table_data').DataTable(data.list);

            $(document).find('#cover-search').remove();
            $('.form-print').append(`
                <div id="cover-search"><input type="hidden" name="search" value="`+data.search+`"></div>
            `);
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
            swal.close();
            $('.btn_search').button('reset');
        }
	});//end ajax
}


$(document).on('click', '.change_status', function () {
    var selector = $(this);
    var id = $(this).data('id');
    $(this).toggleClass('on');
    active_status = $(this).hasClass('on') ? 1 : 0;

    $.ajax({
        url: url_controller+'update_status'+'?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'id':id,'active_status':active_status},
        success: function(data){
            if (data.status) {
                notif({
                    msg: "<b>Sukses :</b> Data berhasil diupdate",
                    type: "success"
                });
            } 
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
        }

    });//end ajax
});


// $(document).on('click', '.btn_edit_limit', function () { 
//     showLoading();
//     var id = $(this).data('id');
//     $.ajax({
//         url: url_controller+'get_limit'+'?token='+_token_user,
//         type: "POST",
//         dataType: "JSON",
//         data:{'id':id},
//         success: function(data){
//             hideLoading();
//             if (data.status) {
//                 $('.html_respon_modal').html(data.html_respon);
//                 $('#modal_form').modal('show');
//             } 
//         },
//         error:function(jqXHR, textStatus, errorThrown)
//         {
//             hideLoading();
//         }

//     });//end ajax
// });

// $(document).on('click', '.btn_save_limit', function (e) { 
//     e.preventDefault();
//     showLoading();
//     // swal.showLoading();
// 	$('.form-group').removeClass('has-danger');
//     $('.help-block').empty();
//     var id = $(this).data('id');
//     // save_method = $(this).data('method');
// 	  //defined form
//     var formData = new FormData($('.form_update_limit')[0]);
//     formData.append('id_customer', id);    
//     $.ajax({
//         url: url_controller+'save_limit/?token='+_token_user,
//         type: "POST",
//         data: formData,
//         contentType: false,
//         processData : false,
//         dataType :"JSON",
//         success: function (data) {
//             hideLoading();
//             if(data.status){
//                 notif({
//                     msg: "<b>Sukses :</b> Data berhasil disimpan",
//                     type: "success"
//                 });

//                 for (let index = 0; index < data.list.length; index++) {
//                     var data_current = data.list[index];
                    
//                     $(document).find('.price_limit_' + data_current.class).text(': Rp.'+data_current.price);
//                 }

//                 $('#modal_form').modal('hide');
//             }
//         },
//         error:function(jqXHR, textStatus, errorThrown)
//         {
//             hideLoading();
//         }
// 	});//end ajax
// });

$(document).on('click', '.btn_update_data', function () { 
    showLoading();
    var id = $(this).data('id');
    $.ajax({
        url: url_controller+'get_form_update'+'?token='+_token_user,
        type: "POST",
        dataType: "JSON",
        data:{'id':id},
        success: function(data){
            hideLoading();
            if (data.status) {
                $('.html_respon_modal').html(data.html_respon);
                $('#modal_form').modal('show');
            } 
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }

    });//end ajax
});

$(document).on('click', '.btn_update_price', function (e) { 
    e.preventDefault();
    showLoading();
    // swal.showLoading();
	$('.form-group').removeClass('has-danger');
    $('.help-block').empty();
    var id = $(this).data('id');
    // save_method = $(this).data('method');
	  //defined form
    var formData = new FormData($('.form-update')[0]);
    formData.append('id_customer', id);    
    $.ajax({
        url: url_controller+'save/?token='+_token_user,
        type: "POST",
        data: formData,
        contentType: false,
        processData : false,
        dataType :"JSON",
        success: function (data) {
            hideLoading();
            if(data.status){
                notif({
                    msg: "<b>Sukses :</b> Data berhasil disimpan",
                    type: "success"
                });

                for (let index = 0; index < data.response.length; index++) {
                    var data_current = data.response[index];
                    $(document).find('.' + data_current.class).text(data_current.value);
                }

                $('#modal_form').modal('hide');
            }
        },
        error:function(jqXHR, textStatus, errorThrown)
        {
            hideLoading();
        }
	});//end ajax
});


$(document).on('keyup', '.rupiah', function () {
    var new_val = money_function($(this).val());
    $(this).val(new_val);
});


function money_function(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split = number_string.split(','),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

if (ribuan) {
    separator = sisa ? '.' : '';
    rupiah += separator + ribuan.join('.');
}

rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}
