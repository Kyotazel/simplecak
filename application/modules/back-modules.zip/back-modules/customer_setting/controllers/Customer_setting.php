<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Customer_setting extends BackendController
{
    var $module_name        = 'customer_setting';
    var $module_directory   = 'customer_setting';
    var $module_js          = ['customer_setting'];
    var $app_data           = [];


    public function __construct()
    {
        parent::__construct();
        Modules::run('security/common_security');
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js']    = $this->module_js;
        $this->app_data['module_name']  = $this->module_name;
        $this->app_data['module_directory']  = $this->module_directory;
    }

    public function index()
    {
        $this->app_data['member_type'] = Modules::run('database/find', 'tb_member_category', ['type' => 1])->result();
        $this->app_data['member_class'] = Modules::run('database/find', 'tb_member_category', ['type' => 2])->result();

        $array_query = [
            'from' => 'tb_main_category',
            'where' => [
                'tb_main_category.type' => 1
            ],
            'order_by' => 'tb_main_category.name'
        ];
        $this->app_data['data_devision'] = Modules::run('database/get', $array_query)->result();

        $this->app_data['page_title'] = "Pengaturan Customer";
        $this->app_data['view_file'] = 'main_view';
        echo Modules::run('template/main_layout', $this->app_data);
    }

    public function list_data()
    {
        Modules::run('security/is_ajax');
        $arr_customer_type = $this->input->post('customer_type');
        $arr_customer_class = $this->input->post('customer_class');
        $name = $this->input->post('name');
        $ktp = $this->input->post('ktp');

        $array_where['mst_customer.isDeleted'] = 'N';
        $array_where_in = [];
        $array_like = [];

        if (!empty($arr_customer_type)) {
            $array_where_in['member_type.id'] = $arr_customer_type;
        }
        if (!empty($arr_customer_class)) {
            $array_where_in['member_class.id'] = $arr_customer_class;
        }
        if ($name != '') {
            $array_like['mst_customer.name'] = $name . ',both';
        }
        if ($ktp != '') {
            $array_like['mst_customer.ktp'] = $ktp . ',both';
        }

        $array_search = [];
        $array_query = [
            'select' => '
                mst_customer.*,
                member_class.name AS member_class_name,
                member_type.name AS member_type_name,
                GROUP_CONCAT(mst_customer_has_limit.id_product_devision,"-",mst_customer_has_limit.credit_limit) AS list_limit,
                GROUP_CONCAT(mst_customer_has_price.id_product_devision,"-",mst_customer_has_price.price) AS list_price,
                GROUP_CONCAT(mst_customer_has_top.id_product_devision,"-",mst_customer_has_top.top_nota,"-",mst_customer_has_top.top_internal) AS list_top
            ',
            'from' => 'mst_customer',
            'join' => [
                'tb_member_category AS member_type, mst_customer.id_member_type = member_type.id, left',
                'tb_member_category AS member_class, mst_customer.id_member_class = member_class.id, left',
                'mst_customer_has_limit, mst_customer.id = mst_customer_has_limit.id_customer, left',
                'mst_customer_has_price, mst_customer.id = mst_customer_has_price.id_customer, left',
                'mst_customer_has_top, mst_customer.id = mst_customer_has_top.id_customer, left',
            ],
            'where' => $array_where,
            'order_by' => 'mst_customer.id, DESC',
            'group_by' => 'mst_customer.id'
        ];
        if (!empty($array_where_in)) {
            $array_query['where_in'] = $array_where_in;
        }
        if (!empty($array_like)) {
            $array_query['like'] = $array_like;
        }


        $get_data = Modules::run('database/get', $array_query)->result();
        $no = 0;
        $data = [];

        //pattern html limit
        $array_query = [
            'select' => 'tb_main_category.*',
            'from' => 'tb_main_category',
            'where' => [
                'tb_main_category.type' => 1
            ],
            'order_by' => 'tb_main_category.name'
        ];
        $data_devision = Modules::run('database/get', $array_query)->result();


        foreach ($get_data as $data_table) {
            $id_encrypt = $this->encrypt->encode($data_table->id);
            $btn_delete     = Modules::run('security/delete_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-danger btn-rounded btn_delete"><i class="las la-trash"></i> </a>');
            $btn_edit     = Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $id_encrypt . '" class="btn btn-sm btn-warning-gradient btn-rounded btn_edit"><i class="las la-pen"></i> </a>');
            $active = $data_table->isActive == 'Y' ? 'on' : '';

            //array limit
            $array_limit = [];
            $explode_limit = explode(',', $data_table->list_limit);
            foreach ($explode_limit as $item_limit) {
                if (empty($item_limit)) {
                    continue;
                }
                $limit_explode = explode('-', $item_limit);
                $array_limit[$limit_explode[0]] = $limit_explode[1];
            }

            //array Price
            $array_price = [];
            $explode_price = explode(',', $data_table->list_price);
            foreach ($explode_price as $item_price) {
                if (empty($item_price)) {
                    continue;
                }
                $item_price_explode = explode('-', $item_price);
                $array_price[$item_price_explode[0]] = $item_price_explode[1];
            }

            //array TOP
            $array_top = [];
            $explode_top = explode(',', $data_table->list_top);
            foreach ($explode_top as $item_top) {
                if (empty($item_top)) {
                    continue;
                }
                $item_top_explode = explode('-', $item_top);
                $array_top[$item_top_explode[0]] = [
                    'nota' => $item_top_explode[1],
                    'internal' => $item_top_explode[2]
                ];
            }
            $image = $data_table->image ? base_url('upload/customer/' . $data_table->image) : base_url('assets/themes/valex/img/faces/3.jpg');
            //html limit
            $html_limit = '';

            $is_special = $data_table->is_special_customer ? 'on' : '';

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = '
                    <span class="badge badge-light font-weight-bold tx-15">#' . $data_table->code . '</span>
                    <div class="row col-12 border-dashed" style="white-space:initial;">
                        <div class="col">
                            <div class=" mt-2 mb-2 text-primary"><b>' . strtoupper($data_table->name) . '</b></div>
                            <p class="tx-11" style="white-space:initial;">' . $data_table->address . '</p>
                        </div>
                        <div class="col-auto align-self-center ">
                            <div class="feature mt-0 mb-0">
                                <i class="fe fe-user project bg-primary-transparent text-primary "></i>
                            </div>
                        </div>
                    </div>
                    <div class="row col-12 border-dashed p-2" style="white-space:initial;">
                        <div for="" class="col-8  m-0">
                            <label class="tx-12 text-muted m-0">Special Customer :</label>
                            <small class="d-block">(* centang untuk diskon khusus)</small>
                        </div>
                        <div class="col-4">
                            <div data-id="' . $data_table->id . '" data-value="1" class="main-toggle price_550 main-toggle-dark change_status ' . $is_special . '"><span></span></div>
                        </div>
                    </div>
                    <div class="text-center mt-2">
                        <a href="javascript:void()0" data-id="' . $data_table->id . '" class="btn btn-rounded btn-warning-gradient btn_update_data"><i class="fa fa-edit"></i> Update Data</a>
                        <small class="d-block text-muted">(* klik untuk update data)</small>
                    </div>
                    ';

            foreach ($data_devision as $item_devision) {
                $id_devision = $item_devision->id;
                //get price 

                $price_limit_avail = isset($array_limit[$item_devision->id]) ? $array_limit[$item_devision->id] : 0;
                $html_limit = '
                    <div class="p-2 border-dashed d-flex" style="width:300px;">
                        <small style="width:80px;" class="text-muted mr-3">LIMIT ' . $item_devision->name . ' </small>
                        <span for="" class="font-weight-bold price_limit_' . $data_table->id . $item_devision->id . '">: Rp.' . number_format($price_limit_avail, 0, '.', '.') . '</span>
                    </div>
                ';
                $price_avail = isset($array_price[$item_devision->id]) ? 'HARGA ' . $array_price[$item_devision->id] : 'Belum Diisi';
                $html_price = '
                    <div class="p-2 border-dashed d-flex" style="width:300px;">
                        <small style="width:80px;" class="text-muted mr-3">HARGA ' . $item_devision->name . ' </small>
                        <span for="" class="font-weight-bold price_type_' . $data_table->id . $item_devision->id . '">: <span class="badge badge-light tx-4">' . $price_avail . '</span></span>
                    </div>
                ';

                $top_avail_nota = isset($array_top[$item_devision->id]['nota']) ? $array_top[$item_devision->id]['nota'] : '0';
                $top_avail_internal = isset($array_top[$item_devision->id]['internal']) ? $array_top[$item_devision->id]['internal'] : '0';
                $html_top = '
                    <div class="p-2 border-dashed d-flex" style="width:300px;">
                        <small style="width:80px;" class="text-muted mr-3">TOP NOTA</small>
                        <span for="" class="font-weight-bold">: <span class="badge badge-light tx-4  top_nota_' . $data_table->id . $item_devision->id . '">' . $top_avail_nota . ' HARI</span></span>
                    </div>
                    <div class="p-2 border-dashed d-flex" style="width:300px;">
                        <small style="width:80px;" class="text-muted mr-3">TOP INTERNAL</small>
                        <span for="" class="font-weight-bold ">: <span class="badge badge-light tx-4 top_internal_' . $data_table->id . $item_devision->id . '">' . $top_avail_internal . ' HARI</span></span>
                    </div>
                ';


                $row[] = $html_limit . $html_price . $html_top;
            }


            // $row[] = $html_price;
            // $row[] = $html_limit . '
            //     <div class="text-right mt-1">
            //         ' . Modules::run('security/edit_access', ' <a href="javascript:void(0)" data-id="' . $this->encrypt->encode($data_table->id) . '" class="btn btn-warning-gradient btn-rounded btn-sm btn_edit_limit"><i class="fa fa-edit"></i> Edit Data</a> ') . '
            //     </div>
            // ';
            // $row[] = '

            //     <div class="input-group" >
            //         <div class="input-group-prepend">
            //             <div class="input-group-text font-weight-bold" style="width:80px";>
            //                 Nota
            //             </div>
            //         </div>
            //         <input type="text" readonly value="' . $data_table->top_nota . ' HARI"  class="form-control bg-white border-dashed font-weight-bold top_nota_' . $data_table->id . '">
            //     </div>
            //     <div class="input-group">
            //         <div class="input-group-prepend">
            //             <div class="input-group-text font-weight-bold" style="width:80px";>
            //                 Internal
            //             </div>
            //         </div>
            //         <input type="text" readonly value="' . $data_table->top_internal . ' HARI"  class="form-control bg-white border-dashed font-weight-bold top_internal_' . $data_table->id . '">
            //     </div>
            //     <div class="text-right mt-2">
            //         ' . Modules::run('security/edit_access', ' <a href="javascript:void(0)" class="btn btn-warning-gradient btn-rounded btn-sm btn_edit_top" data-id="' . $data_table->id . '"><i class="fa fa-edit"></i> Edit Data</a> ') . '
            //     </div>

            // ';
            $data[] = $row;
        }

        $ouput = array(
            "data" => $data
        );

        $array_respon = ['search' => $this->encrypt->encode(json_encode($array_search)), 'list' => $ouput];

        echo json_encode($array_respon);
    }

    public function get_form_update()
    {
        Modules::run('security/is_ajax');
        $id_customer = $this->input->post('id');
        $data['id_customer'] = $id_customer;

        $array_query = [
            'select' => 'tb_main_category.*',
            'from' => 'tb_main_category',
            'where' => [
                'tb_main_category.type' => 1
            ],
            'order_by' => 'tb_main_category.name'
        ];
        $data_devision = Modules::run('database/get', $array_query)->result();

        $data['data_devision'] = $data_devision;
        $data['cat_price'] = [
            1 => 'Harga 1',
            2 => 'Harga 2',
            3 => 'Harga 3',
            4 => 'Harga 4'
        ];
        $html_respon = $this->load->view('form_update', $data, TRUE);
        echo json_encode(['status' => TRUE, 'html_respon' => $html_respon]);
    }

    public function save()
    {
        Modules::run('security/is_ajax');
        $arr_limit = $this->input->post('limit');
        $arr_price = $this->input->post('price');
        $arr_top_nota = $this->input->post('top_nota');
        $arr_top_internal = $this->input->post('top_internal');
        $id_customer = $this->input->post('id_customer');

        $data_respon = [];


        foreach ($arr_limit as $key => $value) {
            $id_devision = $key;
            //delete old limit & insert new limit
            $new_limit = str_replace('.', '', $arr_limit[$id_devision]);
            Modules::run('database/delete', 'mst_customer_has_limit', ['id_customer' => $id_customer, 'id_product_devision' => $id_devision]);
            Modules::run('database/insert', 'mst_customer_has_limit', ['id_customer' => $id_customer, 'id_product_devision' => $id_devision, 'credit_limit' => $new_limit]);
            $data_respon[] = ['class' => 'price_limit_' . $id_customer . $id_devision, 'value' => 'Rp.' . number_format($new_limit, 0, '.', '.')];

            //delete old price & insert new price
            $new_price = str_replace('.', '', $arr_price[$id_devision]);

            Modules::run('database/delete', 'mst_customer_has_price', ['id_customer' => $id_customer, 'id_product_devision' => $id_devision]);
            Modules::run('database/insert', 'mst_customer_has_price', ['id_customer' => $id_customer, 'id_product_devision' => $id_devision, 'price' => $new_price]);
            $data_respon[] = ['class' => 'price_type' . $id_customer . $id_devision, 'value' => 'HARGA ' . $new_price];

            //delete old top & insert new top
            $top_nota = $arr_top_nota[$id_devision];
            $top_internal = $arr_top_internal[$id_devision];
            Modules::run('database/delete', ' mst_customer_has_top', ['id_customer' => $id_customer, 'id_product_devision' => $id_devision]);
            Modules::run(
                'database/insert',
                'mst_customer_has_top',
                ['id_customer' => $id_customer, 'id_product_devision' => $id_devision, 'top_nota' => $top_nota, 'top_internal' => $top_internal]
            );
            $data_respon[] = ['class' => 'top_nota_' . $id_customer . $id_devision, 'value' => $top_nota . ' HARI'];
            $data_respon[] = ['class' => 'top_internal_' . $id_customer . $id_devision, 'value' => $top_internal . ' HARI'];
        }

        echo json_encode(['status' => TRUE, 'response' => $data_respon]);
    }

    public function update_status()
    {
        Modules::run('security/is_ajax');
        $id = $this->input->post('id');
        $active_status = $this->input->post('active_status');

        Modules::run('database/update', 'mst_customer', ['id' => $id], ['is_special_customer' => $active_status]);
        echo json_encode(['status' => TRUE]);
    }

    public function print()
    {
        $encrypt_data_search = $this->encrypt->decode($this->input->post('search'));
        $data_search = json_decode($encrypt_data_search);

        $array_where['mst_customer.isDeleted'] = 'N';
        $array_query = [
            'select' => '
                mst_customer.*
            ',
            'from' => 'mst_customer',
            'where' => $array_where,
            'order_by' => 'mst_customer.id, DESC'
        ];
        $get_data = Modules::run('database/get', $array_query)->result();

        if ($this->input->post('print_excel')) {
            $this->export_excel($get_data);
        }
        if ($this->input->post('print_pdf')) {
            $this->export_pdf($get_data);
        }
    }

    public function export_excel($data)
    {
        error_reporting(0);
        $this->load->library("PHPExcel");
        //membuat objek
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
        $sheet = $objPHPExcel->getActiveSheet();
        //set column 
        $sheet->getColumnDimension('A')->setWidth('5');
        $sheet->getColumnDimension('B')->setWidth('20');
        $sheet->getColumnDimension('C')->setWidth('30');
        $sheet->getColumnDimension('D')->setWidth('30');
        $sheet->getColumnDimension('E')->setWidth('25');
        $sheet->getColumnDimension('F')->setWidth('20');
        $sheet->getColumnDimension('G')->setWidth('20');
        $sheet->getColumnDimension('H')->setWidth('15');
        $sheet->getColumnDimension('I')->setWidth('40');
        $sheet->getColumnDimension('J')->setWidth('10');

        //bold style 
        $sheet->getStyle("A1:J2")->getFont()->setBold(true);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );

        // //marge and center
        $sheet->mergeCells('A1:J2');
        $sheet->getStyle('A1:J2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A1:J2')->getFont()->setSize(18);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'LAPORAN DATA CUSTOMER');
        $sheet->getStyle('A3:J3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //sheet table resume 
        $from = "A3"; // or any value
        $to = "J3"; // or any value
        $objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', 'NAMA LENGKAP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', 'EMAIL');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D3', 'NO.TELP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E3', 'NPWP');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F3', 'PIC');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G3', 'KREDIT LIMIT (RP)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H3', 'LIMIT JATUH TEMPO (HARI)');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I3', 'ALAMAT');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J3', 'STATUS');
        $sheet_number_resume = 3;
        $no = 0;

        $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)
            ->applyFromArray($styleThinBlackBorderOutline);
        $sheet->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '366092')
                ),
                'font'  => array(
                    'bold'  => true,
                    'color' => array('rgb' => 'FFFFFF'),
                    'size'  => 12
                )
            )
        );


        foreach ($data as $data_table) {
            $active = $data_table->isActive == 'Y' ? 'Aktif' : 'Non-Aktif';
            $sheet_number_resume++;
            $no++;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $sheet_number_resume, $no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $sheet_number_resume, $data_table->name);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $sheet_number_resume, $data_table->email);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $sheet_number_resume, $data_table->number_phone);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $sheet_number_resume, $data_table->npwp);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $sheet_number_resume, $data_table->pic);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $sheet_number_resume, $data_table->credit_limit);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $sheet_number_resume, $data_table->expired_limit);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $sheet_number_resume, $data_table->address);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $sheet_number_resume, $active);
            $objPHPExcel->getActiveSheet()->getStyle('A' . $sheet_number_resume . ':J' . $sheet_number_resume)
                ->applyFromArray($styleThinBlackBorderOutline);
        }
        //Set Title
        $objPHPExcel->getActiveSheet()->setTitle('LAPORAN DATA');
        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //Header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //Nama File
        header('Content-Disposition: attachment;filename="LAPORAN DATA CUSTOMER PER ' . date('d-m-Y') . '.xlsx"');
        //Download
        $objWriter->save("php://output");
    }

    public function export_pdf($data_customer)
    {
        error_reporting(0);
        ob_clean();
        $data['data_customer'] = $data_customer;
        //print_r($data['data_profile']);
        //exit;
        ob_start();
        $this->load->view('pdf_customer', $data);
        //print_r($html);
        //exit;
        $html = ob_get_contents();
        ob_end_clean();
        require_once('../assets/plugin/html2pdf/html2pdf.class.php');
        $pdf = new HTML2PDF('L', 'A4', 'en', true, 'UTF-8', array(5, 5, 5, 5));
        $pdf->WriteHTML($html);
        $pdf->Output('LAPORAN DATA CUSTOMER PER -' . date('d-m-Y') . '.pdf', 'D');
    }
}
