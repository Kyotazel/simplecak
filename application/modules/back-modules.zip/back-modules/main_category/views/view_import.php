<div class="card">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
    <div class="card-header text-right">
    </div>
    <div class="card-body">
        <div class="col-md-4 pull-right text-right">
            <a href="<?= base_url('main_category'); ?>" class="btn btn-default btn_link"><i class="fa fa-arrow-circle-left"></i> Kembali</a>
        </div>
        <div class="p-10 border col-md-8 border-radius-5">
            <form class="form-import">
                <div class="col-md-6 form-group">
                    <label for="">Upload CSV</label>
                    <input type="file" name="upload" class="form-control">
                    <span class="help-block upload"></span>
                </div>
                <div class="col-md-6">
                    <label for="">&nbsp;</label><br>
                    <button type="submit" class="btn btn-success btn_import"><i class="fa fa-send"></i> Import Data</button> ||
                    <a href="<?= base_url('assets/document/template_import_product.csv') ?>" class="btn btn-success"><i class="fa fa-download"></i> Download Template CSV</a>
                </div>
            </form>
        </div>
    </div>
    <!-- /.box-body -->
</div>
<div class="html_respon"></div>



<script type="text/javascript" src="<?php echo base_url('assets/assets_admin/'); ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>function_toast.js"></script>
<script type="text/javascript">
    var save_method;
    var table;
    var controller = 'main_category/';
    var base_url = '<?php echo base_url(); ?>' + controller;
    $(document).ready(function() {

    });


    //----------------- import -----------------------------------
    $(document).on('click', '.btn_import', function(e) {
        e.preventDefault();
        $(this).button('loading');
        var id_current = $(this).data('id');
        $('.form-group').removeClass('has-error');
        $('.help-block').empty();
        $('#modal_product').modal('hide');
        // showLoading();
        //defined form
        var formData = new FormData($('.form-import')[0]);
        $.ajax({
            url: base_url + "do_import_data",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            dataType: "JSON",
            success: function(data) {
                if (data.status) {

                    Swal.fire(
                        'Berhasil!',
                        'Data Berhasil Diimport!',
                        'success'
                    );
                    $('.form-import')[0].reset();

                } else {
                    for (var i = 0; i < data.inputerror.length; i++) {
                        $('.' + data.inputerror[i]).parent().addClass('has-error');
                        $('.' + data.inputerror[i]).text(data.error_string[i]);
                    }
                }
                $('.btn_import').button('reset');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('.btn_import').button('reset');
                alert_error('something wrong');
            }

        });
    });

    // $(document).on('click', '.btn_save_import', function(e) {
    //     e.preventDefault();

    //     Swal.fire({
    //         title: 'Data akan Disimpan?',
    //         text: "data yang disimpan hanya data yang telah terverifikasi",
    //         type: 'warning',
    //         showCancelButton: true,
    //         confirmButtonColor: '#3085d6',
    //         cancelButtonColor: '#d33',
    //         confirmButtonText: 'Ya, Lanjutkan',
    //         cancelButtonText: 'Batal'
    //     }).then((result) => {
    //         if (result.value) {
    //             $(this).button('loading');
    //             var id_current = $(this).data('id');
    //             $('.form-group').removeClass('has-error');
    //             $('.help-block').empty();
    //             $('#modal_product').modal('hide');
    //             // showLoading();
    //             //defined form
    //             var formData = new FormData($('.form-save-import')[0]);
    //             $.ajax({
    //                 url: base_url + "save_import_data",
    //                 type: "POST",
    //                 data: formData,
    //                 contentType: false,
    //                 processData: false,
    //                 dataType: "JSON",
    //                 success: function(data) {
    //                     if (data.status) {
    //                         $('.html_respon').html('');
    //                         Swal.fire(
    //                             'Berhasil!',
    //                             data.counter + ' Data Telah Disimpan',
    //                             'success'
    //                         );
    //                         $('.form-import')[0].reset();

    //                     } else {
    //                         for (var i = 0; i < data.inputerror.length; i++) {
    //                             $('.' + data.inputerror[i]).parent().addClass('has-error');
    //                             $('.' + data.inputerror[i]).text(data.error_string[i]);
    //                         }
    //                     }
    //                     $('.btn_save_import').button('reset');
    //                 },
    //                 error: function(jqXHR, textStatus, errorThrown) {
    //                     $('.btn_save_import').button('reset');
    //                     alert_error('something wrong');
    //                 }
    //             });
    //         }
    //     })
    // });
    //end document ready 
</script>