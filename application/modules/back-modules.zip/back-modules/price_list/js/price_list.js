var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var controller = baseUrl + '/price_list';
var save_method;
var table;
var id_use;
var status_scan = 0;

$(document).ready(function () {
    $("#form").submit(function(e){
        return false;
    });

    

    shortcut.add("f2", function () {
        // Do something
        $('[name="search"]').val('');
        $('[name="search"]').focus();
    });

    
    $(document).scannerDetection({
        timeBeforeScanTest: 200, // wait for the next character for upto 200ms
        startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
        endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
        avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
        onComplete: function (barcode, qty) {
            id_use = 1;
            $('.load_auto').show();
            $.ajax({
                url: controller + '/get_detail',
                type: "POST",
                dataType: "JSON",
                data: { 'barcode': barcode },
                success: function (data) {
                    if (data.status) {
                        $('.html_respon').html(data.html_respon);
                        $('[name="search"]').val('');
                        status_scan = 1;
                    } else {
                        // alert_error('barang tidak ditemukan');
                        Swal.fire(
                            'PEMBERITAHUAN',
                            'Barcode Tidak Terdaftar !',
                            'warning'
                        );
                    }
                    $('.load_auto').hide(); 
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $('.load_auto').hide();
                    alert_error('error process');
                }
            });
        } // main callback function	
    });
    

    set_input_field();

});



function set_input_field() {
    $('.input_field').html('<input type="text" class="form-control  form-control-lg p-20" autofocus style="font-size:18px;" name="search" id="product-name" placeholder="ketik barcode / nama produk untuk mencari barang... " />');
    $('#product-name').val('');
}

$(function () {
    $('#product-name').autocomplete({
        source: controller + "/search_data",
        search: function () {
            $(".load_auto").show();
        },
        response: function () {
            $(".load_auto").hide();
        },
        select: function(event, ui) {
            get_detail(ui.item.id);
        }
    });
});

$(document).on('keypress', '#product-name', function (event) {
    if (event.keyCode === 13) { 
        get_like();
    } 
});

function get_detail(id) {
    var name = $('#product-name').val();
    showLoading();
    $.ajax({
        url: controller + '/get_detail',
        type: "POST",
        data: {'id':id},
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.html_respon').html(data.html_respon);
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            $('.btn_detail').button('reset');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_detail').button('reset');
            hideLoading();
            Swal.fire(
                'ERROR',
                'Sorry, Something wrong !',
                'warning'
            );
        }
    });//end ajax
}


function get_like() {
    status_scan = 0;
    var name = $('#product-name').val();
    // showLoading();
    $('.load_auto').show();
    $.ajax({
        url: controller + '/get_name_like',
        type: "POST",
        data: {'name':name},
        dataType: "JSON",
        success: function (data) {
            hideLoading();
            if (data.status) {
                $('.load_auto').hide();
                $('.html_respon').html(data.html_respon);
                
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().addClass('has-error');
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);
                }
            }
            $('.btn_detail').button('reset');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $('.btn_detail').button('reset');
            hideLoading();
            Swal.fire(
                'ERROR',
                'Sorry, Something wrong !',
                'warning'
            );
        }
    });//end ajax
}


$(document).on('keyup', '.number_only', function () {
    var qty = $(this).val();
    var clean_word = qty.replace(/[^,\d]/g, '');
    $(this).val(clean_word);
})