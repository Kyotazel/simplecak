<div class="mb-10">
    <div class="" style="background: transparent !important;">
        <div class="col-md-12 text-center mb-10">
            <img style="width:50px;" src="<?= base_url('upload/profile/' . $data_profile->image); ?>" alt="">
            <h1 class="fa-2x"><?= $data_profile->name; ?></h1>
            <p><?= $data_profile->address; ?> | Telp: <?= $data_profile->number_phone; ?></p>
        </div>
        <span class="clearfix"></span>
        <!-- <form id="form"> -->
        <div style="margin-left:15%;margin-right:15%;">
            <div class="col-md-12 border-radius-5 p-20 shadow2 bg-white">
                <div class="col-md-3 text-right">
                    <label for="">*Ketik Nama Barang / Barcode</label>
                </div>
                <div class="col-md-6 form-group input_field">
                </div>
                <div class="col-md-1">
                    <div class="text-center d-none load_auto">
                        <label for=""><i class="fa fa-refresh fa-spin" style=""></i> <small>Loading..</small></label>
                    </div>

                </div>
                <div class="col-md-2 text-center">
                    <small class="block">Shortcut :</small>
                    <h4 for=""> REFRESH <b>(F2)</b></h4>
                    <!-- <input type="submit"> -->
                </div>
            </div>
        </div>
        <!-- </form> -->
        <span class="clearfix"></span>
        <hr>
        <div class="html_respon">
            <!-- <div class="bg-empty-data"></div> -->
            <h3 class="text-center text-empty-data">ISILAH FORM PENCARIAN TERLEBIH DAHULU</h3>
        </div>
    </div>
    <!-- /.box-body -->
</div>

<div class="modal" id="modal-form">
    <div class="modal-dialog" style="width:40%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="card-body pad">
                <div class="html_respon_modal"></div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
</div>