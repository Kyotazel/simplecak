<div class="col-md-12 bg-white">
    <div class="table-responsive">
        <table class="table table-striped table_data">
            <thead>
                <th>No</th>
                <th>Barcode</th>
                <th>Nama Produk</th>
                <th>Kategori Barang</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Promo</th>
                <th width="100px"></th>
            </thead>
            <tbody>
                <?php
                $counter = 0;
                foreach ($data_product as $item_product) {
                    $counter++;

                    //create event
                    $html_event = '-';
                    if ($item_product->id_detail_event) {

                        if ($item_product->type_event == 1) {
                            $html_event = 'DISKON (' . $item_product->discount_product . ' %)';
                        } else {
                            $html_event = 'Min. Beli = ' . $item_product->min_qty_event . ' ' . $item_product->unit_name . '<br>' . ' GRATIS <br>' . $item_product->product_bonus_name . ' ( ' . $item_product->qty_bonus . ' ' . $item_product->unit_name . ' )';
                        }
                    }

                    echo '
                            <tr>
                                <td>' . $counter . '</td>
                                <td>' . $item_product->barcode_product . '</td>
                                <td>' . $item_product->name . '</td>
                                <td>' . $item_product->main_category . '</td>
                                <td>' . $item_product->stock . ' ' . $item_product->unit_name . '</td>
                                <td>Rp.' . number_format($item_product->price, 0, '.', '.') . '</td>
                                <td>' . $html_event . '</td>
                                <td>
                                    <a href="javascript:void(0)" class="btn btn-info btn_detail" data-id="' . $this->encrypt->encode($item_product->id) . '"><i class="fa fa-tv"></i> Detail Info</a>
                                </td>
                            </tr>
                    ';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>