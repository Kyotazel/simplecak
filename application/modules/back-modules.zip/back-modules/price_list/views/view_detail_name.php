<?php
$counter_data = count($data_search);
if ($counter_data > 1) {
    $style      = 'style="margin-left:3%;margin-right:3%;"';
    $class_col  = 'col-md-6';
} else {
    $style      = 'style="margin-left:20%;margin-right:20%;"';
    $class_col  = 'col-md-12';
}

?>
<div <?= $style; ?>>
    <?php
    foreach ($data_search as $data_detail) {

        $html_event = '<h4>TIDAK ADA</h4>';
        if ($data_detail->id_detail_event) {
            if ($data_detail->type_event == 1) {
                $html_event = '<h4>DISKON :</h4><h1 class="text-bold">' . $data_detail->discount_product . ' %</h1>';
            } else {
                $html_event = '<h4 style="padding:0;margin:0;">Min. Beli = ' . $data_detail->min_qty_event . ' ' . $data_detail->unit_name . '</h4><label style="padding:0;margin:0;">' . ' GRATIS </label><h4 style="padding:0;margin:0;">' . $data_detail->product_bonus_name . ' ( ' . $data_detail->qty_bonus . ' ' . $data_detail->unit_name . ' )</h4>';
            }
        }
    ?>
        <div class="<?= $class_col; ?> p-10 border border-radius-5 bg-white">
            <div class="col-md-12 text-center">
                <div class="p-10 border-radius-5">
                    <h3 class="text-uppercase text-bold text-green"><?= $data_detail->name; ?></h3>
                    <h1 class="mb-10 text-bold fa-4x">Rp <?= number_format($data_detail->price, 0, '.', '.'); ?></h1>
                </div>
            </div>
            <div class="col-md-8">
                <table>
                    <tr>
                        <td width="100px;">Stok Barang</td>
                        <td width="10px;">:</td>
                        <td class="text-bold" style="font-size:20px;"><?= $data_detail->stock . ' ' . $data_detail->unit_name; ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-4">
                <label for="">PROMO :</label>
                <div class="p-20 bg-warning text-center border-radius-5">
                    <?= $html_event; ?>
                </div>
            </div>
            <span class="clearfix"></span>
            <hr>
            <div class="col-md-6">
                <label for=""><i class="fa fa-tv"></i> HARGA PER UNIT :</label>
                <table class="table table-bordered">
                    <thead>
                        <tr class="bg-warning">
                            <th width="200px">Unit Barang</th>
                            <th>Harga</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $data_conversion  = $this->db->where(['id_product' => $data_detail->id])->get('tb_product_has_conversion')->result();
                        if (!empty($data_conversion)) {
                            foreach ($data_conversion as $item_conversion) {
                                $price_current = $item_conversion->qty * $data_detail->price;

                                echo '
                        <tr>
                            <td>' . $item_conversion->name . ' ( ' . $item_conversion->qty . ' ' . $data_detail->unit_name . ' )' . '</td>
                            <td>Rp.' . number_format($price_current, 0, '.', '.') . '</td>
                        </tr>
                    ';
                            }
                        } else {
                            echo '
                            <tr>
                                <td colspan="2">
                                    <h4 class="text-center">TIDAK ADA DATA</h4>
                                </td>
                            </tr>
                    
                        ';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6">
                <label for=""><i class="fa fa-tv"></i> POTONGAN HARGA :</label>
                <table class="table table-bordered">
                    <thead>
                        <tr class="bg-warning">
                            <th width="200px">Min Beli</th>
                            <th>Harga Satuan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $data_margin_price = $this->db->where(['id_product' => $data_detail->id])->get('tb_margin_price')->result();
                        if (!empty($data_margin_price)) {
                            foreach ($data_margin_price as $item_price) {
                                echo '
                        <tr>
                            <td>' . $item_price->qty . ' ' . $data_detail->unit_name . '</td>
                            <td>Rp.' . number_format($item_price->price, 0, '.', '.') . '</td>
                        </tr>
                    ';
                            }
                        } else {
                            echo '
                    <tr>
                        <td colspan="2">
                            <h4 class="text-center">TIDAK ADA DATA</h4>
                        </td>
                    </tr>
            
                ';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php
    };
    ?>
</div>