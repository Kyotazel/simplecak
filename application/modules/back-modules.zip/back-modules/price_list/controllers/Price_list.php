<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Price_list extends CI_Controller
{
    var $location = 'data_price_list/';
    var $tb_name = '';
    var $module_name = 'price_list';
    var $js_page = 'price_list';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('createcode');
        $this->load->model('Main_query', 'model');
        // if ($this->session->userdata('us_id') == false) {
        //     redirect(base_url('login'));
        // }
        // $this->access_modul($this->module_name);
    }

    private function access_modul($module_name)
    {
        $access_module = json_decode($this->db->where(['field' => 'modul_access'])->get('tb_setting')->row()->value, TRUE);
        if (isset($access_module[$this->session->userdata('us_level')])) {

            $array_module_access = $access_module[$this->session->userdata('us_level')];
            if (!in_array($this->module_name, $array_module_access)) {
                show_404();
            }
        } else {
            redirect(base_url('login/logout'));
        }
    }


    public function index()
    {
        $data['data_profile'] = $this->db->get('tb_profile')->row();
        $data['js_page'] = $this->js_page;
        $data['tagline_page'] = "PENCARIAN PRODUK";
        $data['view_file'] = $this->location . 'view';
        $this->load->view('template/media_admin_top_public', $data);
    }

    public function validate_insert()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;


        if ($this->input->post('search') == '') {
            $data['error_string'][] = 'harus diisi';
            $data['inputerror'][] = 'search';
            $data['status'] = FALSE;
        } else {
            if (strlen($this->input->post('search')) < 3) {
                $data['error_string'][] = 'minimal 3 huruf';
                $data['inputerror'][] = 'search';
                $data['status'] = FALSE;
            }
        }

        if ($data['status'] == FALSE) {
            echo json_encode($data);
            exit();
        }
    }
    public function get_barcode_choosen()
    {
        $barcode = $this->input->post('barcode');
        $data_product = $this->db->query("select 
                                        a.id, 
                                        a.name,
                                        a.price,
                                        a.main_price,
                                        a.stock,
                                        b.name as unit_name
                                        from tb_product a 
                                        left join tb_unit b on a.id_unit = b.id
                                        left join tb_barcode_product d on a.id = d.id_product
                                        where d.barcode = '$barcode' ")->row();

        if (!empty($data_product)) {
            $array_result = array(
                'label' => $data_product->name,
                'id' => $data_product->id,
                'price' => $data_product->price,
                'main_price' => $data_product->main_price,
                'unit_name' => $data_product->unit_name,
                'stock' => $data_product->stock
            );
            $array_respon = [
                'status' => TRUE,
                'item' => $array_result
            ];
        } else {
            $array_respon = [
                'status' => FALSE
            ];
        }
        echo json_encode($array_respon);
    }

    public function search_data()
    {
        // $this->validate_insert();
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $search = $this->input->get('term');
            $get_data = $this->db->query("select 
                                                    a.id, 
                                                    a.name,
                                                    a.price,
                                                    a.main_price,
                                                    a.stock,
                                                    b.name as unit_name
													from tb_product a 
													left join tb_unit b on a.id_unit = b.id   
			 										where a.name like '%$term%' LIMIT 10 ")->result();
            // $get_data = $this->db->get()->result();
            if (!empty($get_data)) {
                foreach ($get_data as $data_product) {
                    $array_result[] = array(
                        'label' => $data_product->name,
                        'id' => $data_product->id
                    );
                }
                echo json_encode($array_result);
            }
        }
    }

    public function get_detail()
    {
        $id     = $this->input->post('id');
        $barcode = $this->input->post('barcode');
        $this->db->select('
        tb_product.id,
        tb_product.name,
        tb_product.price,
        tb_product.stock,
        tb_product.id_detail_event,
        tb_barcode_product.barcode AS barcode_product,
        tb_unit.name AS unit_name,
        tb_main_category.name AS main_category,
        tb_event.type AS type_event,
        tb_event_has_product.discount AS discount_product,
        tb_event_has_product.min_qty AS min_qty_event,
        tb_event_has_product.qty_bonus_product AS qty_bonus,
        product_bonus.name AS product_bonus_name
    ');
        $this->db->from('tb_product');
        $this->db->join('tb_barcode_product', 'tb_product.id = tb_barcode_product.id_product', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join(' tb_event_has_product', 'tb_product.id_detail_event =  tb_event_has_product.id', 'left');
        $this->db->join('tb_event', 'tb_event.id = tb_event_has_product.id_event', 'left');
        $this->db->join('tb_product AS product_bonus', 'tb_event_has_product.id_bonus_product = product_bonus.id', 'left');
        $this->db->join('tb_main_category', 'tb_product.id_main_category = tb_main_category.id', 'left');
        if (!empty($id)) {
            $this->db->where(['tb_product.id' => $id]);
        }
        if (!empty($barcode)) {
            $this->db->where(['tb_barcode_product.barcode' => $barcode]);
        }

        $get_data = $this->db->get()->row();
        $data['data_detail'] = $get_data;
        if (!empty($get_data)) {
            $get_margin_price = $this->db->where(['id_product' => $get_data->id])->get('tb_margin_price')->result();
            $data['data_margin_price']  = $get_margin_price;

            $get_conversion_product     = $this->db->where(['id_product' => $get_data->id])->get('tb_product_has_conversion')->result();
            $data['data_conversion']    = $get_conversion_product;
            $html_respon = $this->load->view($this->location . 'view_detail', $data, TRUE);
            $status = TRUE;
        } else {
            $status = FALSE;
            $html_respon = '<h1>DATA TIDAK DITEMUKAN';
        }
        $array_respon = [
            'status' => $status,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }

    public function get_name_like()
    {
        $name = $this->input->post('name');
        $this->db->select('
        tb_product.id,
        tb_product.name,
        tb_product.price,
        tb_product.stock,
        tb_product.id_detail_event,
        tb_barcode_product.barcode AS barcode_product,
        tb_unit.name AS unit_name,
        tb_main_category.name AS main_category,
        tb_event.type AS type_event,
        tb_event_has_product.discount AS discount_product,
        tb_event_has_product.min_qty AS min_qty_event,
        tb_event_has_product.qty_bonus_product AS qty_bonus,
        product_bonus.name AS product_bonus_name
        
    ');
        $this->db->from('tb_product');
        $this->db->join('tb_barcode_product', 'tb_product.id = tb_barcode_product.id_product', 'left');
        $this->db->join('tb_unit', 'tb_product.id_unit = tb_unit.id', 'left');
        $this->db->join(' tb_event_has_product', 'tb_product.id_detail_event =  tb_event_has_product.id', 'left');
        $this->db->join('tb_event', 'tb_event.id = tb_event_has_product.id_event', 'left');
        $this->db->join('tb_product AS product_bonus', 'tb_event_has_product.id_bonus_product = product_bonus.id', 'left');
        $this->db->join('tb_main_category', 'tb_product.id_main_category = tb_main_category.id', 'left');
        $this->db->like('tb_product.name', $name, 'after');
        $this->db->limit(2);
        $get_data = $this->db->get()->result();

        if (!empty($get_data)) {
            $data['data_search'] = $get_data;
            $html_respon = $this->load->view($this->location . 'view_detail_name', $data, TRUE);
        } else {
            $html_respon = '<h3 class="text-center text-empty-data">DATA TIDAK DITEMUKAN</h3>';
        }

        $array_respon = [
            'status' => TRUE,
            'html_respon' => $html_respon
        ];
        echo json_encode($array_respon);
    }
}
