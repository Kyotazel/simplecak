<div class=" row rounded-20 bg-primary align-items-center" style="background: url(http://blk.viscode.id/assets/themes/valex/img/svgicons/cargo.svg) no-repeat;height:100px;">
    <div class="col-3 border-right d-flex align-items-center">
        <h3 class="ml-3 text-white mb-0">Selamat Datang</h3>
    </div>
    <div class="col-6">
        <p class="text-white tx-16 p-0 m-0">Ikuti Pelatihan terbaru untuk menambah kemampuanmu.</p>
    </div>
    <div class="col-3 text-right">
        <a href="http://blk.viscode.id/member-area/order?token=b8a773b245d2bd51c054f536e50d0a15151b88239cff4d4bc06be74ab9b8b4a0bd9c7d34a980604742678859299a5953feaf913c4e435d71be6f3baead20a671ds9NhvNToFLEyvAVU3W1KT10MltpHwT2CNADvKFNSbw%3D" class="btn btn-rounded btn-success font-weight-bold">Lihat Sekarang <i class="fa fa-paper-plane"></i></i></a>
    </div>
</div>