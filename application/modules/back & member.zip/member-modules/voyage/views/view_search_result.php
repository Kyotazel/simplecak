<table id="table_data" class="table table-bordered dt-responsive nowrap table-hover" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
        <th style="width: 5%;">No</th>
        <th>NO.VOYAGE</th>
        <th>KAPAL</th>
        <th>RUTE KEBERANGKATAN</th>
        <th>ESTIMASI PERJALANAN</th>
        <th>TANGGAL TIKET</th>
        <th>STATUS VOYAGE</th>
        <th>TRACKING VOYAGE</th>
        <th>JUMLAH BS TERDAFAR</th>
        <th style="width: 10%;"></th>
    </thead>
    <tbody></tbody>
</table>