<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="mb-3 row">
                <h3 class="col-md-8">Konfirmasi Booking Slot</h3>
                <div class="col-md-4 text-right">
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered t-shadow" id="table_confirm_booking">
                    <thead class="bg-primary-gradient text-white">
                        <tr>
                            <th class="text-white" style="background-color:transparent;">No</th>
                            <th class="text-white" style="background-color:transparent;">Voyage</th>
                            <th class="text-white" style="background-color:transparent;">Booking Slot</th>
                            <th class="text-white" style="background-color:transparent;">Kategori Kontainer</th>
                        </tr>
                    </thead>
                    <tbody class="tbody_item_booking">
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>