<div class="table-responsive">
    <table class="table table-invoice">
        <thead>
            <tr>
                <th>No</th>
                <th>Invoice</th>
            </tr>
        </thead>
    </table>
</div>