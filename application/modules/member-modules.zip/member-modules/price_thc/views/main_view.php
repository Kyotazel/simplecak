<div class="row">
    <div class="col-lg-12 col-xl-12 col-md-12 container_list">
        <div class="card">
            <div class="card-body">
                <div class="mb-3 row">
                    <h3 class="col-md-8">DAFTAR FORMULA HARGA KONTAINER <span class="font-weight-bold text-primary">(THC)</span></h3>
                    <div class="col-md-4 text-right">
                    </div>
                </div>
                <div class="table-responsive border-top userlist-table mt-2">
                    <table id="table_data" class="table table-bordered dt-responsive nowrap t-shadow" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <th style="width: 5%;">No</th>
                            <th style="width: 30%;">NAMA LENGKAP</th>
                            <th>Keterangan</th>
                            <th>PIC</th>
                            <th style="width: 10%;"></th>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>