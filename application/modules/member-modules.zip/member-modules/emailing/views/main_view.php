<div class="container">
    <div class="card">
        <div class="card-body">
            <div class="row  mb-2">
                <div class="col-8">
                    <h3 class="">Template Email</h3>
                </div>
                <div class="col-4 mb-2 text-right">
                </div>
            </div>
            <div class="html_respon row"></div>

        </div>
    </div>
</div>