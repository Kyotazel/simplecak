<div class="sticky">
    <div class="horizontal-main hor-menu clearfix side-header">
        <div class="horizontal-mainwrapper container clearfix" style="display: none;">
            <!--Nav-->
            <nav class="horizontalMenu clearfix">
                <ul class="horizontalMenu-list">
                    <?= $html_main_menu; ?>
                </ul>
            </nav>
            <!--Nav-->
        </div>
    </div>
</div>