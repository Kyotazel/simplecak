<div class="main-header-center ml-3 d-sm-none d-md-none d-lg-block">
    <input class="form-control search_menu" placeholder="ketik untuk mencari menu..." type="input">
    <button class="btn load_search_menu" style="display: none;top:-3px;">
        <div class="spinner-border text-dark" role="status" style="width: 15px;height:15px">
            <span class="sr-only">Loading...</span>
        </div>
    </button>

</div>