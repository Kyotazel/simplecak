<ul class="nav">
    <li class="">
        <div class="dropdown  nav-itemd-none d-md-flex">
            <a href="#" class="d-flex  nav-item nav-link pr-0 country-flag1" data-toggle="dropdown" aria-expanded="false">
                <span class="avatar country-Flag mr-0 align-self-center bg-transparent"><img src="<?= base_url('assets/themes/valex/'); ?>img/flags/us_flag.jpg" alt="img"></span>
                <div class="my-auto">
                    <strong class="mr-2 ml-2 my-auto">English</strong>
                </div>
            </a>
            <div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow" x-placement="bottom-end">
                <a href="#" class="dropdown-item d-flex ">
                    <span class="avatar  mr-3 align-self-center bg-transparent"><img src="<?= base_url('assets/themes/valex/'); ?>img/flags/french_flag.jpg" alt="img"></span>
                    <div class="d-flex">
                        <span class="mt-2">French</span>
                    </div>
                </a>
                <a href="#" class="dropdown-item d-flex">
                    <span class="avatar  mr-3 align-self-center bg-transparent"><img src="<?= base_url('assets/themes/valex/'); ?>img/flags/germany_flag.jpg" alt="img"></span>
                    <div class="d-flex">
                        <span class="mt-2">Germany</span>
                    </div>
                </a>
                <a href="#" class="dropdown-item d-flex">
                    <span class="avatar mr-3 align-self-center bg-transparent"><img src="<?= base_url('assets/themes/valex/'); ?>img/flags/italy_flag.jpg" alt="img"></span>
                    <div class="d-flex">
                        <span class="mt-2">Italy</span>
                    </div>
                </a>
                <a href="#" class="dropdown-item d-flex">
                    <span class="avatar mr-3 align-self-center bg-transparent"><img src="<?= base_url('assets/themes/valex/'); ?>img/flags/russia_flag.jpg" alt="img"></span>
                    <div class="d-flex">
                        <span class="mt-2">Russia</span>
                    </div>
                </a>
                <a href="#" class="dropdown-item d-flex">
                    <span class="avatar  mr-3 align-self-center bg-transparent"><img src="<?= base_url('assets/themes/valex/'); ?>img/flags/spain_flag.jpg" alt="img"></span>
                    <div class="d-flex">
                        <span class="mt-2">spain</span>
                    </div>
                </a>
            </div>
        </div>
    </li>
</ul>