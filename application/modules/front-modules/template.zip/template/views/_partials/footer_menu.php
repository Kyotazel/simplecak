<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="footer-py-60">
                <div class="row">
                    <div class="col-lg-4 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                        <a href="<?= base_url(); ?>" class="logo-footer">
                            <img src="<?= base_url('assets/themes/landrik/'); ?>images/logo-light.png" alt="">
                        </a>
                        <p class="mt-4"><?= $company_tagline; ?></p>
                        <ul class="list-unstyled social-icon foot-social-icon mb-0 mt-4">
                            <li class="list-inline-item"><a href="<?= $company_facebook; ?>" target="_blank" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="<?= $company_instagram; ?>" target="_blank" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                        </ul>
                        <!--end icon-->
                    </div>
                    <!--end col-->

                    <div class="col-lg-2 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <h5 class="footer-head">Halaman Lainnya</h5>
                        <ul class="list-unstyled footer-list mt-4">
                            <?php
                            $get_all = Modules::run('database/get_all', 'tb_cms_page')->result();
                            foreach ($get_all as $item_data) {
                                echo '
                                    <li><a href="' . base_url('p?data=' . $item_data->slug) . '" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> ' . $item_data->title . '</a></li>
                                ';
                            }
                            ?>

                        </ul>
                    </div>
                    <!--end col-->

                    <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <h5 class="footer-head">Perusahaan</h5>
                        <ul class="list-unstyled footer-list mt-4">
                            <li><a href="<?= base_url('company'); ?>" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Tentang Kami</a></li>
                            <li><a href="<?= base_url('company/contact'); ?>" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Cari Jadwal kapal</a></li>
                        </ul>
                    </div>
                    <!--end col-->

                    <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <h5 class="footer-head">Alamat Perusahaan</h5>
                        <p class="mt-4"><?= $company_address; ?></p>
                        <label for="" class="text-bold">
                            <i data-feather="mail" class="fea icon-sm icons"></i> Email : <?= $company_email; ?>
                        </label>
                        <label for="" class="text-bold">
                            <i data-feather="phone" class="fea icon-sm icons"></i> Telp : <?= $company_number_phone; ?>
                        </label>
                    </div>
                    <!--end col-->
                </div>
                <!--end row-->
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->
</div>
<!--end container-->

<div class="footer-py-30 footer-bar">
    <div class="container text-center">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="text-sm-start">
                    <p class="mb-0">
                        © <?= date('Y') . '&nbsp;' . $company_name; ?> . All rights reserved</p>
                </div>
            </div>
            <!--end col-->

            <div class="col-sm-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                <ul class="list-unstyled text-sm-end mb-0">
                </ul>
            </div>
            <!--end col-->
        </div>
        <!--end row-->
    </div>
    <!--end container-->
</div>