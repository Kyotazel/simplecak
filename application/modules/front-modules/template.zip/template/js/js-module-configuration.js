var getUrl = window.location;
var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
var prefix_folder_admin = '';

$(document).ready(function(){
	// $('.overlay_loading').show();

    // $('.main-parent-menu').addClass('is-expanded');
    // $('.main-parent-menu > .side-menu__item').addClass('active');
    // $('.main-parent-menu').find('.slide-item').addClass('active');
});